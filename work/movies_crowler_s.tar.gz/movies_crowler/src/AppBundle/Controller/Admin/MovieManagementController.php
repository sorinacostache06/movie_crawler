<?php

namespace AppBundle\Controller\Admin;

use AppBundle\Entity\Cinemagia;
use AppBundle\Entity\Movie;
use AppBundle\Entity\Rottentomatoes;
use AppBundle\Form\MovieEditType;
use AppBundle\Form\MovieManagementType;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;

class MovieManagementController extends Controller
{

    public function listAction(Request $request)
    {
        $manageForm = $this->createForm(MovieManagementType::class);
        $em = $this->getDoctrine()->getManager();
        $groupRepo = $em->getRepository('AppBundle:Cinemagia');
        $movieManageList = $groupRepo->findAll();

        if (empty($movieManageList)) {
            $this->addFlash('notice', $this->get('translator')->trans('group_management.list_empty'));
        }
        return $this->render(
            ':Admin:movie_manage_list.html.twig',
            [
                'movieManageList' => $movieManageList,
                'manageForm' => $manageForm->createView(),
            ]
        );

    }
    public function editAction(Request $request, Cinemagia $cinemagia)
    {
        $form = $this->createForm(MovieEditType::class, $cinemagia);
        $form->handleRequest($request);
        $em = $this->getDoctrine()->getManager();
        $groupRepo = $em->getRepository('AppBundle:Rottentomatoes');

        $movieManageList = $groupRepo->findAll();
        if (empty($movieManageList)) {
            $this->addFlash('notice', $this->get('translator')->trans('group_management.list_empty'));
        }

        return $this->render(':Admin:edit_movie.html.twig', [
            'form' => $form->createView(),
            'movieManageList' => $movieManageList,
        ]);
    }
}