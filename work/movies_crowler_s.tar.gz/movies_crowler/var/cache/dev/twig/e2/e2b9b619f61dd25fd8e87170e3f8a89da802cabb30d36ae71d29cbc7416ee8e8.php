<?php

/* @Framework/Form/container_attributes.html.php */
class __TwigTemplate_e0874cebc4b81ce5ef6b9e851575327ae38be7a644e1abd4799ed578e129a165 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ae5910a8fd0f598de57c19690eb14c971c70a9e684eaab4d72fe174b6d1db561 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ae5910a8fd0f598de57c19690eb14c971c70a9e684eaab4d72fe174b6d1db561->enter($__internal_ae5910a8fd0f598de57c19690eb14c971c70a9e684eaab4d72fe174b6d1db561_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/container_attributes.html.php"));

        $__internal_f2b94e3a6dfec04d4a0318f0b06c2c6ea81f79e5e927ba817e9c475fc7c119d2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f2b94e3a6dfec04d4a0318f0b06c2c6ea81f79e5e927ba817e9c475fc7c119d2->enter($__internal_f2b94e3a6dfec04d4a0318f0b06c2c6ea81f79e5e927ba817e9c475fc7c119d2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/container_attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>
";
        
        $__internal_ae5910a8fd0f598de57c19690eb14c971c70a9e684eaab4d72fe174b6d1db561->leave($__internal_ae5910a8fd0f598de57c19690eb14c971c70a9e684eaab4d72fe174b6d1db561_prof);

        
        $__internal_f2b94e3a6dfec04d4a0318f0b06c2c6ea81f79e5e927ba817e9c475fc7c119d2->leave($__internal_f2b94e3a6dfec04d4a0318f0b06c2c6ea81f79e5e927ba817e9c475fc7c119d2_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/container_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>
", "@Framework/Form/container_attributes.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/container_attributes.html.php");
    }
}
