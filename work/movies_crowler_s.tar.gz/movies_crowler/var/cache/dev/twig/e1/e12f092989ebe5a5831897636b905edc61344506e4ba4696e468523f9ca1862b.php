<?php

/* base.html.twig */
class __TwigTemplate_717249bbfe4c48f707efcb3abcff871720306f8bd73086303dc7a5873951212a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'flashBag' => array($this, 'block_flashBag'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_804f216270be2f4c065acf62094aa5424464dcc94da1f585e07706600b863421 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_804f216270be2f4c065acf62094aa5424464dcc94da1f585e07706600b863421->enter($__internal_804f216270be2f4c065acf62094aa5424464dcc94da1f585e07706600b863421_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_cfbc4b8b778c880fac2eee658328fe80f2aeb684dd5ab8082bb2d629f8e0499d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cfbc4b8b778c880fac2eee658328fe80f2aeb684dd5ab8082bb2d629f8e0499d->enter($__internal_cfbc4b8b778c880fac2eee658328fe80f2aeb684dd5ab8082bb2d629f8e0499d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
<head>
    <meta charset=\"UTF-8\" />
    <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "    <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
</head>
<body>
";
        // line 10
        $this->displayBlock('flashBag', $context, $blocks);
        // line 33
        $this->displayBlock('body', $context, $blocks);
        // line 34
        $this->displayBlock('javascripts', $context, $blocks);
        // line 35
        echo "</body>
</html>
";
        
        $__internal_804f216270be2f4c065acf62094aa5424464dcc94da1f585e07706600b863421->leave($__internal_804f216270be2f4c065acf62094aa5424464dcc94da1f585e07706600b863421_prof);

        
        $__internal_cfbc4b8b778c880fac2eee658328fe80f2aeb684dd5ab8082bb2d629f8e0499d->leave($__internal_cfbc4b8b778c880fac2eee658328fe80f2aeb684dd5ab8082bb2d629f8e0499d_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_a841d1850f84c57ac630393c4cab1eed171b9d180ac66a58e7f9179b6210ed50 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a841d1850f84c57ac630393c4cab1eed171b9d180ac66a58e7f9179b6210ed50->enter($__internal_a841d1850f84c57ac630393c4cab1eed171b9d180ac66a58e7f9179b6210ed50_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_fac8575e1e104b7f500e3fb03f0e577c64fd60d9fb141347086813d54307b039 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fac8575e1e104b7f500e3fb03f0e577c64fd60d9fb141347086813d54307b039->enter($__internal_fac8575e1e104b7f500e3fb03f0e577c64fd60d9fb141347086813d54307b039_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Movies Crawler";
        
        $__internal_fac8575e1e104b7f500e3fb03f0e577c64fd60d9fb141347086813d54307b039->leave($__internal_fac8575e1e104b7f500e3fb03f0e577c64fd60d9fb141347086813d54307b039_prof);

        
        $__internal_a841d1850f84c57ac630393c4cab1eed171b9d180ac66a58e7f9179b6210ed50->leave($__internal_a841d1850f84c57ac630393c4cab1eed171b9d180ac66a58e7f9179b6210ed50_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_4e5a20c7fb3047c32f58787d0960cec2acc24b4c653c1963471409b3aa464615 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4e5a20c7fb3047c32f58787d0960cec2acc24b4c653c1963471409b3aa464615->enter($__internal_4e5a20c7fb3047c32f58787d0960cec2acc24b4c653c1963471409b3aa464615_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_54d34c359525295e419add77bb4e85a3781fe34251a6e0f6417a39667da70b66 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_54d34c359525295e419add77bb4e85a3781fe34251a6e0f6417a39667da70b66->enter($__internal_54d34c359525295e419add77bb4e85a3781fe34251a6e0f6417a39667da70b66_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_54d34c359525295e419add77bb4e85a3781fe34251a6e0f6417a39667da70b66->leave($__internal_54d34c359525295e419add77bb4e85a3781fe34251a6e0f6417a39667da70b66_prof);

        
        $__internal_4e5a20c7fb3047c32f58787d0960cec2acc24b4c653c1963471409b3aa464615->leave($__internal_4e5a20c7fb3047c32f58787d0960cec2acc24b4c653c1963471409b3aa464615_prof);

    }

    // line 10
    public function block_flashBag($context, array $blocks = array())
    {
        $__internal_ce59c7918119d69ba5becf35fe854242571fc8c16a1d42fe116dbc138df94de1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ce59c7918119d69ba5becf35fe854242571fc8c16a1d42fe116dbc138df94de1->enter($__internal_ce59c7918119d69ba5becf35fe854242571fc8c16a1d42fe116dbc138df94de1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "flashBag"));

        $__internal_835289a4c0bda8b2a10a292318d5fba9c14898d1aaaf3fc5bc53cb37265b7435 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_835289a4c0bda8b2a10a292318d5fba9c14898d1aaaf3fc5bc53cb37265b7435->enter($__internal_835289a4c0bda8b2a10a292318d5fba9c14898d1aaaf3fc5bc53cb37265b7435_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "flashBag"));

        // line 11
        echo "    ";
        if (twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 11, $this->getSourceContext()); })()), "session", array()), "flashBag", array()), "has", array(0 => "error"), "method")) {
            // line 12
            echo "        <div align=\"center\" style=\"background-color:red\">
            ";
            // line 13
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 13, $this->getSourceContext()); })()), "session", array()), "flashBag", array()), "get", array(0 => "error"), "method"));
            foreach ($context['_seq'] as $context["_key"] => $context["msg"]) {
                // line 14
                echo "                ";
                echo twig_escape_filter($this->env, $context["msg"], "html", null, true);
                echo "
            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['msg'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 16
            echo "        </div>
    ";
        }
        // line 18
        echo "    ";
        if (twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 18, $this->getSourceContext()); })()), "session", array()), "flashBag", array()), "has", array(0 => "success"), "method")) {
            // line 19
            echo "        <div align=\"center\" style=\"background-color:green\">
            ";
            // line 20
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 20, $this->getSourceContext()); })()), "session", array()), "flashBag", array()), "get", array(0 => "success"), "method"));
            foreach ($context['_seq'] as $context["_key"] => $context["msg"]) {
                // line 21
                echo "                ";
                echo twig_escape_filter($this->env, $context["msg"], "html", null, true);
                echo "
            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['msg'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 23
            echo "        </div>
    ";
        }
        // line 25
        echo "    ";
        if (twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 25, $this->getSourceContext()); })()), "session", array()), "flashBag", array()), "has", array(0 => "notice"), "method")) {
            // line 26
            echo "        <div align=\"center\" style=\"background-color:lightblue\">
            ";
            // line 27
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 27, $this->getSourceContext()); })()), "session", array()), "flashBag", array()), "get", array(0 => "notice"), "method"));
            foreach ($context['_seq'] as $context["_key"] => $context["msg"]) {
                // line 28
                echo "                ";
                echo twig_escape_filter($this->env, $context["msg"], "html", null, true);
                echo "
            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['msg'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 30
            echo "        </div>
    ";
        }
        
        $__internal_835289a4c0bda8b2a10a292318d5fba9c14898d1aaaf3fc5bc53cb37265b7435->leave($__internal_835289a4c0bda8b2a10a292318d5fba9c14898d1aaaf3fc5bc53cb37265b7435_prof);

        
        $__internal_ce59c7918119d69ba5becf35fe854242571fc8c16a1d42fe116dbc138df94de1->leave($__internal_ce59c7918119d69ba5becf35fe854242571fc8c16a1d42fe116dbc138df94de1_prof);

    }

    // line 33
    public function block_body($context, array $blocks = array())
    {
        $__internal_0fd84bb2fefbb2dac72c937f6b6531c06efb29ddf1225f6ec7256dd2bdfa7558 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0fd84bb2fefbb2dac72c937f6b6531c06efb29ddf1225f6ec7256dd2bdfa7558->enter($__internal_0fd84bb2fefbb2dac72c937f6b6531c06efb29ddf1225f6ec7256dd2bdfa7558_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_0a0a34b86711fd8a6fc127ec8b22dbc0e9e1abe9b4d965ddb0e959663523ae93 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0a0a34b86711fd8a6fc127ec8b22dbc0e9e1abe9b4d965ddb0e959663523ae93->enter($__internal_0a0a34b86711fd8a6fc127ec8b22dbc0e9e1abe9b4d965ddb0e959663523ae93_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_0a0a34b86711fd8a6fc127ec8b22dbc0e9e1abe9b4d965ddb0e959663523ae93->leave($__internal_0a0a34b86711fd8a6fc127ec8b22dbc0e9e1abe9b4d965ddb0e959663523ae93_prof);

        
        $__internal_0fd84bb2fefbb2dac72c937f6b6531c06efb29ddf1225f6ec7256dd2bdfa7558->leave($__internal_0fd84bb2fefbb2dac72c937f6b6531c06efb29ddf1225f6ec7256dd2bdfa7558_prof);

    }

    // line 34
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_3cb8c1c82b24680b59d2222cbdf2b385fabec68742f5503739fef155a4f64152 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3cb8c1c82b24680b59d2222cbdf2b385fabec68742f5503739fef155a4f64152->enter($__internal_3cb8c1c82b24680b59d2222cbdf2b385fabec68742f5503739fef155a4f64152_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_bba35347eab9b3034d067a8d06480d14c3afc79c16cda748d5d6ab6785c58eab = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bba35347eab9b3034d067a8d06480d14c3afc79c16cda748d5d6ab6785c58eab->enter($__internal_bba35347eab9b3034d067a8d06480d14c3afc79c16cda748d5d6ab6785c58eab_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_bba35347eab9b3034d067a8d06480d14c3afc79c16cda748d5d6ab6785c58eab->leave($__internal_bba35347eab9b3034d067a8d06480d14c3afc79c16cda748d5d6ab6785c58eab_prof);

        
        $__internal_3cb8c1c82b24680b59d2222cbdf2b385fabec68742f5503739fef155a4f64152->leave($__internal_3cb8c1c82b24680b59d2222cbdf2b385fabec68742f5503739fef155a4f64152_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  205 => 34,  188 => 33,  176 => 30,  167 => 28,  163 => 27,  160 => 26,  157 => 25,  153 => 23,  144 => 21,  140 => 20,  137 => 19,  134 => 18,  130 => 16,  121 => 14,  117 => 13,  114 => 12,  111 => 11,  102 => 10,  85 => 6,  67 => 5,  55 => 35,  53 => 34,  51 => 33,  49 => 10,  42 => 7,  40 => 6,  36 => 5,  30 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
<head>
    <meta charset=\"UTF-8\" />
    <title>{% block title %}Movies Crawler{% endblock %}</title>
    {% block stylesheets %}{% endblock %}
    <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
</head>
<body>
{% block flashBag %}
    {% if app.session.flashBag.has('error') %}
        <div align=\"center\" style=\"background-color:red\">
            {% for msg in app.session.flashBag.get('error') %}
                {{ msg }}
            {% endfor %}
        </div>
    {% endif %}
    {% if app.session.flashBag.has('success') %}
        <div align=\"center\" style=\"background-color:green\">
            {% for msg in app.session.flashBag.get('success') %}
                {{ msg }}
            {% endfor %}
        </div>
    {% endif %}
    {% if app.session.flashBag.has('notice') %}
        <div align=\"center\" style=\"background-color:lightblue\">
            {% for msg in app.session.flashBag.get('notice') %}
                {{ msg }}
            {% endfor %}
        </div>
    {% endif %}
{% endblock %}
{% block body %}{% endblock %}
{% block javascripts %}{% endblock %}
</body>
</html>
", "base.html.twig", "/home/sorina/Documents/work/movies_crowler/app/Resources/views/base.html.twig");
    }
}
