<?php

/* :Admin:user_list.html.twig */
class __TwigTemplate_dce2b18a422204a5b05234d4e2943dffbe344976f5ff38f80151c9b31a6485be extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base-layout.html.twig", ":Admin:user_list.html.twig", 1);
        $this->blocks = array(
            'page_title' => array($this, 'block_page_title'),
            'page_subtitle' => array($this, 'block_page_subtitle'),
            'page_content' => array($this, 'block_page_content'),
            'flashBag' => array($this, 'block_flashBag'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base-layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_447cfba06936eda1552b12535dea7e1b151bf30f93d616155f68b2d97e5117eb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_447cfba06936eda1552b12535dea7e1b151bf30f93d616155f68b2d97e5117eb->enter($__internal_447cfba06936eda1552b12535dea7e1b151bf30f93d616155f68b2d97e5117eb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Admin:user_list.html.twig"));

        $__internal_8cec13c4bfa3d4c4f42955c78f6ea44c317cd40ccbb76b94c3e4dec89b5758fc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8cec13c4bfa3d4c4f42955c78f6ea44c317cd40ccbb76b94c3e4dec89b5758fc->enter($__internal_8cec13c4bfa3d4c4f42955c78f6ea44c317cd40ccbb76b94c3e4dec89b5758fc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Admin:user_list.html.twig"));

        // line 2
        ob_start();
        // line 3
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["manageForm"]) || array_key_exists("manageForm", $context) ? $context["manageForm"] : (function () { throw new Twig_Error_Runtime('Variable "manageForm" does not exist.', 3, $this->getSourceContext()); })()), "_token", array()), 'row', array("id" => "#id#"));
        echo "
";
        $context["form_token"] = ('' === $tmp = ob_get_clean()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        // line 6
        $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->setTheme((isset($context["filterForm"]) || array_key_exists("filterForm", $context) ? $context["filterForm"] : (function () { throw new Twig_Error_Runtime('Variable "filterForm" does not exist.', 6, $this->getSourceContext()); })()), array(0 => ":Form:fields.html.twig"));
        // line 1
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_447cfba06936eda1552b12535dea7e1b151bf30f93d616155f68b2d97e5117eb->leave($__internal_447cfba06936eda1552b12535dea7e1b151bf30f93d616155f68b2d97e5117eb_prof);

        
        $__internal_8cec13c4bfa3d4c4f42955c78f6ea44c317cd40ccbb76b94c3e4dec89b5758fc->leave($__internal_8cec13c4bfa3d4c4f42955c78f6ea44c317cd40ccbb76b94c3e4dec89b5758fc_prof);

    }

    // line 7
    public function block_page_title($context, array $blocks = array())
    {
        $__internal_34dab5c0fb3d9f9bb2c99256b7295159fd8b3d2fac5d05ecb9a1afe86247dae6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_34dab5c0fb3d9f9bb2c99256b7295159fd8b3d2fac5d05ecb9a1afe86247dae6->enter($__internal_34dab5c0fb3d9f9bb2c99256b7295159fd8b3d2fac5d05ecb9a1afe86247dae6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_title"));

        $__internal_433b2cb02a052db63f8d9b434f8ecd9d2bad1019d50a2e4bb1045ed4cbfdc1c1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_433b2cb02a052db63f8d9b434f8ecd9d2bad1019d50a2e4bb1045ed4cbfdc1c1->enter($__internal_433b2cb02a052db63f8d9b434f8ecd9d2bad1019d50a2e4bb1045ed4cbfdc1c1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_title"));

        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("navigation.user_management.title"), "html", null, true);
        
        $__internal_433b2cb02a052db63f8d9b434f8ecd9d2bad1019d50a2e4bb1045ed4cbfdc1c1->leave($__internal_433b2cb02a052db63f8d9b434f8ecd9d2bad1019d50a2e4bb1045ed4cbfdc1c1_prof);

        
        $__internal_34dab5c0fb3d9f9bb2c99256b7295159fd8b3d2fac5d05ecb9a1afe86247dae6->leave($__internal_34dab5c0fb3d9f9bb2c99256b7295159fd8b3d2fac5d05ecb9a1afe86247dae6_prof);

    }

    // line 8
    public function block_page_subtitle($context, array $blocks = array())
    {
        $__internal_ecc992f87b373e02353a7bd3c866e7a51ae702815af827d21461c8d31d3e4a82 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ecc992f87b373e02353a7bd3c866e7a51ae702815af827d21461c8d31d3e4a82->enter($__internal_ecc992f87b373e02353a7bd3c866e7a51ae702815af827d21461c8d31d3e4a82_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_subtitle"));

        $__internal_73a40cfa0f304495e506a3deda92a30d101d35c9df9d5f390d153dd3bef95b06 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_73a40cfa0f304495e506a3deda92a30d101d35c9df9d5f390d153dd3bef95b06->enter($__internal_73a40cfa0f304495e506a3deda92a30d101d35c9df9d5f390d153dd3bef95b06_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_subtitle"));

        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("navigation.user_management.subtitle"), "html", null, true);
        
        $__internal_73a40cfa0f304495e506a3deda92a30d101d35c9df9d5f390d153dd3bef95b06->leave($__internal_73a40cfa0f304495e506a3deda92a30d101d35c9df9d5f390d153dd3bef95b06_prof);

        
        $__internal_ecc992f87b373e02353a7bd3c866e7a51ae702815af827d21461c8d31d3e4a82->leave($__internal_ecc992f87b373e02353a7bd3c866e7a51ae702815af827d21461c8d31d3e4a82_prof);

    }

    // line 9
    public function block_page_content($context, array $blocks = array())
    {
        $__internal_864b03c2a0149d3abc23d5c8d8a4566b5813e262646d45b70a2e147362c15878 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_864b03c2a0149d3abc23d5c8d8a4566b5813e262646d45b70a2e147362c15878->enter($__internal_864b03c2a0149d3abc23d5c8d8a4566b5813e262646d45b70a2e147362c15878_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_content"));

        $__internal_a284d2be3a9e0d5f0601ebe1316bc46bcf1e5ba5207d9f26375f8513f8a5572f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a284d2be3a9e0d5f0601ebe1316bc46bcf1e5ba5207d9f26375f8513f8a5572f->enter($__internal_a284d2be3a9e0d5f0601ebe1316bc46bcf1e5ba5207d9f26375f8513f8a5572f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_content"));

        // line 10
        echo "    <div class=\"row\">
        <div class=\"col-lg-8 col-md-8 col-lg-offset-2 col-md-offset-2\">
            ";
        // line 12
        $this->displayBlock('flashBag', $context, $blocks);
        // line 15
        echo "        </div>
    </div>
    <div class=\"row\">
        <div class=\"col-lg-12 col-md-12\">
            <div class=\"box box-info\">
                <div class=\"box-header with-border\">
                    <h3 class=\"box-title\">";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("user_management.table.title"), "html", null, true);
        echo "</h3>
                </div>
                <div class=\"box-body table-bordered\">
                    <span style=\"float:left\">
                        ";
        // line 25
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["filterForm"]) || array_key_exists("filterForm", $context) ? $context["filterForm"] : (function () { throw new Twig_Error_Runtime('Variable "filterForm" does not exist.', 25, $this->getSourceContext()); })()), 'form_start', array("method" => "get"));
        echo "
                        <div class=\"row\" style=\"margin-left: 20px; margin-right: 20px;\">
                        <div class=\"col-lg-2\">
                            ";
        // line 28
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["filterForm"]) || array_key_exists("filterForm", $context) ? $context["filterForm"] : (function () { throw new Twig_Error_Runtime('Variable "filterForm" does not exist.', 28, $this->getSourceContext()); })()), "results", array()), 'row');
        echo "
                        </div>
                        <div class=\"col-lg-11\">
                            ";
        // line 31
        if ((isset($context["pagination"]) || array_key_exists("pagination", $context) ? $context["pagination"] : (function () { throw new Twig_Error_Runtime('Variable "pagination" does not exist.', 31, $this->getSourceContext()); })())) {
            // line 32
            echo "                                <ul class=\"pagination pagination-sm no-margin pull-right\">
                                    ";
            // line 33
            echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->render($this->env, (isset($context["pagination"]) || array_key_exists("pagination", $context) ? $context["pagination"] : (function () { throw new Twig_Error_Runtime('Variable "pagination" does not exist.', 33, $this->getSourceContext()); })()), "::adminlte_pagination.html.twig");
            echo "
                                </ul>
                            ";
        }
        // line 36
        echo "                        </div>
                    </div>
                    <table class=\"table table-bordered table-hover dataTable\" role=\"grid\" id=\"voucher_requests\">
                        <thead>
                        ";
        // line 40
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["filterForm"]) || array_key_exists("filterForm", $context) ? $context["filterForm"] : (function () { throw new Twig_Error_Runtime('Variable "filterForm" does not exist.', 40, $this->getSourceContext()); })()), 'form_start', array("method" => "get"));
        echo "
                        ";
        // line 41
        if ( !twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["filterForm"]) || array_key_exists("filterForm", $context) ? $context["filterForm"] : (function () { throw new Twig_Error_Runtime('Variable "filterForm" does not exist.', 41, $this->getSourceContext()); })()), "vars", array()), "valid", array())) {
            // line 42
            echo "                            <tr role=\"row\" align=\"center\">
                            <td colspan=\"6\">
                                ";
            // line 44
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock((isset($context["filterForm"]) || array_key_exists("filterForm", $context) ? $context["filterForm"] : (function () { throw new Twig_Error_Runtime('Variable "filterForm" does not exist.', 44, $this->getSourceContext()); })()), 'errors', array("method" => "get", "attr" => array("class" => "form-inline")));
            echo "
                            </td>
                        </tr>
                        ";
        }
        // line 48
        echo "                        ";
        if ((isset($context["pagination"]) || array_key_exists("pagination", $context) ? $context["pagination"] : (function () { throw new Twig_Error_Runtime('Variable "pagination" does not exist.', 48, $this->getSourceContext()); })())) {
            // line 49
            echo "                        <tr role=\"row\" align=\"center\" style=\"padding:0\">
                            <th width=\"10%\">";
            // line 50
            echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) || array_key_exists("pagination", $context) ? $context["pagination"] : (function () { throw new Twig_Error_Runtime('Variable "pagination" does not exist.', 50, $this->getSourceContext()); })()), $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("user_management.table.id"), "u.id");
            echo "</th>
                            <th width=\"10%\">";
            // line 51
            echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) || array_key_exists("pagination", $context) ? $context["pagination"] : (function () { throw new Twig_Error_Runtime('Variable "pagination" does not exist.', 51, $this->getSourceContext()); })()), $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("user_management.table.name"), "u.username");
            echo "</th>
                            <th width=\"30%\">";
            // line 52
            echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) || array_key_exists("pagination", $context) ? $context["pagination"] : (function () { throw new Twig_Error_Runtime('Variable "pagination" does not exist.', 52, $this->getSourceContext()); })()), $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("user_management.table.join_date"), "u.joinDate");
            echo "</th>
                            <th width=\"10%\">";
            // line 53
            echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) || array_key_exists("pagination", $context) ? $context["pagination"] : (function () { throw new Twig_Error_Runtime('Variable "pagination" does not exist.', 53, $this->getSourceContext()); })()), $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("user_management.table.email"), "u.email");
            echo "</th>
                            <th width=\"10%\">";
            // line 54
            echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) || array_key_exists("pagination", $context) ? $context["pagination"] : (function () { throw new Twig_Error_Runtime('Variable "pagination" does not exist.', 54, $this->getSourceContext()); })()), $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("user_management.table.user_enabled"), "u.enabled");
            echo "</th>
                            <th width=\"10%\">";
            // line 55
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("user_management.table.actions"), "html", null, true);
            echo "</th>
                        </tr>
                        </thead>
                        <tbody>
                    ";
            // line 59
            if (twig_test_empty((isset($context["pagination"]) || array_key_exists("pagination", $context) ? $context["pagination"] : (function () { throw new Twig_Error_Runtime('Variable "pagination" does not exist.', 59, $this->getSourceContext()); })()))) {
                // line 60
                echo "                    <tr role=\"row\" align=\"center\">
                            <td colspan=\"7\">
                                <div class=\"alert alert-info alert-dismissible\">
                                <button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>
                                <h4><i class=\"icon fa fa-info\"></i> Alert!</h4>
                                    ";
                // line 65
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("generic.table.no_results"), "html", null, true);
                echo "
                                </div>
                            </td>
                        </tr>
                    ";
            } else {
                // line 70
                echo "                    <tr role=\"row\" align=\"center\" style=\"padding:0\">
                            <td>
                                ";
                // line 72
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["filterForm"]) || array_key_exists("filterForm", $context) ? $context["filterForm"] : (function () { throw new Twig_Error_Runtime('Variable "filterForm" does not exist.', 72, $this->getSourceContext()); })()), "id", array()), 'row', array("attr" => array("placeholder" => "user_management.form.placeholder.id")));
                echo "
                            </td>
                            <td>
                                ";
                // line 75
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["filterForm"]) || array_key_exists("filterForm", $context) ? $context["filterForm"] : (function () { throw new Twig_Error_Runtime('Variable "filterForm" does not exist.', 75, $this->getSourceContext()); })()), "username", array()), 'row', array("attr" => array("placeholder" => "user_management.form.placeholder.username")));
                echo "
                            </td>
                            <td>
                                ";
                // line 78
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["filterForm"]) || array_key_exists("filterForm", $context) ? $context["filterForm"] : (function () { throw new Twig_Error_Runtime('Variable "filterForm" does not exist.', 78, $this->getSourceContext()); })()), "joinDate", array()), 'row', array("attr" => array("placeholder" => "user_management.form.placeholder.joinDate")));
                echo "
                            </td>
                            <td>
                                ";
                // line 81
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["filterForm"]) || array_key_exists("filterForm", $context) ? $context["filterForm"] : (function () { throw new Twig_Error_Runtime('Variable "filterForm" does not exist.', 81, $this->getSourceContext()); })()), "email", array()), 'row', array("attr" => array("placeholder" => "user_management.form.placeholder.email")));
                echo "
                            </td>
                            <td>
                                ";
                // line 84
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["filterForm"]) || array_key_exists("filterForm", $context) ? $context["filterForm"] : (function () { throw new Twig_Error_Runtime('Variable "filterForm" does not exist.', 84, $this->getSourceContext()); })()), "enabled", array()), 'row');
                echo "
                            </td>
                            <td>
                                <button type=\"submit\" id=\"user_filter_submit\" name=\"submit\"
                                        class=\"btn btn-primary btn-flat\">
                                    <i class=\"glyphicon glyphicon-filter\"></i></button>
                                ";
                // line 90
                echo                 $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["filterForm"]) || array_key_exists("filterForm", $context) ? $context["filterForm"] : (function () { throw new Twig_Error_Runtime('Variable "filterForm" does not exist.', 90, $this->getSourceContext()); })()), 'form_end');
                echo "
                            </td>
                        </tr>
                    ";
                // line 93
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable((isset($context["pagination"]) || array_key_exists("pagination", $context) ? $context["pagination"] : (function () { throw new Twig_Error_Runtime('Variable "pagination" does not exist.', 93, $this->getSourceContext()); })()));
                $context['loop'] = array(
                  'parent' => $context['_parent'],
                  'index0' => 0,
                  'index'  => 1,
                  'first'  => true,
                );
                if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                    $length = count($context['_seq']);
                    $context['loop']['revindex0'] = $length - 1;
                    $context['loop']['revindex'] = $length;
                    $context['loop']['length'] = $length;
                    $context['loop']['last'] = 1 === $length;
                }
                foreach ($context['_seq'] as $context["_key"] => $context["user"]) {
                    // line 94
                    echo "                        <tr role=\"row\" align=\"center\" style=\"padding:0\">
                                <td>";
                    // line 95
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["user"], "id", array()), "html", null, true);
                    echo "</td>
                                <td>";
                    // line 96
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["user"], "username", array()), "html", null, true);
                    echo "</td>
                                <td>";
                    // line 97
                    echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["user"], "joinDate", array()), "d/m/Y H:i:s"), "html", null, true);
                    echo "</td>
                                <td>";
                    // line 98
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["user"], "email", array()), "html", null, true);
                    echo "</td>
                                <td>";
                    // line 99
                    if ((twig_get_attribute($this->env, $this->getSourceContext(), $context["user"], "enabled", array()) == 1)) {
                        // line 100
                        echo "                                        <span class=\"label label-success\" style=\"font-size: 12px\">Enabled</span>
                                    ";
                    } else {
                        // line 102
                        echo "                                        <span class=\"label label-danger\" style=\"font-size: 12px\">Disabled</span>
                                    ";
                    }
                    // line 104
                    echo "                                </td>
                                <td>
                                    <span style=\"float: none\">
                                    ";
                    // line 107
                    echo                     $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["manageForm"]) || array_key_exists("manageForm", $context) ? $context["manageForm"] : (function () { throw new Twig_Error_Runtime('Variable "manageForm" does not exist.', 107, $this->getSourceContext()); })()), 'form_start', array("method" => "post", "attr" => array("class" => "form-inline")));
                    echo "
                                        ";
                    // line 108
                    echo twig_replace_filter((isset($context["form_token"]) || array_key_exists("form_token", $context) ? $context["form_token"] : (function () { throw new Twig_Error_Runtime('Variable "form_token" does not exist.', 108, $this->getSourceContext()); })()), array("#id#" => ("user_management__token_" . twig_get_attribute($this->env, $this->getSourceContext(), $context["user"], "id", array()))));
                    echo "
                                        ";
                    // line 109
                    if ((twig_get_attribute($this->env, $this->getSourceContext(), $context["user"], "enabled", array()) == 0)) {
                        // line 110
                        echo "                                            ";
                        // line 111
                        echo "                                            ";
                        // line 112
                        echo "                                            ";
                        // line 113
                        echo "                                            ";
                        $this->loadTemplate(":Components:popup.html.twig", ":Admin:user_list.html.twig", 113)->display(array_merge($context, array("color" => "success", "button" => "<i class='fa fa-check'></i>", "action" => $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_management_activate", array("id" => twig_get_attribute($this->env, $this->getSourceContext(),                         // line 116
$context["user"], "id", array()))), "id" => twig_get_attribute($this->env, $this->getSourceContext(),                         // line 117
$context["user"], "id", array()), "type" => "activateUser")));
                        // line 121
                        echo "                                        ";
                    } else {
                        // line 122
                        echo "                                            ";
                        $this->loadTemplate(":Components:popup.html.twig", ":Admin:user_list.html.twig", 122)->display(array_merge($context, array("color" => "danger", "button" => "<i class='fa fa-close'></i>", "action" => $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_management_deactivate", array("id" => twig_get_attribute($this->env, $this->getSourceContext(),                         // line 125
$context["user"], "id", array()))), "id" => twig_get_attribute($this->env, $this->getSourceContext(),                         // line 126
$context["user"], "id", array()), "type" => "deactivateUser")));
                        // line 130
                        echo "                                        ";
                    }
                    // line 131
                    echo "                                        ";
                    echo                     $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["manageForm"]) || array_key_exists("manageForm", $context) ? $context["manageForm"] : (function () { throw new Twig_Error_Runtime('Variable "manageForm" does not exist.', 131, $this->getSourceContext()); })()), 'form_end');
                    echo "
                                    </span>
                                </td>
                            </tr>
                    ";
                    ++$context['loop']['index0'];
                    ++$context['loop']['index'];
                    $context['loop']['first'] = false;
                    if (isset($context['loop']['length'])) {
                        --$context['loop']['revindex0'];
                        --$context['loop']['revindex'];
                        $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                    }
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['user'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 136
                echo "                        </tbody>
                        ";
            }
            // line 138
            echo "                        ";
        }
        // line 139
        echo "                    </table>
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_a284d2be3a9e0d5f0601ebe1316bc46bcf1e5ba5207d9f26375f8513f8a5572f->leave($__internal_a284d2be3a9e0d5f0601ebe1316bc46bcf1e5ba5207d9f26375f8513f8a5572f_prof);

        
        $__internal_864b03c2a0149d3abc23d5c8d8a4566b5813e262646d45b70a2e147362c15878->leave($__internal_864b03c2a0149d3abc23d5c8d8a4566b5813e262646d45b70a2e147362c15878_prof);

    }

    // line 12
    public function block_flashBag($context, array $blocks = array())
    {
        $__internal_c4cca49b0206c1a887268b510b6ffe0e0144a10a7c0a4d03f0a2ae5c46fc90db = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c4cca49b0206c1a887268b510b6ffe0e0144a10a7c0a4d03f0a2ae5c46fc90db->enter($__internal_c4cca49b0206c1a887268b510b6ffe0e0144a10a7c0a4d03f0a2ae5c46fc90db_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "flashBag"));

        $__internal_78790328c440be529229177055c8b2963713797ca97bcf911c2e4ade1ad1c5b5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_78790328c440be529229177055c8b2963713797ca97bcf911c2e4ade1ad1c5b5->enter($__internal_78790328c440be529229177055c8b2963713797ca97bcf911c2e4ade1ad1c5b5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "flashBag"));

        // line 13
        echo "                ";
        $this->displayParentBlock("flashBag", $context, $blocks);
        echo "
            ";
        
        $__internal_78790328c440be529229177055c8b2963713797ca97bcf911c2e4ade1ad1c5b5->leave($__internal_78790328c440be529229177055c8b2963713797ca97bcf911c2e4ade1ad1c5b5_prof);

        
        $__internal_c4cca49b0206c1a887268b510b6ffe0e0144a10a7c0a4d03f0a2ae5c46fc90db->leave($__internal_c4cca49b0206c1a887268b510b6ffe0e0144a10a7c0a4d03f0a2ae5c46fc90db_prof);

    }

    // line 146
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_1b568c269b5fc8c2f5ed65bc9d1b5b3a0b5219f1ded196c32457048ea3a6ad60 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1b568c269b5fc8c2f5ed65bc9d1b5b3a0b5219f1ded196c32457048ea3a6ad60->enter($__internal_1b568c269b5fc8c2f5ed65bc9d1b5b3a0b5219f1ded196c32457048ea3a6ad60_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_9096894f1f546d86645e3b990b62fab17aeaf9d73f8791ecb47fb4f963e81d8d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9096894f1f546d86645e3b990b62fab17aeaf9d73f8791ecb47fb4f963e81d8d->enter($__internal_9096894f1f546d86645e3b990b62fab17aeaf9d73f8791ecb47fb4f963e81d8d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 147
        echo "     ";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "
     <script type=\"text/javascript\">
         \$(function () {
             \$('#user_filter_joinDate').datetimepicker();
             \$(joinDate)({
                 useCurrent: false});
         });
     </script>
 ";
        
        $__internal_9096894f1f546d86645e3b990b62fab17aeaf9d73f8791ecb47fb4f963e81d8d->leave($__internal_9096894f1f546d86645e3b990b62fab17aeaf9d73f8791ecb47fb4f963e81d8d_prof);

        
        $__internal_1b568c269b5fc8c2f5ed65bc9d1b5b3a0b5219f1ded196c32457048ea3a6ad60->leave($__internal_1b568c269b5fc8c2f5ed65bc9d1b5b3a0b5219f1ded196c32457048ea3a6ad60_prof);

    }

    public function getTemplateName()
    {
        return ":Admin:user_list.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  416 => 147,  407 => 146,  394 => 13,  385 => 12,  370 => 139,  367 => 138,  363 => 136,  343 => 131,  340 => 130,  338 => 126,  337 => 125,  335 => 122,  332 => 121,  330 => 117,  329 => 116,  327 => 113,  325 => 112,  323 => 111,  321 => 110,  319 => 109,  315 => 108,  311 => 107,  306 => 104,  302 => 102,  298 => 100,  296 => 99,  292 => 98,  288 => 97,  284 => 96,  280 => 95,  277 => 94,  260 => 93,  254 => 90,  245 => 84,  239 => 81,  233 => 78,  227 => 75,  221 => 72,  217 => 70,  209 => 65,  202 => 60,  200 => 59,  193 => 55,  189 => 54,  185 => 53,  181 => 52,  177 => 51,  173 => 50,  170 => 49,  167 => 48,  160 => 44,  156 => 42,  154 => 41,  150 => 40,  144 => 36,  138 => 33,  135 => 32,  133 => 31,  127 => 28,  121 => 25,  114 => 21,  106 => 15,  104 => 12,  100 => 10,  91 => 9,  73 => 8,  55 => 7,  45 => 1,  43 => 6,  37 => 3,  35 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '::base-layout.html.twig' %}
{% set form_token %}
    {{ form_row(manageForm._token, {'id': \"#id#\"}) }}
{% endset %}

{% form_theme filterForm ':Form:fields.html.twig' %}
{% block page_title %}{{ 'navigation.user_management.title'|trans }}{% endblock %}
{% block page_subtitle %}{{ 'navigation.user_management.subtitle'|trans }}{% endblock %}
{% block page_content %}
    <div class=\"row\">
        <div class=\"col-lg-8 col-md-8 col-lg-offset-2 col-md-offset-2\">
            {% block flashBag %}
                {{ parent() }}
            {% endblock %}
        </div>
    </div>
    <div class=\"row\">
        <div class=\"col-lg-12 col-md-12\">
            <div class=\"box box-info\">
                <div class=\"box-header with-border\">
                    <h3 class=\"box-title\">{{ 'user_management.table.title'|trans }}</h3>
                </div>
                <div class=\"box-body table-bordered\">
                    <span style=\"float:left\">
                        {{ form_start(filterForm, { 'method' : 'get' }) }}
                        <div class=\"row\" style=\"margin-left: 20px; margin-right: 20px;\">
                        <div class=\"col-lg-2\">
                            {{ form_row(filterForm.results) }}
                        </div>
                        <div class=\"col-lg-11\">
                            {% if pagination %}
                                <ul class=\"pagination pagination-sm no-margin pull-right\">
                                    {{ knp_pagination_render(pagination, '::adminlte_pagination.html.twig') }}
                                </ul>
                            {% endif %}
                        </div>
                    </div>
                    <table class=\"table table-bordered table-hover dataTable\" role=\"grid\" id=\"voucher_requests\">
                        <thead>
                        {{ form_start(filterForm, { 'method' : 'get'}) }}
                        {% if not filterForm.vars.valid %}
                            <tr role=\"row\" align=\"center\">
                            <td colspan=\"6\">
                                {{ form_errors(filterForm, { 'method' : 'get', 'attr': {'class' : 'form-inline'}}) }}
                            </td>
                        </tr>
                        {% endif %}
                        {% if pagination %}
                        <tr role=\"row\" align=\"center\" style=\"padding:0\">
                            <th width=\"10%\">{{ knp_pagination_sortable(pagination, 'user_management.table.id'|trans, 'u.id') }}</th>
                            <th width=\"10%\">{{ knp_pagination_sortable(pagination, 'user_management.table.name'|trans, 'u.username') }}</th>
                            <th width=\"30%\">{{ knp_pagination_sortable(pagination, 'user_management.table.join_date'|trans, 'u.joinDate') }}</th>
                            <th width=\"10%\">{{ knp_pagination_sortable(pagination, 'user_management.table.email'|trans, 'u.email') }}</th>
                            <th width=\"10%\">{{ knp_pagination_sortable(pagination, 'user_management.table.user_enabled'|trans, 'u.enabled') }}</th>
                            <th width=\"10%\">{{ 'user_management.table.actions'|trans }}</th>
                        </tr>
                        </thead>
                        <tbody>
                    {% if pagination is empty %}
                    <tr role=\"row\" align=\"center\">
                            <td colspan=\"7\">
                                <div class=\"alert alert-info alert-dismissible\">
                                <button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>
                                <h4><i class=\"icon fa fa-info\"></i> Alert!</h4>
                                    {{ 'generic.table.no_results'|trans }}
                                </div>
                            </td>
                        </tr>
                    {% else %}
                    <tr role=\"row\" align=\"center\" style=\"padding:0\">
                            <td>
                                {{ form_row(filterForm.id, {'attr': {'placeholder' : 'user_management.form.placeholder.id'}}) }}
                            </td>
                            <td>
                                {{ form_row(filterForm.username, {'attr': {'placeholder' : 'user_management.form.placeholder.username'}}) }}
                            </td>
                            <td>
                                {{ form_row(filterForm.joinDate, {'attr': {'placeholder' : 'user_management.form.placeholder.joinDate'}}) }}
                            </td>
                            <td>
                                {{ form_row(filterForm.email, {'attr': {'placeholder' : 'user_management.form.placeholder.email'}}) }}
                            </td>
                            <td>
                                {{ form_row(filterForm.enabled) }}
                            </td>
                            <td>
                                <button type=\"submit\" id=\"user_filter_submit\" name=\"submit\"
                                        class=\"btn btn-primary btn-flat\">
                                    <i class=\"glyphicon glyphicon-filter\"></i></button>
                                {{ form_end(filterForm) }}
                            </td>
                        </tr>
                    {% for user in pagination %}
                        <tr role=\"row\" align=\"center\" style=\"padding:0\">
                                <td>{{ user.id }}</td>
                                <td>{{ user.username }}</td>
                                <td>{{ user.joinDate|date(\"d/m/Y H:i:s\") }}</td>
                                <td>{{ user.email }}</td>
                                <td>{% if user.enabled == 1 %}
                                        <span class=\"label label-success\" style=\"font-size: 12px\">Enabled</span>
                                    {% else %}
                                        <span class=\"label label-danger\" style=\"font-size: 12px\">Disabled</span>
                                    {% endif %}
                                </td>
                                <td>
                                    <span style=\"float: none\">
                                    {{ form_start(manageForm, { 'method' : 'post', 'attr' : {'class' : 'form-inline'}}) }}
                                        {{ form_token|replace({'#id#': 'user_management__token_'~user.id})|raw }}
                                        {% if user.enabled == 0 %}
                                            {#<button type=\"submit\" class=\"btn btn-success btn-flat form-control\"#}
                                            {#formaction=\"{{ path('user_management_activate', {'id': user.id }) }}\">#}
                                            {#<i class=\"fa fa-check\"></i></button>#}
                                            {% include ':Components:popup.html.twig' with{
                                            'color' : 'success',
                                            'button' : \"<i class='fa fa-check'></i>\",
                                            'action' : path('user_management_activate', {'id': user.id }),
                                            'id' : user.id,
                                            'type' : 'activateUser'
                                            }
                                            %}
                                        {% else %}
                                            {% include ':Components:popup.html.twig' with{
                                            'color' : 'danger',
                                            'button' : \"<i class='fa fa-close'></i>\",
                                            'action' : path('user_management_deactivate', {'id': user.id }),
                                            'id' : user.id,
                                            'type' : 'deactivateUser'
                                            }
                                            %}
                                        {% endif %}
                                        {{ form_end(manageForm) }}
                                    </span>
                                </td>
                            </tr>
                    {% endfor %}
                        </tbody>
                        {% endif %}
                        {% endif %}
                    </table>
                </div>
            </div>
        </div>
    </div>
{% endblock %}

 {% block javascripts %}
     {{ parent() }}
     <script type=\"text/javascript\">
         \$(function () {
             \$('#user_filter_joinDate').datetimepicker();
             \$(joinDate)({
                 useCurrent: false});
         });
     </script>
 {% endblock %}", ":Admin:user_list.html.twig", "/home/sorina/Documents/work/movies_crowler/app/Resources/views/Admin/user_list.html.twig");
    }
}
