<?php

/* WebProfilerBundle:Profiler:toolbar_redirect.html.twig */
class __TwigTemplate_09d0f02fc37d26aea3056ecd1eeb1d2575b417bf42dbf5159f3c6cc9392f0c6d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_126d25a53aafe03cb018058169db5c0ec85e1df7d8b5d739db6f643651fe207e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_126d25a53aafe03cb018058169db5c0ec85e1df7d8b5d739db6f643651fe207e->enter($__internal_126d25a53aafe03cb018058169db5c0ec85e1df7d8b5d739db6f643651fe207e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig"));

        $__internal_02617899844a11051f0de4371e03b1849bbaccbe6adb616556e5c58ca9dd617e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_02617899844a11051f0de4371e03b1849bbaccbe6adb616556e5c58ca9dd617e->enter($__internal_02617899844a11051f0de4371e03b1849bbaccbe6adb616556e5c58ca9dd617e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_126d25a53aafe03cb018058169db5c0ec85e1df7d8b5d739db6f643651fe207e->leave($__internal_126d25a53aafe03cb018058169db5c0ec85e1df7d8b5d739db6f643651fe207e_prof);

        
        $__internal_02617899844a11051f0de4371e03b1849bbaccbe6adb616556e5c58ca9dd617e->leave($__internal_02617899844a11051f0de4371e03b1849bbaccbe6adb616556e5c58ca9dd617e_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_83e95de56e1ed2aa9d2922434e130410920c79ab2059629126966cf67633d5c5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_83e95de56e1ed2aa9d2922434e130410920c79ab2059629126966cf67633d5c5->enter($__internal_83e95de56e1ed2aa9d2922434e130410920c79ab2059629126966cf67633d5c5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_8f0e0661f933c79cbbf5a8d6fc4c035f531748456b947a6105d0590ac0d7246d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8f0e0661f933c79cbbf5a8d6fc4c035f531748456b947a6105d0590ac0d7246d->enter($__internal_8f0e0661f933c79cbbf5a8d6fc4c035f531748456b947a6105d0590ac0d7246d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Redirection Intercepted";
        
        $__internal_8f0e0661f933c79cbbf5a8d6fc4c035f531748456b947a6105d0590ac0d7246d->leave($__internal_8f0e0661f933c79cbbf5a8d6fc4c035f531748456b947a6105d0590ac0d7246d_prof);

        
        $__internal_83e95de56e1ed2aa9d2922434e130410920c79ab2059629126966cf67633d5c5->leave($__internal_83e95de56e1ed2aa9d2922434e130410920c79ab2059629126966cf67633d5c5_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_23cc7cd2a822e448a8d565f2333d7bc304b9065051d7af933d8ddfdc1909ccaa = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_23cc7cd2a822e448a8d565f2333d7bc304b9065051d7af933d8ddfdc1909ccaa->enter($__internal_23cc7cd2a822e448a8d565f2333d7bc304b9065051d7af933d8ddfdc1909ccaa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_2fc48ec87815383eb9196f236babf1023da9a0c2a8b9e3d652dd7ccdaaa239aa = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2fc48ec87815383eb9196f236babf1023da9a0c2a8b9e3d652dd7ccdaaa239aa->enter($__internal_2fc48ec87815383eb9196f236babf1023da9a0c2a8b9e3d652dd7ccdaaa239aa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"";
        // line 8
        echo twig_escape_filter($this->env, (isset($context["location"]) || array_key_exists("location", $context) ? $context["location"] : (function () { throw new Twig_Error_Runtime('Variable "location" does not exist.', 8, $this->getSourceContext()); })()), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, (isset($context["location"]) || array_key_exists("location", $context) ? $context["location"] : (function () { throw new Twig_Error_Runtime('Variable "location" does not exist.', 8, $this->getSourceContext()); })()), "html", null, true);
        echo "</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
";
        
        $__internal_2fc48ec87815383eb9196f236babf1023da9a0c2a8b9e3d652dd7ccdaaa239aa->leave($__internal_2fc48ec87815383eb9196f236babf1023da9a0c2a8b9e3d652dd7ccdaaa239aa_prof);

        
        $__internal_23cc7cd2a822e448a8d565f2333d7bc304b9065051d7af933d8ddfdc1909ccaa->leave($__internal_23cc7cd2a822e448a8d565f2333d7bc304b9065051d7af933d8ddfdc1909ccaa_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:toolbar_redirect.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  72 => 8,  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block title 'Redirection Intercepted' %}

{% block body %}
    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"{{ location }}\">{{ location }}</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
{% endblock %}
", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Profiler/toolbar_redirect.html.twig");
    }
}
