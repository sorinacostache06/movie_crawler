<?php

/* AvanzuAdminThemeBundle:Default:form.html.twig */
class __TwigTemplate_53d79175febc9a7b36b02d883505d1e8c8dbe8180acef79a80e8444107445550 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("AvanzuAdminThemeBundle:layout:base-layout.html.twig", "AvanzuAdminThemeBundle:Default:form.html.twig", 1);
        $this->blocks = array(
            'page_content' => array($this, 'block_page_content'),
            'page_title' => array($this, 'block_page_title'),
            'page_subtitle' => array($this, 'block_page_subtitle'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "AvanzuAdminThemeBundle:layout:base-layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b487729ce713e469c1f89c850a482a5a0a4cb043b7843a9c1878551951dc3858 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b487729ce713e469c1f89c850a482a5a0a4cb043b7843a9c1878551951dc3858->enter($__internal_b487729ce713e469c1f89c850a482a5a0a4cb043b7843a9c1878551951dc3858_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AvanzuAdminThemeBundle:Default:form.html.twig"));

        $__internal_de531756a6540752f09ebc6ef2441104860462cf0c5a09281303bd3be8738960 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_de531756a6540752f09ebc6ef2441104860462cf0c5a09281303bd3be8738960->enter($__internal_de531756a6540752f09ebc6ef2441104860462cf0c5a09281303bd3be8738960_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AvanzuAdminThemeBundle:Default:form.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b487729ce713e469c1f89c850a482a5a0a4cb043b7843a9c1878551951dc3858->leave($__internal_b487729ce713e469c1f89c850a482a5a0a4cb043b7843a9c1878551951dc3858_prof);

        
        $__internal_de531756a6540752f09ebc6ef2441104860462cf0c5a09281303bd3be8738960->leave($__internal_de531756a6540752f09ebc6ef2441104860462cf0c5a09281303bd3be8738960_prof);

    }

    // line 3
    public function block_page_content($context, array $blocks = array())
    {
        $__internal_5c8bc5f9f73bf5143d66afe4f9a8149b483d82860a3621e5d1a4325b5b8df1e2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5c8bc5f9f73bf5143d66afe4f9a8149b483d82860a3621e5d1a4325b5b8df1e2->enter($__internal_5c8bc5f9f73bf5143d66afe4f9a8149b483d82860a3621e5d1a4325b5b8df1e2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_content"));

        $__internal_8420991760a80f61b8b9b19066bc7421f0a14ad16651d9cd92d4e9a709673d8a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8420991760a80f61b8b9b19066bc7421f0a14ad16651d9cd92d4e9a709673d8a->enter($__internal_8420991760a80f61b8b9b19066bc7421f0a14ad16651d9cd92d4e9a709673d8a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_content"));

        // line 4
        echo "
    <div class=\"row\">
        <div class=\"col-md-4\">


        </div>
        <div class=\"col-md-4\">

        </div>
        <div class=\"col-md-4\">

        </div>
    </div>

    <div class=\"row\">
        <div class=\"col-md-6\">

            <div class=\"box box-primary\">
                <div class=\"box-header\">
                    <h3 class=\"box-title\">Form Theme</h3>
                </div>
                <div class=\"box-body\">
                    ";
        // line 26
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 26, $this->getSourceContext()); })()), 'form');
        echo "
                </div>
                <div class=\"box-footer clearfix\">

                        <button type=\"reset\" class=\"btn btn-warning pull-left\"><i class=\"fa fa-times\"></i> Cancel</button>
                        <button type=\"submit\" class=\"btn btn-primary pull-right\"><i class=\"fa fa-check-square\"></i> Submit</button>


                </div>
            </div>

        </div>
        <div class=\"col-md-6\">
            <div class=\"box box-solid box-primary\">
                ";
        // line 40
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["macro"]) || array_key_exists("macro", $context) ? $context["macro"] : (function () { throw new Twig_Error_Runtime('Variable "macro" does not exist.', 40, $this->getSourceContext()); })()), "box_header", array(0 => "built from macro", 1 => true, 2 => false, 3 => "primary"), "method"), "html", null, true);
        echo "
                <div class=\"box-body\">
                    some content...
                </div>
            </div>
        </div>
    </div>


";
        
        $__internal_8420991760a80f61b8b9b19066bc7421f0a14ad16651d9cd92d4e9a709673d8a->leave($__internal_8420991760a80f61b8b9b19066bc7421f0a14ad16651d9cd92d4e9a709673d8a_prof);

        
        $__internal_5c8bc5f9f73bf5143d66afe4f9a8149b483d82860a3621e5d1a4325b5b8df1e2->leave($__internal_5c8bc5f9f73bf5143d66afe4f9a8149b483d82860a3621e5d1a4325b5b8df1e2_prof);

    }

    // line 51
    public function block_page_title($context, array $blocks = array())
    {
        $__internal_787b8da050731b4d894909072b340daa1f0b2533575b32bb5ae37f38fd1b98b2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_787b8da050731b4d894909072b340daa1f0b2533575b32bb5ae37f38fd1b98b2->enter($__internal_787b8da050731b4d894909072b340daa1f0b2533575b32bb5ae37f38fd1b98b2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_title"));

        $__internal_dd6b6d04198bfb76e884c1c0c3fbef5ca18cb01ece16de0de22975915d6c26a9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dd6b6d04198bfb76e884c1c0c3fbef5ca18cb01ece16de0de22975915d6c26a9->enter($__internal_dd6b6d04198bfb76e884c1c0c3fbef5ca18cb01ece16de0de22975915d6c26a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_title"));

        echo " Forms ";
        
        $__internal_dd6b6d04198bfb76e884c1c0c3fbef5ca18cb01ece16de0de22975915d6c26a9->leave($__internal_dd6b6d04198bfb76e884c1c0c3fbef5ca18cb01ece16de0de22975915d6c26a9_prof);

        
        $__internal_787b8da050731b4d894909072b340daa1f0b2533575b32bb5ae37f38fd1b98b2->leave($__internal_787b8da050731b4d894909072b340daa1f0b2533575b32bb5ae37f38fd1b98b2_prof);

    }

    // line 52
    public function block_page_subtitle($context, array $blocks = array())
    {
        $__internal_21a736ca6bf0a29ee5a6071adb601c1dda41fdf952aeb1f21c2b0f2f9f6a277b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_21a736ca6bf0a29ee5a6071adb601c1dda41fdf952aeb1f21c2b0f2f9f6a277b->enter($__internal_21a736ca6bf0a29ee5a6071adb601c1dda41fdf952aeb1f21c2b0f2f9f6a277b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_subtitle"));

        $__internal_45a47a0d919fe648347aa31f54cd8bab891f8556295a5e6a859e30f867cc07f5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_45a47a0d919fe648347aa31f54cd8bab891f8556295a5e6a859e30f867cc07f5->enter($__internal_45a47a0d919fe648347aa31f54cd8bab891f8556295a5e6a859e30f867cc07f5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_subtitle"));

        echo " demonstration ";
        
        $__internal_45a47a0d919fe648347aa31f54cd8bab891f8556295a5e6a859e30f867cc07f5->leave($__internal_45a47a0d919fe648347aa31f54cd8bab891f8556295a5e6a859e30f867cc07f5_prof);

        
        $__internal_21a736ca6bf0a29ee5a6071adb601c1dda41fdf952aeb1f21c2b0f2f9f6a277b->leave($__internal_21a736ca6bf0a29ee5a6071adb601c1dda41fdf952aeb1f21c2b0f2f9f6a277b_prof);

    }

    public function getTemplateName()
    {
        return "AvanzuAdminThemeBundle:Default:form.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  130 => 52,  112 => 51,  92 => 40,  75 => 26,  51 => 4,  42 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'AvanzuAdminThemeBundle:layout:base-layout.html.twig' %}

{% block page_content %}

    <div class=\"row\">
        <div class=\"col-md-4\">


        </div>
        <div class=\"col-md-4\">

        </div>
        <div class=\"col-md-4\">

        </div>
    </div>

    <div class=\"row\">
        <div class=\"col-md-6\">

            <div class=\"box box-primary\">
                <div class=\"box-header\">
                    <h3 class=\"box-title\">Form Theme</h3>
                </div>
                <div class=\"box-body\">
                    {{ form(form) }}
                </div>
                <div class=\"box-footer clearfix\">

                        <button type=\"reset\" class=\"btn btn-warning pull-left\"><i class=\"fa fa-times\"></i> Cancel</button>
                        <button type=\"submit\" class=\"btn btn-primary pull-right\"><i class=\"fa fa-check-square\"></i> Submit</button>


                </div>
            </div>

        </div>
        <div class=\"col-md-6\">
            <div class=\"box box-solid box-primary\">
                {{ macro.box_header('built from macro', true, false, 'primary') }}
                <div class=\"box-body\">
                    some content...
                </div>
            </div>
        </div>
    </div>


{% endblock %}

{% block page_title %} Forms {% endblock %}
{% block page_subtitle %} demonstration {% endblock %}", "AvanzuAdminThemeBundle:Default:form.html.twig", "/home/sorina/Documents/work/movies_crowler/vendor/avanzu/admin-theme-bundle/Resources/views/Default/form.html.twig");
    }
}
