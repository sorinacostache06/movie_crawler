<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_b63320d36f11c5333dbb783c202aa74d7c31d187b871f300f5fada9c9734d22f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8b165f25b16a537c7cd5901fe7a065be514c2c423de931362b48784daf7c3a07 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8b165f25b16a537c7cd5901fe7a065be514c2c423de931362b48784daf7c3a07->enter($__internal_8b165f25b16a537c7cd5901fe7a065be514c2c423de931362b48784daf7c3a07_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_2a4681df372ded80e357b67eec0fbfa0d0003fcea4a2a1b23df355e7885af3fc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2a4681df372ded80e357b67eec0fbfa0d0003fcea4a2a1b23df355e7885af3fc->enter($__internal_2a4681df372ded80e357b67eec0fbfa0d0003fcea4a2a1b23df355e7885af3fc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_8b165f25b16a537c7cd5901fe7a065be514c2c423de931362b48784daf7c3a07->leave($__internal_8b165f25b16a537c7cd5901fe7a065be514c2c423de931362b48784daf7c3a07_prof);

        
        $__internal_2a4681df372ded80e357b67eec0fbfa0d0003fcea4a2a1b23df355e7885af3fc->leave($__internal_2a4681df372ded80e357b67eec0fbfa0d0003fcea4a2a1b23df355e7885af3fc_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_ede447e83bc7255b84d4f2a648d3e314d37d11bb6c164b5082348acd2544cc38 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ede447e83bc7255b84d4f2a648d3e314d37d11bb6c164b5082348acd2544cc38->enter($__internal_ede447e83bc7255b84d4f2a648d3e314d37d11bb6c164b5082348acd2544cc38_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_78b75a789113d5f7dda2d6c75895d90db936b6a2af525bd1ba878cff26c70704 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_78b75a789113d5f7dda2d6c75895d90db936b6a2af525bd1ba878cff26c70704->enter($__internal_78b75a789113d5f7dda2d6c75895d90db936b6a2af525bd1ba878cff26c70704_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_78b75a789113d5f7dda2d6c75895d90db936b6a2af525bd1ba878cff26c70704->leave($__internal_78b75a789113d5f7dda2d6c75895d90db936b6a2af525bd1ba878cff26c70704_prof);

        
        $__internal_ede447e83bc7255b84d4f2a648d3e314d37d11bb6c164b5082348acd2544cc38->leave($__internal_ede447e83bc7255b84d4f2a648d3e314d37d11bb6c164b5082348acd2544cc38_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_285eab15d8177682f50f7af7592dd2923e6921be1677cbf87c04f4d6e7fa71af = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_285eab15d8177682f50f7af7592dd2923e6921be1677cbf87c04f4d6e7fa71af->enter($__internal_285eab15d8177682f50f7af7592dd2923e6921be1677cbf87c04f4d6e7fa71af_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_df19383d74aea91eddfecc16d7e905f9dfee038e3f5c0a4b9e6763603a574293 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_df19383d74aea91eddfecc16d7e905f9dfee038e3f5c0a4b9e6763603a574293->enter($__internal_df19383d74aea91eddfecc16d7e905f9dfee038e3f5c0a4b9e6763603a574293_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_df19383d74aea91eddfecc16d7e905f9dfee038e3f5c0a4b9e6763603a574293->leave($__internal_df19383d74aea91eddfecc16d7e905f9dfee038e3f5c0a4b9e6763603a574293_prof);

        
        $__internal_285eab15d8177682f50f7af7592dd2923e6921be1677cbf87c04f4d6e7fa71af->leave($__internal_285eab15d8177682f50f7af7592dd2923e6921be1677cbf87c04f4d6e7fa71af_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_8727921efa17537a568b8f895fdbdb9f30f27e87850e46f87346586438c05a0b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8727921efa17537a568b8f895fdbdb9f30f27e87850e46f87346586438c05a0b->enter($__internal_8727921efa17537a568b8f895fdbdb9f30f27e87850e46f87346586438c05a0b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_9746d2ff828bacc1121169231b7cec45dd0b3242ec6070bcdfa9c7846666a7c0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9746d2ff828bacc1121169231b7cec45dd0b3242ec6070bcdfa9c7846666a7c0->enter($__internal_9746d2ff828bacc1121169231b7cec45dd0b3242ec6070bcdfa9c7846666a7c0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) || array_key_exists("token", $context) ? $context["token"] : (function () { throw new Twig_Error_Runtime('Variable "token" does not exist.', 13, $this->getSourceContext()); })()))));
        echo "
";
        
        $__internal_9746d2ff828bacc1121169231b7cec45dd0b3242ec6070bcdfa9c7846666a7c0->leave($__internal_9746d2ff828bacc1121169231b7cec45dd0b3242ec6070bcdfa9c7846666a7c0_prof);

        
        $__internal_8727921efa17537a568b8f895fdbdb9f30f27e87850e46f87346586438c05a0b->leave($__internal_8727921efa17537a568b8f895fdbdb9f30f27e87850e46f87346586438c05a0b_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/router.html.twig");
    }
}
