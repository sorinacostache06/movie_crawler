<?php

/* :Components:popup.html.twig */
class __TwigTemplate_69d3dc931834e1afb34ed84ad8d0207db031ae8b550b6ec7bff47e005816bab7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d63b373ef4b4d1cf72e430531b1aaabf2f85773566ebd7d4807186ba2b2a8a23 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d63b373ef4b4d1cf72e430531b1aaabf2f85773566ebd7d4807186ba2b2a8a23->enter($__internal_d63b373ef4b4d1cf72e430531b1aaabf2f85773566ebd7d4807186ba2b2a8a23_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Components:popup.html.twig"));

        $__internal_6484ea3c8536e48d2074ca44ba9562cd3968d6403ddb8f78dc0deea3264c0c29 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6484ea3c8536e48d2074ca44ba9562cd3968d6403ddb8f78dc0deea3264c0c29->enter($__internal_6484ea3c8536e48d2074ca44ba9562cd3968d6403ddb8f78dc0deea3264c0c29_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Components:popup.html.twig"));

        // line 1
        echo "<a href=\"#myModal_";
        echo twig_escape_filter($this->env, (isset($context["type"]) || array_key_exists("type", $context) ? $context["type"] : (function () { throw new Twig_Error_Runtime('Variable "type" does not exist.', 1, $this->getSourceContext()); })()), "html", null, true);
        echo "_";
        echo twig_escape_filter($this->env, (isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new Twig_Error_Runtime('Variable "id" does not exist.', 1, $this->getSourceContext()); })()), "html", null, true);
        echo "\"
   role=\"button\"
   class=\"btn btn-";
        // line 3
        echo twig_escape_filter($this->env, (isset($context["color"]) || array_key_exists("color", $context) ? $context["color"] : (function () { throw new Twig_Error_Runtime('Variable "color" does not exist.', 3, $this->getSourceContext()); })()), "html", null, true);
        echo " btn-flat\"
   data-toggle=\"modal\"
   title=\"Tooltip Dummy Text\">";
        // line 5
        echo (isset($context["button"]) || array_key_exists("button", $context) ? $context["button"] : (function () { throw new Twig_Error_Runtime('Variable "button" does not exist.', 5, $this->getSourceContext()); })());
        echo "
</a>
<div id=\"myModal_";
        // line 7
        echo twig_escape_filter($this->env, (isset($context["type"]) || array_key_exists("type", $context) ? $context["type"] : (function () { throw new Twig_Error_Runtime('Variable "type" does not exist.', 7, $this->getSourceContext()); })()), "html", null, true);
        echo "_";
        echo twig_escape_filter($this->env, (isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new Twig_Error_Runtime('Variable "id" does not exist.', 7, $this->getSourceContext()); })()), "html", null, true);
        echo "\" class=\"modal fade\" role=\"dialog\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\">×</button>
            </div>
            <div class=\"modal-body\">
                <div class=\"modal-body\">
                    ";
        // line 15
        $context["message"] = ("popup." . (isset($context["type"]) || array_key_exists("type", $context) ? $context["type"] : (function () { throw new Twig_Error_Runtime('Variable "type" does not exist.', 15, $this->getSourceContext()); })()));
        // line 16
        echo "                    <p>";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans((isset($context["message"]) || array_key_exists("message", $context) ? $context["message"] : (function () { throw new Twig_Error_Runtime('Variable "message" does not exist.', 16, $this->getSourceContext()); })())), "html", null, true);
        echo "</p>
                </div>
                <div class=\"modal-footer\">
                    <button type=\"submit\" class=\"btn btn-primary\" formaction=\"";
        // line 19
        echo twig_escape_filter($this->env, (isset($context["action"]) || array_key_exists("action", $context) ? $context["action"] : (function () { throw new Twig_Error_Runtime('Variable "action" does not exist.', 19, $this->getSourceContext()); })()), "html", null, true);
        echo "\">
                        ";
        // line 20
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("popup.accept"), "html", null, true);
        echo "
                    </button>
                    <button type=\"button\" class=\"btn btn-default pull-left\" data-dismiss=\"modal\">
                        ";
        // line 23
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("popup.close"), "html", null, true);
        echo "
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>
";
        // line 30
        $this->displayBlock('javascripts', $context, $blocks);
        
        $__internal_d63b373ef4b4d1cf72e430531b1aaabf2f85773566ebd7d4807186ba2b2a8a23->leave($__internal_d63b373ef4b4d1cf72e430531b1aaabf2f85773566ebd7d4807186ba2b2a8a23_prof);

        
        $__internal_6484ea3c8536e48d2074ca44ba9562cd3968d6403ddb8f78dc0deea3264c0c29->leave($__internal_6484ea3c8536e48d2074ca44ba9562cd3968d6403ddb8f78dc0deea3264c0c29_prof);

    }

    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_5dd2facaee2f07e66e226f92c0b96c7e6894eeeee77f614d8b20f782ad92ab00 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5dd2facaee2f07e66e226f92c0b96c7e6894eeeee77f614d8b20f782ad92ab00->enter($__internal_5dd2facaee2f07e66e226f92c0b96c7e6894eeeee77f614d8b20f782ad92ab00_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_db02562d2b016fa308f1540760451f3e9b392566eeeeb83c97c5afa73f173027 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_db02562d2b016fa308f1540760451f3e9b392566eeeeb83c97c5afa73f173027->enter($__internal_db02562d2b016fa308f1540760451f3e9b392566eeeeb83c97c5afa73f173027_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 31
        echo "    <script>
        \$(document).ready(function(){
            \$(\"body\").tooltip({ selector: '[modal]' });
        });
    </script>
";
        
        $__internal_db02562d2b016fa308f1540760451f3e9b392566eeeeb83c97c5afa73f173027->leave($__internal_db02562d2b016fa308f1540760451f3e9b392566eeeeb83c97c5afa73f173027_prof);

        
        $__internal_5dd2facaee2f07e66e226f92c0b96c7e6894eeeee77f614d8b20f782ad92ab00->leave($__internal_5dd2facaee2f07e66e226f92c0b96c7e6894eeeee77f614d8b20f782ad92ab00_prof);

    }

    public function getTemplateName()
    {
        return ":Components:popup.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  104 => 31,  86 => 30,  76 => 23,  70 => 20,  66 => 19,  59 => 16,  57 => 15,  44 => 7,  39 => 5,  34 => 3,  26 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<a href=\"#myModal_{{ type }}_{{ id }}\"
   role=\"button\"
   class=\"btn btn-{{ color }} btn-flat\"
   data-toggle=\"modal\"
   title=\"Tooltip Dummy Text\">{{ button|raw }}
</a>
<div id=\"myModal_{{ type }}_{{ id }}\" class=\"modal fade\" role=\"dialog\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\">×</button>
            </div>
            <div class=\"modal-body\">
                <div class=\"modal-body\">
                    {% set message = 'popup.'~type %}
                    <p>{{ message|trans }}</p>
                </div>
                <div class=\"modal-footer\">
                    <button type=\"submit\" class=\"btn btn-primary\" formaction=\"{{ action }}\">
                        {{ 'popup.accept'|trans }}
                    </button>
                    <button type=\"button\" class=\"btn btn-default pull-left\" data-dismiss=\"modal\">
                        {{ 'popup.close'|trans }}
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>
{% block javascripts %}
    <script>
        \$(document).ready(function(){
            \$(\"body\").tooltip({ selector: '[modal]' });
        });
    </script>
{% endblock %}", ":Components:popup.html.twig", "/home/sorina/Documents/work/movies_crowler/app/Resources/views/Components/popup.html.twig");
    }
}
