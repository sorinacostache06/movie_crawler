<?php

/* TwigBundle:Exception:exception.css.twig */
class __TwigTemplate_6e25e8c8f49bb567fdceceb803ed1a31368c5042174bcc2260d8cb04cf7d1aaa extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_89b0705e46cc15d94932744051949c0f6f269e7c334baa91b4f32c5bd9b136fc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_89b0705e46cc15d94932744051949c0f6f269e7c334baa91b4f32c5bd9b136fc->enter($__internal_89b0705e46cc15d94932744051949c0f6f269e7c334baa91b4f32c5bd9b136fc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.css.twig"));

        $__internal_1babe944267d48276ad5e9ff25c5306f55e802de1ae9a712d621d8fb3463985a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1babe944267d48276ad5e9ff25c5306f55e802de1ae9a712d621d8fb3463985a->enter($__internal_1babe944267d48276ad5e9ff25c5306f55e802de1ae9a712d621d8fb3463985a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        $this->loadTemplate("@Twig/Exception/exception.txt.twig", "TwigBundle:Exception:exception.css.twig", 2)->display(array_merge($context, array("exception" => (isset($context["exception"]) || array_key_exists("exception", $context) ? $context["exception"] : (function () { throw new Twig_Error_Runtime('Variable "exception" does not exist.', 2, $this->getSourceContext()); })()))));
        // line 3
        echo "*/
";
        
        $__internal_89b0705e46cc15d94932744051949c0f6f269e7c334baa91b4f32c5bd9b136fc->leave($__internal_89b0705e46cc15d94932744051949c0f6f269e7c334baa91b4f32c5bd9b136fc_prof);

        
        $__internal_1babe944267d48276ad5e9ff25c5306f55e802de1ae9a712d621d8fb3463985a->leave($__internal_1babe944267d48276ad5e9ff25c5306f55e802de1ae9a712d621d8fb3463985a_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  30 => 3,  28 => 2,  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{% include '@Twig/Exception/exception.txt.twig' with { 'exception': exception } %}
*/
", "TwigBundle:Exception:exception.css.twig", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/exception.css.twig");
    }
}
