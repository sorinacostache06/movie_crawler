<?php

/* ::base-layout.html.twig */
class __TwigTemplate_8a68661cc3736ca54c4d7f2fa414d28304984401dfbe3a6fa9fc1d2eeb552523 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("AvanzuAdminThemeBundle:layout:base-layout.html.twig", "::base-layout.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'flashBag' => array($this, 'block_flashBag'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'avanzu_navbar' => array($this, 'block_avanzu_navbar'),
            'avanzu_sidebar' => array($this, 'block_avanzu_sidebar'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "AvanzuAdminThemeBundle:layout:base-layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fb7f1e2ba096eb0d6099947b729a7c77f07a4f0408dcc758f250715d1f6d9e1f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fb7f1e2ba096eb0d6099947b729a7c77f07a4f0408dcc758f250715d1f6d9e1f->enter($__internal_fb7f1e2ba096eb0d6099947b729a7c77f07a4f0408dcc758f250715d1f6d9e1f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base-layout.html.twig"));

        $__internal_bca272dfdfa1cc4d81fa1f4c1652f0ecfb425056357b4e356fd11637c633da4d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bca272dfdfa1cc4d81fa1f4c1652f0ecfb425056357b4e356fd11637c633da4d->enter($__internal_bca272dfdfa1cc4d81fa1f4c1652f0ecfb425056357b4e356fd11637c633da4d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base-layout.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_fb7f1e2ba096eb0d6099947b729a7c77f07a4f0408dcc758f250715d1f6d9e1f->leave($__internal_fb7f1e2ba096eb0d6099947b729a7c77f07a4f0408dcc758f250715d1f6d9e1f_prof);

        
        $__internal_bca272dfdfa1cc4d81fa1f4c1652f0ecfb425056357b4e356fd11637c633da4d->leave($__internal_bca272dfdfa1cc4d81fa1f4c1652f0ecfb425056357b4e356fd11637c633da4d_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_fe7c407832a91f1e14a4c2e3f8705a8150f37e5859ccae340dfb994929faecdd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fe7c407832a91f1e14a4c2e3f8705a8150f37e5859ccae340dfb994929faecdd->enter($__internal_fe7c407832a91f1e14a4c2e3f8705a8150f37e5859ccae340dfb994929faecdd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_9250ae2e1cefa87d77154600a036e0e0da72dfe9eb5d50cb2323fb6e87e2984a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9250ae2e1cefa87d77154600a036e0e0da72dfe9eb5d50cb2323fb6e87e2984a->enter($__internal_9250ae2e1cefa87d77154600a036e0e0da72dfe9eb5d50cb2323fb6e87e2984a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 4
        echo "    Movies Crawler
";
        
        $__internal_9250ae2e1cefa87d77154600a036e0e0da72dfe9eb5d50cb2323fb6e87e2984a->leave($__internal_9250ae2e1cefa87d77154600a036e0e0da72dfe9eb5d50cb2323fb6e87e2984a_prof);

        
        $__internal_fe7c407832a91f1e14a4c2e3f8705a8150f37e5859ccae340dfb994929faecdd->leave($__internal_fe7c407832a91f1e14a4c2e3f8705a8150f37e5859ccae340dfb994929faecdd_prof);

    }

    // line 6
    public function block_flashBag($context, array $blocks = array())
    {
        $__internal_0593298045eab989de4e824ba934a4cab2b5cf530a7e0b3b073fcd1fbf72ad5e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0593298045eab989de4e824ba934a4cab2b5cf530a7e0b3b073fcd1fbf72ad5e->enter($__internal_0593298045eab989de4e824ba934a4cab2b5cf530a7e0b3b073fcd1fbf72ad5e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "flashBag"));

        $__internal_e58978f95fcd726de5d45ec9d15488b86da1745bcf63162a41b1922b8f05eb56 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e58978f95fcd726de5d45ec9d15488b86da1745bcf63162a41b1922b8f05eb56->enter($__internal_e58978f95fcd726de5d45ec9d15488b86da1745bcf63162a41b1922b8f05eb56_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "flashBag"));

        // line 7
        echo "    ";
        $this->loadTemplate("::flashBag.html.twig", "::base-layout.html.twig", 7)->display($context);
        
        $__internal_e58978f95fcd726de5d45ec9d15488b86da1745bcf63162a41b1922b8f05eb56->leave($__internal_e58978f95fcd726de5d45ec9d15488b86da1745bcf63162a41b1922b8f05eb56_prof);

        
        $__internal_0593298045eab989de4e824ba934a4cab2b5cf530a7e0b3b073fcd1fbf72ad5e->leave($__internal_0593298045eab989de4e824ba934a4cab2b5cf530a7e0b3b073fcd1fbf72ad5e_prof);

    }

    // line 9
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_c0b125c29aaca9b7cd15ac0b6127f153234d08e38851ee69c090135c23cb7771 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c0b125c29aaca9b7cd15ac0b6127f153234d08e38851ee69c090135c23cb7771->enter($__internal_c0b125c29aaca9b7cd15ac0b6127f153234d08e38851ee69c090135c23cb7771_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_9e7b8dd78da6177b1c0e5cc57ce16ad17ae1b006e97c4ed2d499eeab59bca1c2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9e7b8dd78da6177b1c0e5cc57ce16ad17ae1b006e97c4ed2d499eeab59bca1c2->enter($__internal_9e7b8dd78da6177b1c0e5cc57ce16ad17ae1b006e97c4ed2d499eeab59bca1c2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 10
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
    <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css\">
    <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.css\" />
    <link rel=\"stylesheet\" href=\"//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css\">
";
        
        $__internal_9e7b8dd78da6177b1c0e5cc57ce16ad17ae1b006e97c4ed2d499eeab59bca1c2->leave($__internal_9e7b8dd78da6177b1c0e5cc57ce16ad17ae1b006e97c4ed2d499eeab59bca1c2_prof);

        
        $__internal_c0b125c29aaca9b7cd15ac0b6127f153234d08e38851ee69c090135c23cb7771->leave($__internal_c0b125c29aaca9b7cd15ac0b6127f153234d08e38851ee69c090135c23cb7771_prof);

    }

    // line 15
    public function block_avanzu_navbar($context, array $blocks = array())
    {
        $__internal_946650611ebe118b559b2a959adb298e2f3922c1a7fa4eaaa3976b7feec524bc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_946650611ebe118b559b2a959adb298e2f3922c1a7fa4eaaa3976b7feec524bc->enter($__internal_946650611ebe118b559b2a959adb298e2f3922c1a7fa4eaaa3976b7feec524bc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "avanzu_navbar"));

        $__internal_c7120829750ff3f3996d36ba21c4dc4ae7b32adc2f6d0522d6d6b65561a5d74a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c7120829750ff3f3996d36ba21c4dc4ae7b32adc2f6d0522d6d6b65561a5d74a->enter($__internal_c7120829750ff3f3996d36ba21c4dc4ae7b32adc2f6d0522d6d6b65561a5d74a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "avanzu_navbar"));

        // line 16
        echo "    <div class=\"navbar-custom-menu\">
        <ul class=\"nav navbar-nav\">
            <li class=\"dropdown user user-menu\">
                <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">
                    <img src=\"https://image.freepik.com/free-icon/question-mark_318-52837.jpg\" class=\"user-image\" alt=\"User Image\">
                    <span class=\"hidden-xs\">";
        // line 21
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 21, $this->getSourceContext()); })()), "user", array()), "username", array()), "html", null, true);
        echo "</span>
                </a>
                <ul class=\"dropdown-menu\">
                    <li class=\"user-header\">
                        <img src=\"https://image.freepik.com/free-icon/question-mark_318-52837.jpg\" class=\"img-circle\" alt=\"User Image\">
                        <p>
                            ";
        // line 27
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 27, $this->getSourceContext()); })()), "user", array()), "username", array()), "html", null, true);
        echo "
                            <small>Member since ";
        // line 28
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 28, $this->getSourceContext()); })()), "user", array()), "joinDate", array()), "d/m/Y"), "html", null, true);
        echo "</small>
                        </p>
                    </li>
                    <li class=\"user-footer\">
                        <div class=\"fa-align-center\">
                            <a href=";
        // line 33
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("logout");
        echo "#\" class=\"btn btn-default btn-flat\">Sign out</a>
                        </div>
                    </li>
                </ul>
            </li>
        </ul>
    </div>
";
        
        $__internal_c7120829750ff3f3996d36ba21c4dc4ae7b32adc2f6d0522d6d6b65561a5d74a->leave($__internal_c7120829750ff3f3996d36ba21c4dc4ae7b32adc2f6d0522d6d6b65561a5d74a_prof);

        
        $__internal_946650611ebe118b559b2a959adb298e2f3922c1a7fa4eaaa3976b7feec524bc->leave($__internal_946650611ebe118b559b2a959adb298e2f3922c1a7fa4eaaa3976b7feec524bc_prof);

    }

    // line 41
    public function block_avanzu_sidebar($context, array $blocks = array())
    {
        $__internal_44f2466ad442d5e77593d7ee96eeedf921674ae9727a87d4465fc697b077b39b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_44f2466ad442d5e77593d7ee96eeedf921674ae9727a87d4465fc697b077b39b->enter($__internal_44f2466ad442d5e77593d7ee96eeedf921674ae9727a87d4465fc697b077b39b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "avanzu_sidebar"));

        $__internal_00231ada88ca1dbf2a4568b0aca3b04396b273fe60cd15cd91ae11956a46852d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_00231ada88ca1dbf2a4568b0aca3b04396b273fe60cd15cd91ae11956a46852d->enter($__internal_00231ada88ca1dbf2a4568b0aca3b04396b273fe60cd15cd91ae11956a46852d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "avanzu_sidebar"));

        // line 42
        echo "    <ul class=\"sidebar-menu\">
        <li class=\"header\">";
        // line 43
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("sidebar.navigation.main_navigation"), "html", null, true);
        echo "</li>
        <li><a href=\"";
        // line 44
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("home");
        echo "\"><i class=\"fa fa-home\"></i>";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("sidebar.navigation.home"), "html", null, true);
        echo "</a></li>
        <li><a href=\"";
        // line 45
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("want_to_watch");
        echo "\"><i class=\"fa fa fa-file-movie-o\"></i>";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("sidebar.navigation.wanttowatch"), "html", null, true);
        echo "</a></li>
        ";
        // line 47
        echo "        <li><a href=\"";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("movie_management_list");
        echo "\"><i class=\"fa fa fa-file-movie-o\"></i>";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("sidebar.navigation.movie_managementc"), "html", null, true);
        echo "</a></li>
        <li class=\"";
        // line 48
        if ((twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 48, $this->getSourceContext()); })()), "request", array()), "get", array(0 => "_route"), "method") == "user_management_list")) {
            echo "active";
        }
        echo "\">
            <a href=\"";
        // line 49
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_management_list");
        echo "\"><i class=\"fa fa fa-file-movie-o\"></i>";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("sidebar.navigation.user_management"), "html", null, true);
        echo "</a> </li>        <li><a href=\"";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("logout");
        echo "\"><i class=\"fa fa-cog\"></i>";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("sidebar.logout"), "html", null, true);
        echo "</a></li>
        <li class=\"treeview\">
            <a href=\"#\"><i class=\"fa fa-language\"></i>";
        // line 51
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("sidebar.navigation.language"), "html", null, true);
        echo "</a>
            <ul class=\"treeview-menu\" style=\"display: none;\">
                <li><a href=\"";
        // line 53
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("switch_locale", array("locale" => "ro"));
        echo "\"><i class=\"fa fa-circle-o\"></i>";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("sidebar.navigation.language.ro"), "html", null, true);
        echo "</a></li>
                <li><a href=\"";
        // line 54
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("switch_locale", array("locale" => "en"));
        echo "\"><i class=\"fa fa-circle-o\"></i>";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("sidebar.navigation.language.en"), "html", null, true);
        echo "</a></li>
            </ul>
        </li>
    </ul>
";
        
        $__internal_00231ada88ca1dbf2a4568b0aca3b04396b273fe60cd15cd91ae11956a46852d->leave($__internal_00231ada88ca1dbf2a4568b0aca3b04396b273fe60cd15cd91ae11956a46852d_prof);

        
        $__internal_44f2466ad442d5e77593d7ee96eeedf921674ae9727a87d4465fc697b077b39b->leave($__internal_44f2466ad442d5e77593d7ee96eeedf921674ae9727a87d4465fc697b077b39b_prof);

    }

    // line 60
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_3e11824bc4e921e20023cee69e7052b6ac9e630bf90daad084fe27b3edc0bf74 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3e11824bc4e921e20023cee69e7052b6ac9e630bf90daad084fe27b3edc0bf74->enter($__internal_3e11824bc4e921e20023cee69e7052b6ac9e630bf90daad084fe27b3edc0bf74_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_3bdf9ebb27d8333d419d8b314bc1fe31a518112d73fd8139902309c1be0f269b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3bdf9ebb27d8333d419d8b314bc1fe31a518112d73fd8139902309c1be0f269b->enter($__internal_3bdf9ebb27d8333d419d8b314bc1fe31a518112d73fd8139902309c1be0f269b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 61
        echo "    ";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.42/js/bootstrap-datetimepicker.min.js\"></script>
";
        
        $__internal_3bdf9ebb27d8333d419d8b314bc1fe31a518112d73fd8139902309c1be0f269b->leave($__internal_3bdf9ebb27d8333d419d8b314bc1fe31a518112d73fd8139902309c1be0f269b_prof);

        
        $__internal_3e11824bc4e921e20023cee69e7052b6ac9e630bf90daad084fe27b3edc0bf74->leave($__internal_3e11824bc4e921e20023cee69e7052b6ac9e630bf90daad084fe27b3edc0bf74_prof);

    }

    public function getTemplateName()
    {
        return "::base-layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  254 => 61,  245 => 60,  228 => 54,  222 => 53,  217 => 51,  206 => 49,  200 => 48,  193 => 47,  187 => 45,  181 => 44,  177 => 43,  174 => 42,  165 => 41,  147 => 33,  139 => 28,  135 => 27,  126 => 21,  119 => 16,  110 => 15,  94 => 10,  85 => 9,  74 => 7,  65 => 6,  54 => 4,  45 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'AvanzuAdminThemeBundle:layout:base-layout.html.twig' %}

{% block title %}
    Movies Crawler
{% endblock %}
{% block flashBag %}
    {% include '::flashBag.html.twig' %}
{% endblock %}
{% block stylesheets %}
    {{ parent() }}
    <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css\">
    <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.css\" />
    <link rel=\"stylesheet\" href=\"//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css\">
{% endblock %}
{% block avanzu_navbar %}
    <div class=\"navbar-custom-menu\">
        <ul class=\"nav navbar-nav\">
            <li class=\"dropdown user user-menu\">
                <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">
                    <img src=\"https://image.freepik.com/free-icon/question-mark_318-52837.jpg\" class=\"user-image\" alt=\"User Image\">
                    <span class=\"hidden-xs\">{{ app.user.username }}</span>
                </a>
                <ul class=\"dropdown-menu\">
                    <li class=\"user-header\">
                        <img src=\"https://image.freepik.com/free-icon/question-mark_318-52837.jpg\" class=\"img-circle\" alt=\"User Image\">
                        <p>
                            {{ app.user.username}}
                            <small>Member since {{ app.user.joinDate|date(\"d/m/Y\") }}</small>
                        </p>
                    </li>
                    <li class=\"user-footer\">
                        <div class=\"fa-align-center\">
                            <a href={{ path('logout') }}#\" class=\"btn btn-default btn-flat\">Sign out</a>
                        </div>
                    </li>
                </ul>
            </li>
        </ul>
    </div>
{% endblock %}
{% block avanzu_sidebar %}
    <ul class=\"sidebar-menu\">
        <li class=\"header\">{{ 'sidebar.navigation.main_navigation'|trans }}</li>
        <li><a href=\"{{ path('home') }}\"><i class=\"fa fa-home\"></i>{{ 'sidebar.navigation.home'|trans }}</a></li>
        <li><a href=\"{{ path('want_to_watch') }}\"><i class=\"fa fa fa-file-movie-o\"></i>{{ 'sidebar.navigation.wanttowatch'|trans }}</a></li>
        {#<li><a href=\"{{ path('user_management_list') }}\"><i class=\"fa fa fa-file-movie-o\"></i>{{ 'sidebar.navigation.user_management'|trans }}</a></li>#}
        <li><a href=\"{{ path('movie_management_list') }}\"><i class=\"fa fa fa-file-movie-o\"></i>{{ 'sidebar.navigation.movie_managementc'|trans }}</a></li>
        <li class=\"{% if app.request.get('_route') == 'user_management_list' %}active{% endif %}\">
            <a href=\"{{ path('user_management_list') }}\"><i class=\"fa fa fa-file-movie-o\"></i>{{ 'sidebar.navigation.user_management'|trans }}</a> </li>        <li><a href=\"{{ path('logout') }}\"><i class=\"fa fa-cog\"></i>{{ 'sidebar.logout'|trans }}</a></li>
        <li class=\"treeview\">
            <a href=\"#\"><i class=\"fa fa-language\"></i>{{ 'sidebar.navigation.language'|trans }}</a>
            <ul class=\"treeview-menu\" style=\"display: none;\">
                <li><a href=\"{{ path('switch_locale', {'locale': 'ro' }) }}\"><i class=\"fa fa-circle-o\"></i>{{ 'sidebar.navigation.language.ro'|trans }}</a></li>
                <li><a href=\"{{ path('switch_locale', {'locale': 'en' }) }}\"><i class=\"fa fa-circle-o\"></i>{{ 'sidebar.navigation.language.en'|trans }}</a></li>
            </ul>
        </li>
    </ul>
{% endblock %}

{% block javascripts %}
    {{ parent() }}
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.42/js/bootstrap-datetimepicker.min.js\"></script>
{% endblock %}", "::base-layout.html.twig", "/home/sorina/Documents/work/movies_crowler/app/Resources/views/base-layout.html.twig");
    }
}
