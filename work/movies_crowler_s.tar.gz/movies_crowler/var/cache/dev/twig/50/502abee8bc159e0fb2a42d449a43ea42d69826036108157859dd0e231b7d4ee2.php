<?php

/* @Framework/FormTable/form_widget_compound.html.php */
class __TwigTemplate_ff22f877a3c45968a5803e5eb1654e495089abc2e08794087e303dcb63d754b6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_60b6f74a285704e47e286bac40ca5f2fda273bcc3864fe4c1190a44e0bed9278 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_60b6f74a285704e47e286bac40ca5f2fda273bcc3864fe4c1190a44e0bed9278->enter($__internal_60b6f74a285704e47e286bac40ca5f2fda273bcc3864fe4c1190a44e0bed9278_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_widget_compound.html.php"));

        $__internal_7f3d50329161d07ed80094cad49d4f7558641ecc1ef70c3e64b9f2f94d5a5ac7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7f3d50329161d07ed80094cad49d4f7558641ecc1ef70c3e64b9f2f94d5a5ac7->enter($__internal_7f3d50329161d07ed80094cad49d4f7558641ecc1ef70c3e64b9f2f94d5a5ac7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_widget_compound.html.php"));

        // line 1
        echo "<table <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <tr>
        <td colspan=\"2\">
            <?php echo \$view['form']->errors(\$form) ?>
        </td>
    </tr>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</table>
";
        
        $__internal_60b6f74a285704e47e286bac40ca5f2fda273bcc3864fe4c1190a44e0bed9278->leave($__internal_60b6f74a285704e47e286bac40ca5f2fda273bcc3864fe4c1190a44e0bed9278_prof);

        
        $__internal_7f3d50329161d07ed80094cad49d4f7558641ecc1ef70c3e64b9f2f94d5a5ac7->leave($__internal_7f3d50329161d07ed80094cad49d4f7558641ecc1ef70c3e64b9f2f94d5a5ac7_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_widget_compound.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<table <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <tr>
        <td colspan=\"2\">
            <?php echo \$view['form']->errors(\$form) ?>
        </td>
    </tr>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</table>
", "@Framework/FormTable/form_widget_compound.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/FormTable/form_widget_compound.html.php");
    }
}
