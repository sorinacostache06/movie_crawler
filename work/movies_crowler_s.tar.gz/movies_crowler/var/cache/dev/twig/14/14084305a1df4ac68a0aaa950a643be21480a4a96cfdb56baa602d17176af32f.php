<?php

/* @Framework/Form/form_widget_compound.html.php */
class __TwigTemplate_2535da40fa7aa66b8d797a55e81bb14ef63e64f8f2e5216966c719650f6a86dd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b2c56eadd665b2c2a53dd34e2c3456b19262f2d81b98f87cc582790b6e20f9d7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b2c56eadd665b2c2a53dd34e2c3456b19262f2d81b98f87cc582790b6e20f9d7->enter($__internal_b2c56eadd665b2c2a53dd34e2c3456b19262f2d81b98f87cc582790b6e20f9d7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_compound.html.php"));

        $__internal_9a78cc630928fd04ed76f220fee4c9424da8b3983f055b84c4c91f81b1097d21 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9a78cc630928fd04ed76f220fee4c9424da8b3983f055b84c4c91f81b1097d21->enter($__internal_9a78cc630928fd04ed76f220fee4c9424da8b3983f055b84c4c91f81b1097d21_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_compound.html.php"));

        // line 1
        echo "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</div>
";
        
        $__internal_b2c56eadd665b2c2a53dd34e2c3456b19262f2d81b98f87cc582790b6e20f9d7->leave($__internal_b2c56eadd665b2c2a53dd34e2c3456b19262f2d81b98f87cc582790b6e20f9d7_prof);

        
        $__internal_9a78cc630928fd04ed76f220fee4c9424da8b3983f055b84c4c91f81b1097d21->leave($__internal_9a78cc630928fd04ed76f220fee4c9424da8b3983f055b84c4c91f81b1097d21_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget_compound.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</div>
", "@Framework/Form/form_widget_compound.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_widget_compound.html.php");
    }
}
