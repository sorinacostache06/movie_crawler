<?php

/* :Admin:movie_manage_list.html.twig */
class __TwigTemplate_e2b9c70f36f64586f1833c7e094f4849d0ffac39e1774a28185dc18e6e86506d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base-layout.html.twig", ":Admin:movie_manage_list.html.twig", 1);
        $this->blocks = array(
            'page_title' => array($this, 'block_page_title'),
            'page_subtitle' => array($this, 'block_page_subtitle'),
            'page_content' => array($this, 'block_page_content'),
            'flashBag' => array($this, 'block_flashBag'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base-layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9d7ca2871b4b05f71e7442fe7b6ccdd8bebd2abcde96c56a9e149a26af719764 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9d7ca2871b4b05f71e7442fe7b6ccdd8bebd2abcde96c56a9e149a26af719764->enter($__internal_9d7ca2871b4b05f71e7442fe7b6ccdd8bebd2abcde96c56a9e149a26af719764_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Admin:movie_manage_list.html.twig"));

        $__internal_1eaf67f90f0a72a10073a69e362f858f32672c9bfc60ac9d00a62f6765cd75ea = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1eaf67f90f0a72a10073a69e362f858f32672c9bfc60ac9d00a62f6765cd75ea->enter($__internal_1eaf67f90f0a72a10073a69e362f858f32672c9bfc60ac9d00a62f6765cd75ea_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Admin:movie_manage_list.html.twig"));

        // line 2
        ob_start();
        // line 3
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["manageForm"]) || array_key_exists("manageForm", $context) ? $context["manageForm"] : (function () { throw new Twig_Error_Runtime('Variable "manageForm" does not exist.', 3, $this->getSourceContext()); })()), "_token", array()), 'row', array("id" => "#id#"));
        echo "
";
        $context["form_token"] = ('' === $tmp = ob_get_clean()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        // line 1
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9d7ca2871b4b05f71e7442fe7b6ccdd8bebd2abcde96c56a9e149a26af719764->leave($__internal_9d7ca2871b4b05f71e7442fe7b6ccdd8bebd2abcde96c56a9e149a26af719764_prof);

        
        $__internal_1eaf67f90f0a72a10073a69e362f858f32672c9bfc60ac9d00a62f6765cd75ea->leave($__internal_1eaf67f90f0a72a10073a69e362f858f32672c9bfc60ac9d00a62f6765cd75ea_prof);

    }

    // line 5
    public function block_page_title($context, array $blocks = array())
    {
        $__internal_97cb32e5035f5dea4255e946d9c66c5fb206212a3d577f491d070a0341297484 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_97cb32e5035f5dea4255e946d9c66c5fb206212a3d577f491d070a0341297484->enter($__internal_97cb32e5035f5dea4255e946d9c66c5fb206212a3d577f491d070a0341297484_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_title"));

        $__internal_9a1d1c1b242001ea262c212d214d7cda65102dc5fd88cf6b18e7a37bb00f5add = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9a1d1c1b242001ea262c212d214d7cda65102dc5fd88cf6b18e7a37bb00f5add->enter($__internal_9a1d1c1b242001ea262c212d214d7cda65102dc5fd88cf6b18e7a37bb00f5add_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_title"));

        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("navigation.management_group.title"), "html", null, true);
        
        $__internal_9a1d1c1b242001ea262c212d214d7cda65102dc5fd88cf6b18e7a37bb00f5add->leave($__internal_9a1d1c1b242001ea262c212d214d7cda65102dc5fd88cf6b18e7a37bb00f5add_prof);

        
        $__internal_97cb32e5035f5dea4255e946d9c66c5fb206212a3d577f491d070a0341297484->leave($__internal_97cb32e5035f5dea4255e946d9c66c5fb206212a3d577f491d070a0341297484_prof);

    }

    // line 6
    public function block_page_subtitle($context, array $blocks = array())
    {
        $__internal_ad4059ed821939640431ce15083af654cfab90523d3bd5b3a8b0a8d0a53ff141 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ad4059ed821939640431ce15083af654cfab90523d3bd5b3a8b0a8d0a53ff141->enter($__internal_ad4059ed821939640431ce15083af654cfab90523d3bd5b3a8b0a8d0a53ff141_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_subtitle"));

        $__internal_a5ebdfcb8705d013a189ce7740ad8042d5de0a9a34def2e3dd10a0bb51d79f39 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a5ebdfcb8705d013a189ce7740ad8042d5de0a9a34def2e3dd10a0bb51d79f39->enter($__internal_a5ebdfcb8705d013a189ce7740ad8042d5de0a9a34def2e3dd10a0bb51d79f39_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_subtitle"));

        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("navigation.management_group.subtitle"), "html", null, true);
        
        $__internal_a5ebdfcb8705d013a189ce7740ad8042d5de0a9a34def2e3dd10a0bb51d79f39->leave($__internal_a5ebdfcb8705d013a189ce7740ad8042d5de0a9a34def2e3dd10a0bb51d79f39_prof);

        
        $__internal_ad4059ed821939640431ce15083af654cfab90523d3bd5b3a8b0a8d0a53ff141->leave($__internal_ad4059ed821939640431ce15083af654cfab90523d3bd5b3a8b0a8d0a53ff141_prof);

    }

    // line 7
    public function block_page_content($context, array $blocks = array())
    {
        $__internal_91b0dff4653d0d5a8c08b544eae34b1b8d2d3394c3867479d20d23ee84fa2261 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_91b0dff4653d0d5a8c08b544eae34b1b8d2d3394c3867479d20d23ee84fa2261->enter($__internal_91b0dff4653d0d5a8c08b544eae34b1b8d2d3394c3867479d20d23ee84fa2261_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_content"));

        $__internal_99da6dc96249497244401065c3d9d5c88b828029832d64ca4f84cd6b23ea4ebd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_99da6dc96249497244401065c3d9d5c88b828029832d64ca4f84cd6b23ea4ebd->enter($__internal_99da6dc96249497244401065c3d9d5c88b828029832d64ca4f84cd6b23ea4ebd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_content"));

        // line 8
        echo "    <div class=\"row\">
        <div class=\"col-lg-8 col-md-8 col-lg-offset-2 col-md-offset-2\">
            ";
        // line 10
        $this->displayBlock('flashBag', $context, $blocks);
        // line 13
        echo "        </div>
    </div>
    <div class=\"row\">
        <div class=\"col-lg-10 col-lg-offset-1\">
            <div class=\"box box-info\">
                <div class=\"box-header with-border\">
                    <h3 class=\"box-title\">";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("groups.table.title"), "html", null, true);
        echo "</h3>
                    ";
        // line 21
        echo "                            ";
        // line 22
        echo "                               ";
        // line 23
        echo "                                ";
        // line 24
        echo "                            ";
        // line 25
        echo "                        ";
        // line 26
        echo "                </div>
                <div class=\"box-body\">
                    <table class=\"table table-bordered\">
                        <thead>
                        <tr align=\"center\" style=\"font-weight: bold;\">
                            <td width=\"5%\">";
        // line 31
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("management_group.table.id"), "html", null, true);
        echo "</td>
                            <td width=\"15%\">";
        // line 32
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("management_group.table.name_group"), "html", null, true);
        echo "</td>
                            <td width=\"7%\">Actions</td>
                        </tr>
                        </thead>
                        ";
        // line 36
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["movieManageList"]) || array_key_exists("movieManageList", $context) ? $context["movieManageList"] : (function () { throw new Twig_Error_Runtime('Variable "movieManageList" does not exist.', 36, $this->getSourceContext()); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["group"]) {
            // line 37
            echo "                            <tr role=\"row\" align=\"center\">
                                <td>";
            // line 38
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["group"], "id", array()), "html", null, true);
            echo "</td>
                                <td>";
            // line 39
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["group"], "title", array()), "html", null, true);
            echo "</td>
                                <td>
                                    <span style=\"float: none\">
                                    ";
            // line 42
            echo             $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["manageForm"]) || array_key_exists("manageForm", $context) ? $context["manageForm"] : (function () { throw new Twig_Error_Runtime('Variable "manageForm" does not exist.', 42, $this->getSourceContext()); })()), 'form_start', array("method" => "get"));
            echo "
                                    ";
            // line 43
            echo twig_replace_filter((isset($context["form_token"]) || array_key_exists("form_token", $context) ? $context["form_token"] : (function () { throw new Twig_Error_Runtime('Variable "form_token" does not exist.', 43, $this->getSourceContext()); })()), array("#id#" => ("movie_management__token_" . twig_get_attribute($this->env, $this->getSourceContext(), $context["group"], "id", array()))));
            echo "
                                    <a class=\"btn btn-primary btn-flat\"
                                       href=\"";
            // line 45
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("movie_management_edit", array("id" => twig_get_attribute($this->env, $this->getSourceContext(), $context["group"], "id", array()))), "html", null, true);
            echo "\" title=\"Edit group\">
                                        <i class=\"fa fa-edit\"></i>
                                    </a>
                                    </span>
                                </td>
                            </tr>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['group'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 52
        echo "                    </table>
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_99da6dc96249497244401065c3d9d5c88b828029832d64ca4f84cd6b23ea4ebd->leave($__internal_99da6dc96249497244401065c3d9d5c88b828029832d64ca4f84cd6b23ea4ebd_prof);

        
        $__internal_91b0dff4653d0d5a8c08b544eae34b1b8d2d3394c3867479d20d23ee84fa2261->leave($__internal_91b0dff4653d0d5a8c08b544eae34b1b8d2d3394c3867479d20d23ee84fa2261_prof);

    }

    // line 10
    public function block_flashBag($context, array $blocks = array())
    {
        $__internal_ced730bf9a536ad448aef113c5228f01e2cf52a61431f67efe728be04f58d2fc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ced730bf9a536ad448aef113c5228f01e2cf52a61431f67efe728be04f58d2fc->enter($__internal_ced730bf9a536ad448aef113c5228f01e2cf52a61431f67efe728be04f58d2fc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "flashBag"));

        $__internal_8c3d65a8ed95f3209287ec11ec894a7836f5f1fc723b9c27e0843713117bc668 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8c3d65a8ed95f3209287ec11ec894a7836f5f1fc723b9c27e0843713117bc668->enter($__internal_8c3d65a8ed95f3209287ec11ec894a7836f5f1fc723b9c27e0843713117bc668_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "flashBag"));

        // line 11
        echo "                ";
        $this->displayParentBlock("flashBag", $context, $blocks);
        echo "
            ";
        
        $__internal_8c3d65a8ed95f3209287ec11ec894a7836f5f1fc723b9c27e0843713117bc668->leave($__internal_8c3d65a8ed95f3209287ec11ec894a7836f5f1fc723b9c27e0843713117bc668_prof);

        
        $__internal_ced730bf9a536ad448aef113c5228f01e2cf52a61431f67efe728be04f58d2fc->leave($__internal_ced730bf9a536ad448aef113c5228f01e2cf52a61431f67efe728be04f58d2fc_prof);

    }

    public function getTemplateName()
    {
        return ":Admin:movie_manage_list.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  206 => 11,  197 => 10,  182 => 52,  169 => 45,  164 => 43,  160 => 42,  154 => 39,  150 => 38,  147 => 37,  143 => 36,  136 => 32,  132 => 31,  125 => 26,  123 => 25,  121 => 24,  119 => 23,  117 => 22,  115 => 21,  111 => 19,  103 => 13,  101 => 10,  97 => 8,  88 => 7,  70 => 6,  52 => 5,  42 => 1,  36 => 3,  34 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '::base-layout.html.twig' %}
{% set form_token %}
    {{ form_row(manageForm._token, {'id': \"#id#\"}) }}
{% endset %}
{% block page_title %}{{ 'navigation.management_group.title'|trans }}{% endblock %}
{% block page_subtitle %}{{ 'navigation.management_group.subtitle'|trans }}{% endblock %}
{% block page_content %}
    <div class=\"row\">
        <div class=\"col-lg-8 col-md-8 col-lg-offset-2 col-md-offset-2\">
            {% block flashBag %}
                {{ parent() }}
            {% endblock %}
        </div>
    </div>
    <div class=\"row\">
        <div class=\"col-lg-10 col-lg-offset-1\">
            <div class=\"box box-info\">
                <div class=\"box-header with-border\">
                    <h3 class=\"box-title\">{{ 'groups.table.title'|trans }}</h3>
                    {#<span style=\"float: right\">#}
                            {#<a class=\"btn btn-success btn-flat\"#}
                               {#href=\"{{ path('create_group') }}\" title=\"Create group\">#}
                                {#{{ 'create_new_group.button_create_group'|trans }}#}
                            {#</a>#}
                        {#</span>#}
                </div>
                <div class=\"box-body\">
                    <table class=\"table table-bordered\">
                        <thead>
                        <tr align=\"center\" style=\"font-weight: bold;\">
                            <td width=\"5%\">{{ 'management_group.table.id'|trans }}</td>
                            <td width=\"15%\">{{ 'management_group.table.name_group'|trans }}</td>
                            <td width=\"7%\">Actions</td>
                        </tr>
                        </thead>
                        {% for group in movieManageList %}
                            <tr role=\"row\" align=\"center\">
                                <td>{{ group.id }}</td>
                                <td>{{ group.title }}</td>
                                <td>
                                    <span style=\"float: none\">
                                    {{ form_start(manageForm, { 'method' : 'get'}) }}
                                    {{ form_token|replace({'#id#':'movie_management__token_'~group.id})|raw }}
                                    <a class=\"btn btn-primary btn-flat\"
                                       href=\"{{ path('movie_management_edit', {'id': group.id }) }}\" title=\"Edit group\">
                                        <i class=\"fa fa-edit\"></i>
                                    </a>
                                    </span>
                                </td>
                            </tr>
                        {% endfor %}
                    </table>
                </div>
            </div>
        </div>
    </div>
{% endblock %}", ":Admin:movie_manage_list.html.twig", "/home/sorina/Documents/work/movies_crowler/app/Resources/views/Admin/movie_manage_list.html.twig");
    }
}
