<?php

/* TwigBundle:Exception:error.json.twig */
class __TwigTemplate_e852424769c4171122a458ee5cee2e4f43aa44b51c1e0650ae92795579b6591f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9564aad3776c71daa3db1f9e39aaed5f96f3b8332828bbbde183df153bb3b455 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9564aad3776c71daa3db1f9e39aaed5f96f3b8332828bbbde183df153bb3b455->enter($__internal_9564aad3776c71daa3db1f9e39aaed5f96f3b8332828bbbde183df153bb3b455_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.json.twig"));

        $__internal_607f275d08ca8b8ee0b35c365b500970bbcc8b71a4489f8928cd93b68da0a6b6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_607f275d08ca8b8ee0b35c365b500970bbcc8b71a4489f8928cd93b68da0a6b6->enter($__internal_607f275d08ca8b8ee0b35c365b500970bbcc8b71a4489f8928cd93b68da0a6b6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.json.twig"));

        // line 1
        echo json_encode(array("error" => array("code" => (isset($context["status_code"]) || array_key_exists("status_code", $context) ? $context["status_code"] : (function () { throw new Twig_Error_Runtime('Variable "status_code" does not exist.', 1, $this->getSourceContext()); })()), "message" => (isset($context["status_text"]) || array_key_exists("status_text", $context) ? $context["status_text"] : (function () { throw new Twig_Error_Runtime('Variable "status_text" does not exist.', 1, $this->getSourceContext()); })()))));
        echo "
";
        
        $__internal_9564aad3776c71daa3db1f9e39aaed5f96f3b8332828bbbde183df153bb3b455->leave($__internal_9564aad3776c71daa3db1f9e39aaed5f96f3b8332828bbbde183df153bb3b455_prof);

        
        $__internal_607f275d08ca8b8ee0b35c365b500970bbcc8b71a4489f8928cd93b68da0a6b6->leave($__internal_607f275d08ca8b8ee0b35c365b500970bbcc8b71a4489f8928cd93b68da0a6b6_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ { 'error': { 'code': status_code, 'message': status_text } }|json_encode|raw }}
", "TwigBundle:Exception:error.json.twig", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/error.json.twig");
    }
}
