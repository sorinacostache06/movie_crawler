<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_5a7b6c0b682e1c4f4f88fee8ac1e92419587dfc203684c49043d3a40cad9e26c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7ceb3a80a8fa1309dbe021f6a4847a8a978660cd4ab7d6f991ece60d502bf3ee = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7ceb3a80a8fa1309dbe021f6a4847a8a978660cd4ab7d6f991ece60d502bf3ee->enter($__internal_7ceb3a80a8fa1309dbe021f6a4847a8a978660cd4ab7d6f991ece60d502bf3ee_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        $__internal_9ea0254d5d0a963c9ca79a1800242dbc61cb11e6700993b0cd781484e85c61ba = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9ea0254d5d0a963c9ca79a1800242dbc61cb11e6700993b0cd781484e85c61ba->enter($__internal_9ea0254d5d0a963c9ca79a1800242dbc61cb11e6700993b0cd781484e85c61ba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_7ceb3a80a8fa1309dbe021f6a4847a8a978660cd4ab7d6f991ece60d502bf3ee->leave($__internal_7ceb3a80a8fa1309dbe021f6a4847a8a978660cd4ab7d6f991ece60d502bf3ee_prof);

        
        $__internal_9ea0254d5d0a963c9ca79a1800242dbc61cb11e6700993b0cd781484e85c61ba->leave($__internal_9ea0254d5d0a963c9ca79a1800242dbc61cb11e6700993b0cd781484e85c61ba_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "@Framework/Form/button_label.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/button_label.html.php");
    }
}
