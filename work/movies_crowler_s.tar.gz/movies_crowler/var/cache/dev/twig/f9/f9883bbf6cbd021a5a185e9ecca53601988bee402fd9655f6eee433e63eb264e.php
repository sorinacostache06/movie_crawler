<?php

/* @Framework/FormTable/button_row.html.php */
class __TwigTemplate_85eff6a1862f26d56477c559f201128cf98de680ce4054a606becc97d9a071e4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_82139ed46596bbec63dd17f1a07a7cb20f843573e2da16d4c03ae6ec19d244f7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_82139ed46596bbec63dd17f1a07a7cb20f843573e2da16d4c03ae6ec19d244f7->enter($__internal_82139ed46596bbec63dd17f1a07a7cb20f843573e2da16d4c03ae6ec19d244f7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        $__internal_83212daba3056a4f02099a17aaa5fe277f501771018fe6347bc9060eca1cc7a8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_83212daba3056a4f02099a17aaa5fe277f501771018fe6347bc9060eca1cc7a8->enter($__internal_83212daba3056a4f02099a17aaa5fe277f501771018fe6347bc9060eca1cc7a8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        // line 1
        echo "<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_82139ed46596bbec63dd17f1a07a7cb20f843573e2da16d4c03ae6ec19d244f7->leave($__internal_82139ed46596bbec63dd17f1a07a7cb20f843573e2da16d4c03ae6ec19d244f7_prof);

        
        $__internal_83212daba3056a4f02099a17aaa5fe277f501771018fe6347bc9060eca1cc7a8->leave($__internal_83212daba3056a4f02099a17aaa5fe277f501771018fe6347bc9060eca1cc7a8_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
", "@Framework/FormTable/button_row.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/FormTable/button_row.html.php");
    }
}
