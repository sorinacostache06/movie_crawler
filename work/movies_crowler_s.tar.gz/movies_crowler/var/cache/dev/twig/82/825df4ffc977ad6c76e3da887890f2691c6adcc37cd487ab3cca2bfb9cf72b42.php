<?php

/* @Framework/Form/form_widget_simple.html.php */
class __TwigTemplate_9f3864f897c3de9afc1f8aec9bb9b6703eb60223fd56eb7dae76098a0f12c960 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3e2e40bb83697dd540bc3ca3bdc214b7d1dbbb9a4eb6a6ccd792b78d2fc59469 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3e2e40bb83697dd540bc3ca3bdc214b7d1dbbb9a4eb6a6ccd792b78d2fc59469->enter($__internal_3e2e40bb83697dd540bc3ca3bdc214b7d1dbbb9a4eb6a6ccd792b78d2fc59469_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_simple.html.php"));

        $__internal_7459af03ab9a5b1a6f163996568c5eaa820dfcd55aa0a1c316d3053839174678 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7459af03ab9a5b1a6f163996568c5eaa820dfcd55aa0a1c316d3053839174678->enter($__internal_7459af03ab9a5b1a6f163996568c5eaa820dfcd55aa0a1c316d3053839174678_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_simple.html.php"));

        // line 1
        echo "<input type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'text' ?>\" <?php echo \$view['form']->block(\$form, 'widget_attributes') ?><?php if (!empty(\$value) || is_numeric(\$value)): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?> />
";
        
        $__internal_3e2e40bb83697dd540bc3ca3bdc214b7d1dbbb9a4eb6a6ccd792b78d2fc59469->leave($__internal_3e2e40bb83697dd540bc3ca3bdc214b7d1dbbb9a4eb6a6ccd792b78d2fc59469_prof);

        
        $__internal_7459af03ab9a5b1a6f163996568c5eaa820dfcd55aa0a1c316d3053839174678->leave($__internal_7459af03ab9a5b1a6f163996568c5eaa820dfcd55aa0a1c316d3053839174678_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget_simple.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<input type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'text' ?>\" <?php echo \$view['form']->block(\$form, 'widget_attributes') ?><?php if (!empty(\$value) || is_numeric(\$value)): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?> />
", "@Framework/Form/form_widget_simple.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_widget_simple.html.php");
    }
}
