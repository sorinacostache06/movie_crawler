<?php

/* ::flashBag.html.twig */
class __TwigTemplate_bcab25ea0c8262d190f117a5e01cf65cb4824945422206c9f35f1878f2b42997 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f86f7623e578cd2b6e630239702a5e97236e45074f2336abc556bf17b16418d2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f86f7623e578cd2b6e630239702a5e97236e45074f2336abc556bf17b16418d2->enter($__internal_f86f7623e578cd2b6e630239702a5e97236e45074f2336abc556bf17b16418d2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::flashBag.html.twig"));

        $__internal_d2452bf087d4db2e0ffa6052b2741e48592558474edd21376a6dd3e4815dad91 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d2452bf087d4db2e0ffa6052b2741e48592558474edd21376a6dd3e4815dad91->enter($__internal_d2452bf087d4db2e0ffa6052b2741e48592558474edd21376a6dd3e4815dad91_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::flashBag.html.twig"));

        // line 1
        if (twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 1, $this->getSourceContext()); })()), "session", array()), "flashBag", array()), "has", array(0 => "error"), "method")) {
            // line 2
            echo "    <div class=\"alert alert-danger alert-dismissible\">
        <button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>
        <h4><i class=\"icon fa fa-ban\"></i>";
            // line 4
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("flashbag.error.title"), "html", null, true);
            echo " </h4>
        ";
            // line 5
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 5, $this->getSourceContext()); })()), "session", array()), "flashBag", array()), "get", array(0 => "error"), "method"));
            foreach ($context['_seq'] as $context["_key"] => $context["msg"]) {
                // line 6
                echo "            ";
                echo twig_escape_filter($this->env, $context["msg"], "html", null, true);
                echo "
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['msg'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 8
            echo "    </div>
";
        }
        // line 10
        if (twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 10, $this->getSourceContext()); })()), "session", array()), "flashBag", array()), "has", array(0 => "success"), "method")) {
            // line 11
            echo "    <div class=\"alert alert-success alert-dismissible\">
        <button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>
        <h4><i class=\"icon fa fa-ban\"></i>";
            // line 13
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("flashbag.success.title"), "html", null, true);
            echo " </h4>
        ";
            // line 14
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 14, $this->getSourceContext()); })()), "session", array()), "flashBag", array()), "get", array(0 => "success"), "method"));
            foreach ($context['_seq'] as $context["_key"] => $context["msg"]) {
                // line 15
                echo "            ";
                echo twig_escape_filter($this->env, $context["msg"], "html", null, true);
                echo "
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['msg'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 17
            echo "    </div>
";
        }
        // line 19
        if (twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 19, $this->getSourceContext()); })()), "session", array()), "flashBag", array()), "has", array(0 => "notice"), "method")) {
            // line 20
            echo "    <div class=\"alert alert-info alert-dismissible\">
        <button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>
        <h4><i class=\"icon fa fa-ban\"></i>";
            // line 22
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("flashbag.notice.title"), "html", null, true);
            echo " </h4>
        ";
            // line 23
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 23, $this->getSourceContext()); })()), "session", array()), "flashBag", array()), "get", array(0 => "notice"), "method"));
            foreach ($context['_seq'] as $context["_key"] => $context["msg"]) {
                // line 24
                echo "            ";
                echo twig_escape_filter($this->env, $context["msg"], "html", null, true);
                echo "
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['msg'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 26
            echo "    </div>
";
        }
        
        $__internal_f86f7623e578cd2b6e630239702a5e97236e45074f2336abc556bf17b16418d2->leave($__internal_f86f7623e578cd2b6e630239702a5e97236e45074f2336abc556bf17b16418d2_prof);

        
        $__internal_d2452bf087d4db2e0ffa6052b2741e48592558474edd21376a6dd3e4815dad91->leave($__internal_d2452bf087d4db2e0ffa6052b2741e48592558474edd21376a6dd3e4815dad91_prof);

    }

    public function getTemplateName()
    {
        return "::flashBag.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  102 => 26,  93 => 24,  89 => 23,  85 => 22,  81 => 20,  79 => 19,  75 => 17,  66 => 15,  62 => 14,  58 => 13,  54 => 11,  52 => 10,  48 => 8,  39 => 6,  35 => 5,  31 => 4,  27 => 2,  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% if app.session.flashBag.has('error') %}
    <div class=\"alert alert-danger alert-dismissible\">
        <button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>
        <h4><i class=\"icon fa fa-ban\"></i>{{ 'flashbag.error.title'|trans }} </h4>
        {% for msg in app.session.flashBag.get('error') %}
            {{ msg }}
        {% endfor %}
    </div>
{% endif %}
{% if app.session.flashBag.has('success') %}
    <div class=\"alert alert-success alert-dismissible\">
        <button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>
        <h4><i class=\"icon fa fa-ban\"></i>{{ 'flashbag.success.title'|trans }} </h4>
        {% for msg in app.session.flashBag.get('success') %}
            {{ msg }}
        {% endfor %}
    </div>
{% endif %}
{% if app.session.flashBag.has('notice') %}
    <div class=\"alert alert-info alert-dismissible\">
        <button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>
        <h4><i class=\"icon fa fa-ban\"></i>{{ 'flashbag.notice.title'|trans }} </h4>
        {% for msg in app.session.flashBag.get('notice') %}
            {{ msg }}
        {% endfor %}
    </div>
{% endif %}
", "::flashBag.html.twig", "/home/sorina/Documents/work/movies_crowler/app/Resources/views/flashBag.html.twig");
    }
}
