<?php

/* :Admin:success.html.twig */
class __TwigTemplate_d8b29fa5f8e81d3d5f56200b35944acf62d7657dcc9a55bcf5d9b60a0318bb10 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base-layout.html.twig", ":Admin:success.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base-layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f173e18ed0b915e721384e15a2a78f82e4346c7c0b1507af6e6ca334aa05b531 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f173e18ed0b915e721384e15a2a78f82e4346c7c0b1507af6e6ca334aa05b531->enter($__internal_f173e18ed0b915e721384e15a2a78f82e4346c7c0b1507af6e6ca334aa05b531_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Admin:success.html.twig"));

        $__internal_23bdd372351e47fc740cb26a24754978f61e51e8ef5525af3a0b67f2d158814b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_23bdd372351e47fc740cb26a24754978f61e51e8ef5525af3a0b67f2d158814b->enter($__internal_23bdd372351e47fc740cb26a24754978f61e51e8ef5525af3a0b67f2d158814b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Admin:success.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f173e18ed0b915e721384e15a2a78f82e4346c7c0b1507af6e6ca334aa05b531->leave($__internal_f173e18ed0b915e721384e15a2a78f82e4346c7c0b1507af6e6ca334aa05b531_prof);

        
        $__internal_23bdd372351e47fc740cb26a24754978f61e51e8ef5525af3a0b67f2d158814b->leave($__internal_23bdd372351e47fc740cb26a24754978f61e51e8ef5525af3a0b67f2d158814b_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_6aecbc1a8a82a37d72734c416d3db59cf39555bd0777cb6ee03be0b6499d5844 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6aecbc1a8a82a37d72734c416d3db59cf39555bd0777cb6ee03be0b6499d5844->enter($__internal_6aecbc1a8a82a37d72734c416d3db59cf39555bd0777cb6ee03be0b6499d5844_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_ca6ef8f78201cf96ab855debe301a4e0782cd021081b5535becc39fe2b8840d1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ca6ef8f78201cf96ab855debe301a4e0782cd021081b5535becc39fe2b8840d1->enter($__internal_ca6ef8f78201cf96ab855debe301a4e0782cd021081b5535becc39fe2b8840d1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 4
        echo "    <div>
        Autentificare cu succes!
    </div>
";
        
        $__internal_ca6ef8f78201cf96ab855debe301a4e0782cd021081b5535becc39fe2b8840d1->leave($__internal_ca6ef8f78201cf96ab855debe301a4e0782cd021081b5535becc39fe2b8840d1_prof);

        
        $__internal_6aecbc1a8a82a37d72734c416d3db59cf39555bd0777cb6ee03be0b6499d5844->leave($__internal_6aecbc1a8a82a37d72734c416d3db59cf39555bd0777cb6ee03be0b6499d5844_prof);

    }

    public function getTemplateName()
    {
        return ":Admin:success.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 4,  40 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '::base-layout.html.twig' %}

{% block title%}
    <div>
        Autentificare cu succes!
    </div>
{% endblock %}
", ":Admin:success.html.twig", "/home/sorina/Documents/work/movies_crowler/app/Resources/views/Admin/success.html.twig");
    }
}
