<?php

/* @Framework/Form/form_errors.html.php */
class __TwigTemplate_fb593f51cdc7034c0e93b9fa61b2a7e5edadb73cedd7bc7f548a3716d22698ef extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_53b7ae300506e7becfa66bc9208d7d0838e192c18165460973af08d64bfe1c95 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_53b7ae300506e7becfa66bc9208d7d0838e192c18165460973af08d64bfe1c95->enter($__internal_53b7ae300506e7becfa66bc9208d7d0838e192c18165460973af08d64bfe1c95_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_errors.html.php"));

        $__internal_4593b1422e534b9016c6cffd8ece45dda105e42cb65bffaffdfcc864cc645982 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4593b1422e534b9016c6cffd8ece45dda105e42cb65bffaffdfcc864cc645982->enter($__internal_4593b1422e534b9016c6cffd8ece45dda105e42cb65bffaffdfcc864cc645982_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_errors.html.php"));

        // line 1
        echo "<?php if (count(\$errors) > 0): ?>
    <ul>
        <?php foreach (\$errors as \$error): ?>
            <li><?php echo \$error->getMessage() ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif ?>
";
        
        $__internal_53b7ae300506e7becfa66bc9208d7d0838e192c18165460973af08d64bfe1c95->leave($__internal_53b7ae300506e7becfa66bc9208d7d0838e192c18165460973af08d64bfe1c95_prof);

        
        $__internal_4593b1422e534b9016c6cffd8ece45dda105e42cb65bffaffdfcc864cc645982->leave($__internal_4593b1422e534b9016c6cffd8ece45dda105e42cb65bffaffdfcc864cc645982_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_errors.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (count(\$errors) > 0): ?>
    <ul>
        <?php foreach (\$errors as \$error): ?>
            <li><?php echo \$error->getMessage() ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif ?>
", "@Framework/Form/form_errors.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_errors.html.php");
    }
}
