<?php

/* @Framework/Form/form_widget.html.php */
class __TwigTemplate_5ddfc765c000494ad6b6617ccad802188987a8fb2fa984b7362972e44c08d500 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5deb6db11c4f36bf05124171dcd7b541ade42a3e20d6e16efd642f2d98cef882 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5deb6db11c4f36bf05124171dcd7b541ade42a3e20d6e16efd642f2d98cef882->enter($__internal_5deb6db11c4f36bf05124171dcd7b541ade42a3e20d6e16efd642f2d98cef882_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget.html.php"));

        $__internal_a4d1d11b7fdcab17aa416ed75806629391a9281daa2121b377e5f007e1cce757 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a4d1d11b7fdcab17aa416ed75806629391a9281daa2121b377e5f007e1cce757->enter($__internal_a4d1d11b7fdcab17aa416ed75806629391a9281daa2121b377e5f007e1cce757_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget.html.php"));

        // line 1
        echo "<?php if (\$compound): ?>
<?php echo \$view['form']->block(\$form, 'form_widget_compound')?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'form_widget_simple')?>
<?php endif ?>
";
        
        $__internal_5deb6db11c4f36bf05124171dcd7b541ade42a3e20d6e16efd642f2d98cef882->leave($__internal_5deb6db11c4f36bf05124171dcd7b541ade42a3e20d6e16efd642f2d98cef882_prof);

        
        $__internal_a4d1d11b7fdcab17aa416ed75806629391a9281daa2121b377e5f007e1cce757->leave($__internal_a4d1d11b7fdcab17aa416ed75806629391a9281daa2121b377e5f007e1cce757_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$compound): ?>
<?php echo \$view['form']->block(\$form, 'form_widget_compound')?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'form_widget_simple')?>
<?php endif ?>
", "@Framework/Form/form_widget.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_widget.html.php");
    }
}
