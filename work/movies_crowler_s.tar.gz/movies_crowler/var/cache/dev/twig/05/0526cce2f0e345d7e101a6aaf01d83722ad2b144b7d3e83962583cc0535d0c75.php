<?php

/* :Form:fields.html.twig */
class __TwigTemplate_794f9c00e3bc249a9d205764edbc85e1f3decb1061acdc54f2642dd0def955f0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'datepicker_widget' => array($this, 'block_datepicker_widget'),
            'datetimepicker_widget' => array($this, 'block_datetimepicker_widget'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f4b0379f07390c58d033bd0d7808497a1b4e2af6eabb35cfbccc913b72686d47 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f4b0379f07390c58d033bd0d7808497a1b4e2af6eabb35cfbccc913b72686d47->enter($__internal_f4b0379f07390c58d033bd0d7808497a1b4e2af6eabb35cfbccc913b72686d47_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Form:fields.html.twig"));

        $__internal_839a31c9e00be5dcc0f31ce335cad99e3ead5777c07478ddc0122f5d3b4bceed = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_839a31c9e00be5dcc0f31ce335cad99e3ead5777c07478ddc0122f5d3b4bceed->enter($__internal_839a31c9e00be5dcc0f31ce335cad99e3ead5777c07478ddc0122f5d3b4bceed_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Form:fields.html.twig"));

        // line 2
        $this->displayBlock('datepicker_widget', $context, $blocks);
        // line 6
        $this->displayBlock('datetimepicker_widget', $context, $blocks);
        
        $__internal_f4b0379f07390c58d033bd0d7808497a1b4e2af6eabb35cfbccc913b72686d47->leave($__internal_f4b0379f07390c58d033bd0d7808497a1b4e2af6eabb35cfbccc913b72686d47_prof);

        
        $__internal_839a31c9e00be5dcc0f31ce335cad99e3ead5777c07478ddc0122f5d3b4bceed->leave($__internal_839a31c9e00be5dcc0f31ce335cad99e3ead5777c07478ddc0122f5d3b4bceed_prof);

    }

    // line 2
    public function block_datepicker_widget($context, array $blocks = array())
    {
        $__internal_45eb12b5371c7d5f37e6aee3d778d888148bcc3e5f2529deb06f178d51aacba3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_45eb12b5371c7d5f37e6aee3d778d888148bcc3e5f2529deb06f178d51aacba3->enter($__internal_45eb12b5371c7d5f37e6aee3d778d888148bcc3e5f2529deb06f178d51aacba3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datepicker_widget"));

        $__internal_3c5684acddd19de3549be45543abbd25d79655b7ba80c152d0b5dcae65187908 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3c5684acddd19de3549be45543abbd25d79655b7ba80c152d0b5dcae65187908->enter($__internal_3c5684acddd19de3549be45543abbd25d79655b7ba80c152d0b5dcae65187908_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datepicker_widget"));

        // line 3
        echo "    <input placeholder=\"Date\" class=\"form-control datepicker\" type=\"text\" ";
        if ( !twig_test_empty((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 3, $this->getSourceContext()); })()))) {
            echo "value=\"";
            echo twig_escape_filter($this->env, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 3, $this->getSourceContext()); })()), "html", null, true);
            echo "\" ";
        }
        echo " ";
        $this->displayBlock("widget_attributes", $context, $blocks);
        echo "/>
";
        
        $__internal_3c5684acddd19de3549be45543abbd25d79655b7ba80c152d0b5dcae65187908->leave($__internal_3c5684acddd19de3549be45543abbd25d79655b7ba80c152d0b5dcae65187908_prof);

        
        $__internal_45eb12b5371c7d5f37e6aee3d778d888148bcc3e5f2529deb06f178d51aacba3->leave($__internal_45eb12b5371c7d5f37e6aee3d778d888148bcc3e5f2529deb06f178d51aacba3_prof);

    }

    // line 6
    public function block_datetimepicker_widget($context, array $blocks = array())
    {
        $__internal_1b0ffdced9913067896cd2ab821ca6712cc6c747b854f9fd499906e1e09d3b6d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1b0ffdced9913067896cd2ab821ca6712cc6c747b854f9fd499906e1e09d3b6d->enter($__internal_1b0ffdced9913067896cd2ab821ca6712cc6c747b854f9fd499906e1e09d3b6d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datetimepicker_widget"));

        $__internal_5c89fc4661353d919f2d2f3ceeba3298d3f2bd7dcba9970b7cc43d52be03a4d1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5c89fc4661353d919f2d2f3ceeba3298d3f2bd7dcba9970b7cc43d52be03a4d1->enter($__internal_5c89fc4661353d919f2d2f3ceeba3298d3f2bd7dcba9970b7cc43d52be03a4d1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datetimepicker_widget"));

        // line 7
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 7, $this->getSourceContext()); })()), "date", array()), 'errors');
        echo "
    ";
        // line 8
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 8, $this->getSourceContext()); })()), "time", array()), 'errors');
        echo "
    <div class=\"input-group datetimepicker\">
        <span class=\"input-group-addon\">Le</span>
        ";
        // line 11
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 11, $this->getSourceContext()); })()), "date", array()), 'widget');
        echo "
        <span class=\"input-group-addon inner-addon\">à</span>
        ";
        // line 13
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 13, $this->getSourceContext()); })()), "time", array()), 'widget');
        echo "
    </div>
";
        
        $__internal_5c89fc4661353d919f2d2f3ceeba3298d3f2bd7dcba9970b7cc43d52be03a4d1->leave($__internal_5c89fc4661353d919f2d2f3ceeba3298d3f2bd7dcba9970b7cc43d52be03a4d1_prof);

        
        $__internal_1b0ffdced9913067896cd2ab821ca6712cc6c747b854f9fd499906e1e09d3b6d->leave($__internal_1b0ffdced9913067896cd2ab821ca6712cc6c747b854f9fd499906e1e09d3b6d_prof);

    }

    public function getTemplateName()
    {
        return ":Form:fields.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  92 => 13,  87 => 11,  81 => 8,  76 => 7,  67 => 6,  48 => 3,  39 => 2,  29 => 6,  27 => 2,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{# DATEPICKER #}
{% block datepicker_widget %}
    <input placeholder=\"Date\" class=\"form-control datepicker\" type=\"text\" {% if value is not empty %}value=\"{{ value }}\" {% endif %} {{ block('widget_attributes') }}/>
{% endblock %}
{# DATETIMEPICKER #}
{% block datetimepicker_widget %}
    {{ form_errors(form.date) }}
    {{ form_errors(form.time) }}
    <div class=\"input-group datetimepicker\">
        <span class=\"input-group-addon\">Le</span>
        {{ form_widget(form.date) }}
        <span class=\"input-group-addon inner-addon\">à</span>
        {{ form_widget(form.time) }}
    </div>
{% endblock %}", ":Form:fields.html.twig", "/home/sorina/Documents/work/movies_crowler/app/Resources/views/Form/fields.html.twig");
    }
}
