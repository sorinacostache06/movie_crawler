<?php

/* @Framework/Form/number_widget.html.php */
class __TwigTemplate_ed823c42179a98d3a8e69d25ad4b08b6e7756df5546774e41ed8bfebfe7e01a4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3fcd3d9c9a3c8fb0472426e2678b69c752382bc34a96ecef2424c48ddbe274ac = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3fcd3d9c9a3c8fb0472426e2678b69c752382bc34a96ecef2424c48ddbe274ac->enter($__internal_3fcd3d9c9a3c8fb0472426e2678b69c752382bc34a96ecef2424c48ddbe274ac_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/number_widget.html.php"));

        $__internal_f26b848bc08822d0b431235793fc9f09b3fd7dba3ee1c3140950bfad340d6b2a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f26b848bc08822d0b431235793fc9f09b3fd7dba3ee1c3140950bfad340d6b2a->enter($__internal_f26b848bc08822d0b431235793fc9f09b3fd7dba3ee1c3140950bfad340d6b2a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/number_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'text')) ?>
";
        
        $__internal_3fcd3d9c9a3c8fb0472426e2678b69c752382bc34a96ecef2424c48ddbe274ac->leave($__internal_3fcd3d9c9a3c8fb0472426e2678b69c752382bc34a96ecef2424c48ddbe274ac_prof);

        
        $__internal_f26b848bc08822d0b431235793fc9f09b3fd7dba3ee1c3140950bfad340d6b2a->leave($__internal_f26b848bc08822d0b431235793fc9f09b3fd7dba3ee1c3140950bfad340d6b2a_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/number_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'text')) ?>
", "@Framework/Form/number_widget.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/number_widget.html.php");
    }
}
