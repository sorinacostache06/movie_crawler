<?php

/* @Framework/FormTable/form_row.html.php */
class __TwigTemplate_d84221b824af51745a99c41ddaca074e24728ca17abbac226e2bf8e265deb51d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4ac391eb058bb02213f23ed127133c58e2f1372b25ad892faf7f07dd3deb3ce3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4ac391eb058bb02213f23ed127133c58e2f1372b25ad892faf7f07dd3deb3ce3->enter($__internal_4ac391eb058bb02213f23ed127133c58e2f1372b25ad892faf7f07dd3deb3ce3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_row.html.php"));

        $__internal_2bd394e4f572e17d75f050ef43337d358f8624482185e30163b089882ee863c2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2bd394e4f572e17d75f050ef43337d358f8624482185e30163b089882ee863c2->enter($__internal_2bd394e4f572e17d75f050ef43337d358f8624482185e30163b089882ee863c2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_row.html.php"));

        // line 1
        echo "<tr>
    <td>
        <?php echo \$view['form']->label(\$form) ?>
    </td>
    <td>
        <?php echo \$view['form']->errors(\$form) ?>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_4ac391eb058bb02213f23ed127133c58e2f1372b25ad892faf7f07dd3deb3ce3->leave($__internal_4ac391eb058bb02213f23ed127133c58e2f1372b25ad892faf7f07dd3deb3ce3_prof);

        
        $__internal_2bd394e4f572e17d75f050ef43337d358f8624482185e30163b089882ee863c2->leave($__internal_2bd394e4f572e17d75f050ef43337d358f8624482185e30163b089882ee863c2_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr>
    <td>
        <?php echo \$view['form']->label(\$form) ?>
    </td>
    <td>
        <?php echo \$view['form']->errors(\$form) ?>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
", "@Framework/FormTable/form_row.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/FormTable/form_row.html.php");
    }
}
