<?php

/* @Framework/Form/form.html.php */
class __TwigTemplate_47d235d744e113b50544dd496bf4e3a548d2ec569d664cb8b2cd7d77e8c9db74 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_35f73421ccdfa9157aeabebf2a253d3f5dc556d43beb5812a16e3d9111813025 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_35f73421ccdfa9157aeabebf2a253d3f5dc556d43beb5812a16e3d9111813025->enter($__internal_35f73421ccdfa9157aeabebf2a253d3f5dc556d43beb5812a16e3d9111813025_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form.html.php"));

        $__internal_da138def99fea6458ed1e4799dc865e81a57ef00d1883633c4015ec314d249de = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_da138def99fea6458ed1e4799dc865e81a57ef00d1883633c4015ec314d249de->enter($__internal_da138def99fea6458ed1e4799dc865e81a57ef00d1883633c4015ec314d249de_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form.html.php"));

        // line 1
        echo "<?php echo \$view['form']->start(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
<?php echo \$view['form']->end(\$form) ?>
";
        
        $__internal_35f73421ccdfa9157aeabebf2a253d3f5dc556d43beb5812a16e3d9111813025->leave($__internal_35f73421ccdfa9157aeabebf2a253d3f5dc556d43beb5812a16e3d9111813025_prof);

        
        $__internal_da138def99fea6458ed1e4799dc865e81a57ef00d1883633c4015ec314d249de->leave($__internal_da138def99fea6458ed1e4799dc865e81a57ef00d1883633c4015ec314d249de_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->start(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
<?php echo \$view['form']->end(\$form) ?>
", "@Framework/Form/form.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form.html.php");
    }
}
