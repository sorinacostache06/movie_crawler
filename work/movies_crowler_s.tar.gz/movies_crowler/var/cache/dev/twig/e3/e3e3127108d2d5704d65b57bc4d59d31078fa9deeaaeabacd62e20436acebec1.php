<?php

/* ::login-layout.html.twig */
class __TwigTemplate_38ad909c7bdead1889104f006b3e93f5dc556a8b520433a7efcc80e20f5243fb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("AvanzuAdminThemeBundle:layout:login-layout.html.twig", "::login-layout.html.twig", 1);
        $this->blocks = array(
            'flashBag' => array($this, 'block_flashBag'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "AvanzuAdminThemeBundle:layout:login-layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f7866af91ed7637b320848dd9459a55ad5e8f0a7399ff43b868f5de8e5e9a56f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f7866af91ed7637b320848dd9459a55ad5e8f0a7399ff43b868f5de8e5e9a56f->enter($__internal_f7866af91ed7637b320848dd9459a55ad5e8f0a7399ff43b868f5de8e5e9a56f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::login-layout.html.twig"));

        $__internal_1c946d6befab7b3e3ad897b2e276a00d0d0f7ff4f891f30f257fdc4f510549c6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1c946d6befab7b3e3ad897b2e276a00d0d0f7ff4f891f30f257fdc4f510549c6->enter($__internal_1c946d6befab7b3e3ad897b2e276a00d0d0f7ff4f891f30f257fdc4f510549c6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::login-layout.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f7866af91ed7637b320848dd9459a55ad5e8f0a7399ff43b868f5de8e5e9a56f->leave($__internal_f7866af91ed7637b320848dd9459a55ad5e8f0a7399ff43b868f5de8e5e9a56f_prof);

        
        $__internal_1c946d6befab7b3e3ad897b2e276a00d0d0f7ff4f891f30f257fdc4f510549c6->leave($__internal_1c946d6befab7b3e3ad897b2e276a00d0d0f7ff4f891f30f257fdc4f510549c6_prof);

    }

    // line 3
    public function block_flashBag($context, array $blocks = array())
    {
        $__internal_adde61042476ccce6082f2d66bbcb97652d54724f708a911eb9515fbf13f1dff = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_adde61042476ccce6082f2d66bbcb97652d54724f708a911eb9515fbf13f1dff->enter($__internal_adde61042476ccce6082f2d66bbcb97652d54724f708a911eb9515fbf13f1dff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "flashBag"));

        $__internal_34cd922db77dd23192f88c2cc7eedca71df4f12babcb21b294eb80824df0f8df = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_34cd922db77dd23192f88c2cc7eedca71df4f12babcb21b294eb80824df0f8df->enter($__internal_34cd922db77dd23192f88c2cc7eedca71df4f12babcb21b294eb80824df0f8df_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "flashBag"));

        // line 4
        echo "    ";
        $this->loadTemplate("::flashBag.html.twig", "::login-layout.html.twig", 4)->display($context);
        
        $__internal_34cd922db77dd23192f88c2cc7eedca71df4f12babcb21b294eb80824df0f8df->leave($__internal_34cd922db77dd23192f88c2cc7eedca71df4f12babcb21b294eb80824df0f8df_prof);

        
        $__internal_adde61042476ccce6082f2d66bbcb97652d54724f708a911eb9515fbf13f1dff->leave($__internal_adde61042476ccce6082f2d66bbcb97652d54724f708a911eb9515fbf13f1dff_prof);

    }

    public function getTemplateName()
    {
        return "::login-layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 4,  40 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'AvanzuAdminThemeBundle:layout:login-layout.html.twig' %}

{% block flashBag %}
    {% include '::flashBag.html.twig' %}
{% endblock %}
", "::login-layout.html.twig", "/home/sorina/Documents/work/movies_crowler/app/Resources/views/login-layout.html.twig");
    }
}
