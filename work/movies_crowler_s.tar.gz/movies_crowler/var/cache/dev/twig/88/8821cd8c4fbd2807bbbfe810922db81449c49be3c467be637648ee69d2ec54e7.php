<?php

/* @Framework/Form/form_enctype.html.php */
class __TwigTemplate_d7a709c3dbd30f8f4e2efc9a0b002cca616d2c819fef32c9926a7a22368973d3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_20d2c1244befec6667c7307232a3118c1d9c3c4bfb59d2e023df2362444abfe8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_20d2c1244befec6667c7307232a3118c1d9c3c4bfb59d2e023df2362444abfe8->enter($__internal_20d2c1244befec6667c7307232a3118c1d9c3c4bfb59d2e023df2362444abfe8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        $__internal_abf252d39886ed6c6001b1ce92ec16d89527d45c5596d082c34fb6f145c23df5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_abf252d39886ed6c6001b1ce92ec16d89527d45c5596d082c34fb6f145c23df5->enter($__internal_abf252d39886ed6c6001b1ce92ec16d89527d45c5596d082c34fb6f145c23df5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        // line 1
        echo "<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
";
        
        $__internal_20d2c1244befec6667c7307232a3118c1d9c3c4bfb59d2e023df2362444abfe8->leave($__internal_20d2c1244befec6667c7307232a3118c1d9c3c4bfb59d2e023df2362444abfe8_prof);

        
        $__internal_abf252d39886ed6c6001b1ce92ec16d89527d45c5596d082c34fb6f145c23df5->leave($__internal_abf252d39886ed6c6001b1ce92ec16d89527d45c5596d082c34fb6f145c23df5_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_enctype.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
", "@Framework/Form/form_enctype.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_enctype.html.php");
    }
}
