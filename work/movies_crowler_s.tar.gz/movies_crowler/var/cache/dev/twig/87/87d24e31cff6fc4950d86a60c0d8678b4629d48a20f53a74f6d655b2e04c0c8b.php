<?php

/* :default:base-navbar-static.html.twig */
class __TwigTemplate_39309992e438406931b0044bf580bb65b15189ad86aa2137662394aaf6901a5e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_82fb0b23e8c9d1dd2b336d5d86b0b7d831f3b73140e20226fa93bba33d34687e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_82fb0b23e8c9d1dd2b336d5d86b0b7d831f3b73140e20226fa93bba33d34687e->enter($__internal_82fb0b23e8c9d1dd2b336d5d86b0b7d831f3b73140e20226fa93bba33d34687e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":default:base-navbar-static.html.twig"));

        $__internal_374d75891a4f0bd5583ad328d3ef746204f66daed2ca751b03a408300b2098d6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_374d75891a4f0bd5583ad328d3ef746204f66daed2ca751b03a408300b2098d6->enter($__internal_374d75891a4f0bd5583ad328d3ef746204f66daed2ca751b03a408300b2098d6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":default:base-navbar-static.html.twig"));

        
        $__internal_82fb0b23e8c9d1dd2b336d5d86b0b7d831f3b73140e20226fa93bba33d34687e->leave($__internal_82fb0b23e8c9d1dd2b336d5d86b0b7d831f3b73140e20226fa93bba33d34687e_prof);

        
        $__internal_374d75891a4f0bd5583ad328d3ef746204f66daed2ca751b03a408300b2098d6->leave($__internal_374d75891a4f0bd5583ad328d3ef746204f66daed2ca751b03a408300b2098d6_prof);

    }

    public function getTemplateName()
    {
        return ":default:base-navbar-static.html.twig";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", ":default:base-navbar-static.html.twig", "/home/sorina/Documents/work/movies_crowler/app/Resources/views/default/base-navbar-static.html.twig");
    }
}
