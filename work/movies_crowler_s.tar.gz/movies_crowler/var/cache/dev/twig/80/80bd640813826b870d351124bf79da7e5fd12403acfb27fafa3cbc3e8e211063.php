<?php

/* AvanzuAdminThemeBundle:layout:login-layout.html.twig */
class __TwigTemplate_3fe42bb3358d50b3cc10b2361950411007cca846de803a928d10eb76cc45241c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts_head' => array($this, 'block_javascripts_head'),
            'page_content' => array($this, 'block_page_content'),
            'javascripts' => array($this, 'block_javascripts'),
            'javascripts_inline' => array($this, 'block_javascripts_inline'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_34a1a3ad55bf31ebb5c6f60b134a5d9c9ba4b6c0d3eacd76d954083f39199942 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_34a1a3ad55bf31ebb5c6f60b134a5d9c9ba4b6c0d3eacd76d954083f39199942->enter($__internal_34a1a3ad55bf31ebb5c6f60b134a5d9c9ba4b6c0d3eacd76d954083f39199942_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AvanzuAdminThemeBundle:layout:login-layout.html.twig"));

        $__internal_80a03431f3fb4e1b65a3e6f8a6d7fca1c5a720289220f04af2c3ce304b9cdf40 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_80a03431f3fb4e1b65a3e6f8a6d7fca1c5a720289220f04af2c3ce304b9cdf40->enter($__internal_80a03431f3fb4e1b65a3e6f8a6d7fca1c5a720289220f04af2c3ce304b9cdf40_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AvanzuAdminThemeBundle:layout:login-layout.html.twig"));

        // line 1
        $context["macro"] = $this->loadTemplate("AvanzuAdminThemeBundle:layout:macros.html.twig", "AvanzuAdminThemeBundle:layout:login-layout.html.twig", 1);
        // line 2
        echo "<!doctype html>
<!--[if lt IE 7 ]><html lang=\"en\" class=\"no-js ie6\"> <![endif]-->
<!--[if IE 7 ]><html lang=\"en\" class=\"no-js ie7\"> <![endif]-->
<!--[if IE 8 ]><html lang=\"en\" class=\"no-js ie8\"> <![endif]-->
<!--[if IE 9 ]><html lang=\"en\" class=\"no-js ie9\"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--><html lang=\"en\" class=\"no-js\"> <!--<![endif]-->
<head>
    <meta charset=\"utf-8\">
    <meta name=\"author\" content=\"\">
    <meta name=\"keywords\" content=\"\">
    <meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">
    <title>";
        // line 13
        $this->displayBlock('title', $context, $blocks);
        echo "</title>

    ";
        // line 16
        echo "    ";
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 19
        echo "

    <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />

    ";
        // line 24
        echo "    ";
        $this->displayBlock('javascripts_head', $context, $blocks);
        // line 31
        echo "
</head>
<body class=\"login-page\">
";
        // line 34
        $this->displayBlock('page_content', $context, $blocks);
        // line 35
        echo "

";
        // line 38
        $this->displayBlock('javascripts', $context, $blocks);
        // line 41
        echo "
";
        // line 43
        $this->displayBlock('javascripts_inline', $context, $blocks);
        // line 45
        echo "</body>
</html>
";
        
        $__internal_34a1a3ad55bf31ebb5c6f60b134a5d9c9ba4b6c0d3eacd76d954083f39199942->leave($__internal_34a1a3ad55bf31ebb5c6f60b134a5d9c9ba4b6c0d3eacd76d954083f39199942_prof);

        
        $__internal_80a03431f3fb4e1b65a3e6f8a6d7fca1c5a720289220f04af2c3ce304b9cdf40->leave($__internal_80a03431f3fb4e1b65a3e6f8a6d7fca1c5a720289220f04af2c3ce304b9cdf40_prof);

    }

    // line 13
    public function block_title($context, array $blocks = array())
    {
        $__internal_d8177e0db29a49fb920da0e68ba519261deafc2161e9b7f2011e97ff8184ebf9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d8177e0db29a49fb920da0e68ba519261deafc2161e9b7f2011e97ff8184ebf9->enter($__internal_d8177e0db29a49fb920da0e68ba519261deafc2161e9b7f2011e97ff8184ebf9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_bba4ba387880f571c0a35081f11f1f479b88303b60e63bee395bccdce5facd94 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bba4ba387880f571c0a35081f11f1f479b88303b60e63bee395bccdce5facd94->enter($__internal_bba4ba387880f571c0a35081f11f1f479b88303b60e63bee395bccdce5facd94_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Avanzu Admin!";
        
        $__internal_bba4ba387880f571c0a35081f11f1f479b88303b60e63bee395bccdce5facd94->leave($__internal_bba4ba387880f571c0a35081f11f1f479b88303b60e63bee395bccdce5facd94_prof);

        
        $__internal_d8177e0db29a49fb920da0e68ba519261deafc2161e9b7f2011e97ff8184ebf9->leave($__internal_d8177e0db29a49fb920da0e68ba519261deafc2161e9b7f2011e97ff8184ebf9_prof);

    }

    // line 16
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_369edc004913345296d5ea76a34e4a55a05c5d18ec4fb7a44b9e8e2f90e4ee3c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_369edc004913345296d5ea76a34e4a55a05c5d18ec4fb7a44b9e8e2f90e4ee3c->enter($__internal_369edc004913345296d5ea76a34e4a55a05c5d18ec4fb7a44b9e8e2f90e4ee3c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_19a262e1dc0dfa486fe17e28ff33d46bc2c88fdd4d009d8994ed47abd5a587e1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_19a262e1dc0dfa486fe17e28ff33d46bc2c88fdd4d009d8994ed47abd5a587e1->enter($__internal_19a262e1dc0dfa486fe17e28ff33d46bc2c88fdd4d009d8994ed47abd5a587e1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 17
        echo "        <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl((("bundles/avanzuadmintheme/static/" . twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 17, $this->getSourceContext()); })()), "environment", array())) . "/styles/admin-lte-all.css")), "html", null, true);
        echo "\" />
    ";
        
        $__internal_19a262e1dc0dfa486fe17e28ff33d46bc2c88fdd4d009d8994ed47abd5a587e1->leave($__internal_19a262e1dc0dfa486fe17e28ff33d46bc2c88fdd4d009d8994ed47abd5a587e1_prof);

        
        $__internal_369edc004913345296d5ea76a34e4a55a05c5d18ec4fb7a44b9e8e2f90e4ee3c->leave($__internal_369edc004913345296d5ea76a34e4a55a05c5d18ec4fb7a44b9e8e2f90e4ee3c_prof);

    }

    // line 24
    public function block_javascripts_head($context, array $blocks = array())
    {
        $__internal_2b3e740fc9715290cde63b9b82a79283d84fd30bd3efd57b241684963e0be3a3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2b3e740fc9715290cde63b9b82a79283d84fd30bd3efd57b241684963e0be3a3->enter($__internal_2b3e740fc9715290cde63b9b82a79283d84fd30bd3efd57b241684963e0be3a3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts_head"));

        $__internal_0d7b83a8e40721df8840b7e08fcc67ce8fdbdc2dd0c03d504e675e174fe6db7b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0d7b83a8e40721df8840b7e08fcc67ce8fdbdc2dd0c03d504e675e174fe6db7b->enter($__internal_0d7b83a8e40721df8840b7e08fcc67ce8fdbdc2dd0c03d504e675e174fe6db7b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts_head"));

        // line 25
        echo "        <script type=\"text/javascript\" src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl((("bundles/avanzuadmintheme/static/" . twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 25, $this->getSourceContext()); })()), "environment", array())) . "/scripts/modernizr.js")), "html", null, true);
        echo "\"></script>
        <!--[if lt IE 9]>

        <![endif]-->

    ";
        
        $__internal_0d7b83a8e40721df8840b7e08fcc67ce8fdbdc2dd0c03d504e675e174fe6db7b->leave($__internal_0d7b83a8e40721df8840b7e08fcc67ce8fdbdc2dd0c03d504e675e174fe6db7b_prof);

        
        $__internal_2b3e740fc9715290cde63b9b82a79283d84fd30bd3efd57b241684963e0be3a3->leave($__internal_2b3e740fc9715290cde63b9b82a79283d84fd30bd3efd57b241684963e0be3a3_prof);

    }

    // line 34
    public function block_page_content($context, array $blocks = array())
    {
        $__internal_f6c8b192686ba334fbb3ed00045989df5fae895c1a15dfd0e6d9c02d8dba2baa = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f6c8b192686ba334fbb3ed00045989df5fae895c1a15dfd0e6d9c02d8dba2baa->enter($__internal_f6c8b192686ba334fbb3ed00045989df5fae895c1a15dfd0e6d9c02d8dba2baa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_content"));

        $__internal_dda0afd03a7c3da9198481e9be21b76525484799d60a5f55297d1659706af774 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dda0afd03a7c3da9198481e9be21b76525484799d60a5f55297d1659706af774->enter($__internal_dda0afd03a7c3da9198481e9be21b76525484799d60a5f55297d1659706af774_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_content"));

        
        $__internal_dda0afd03a7c3da9198481e9be21b76525484799d60a5f55297d1659706af774->leave($__internal_dda0afd03a7c3da9198481e9be21b76525484799d60a5f55297d1659706af774_prof);

        
        $__internal_f6c8b192686ba334fbb3ed00045989df5fae895c1a15dfd0e6d9c02d8dba2baa->leave($__internal_f6c8b192686ba334fbb3ed00045989df5fae895c1a15dfd0e6d9c02d8dba2baa_prof);

    }

    // line 38
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_5f751a8e91170b6f501c1a80da52a2c95ab2ad5a429491f85bfd12cef234379a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5f751a8e91170b6f501c1a80da52a2c95ab2ad5a429491f85bfd12cef234379a->enter($__internal_5f751a8e91170b6f501c1a80da52a2c95ab2ad5a429491f85bfd12cef234379a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_fc10e7ca07e1077838a31fc19606e9fca6121159866b54746ecc8f69345a4fb2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fc10e7ca07e1077838a31fc19606e9fca6121159866b54746ecc8f69345a4fb2->enter($__internal_fc10e7ca07e1077838a31fc19606e9fca6121159866b54746ecc8f69345a4fb2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 39
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl((("bundles/avanzuadmintheme/static/" . twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 39, $this->getSourceContext()); })()), "environment", array())) . "/scripts/admin-lte-all.js")), "html", null, true);
        echo "\"></script>
";
        
        $__internal_fc10e7ca07e1077838a31fc19606e9fca6121159866b54746ecc8f69345a4fb2->leave($__internal_fc10e7ca07e1077838a31fc19606e9fca6121159866b54746ecc8f69345a4fb2_prof);

        
        $__internal_5f751a8e91170b6f501c1a80da52a2c95ab2ad5a429491f85bfd12cef234379a->leave($__internal_5f751a8e91170b6f501c1a80da52a2c95ab2ad5a429491f85bfd12cef234379a_prof);

    }

    // line 43
    public function block_javascripts_inline($context, array $blocks = array())
    {
        $__internal_8991926c6a94dbe691efe93b1ca111acd338953c746722192e0b56d265a74be7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8991926c6a94dbe691efe93b1ca111acd338953c746722192e0b56d265a74be7->enter($__internal_8991926c6a94dbe691efe93b1ca111acd338953c746722192e0b56d265a74be7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts_inline"));

        $__internal_6125ab6dd2f30912865b857bd20858e4e9e947b1b3e9cdc95688b29312d53f31 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6125ab6dd2f30912865b857bd20858e4e9e947b1b3e9cdc95688b29312d53f31->enter($__internal_6125ab6dd2f30912865b857bd20858e4e9e947b1b3e9cdc95688b29312d53f31_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts_inline"));

        
        $__internal_6125ab6dd2f30912865b857bd20858e4e9e947b1b3e9cdc95688b29312d53f31->leave($__internal_6125ab6dd2f30912865b857bd20858e4e9e947b1b3e9cdc95688b29312d53f31_prof);

        
        $__internal_8991926c6a94dbe691efe93b1ca111acd338953c746722192e0b56d265a74be7->leave($__internal_8991926c6a94dbe691efe93b1ca111acd338953c746722192e0b56d265a74be7_prof);

    }

    public function getTemplateName()
    {
        return "AvanzuAdminThemeBundle:layout:login-layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  201 => 43,  188 => 39,  179 => 38,  162 => 34,  145 => 25,  136 => 24,  123 => 17,  114 => 16,  96 => 13,  84 => 45,  82 => 43,  79 => 41,  77 => 38,  73 => 35,  71 => 34,  66 => 31,  63 => 24,  58 => 21,  54 => 19,  51 => 16,  46 => 13,  33 => 2,  31 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% import \"AvanzuAdminThemeBundle:layout:macros.html.twig\" as macro %}
<!doctype html>
<!--[if lt IE 7 ]><html lang=\"en\" class=\"no-js ie6\"> <![endif]-->
<!--[if IE 7 ]><html lang=\"en\" class=\"no-js ie7\"> <![endif]-->
<!--[if IE 8 ]><html lang=\"en\" class=\"no-js ie8\"> <![endif]-->
<!--[if IE 9 ]><html lang=\"en\" class=\"no-js ie9\"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--><html lang=\"en\" class=\"no-js\"> <!--<![endif]-->
<head>
    <meta charset=\"utf-8\">
    <meta name=\"author\" content=\"\">
    <meta name=\"keywords\" content=\"\">
    <meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">
    <title>{% block title %}Avanzu Admin!{% endblock %}</title>

    {# -------------------------------------------------------------------------------------------------- STYLESHEETS #}
    {% block stylesheets %}
        <link rel=\"stylesheet\" href=\"{{ asset('bundles/avanzuadmintheme/static/'~ app.environment ~'/styles/admin-lte-all.css') }}\" />
    {% endblock %}


    <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />

    {# --------------------------------------------------------------------------------------------- JAVASCRIPTS_HEAD #}
    {%  block javascripts_head %}
        <script type=\"text/javascript\" src=\"{{ asset('bundles/avanzuadmintheme/static/'~ app.environment ~'/scripts/modernizr.js') }}\"></script>
        <!--[if lt IE 9]>

        <![endif]-->

    {% endblock %}

</head>
<body class=\"login-page\">
{% block page_content %}{% endblock %}


{# ------------------------------------------------------------------------------------------------------ JAVASCRIPTS #}
{% block javascripts %}
    <script src=\"{{ asset('bundles/avanzuadmintheme/static/'~ app.environment ~'/scripts/admin-lte-all.js') }}\"></script>
{% endblock %}

{# ----------------------------------------------------------------------------------------------- JAVASCRIPTS_INLINE #}
{% block javascripts_inline %}
{% endblock %}
</body>
</html>
", "AvanzuAdminThemeBundle:layout:login-layout.html.twig", "/home/sorina/Documents/work/movies_crowler/vendor/avanzu/admin-theme-bundle/Resources/views/layout/login-layout.html.twig");
    }
}
