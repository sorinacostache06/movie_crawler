<?php

/* @Framework/Form/form_start.html.php */
class __TwigTemplate_a7ec606807621abe51ade85baf245b9178580aeeae7681ffb6b1da39d418e62a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c8c95899158e24a96e62cf1450bcff97d8117465f0e1ec26a5405d9580c75874 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c8c95899158e24a96e62cf1450bcff97d8117465f0e1ec26a5405d9580c75874->enter($__internal_c8c95899158e24a96e62cf1450bcff97d8117465f0e1ec26a5405d9580c75874_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_start.html.php"));

        $__internal_de662ef4fd70b9d08a0356986102d0c56c1de6acae9e314f8e95799a4606aba5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_de662ef4fd70b9d08a0356986102d0c56c1de6acae9e314f8e95799a4606aba5->enter($__internal_de662ef4fd70b9d08a0356986102d0c56c1de6acae9e314f8e95799a4606aba5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_start.html.php"));

        // line 1
        echo "<?php \$method = strtoupper(\$method) ?>
<?php \$form_method = \$method === 'GET' || \$method === 'POST' ? \$method : 'POST' ?>
<form name=\"<?php echo \$name ?>\" method=\"<?php echo strtolower(\$form_method) ?>\"<?php if (\$action !== ''): ?> action=\"<?php echo \$action ?>\"<?php endif ?><?php foreach (\$attr as \$k => \$v) { printf(' %s=\"%s\"', \$view->escape(\$k), \$view->escape(\$v)); } ?><?php if (\$multipart): ?> enctype=\"multipart/form-data\"<?php endif ?>>
<?php if (\$form_method !== \$method): ?>
    <input type=\"hidden\" name=\"_method\" value=\"<?php echo \$method ?>\" />
<?php endif ?>
";
        
        $__internal_c8c95899158e24a96e62cf1450bcff97d8117465f0e1ec26a5405d9580c75874->leave($__internal_c8c95899158e24a96e62cf1450bcff97d8117465f0e1ec26a5405d9580c75874_prof);

        
        $__internal_de662ef4fd70b9d08a0356986102d0c56c1de6acae9e314f8e95799a4606aba5->leave($__internal_de662ef4fd70b9d08a0356986102d0c56c1de6acae9e314f8e95799a4606aba5_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_start.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php \$method = strtoupper(\$method) ?>
<?php \$form_method = \$method === 'GET' || \$method === 'POST' ? \$method : 'POST' ?>
<form name=\"<?php echo \$name ?>\" method=\"<?php echo strtolower(\$form_method) ?>\"<?php if (\$action !== ''): ?> action=\"<?php echo \$action ?>\"<?php endif ?><?php foreach (\$attr as \$k => \$v) { printf(' %s=\"%s\"', \$view->escape(\$k), \$view->escape(\$v)); } ?><?php if (\$multipart): ?> enctype=\"multipart/form-data\"<?php endif ?>>
<?php if (\$form_method !== \$method): ?>
    <input type=\"hidden\" name=\"_method\" value=\"<?php echo \$method ?>\" />
<?php endif ?>
", "@Framework/Form/form_start.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_start.html.php");
    }
}
