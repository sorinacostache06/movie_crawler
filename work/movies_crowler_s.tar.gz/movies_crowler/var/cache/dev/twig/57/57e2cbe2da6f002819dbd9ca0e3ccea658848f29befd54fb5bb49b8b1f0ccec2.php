<?php

/* @Framework/Form/email_widget.html.php */
class __TwigTemplate_c3f0e0e17f985c6877c55c7a0b7f45761d5fc233e8c7dab31dadf35a8947c7e7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_100c5a7f7bd6ae05d8382e7cec88986db28ac5d48bc64212f8e7b5682b2f24c4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_100c5a7f7bd6ae05d8382e7cec88986db28ac5d48bc64212f8e7b5682b2f24c4->enter($__internal_100c5a7f7bd6ae05d8382e7cec88986db28ac5d48bc64212f8e7b5682b2f24c4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/email_widget.html.php"));

        $__internal_348197f304d21aa2a9b737400e8ae10033c5ac36a47f4236c75a5619d73af19f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_348197f304d21aa2a9b737400e8ae10033c5ac36a47f4236c75a5619d73af19f->enter($__internal_348197f304d21aa2a9b737400e8ae10033c5ac36a47f4236c75a5619d73af19f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/email_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'email')) ?>
";
        
        $__internal_100c5a7f7bd6ae05d8382e7cec88986db28ac5d48bc64212f8e7b5682b2f24c4->leave($__internal_100c5a7f7bd6ae05d8382e7cec88986db28ac5d48bc64212f8e7b5682b2f24c4_prof);

        
        $__internal_348197f304d21aa2a9b737400e8ae10033c5ac36a47f4236c75a5619d73af19f->leave($__internal_348197f304d21aa2a9b737400e8ae10033c5ac36a47f4236c75a5619d73af19f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/email_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'email')) ?>
", "@Framework/Form/email_widget.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/email_widget.html.php");
    }
}
