<?php

/* @Framework/Form/money_widget.html.php */
class __TwigTemplate_a077b2d63ba941a1ca3c2d12610dff087831dbf623c791d2bf632b128235eb1e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7de953b42c056ba072105c30947e96f28fe58acc0cb8481af7bc1a8b0edcb67d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7de953b42c056ba072105c30947e96f28fe58acc0cb8481af7bc1a8b0edcb67d->enter($__internal_7de953b42c056ba072105c30947e96f28fe58acc0cb8481af7bc1a8b0edcb67d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/money_widget.html.php"));

        $__internal_4d7f1c4f76255c58c61126497d878f0302f9e969a4b753ad62bd2f5612e2075a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4d7f1c4f76255c58c61126497d878f0302f9e969a4b753ad62bd2f5612e2075a->enter($__internal_4d7f1c4f76255c58c61126497d878f0302f9e969a4b753ad62bd2f5612e2075a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/money_widget.html.php"));

        // line 1
        echo "<?php echo str_replace('";
        echo twig_escape_filter($this->env, (isset($context["widget"]) || array_key_exists("widget", $context) ? $context["widget"] : (function () { throw new Twig_Error_Runtime('Variable "widget" does not exist.', 1, $this->getSourceContext()); })()), "html", null, true);
        echo "', \$view['form']->block(\$form, 'form_widget_simple'), \$money_pattern) ?>
";
        
        $__internal_7de953b42c056ba072105c30947e96f28fe58acc0cb8481af7bc1a8b0edcb67d->leave($__internal_7de953b42c056ba072105c30947e96f28fe58acc0cb8481af7bc1a8b0edcb67d_prof);

        
        $__internal_4d7f1c4f76255c58c61126497d878f0302f9e969a4b753ad62bd2f5612e2075a->leave($__internal_4d7f1c4f76255c58c61126497d878f0302f9e969a4b753ad62bd2f5612e2075a_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/money_widget.html.php";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo str_replace('{{ widget }}', \$view['form']->block(\$form, 'form_widget_simple'), \$money_pattern) ?>
", "@Framework/Form/money_widget.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/money_widget.html.php");
    }
}
