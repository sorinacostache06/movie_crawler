<?php

/* @Framework/Form/choice_widget_expanded.html.php */
class __TwigTemplate_73f2f2ed92773cbbea90a0b8debe28d99f6e57e02079f5a2417e2b6a0655e996 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fa90da355774acdc9935c87ad78726bdd5a127444bdde28c0d1bd866109212da = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fa90da355774acdc9935c87ad78726bdd5a127444bdde28c0d1bd866109212da->enter($__internal_fa90da355774acdc9935c87ad78726bdd5a127444bdde28c0d1bd866109212da_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget_expanded.html.php"));

        $__internal_37167d5738e542861ea49d84e750fe410a6b0ae4dbc0858de67ead3e6dc8088b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_37167d5738e542861ea49d84e750fe410a6b0ae4dbc0858de67ead3e6dc8088b->enter($__internal_37167d5738e542861ea49d84e750fe410a6b0ae4dbc0858de67ead3e6dc8088b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget_expanded.html.php"));

        // line 1
        echo "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
<?php foreach (\$form as \$child): ?>
    <?php echo \$view['form']->widget(\$child) ?>
    <?php echo \$view['form']->label(\$child, null, array('translation_domain' => \$choice_translation_domain)) ?>
<?php endforeach ?>
</div>
";
        
        $__internal_fa90da355774acdc9935c87ad78726bdd5a127444bdde28c0d1bd866109212da->leave($__internal_fa90da355774acdc9935c87ad78726bdd5a127444bdde28c0d1bd866109212da_prof);

        
        $__internal_37167d5738e542861ea49d84e750fe410a6b0ae4dbc0858de67ead3e6dc8088b->leave($__internal_37167d5738e542861ea49d84e750fe410a6b0ae4dbc0858de67ead3e6dc8088b_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_widget_expanded.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
<?php foreach (\$form as \$child): ?>
    <?php echo \$view['form']->widget(\$child) ?>
    <?php echo \$view['form']->label(\$child, null, array('translation_domain' => \$choice_translation_domain)) ?>
<?php endforeach ?>
</div>
", "@Framework/Form/choice_widget_expanded.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/choice_widget_expanded.html.php");
    }
}
