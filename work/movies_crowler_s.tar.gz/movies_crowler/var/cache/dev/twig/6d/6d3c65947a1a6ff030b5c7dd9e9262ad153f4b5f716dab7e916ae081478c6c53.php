<?php

/* AvanzuAdminThemeBundle:Exception:exception_full.html.twig */
class __TwigTemplate_489da043d3b0a017a9ef3b08245756208aee37eb5a33030092abc5005d24531a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("AvanzuAdminThemeBundle:layout:base-layout.html.twig", "AvanzuAdminThemeBundle:Exception:exception_full.html.twig", 1);
        $this->blocks = array(
            'page_title' => array($this, 'block_page_title'),
            'page_subtitle' => array($this, 'block_page_subtitle'),
            'page_content' => array($this, 'block_page_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "AvanzuAdminThemeBundle:layout:base-layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7f4c4915773f834844a3ca73a968389078184a194e8d41a7069b004f964189ec = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7f4c4915773f834844a3ca73a968389078184a194e8d41a7069b004f964189ec->enter($__internal_7f4c4915773f834844a3ca73a968389078184a194e8d41a7069b004f964189ec_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AvanzuAdminThemeBundle:Exception:exception_full.html.twig"));

        $__internal_e51e5ddebd3ff1ba29e8569a2b7498d7ad5e5c18d9a9d41d500c4dffe35f2743 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e51e5ddebd3ff1ba29e8569a2b7498d7ad5e5c18d9a9d41d500c4dffe35f2743->enter($__internal_e51e5ddebd3ff1ba29e8569a2b7498d7ad5e5c18d9a9d41d500c4dffe35f2743_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AvanzuAdminThemeBundle:Exception:exception_full.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_7f4c4915773f834844a3ca73a968389078184a194e8d41a7069b004f964189ec->leave($__internal_7f4c4915773f834844a3ca73a968389078184a194e8d41a7069b004f964189ec_prof);

        
        $__internal_e51e5ddebd3ff1ba29e8569a2b7498d7ad5e5c18d9a9d41d500c4dffe35f2743->leave($__internal_e51e5ddebd3ff1ba29e8569a2b7498d7ad5e5c18d9a9d41d500c4dffe35f2743_prof);

    }

    // line 2
    public function block_page_title($context, array $blocks = array())
    {
        $__internal_1327986959f38124103ef8fe90e515fa0d9855d222ad0973cdd537024fb4ce7c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1327986959f38124103ef8fe90e515fa0d9855d222ad0973cdd537024fb4ce7c->enter($__internal_1327986959f38124103ef8fe90e515fa0d9855d222ad0973cdd537024fb4ce7c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_title"));

        $__internal_39de17601600aa3955390d635a8fc6a5850c3f8da6067d9e9f10770c1a8a8957 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_39de17601600aa3955390d635a8fc6a5850c3f8da6067d9e9f10770c1a8a8957->enter($__internal_39de17601600aa3955390d635a8fc6a5850c3f8da6067d9e9f10770c1a8a8957_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_title"));

        echo " Error ";
        
        $__internal_39de17601600aa3955390d635a8fc6a5850c3f8da6067d9e9f10770c1a8a8957->leave($__internal_39de17601600aa3955390d635a8fc6a5850c3f8da6067d9e9f10770c1a8a8957_prof);

        
        $__internal_1327986959f38124103ef8fe90e515fa0d9855d222ad0973cdd537024fb4ce7c->leave($__internal_1327986959f38124103ef8fe90e515fa0d9855d222ad0973cdd537024fb4ce7c_prof);

    }

    // line 3
    public function block_page_subtitle($context, array $blocks = array())
    {
        $__internal_2480dca540fad6ea9cf3c4dc9ae7cadcb82bd989a35d751652692e16aad7386e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2480dca540fad6ea9cf3c4dc9ae7cadcb82bd989a35d751652692e16aad7386e->enter($__internal_2480dca540fad6ea9cf3c4dc9ae7cadcb82bd989a35d751652692e16aad7386e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_subtitle"));

        $__internal_b3346ad44ffbaa06b78f9f66066805ce19623eba041f33111e732e4c6c482117 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b3346ad44ffbaa06b78f9f66066805ce19623eba041f33111e732e4c6c482117->enter($__internal_b3346ad44ffbaa06b78f9f66066805ce19623eba041f33111e732e4c6c482117_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_subtitle"));

        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_code"]) || array_key_exists("status_code", $context) ? $context["status_code"] : (function () { throw new Twig_Error_Runtime('Variable "status_code" does not exist.', 3, $this->getSourceContext()); })()), "html", null, true);
        echo " ";
        
        $__internal_b3346ad44ffbaa06b78f9f66066805ce19623eba041f33111e732e4c6c482117->leave($__internal_b3346ad44ffbaa06b78f9f66066805ce19623eba041f33111e732e4c6c482117_prof);

        
        $__internal_2480dca540fad6ea9cf3c4dc9ae7cadcb82bd989a35d751652692e16aad7386e->leave($__internal_2480dca540fad6ea9cf3c4dc9ae7cadcb82bd989a35d751652692e16aad7386e_prof);

    }

    // line 5
    public function block_page_content($context, array $blocks = array())
    {
        $__internal_11ccaf42c739dd930a361d0a523264b0fc74a265b6738a065944f1eb0cc8ae70 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_11ccaf42c739dd930a361d0a523264b0fc74a265b6738a065944f1eb0cc8ae70->enter($__internal_11ccaf42c739dd930a361d0a523264b0fc74a265b6738a065944f1eb0cc8ae70_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_content"));

        $__internal_3f6cadc991c8b08d4747029e3501e8209169b5587c7942cad85f4f0b6fcb746c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3f6cadc991c8b08d4747029e3501e8209169b5587c7942cad85f4f0b6fcb746c->enter($__internal_3f6cadc991c8b08d4747029e3501e8209169b5587c7942cad85f4f0b6fcb746c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_content"));

        // line 6
        echo "    <div class=\"error-page\">
        <h2 class=\"headline\">";
        // line 7
        echo twig_escape_filter($this->env, (isset($context["status_code"]) || array_key_exists("status_code", $context) ? $context["status_code"] : (function () { throw new Twig_Error_Runtime('Variable "status_code" does not exist.', 7, $this->getSourceContext()); })()), "html", null, true);
        echo "</h2>

        <div class=\"error-content\">
            <h3>";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Something seems to have gone wrong"), "html", null, true);
        echo "</h3>

            <p>";
        // line 12
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["exception"]) || array_key_exists("exception", $context) ? $context["exception"] : (function () { throw new Twig_Error_Runtime('Variable "exception" does not exist.', 12, $this->getSourceContext()); })()), "message", array()), "html", null, true);
        echo "</p>
        </div>
    </div>

    <div class=\"\">

    ";
        // line 18
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["exception"]) || array_key_exists("exception", $context) ? $context["exception"] : (function () { throw new Twig_Error_Runtime('Variable "exception" does not exist.', 18, $this->getSourceContext()); })()), "toarray", array()));
        foreach ($context['_seq'] as $context["n"] => $context["position"]) {
            // line 19
            echo "
        <div class=\"box box-danger\">
            <div class=\"box-header\">
                <i class=\"fa fa-warning\"></i>

                <h3 class=\"box-title\">";
            // line 24
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\CodeExtension')->abbrClass(twig_get_attribute($this->env, $this->getSourceContext(), $context["position"], "class", array()));
            echo "</h3>
            </div>
            <div class=\"box-body\">

                <div class=\"callout callout-danger\">
                    ";
            // line 29
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\CodeExtension')->formatFileFromText(nl2br(twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["position"], "message", array()), "html", null, true)));
            echo "
                </div>

                <div class=\"box-group\" id=\"box-";
            // line 32
            echo twig_escape_filter($this->env, $context["n"], "html", null, true);
            echo "\">


                    <!-- trace -->
                    <div class=\"panel box box-warning\">
                        <div class=\"box-header\">
                            <h4 class=\"box-title\">
                                <a data-toggle=\"collapse\" data-parent=\"box-";
            // line 39
            echo twig_escape_filter($this->env, $context["n"], "html", null, true);
            echo "\"
                                   href=\"#trace-";
            // line 40
            echo twig_escape_filter($this->env, $context["n"], "html", null, true);
            echo "\">
                                    ";
            // line 41
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Stack Trace"), "html", null, true);
            echo "
                                </a>
                            </h4>
                        </div>
                        <div id=\"trace-";
            // line 45
            echo twig_escape_filter($this->env, $context["n"], "html", null, true);
            echo "\" class=\"panel-collapse collapse\">
                            <div class=\"box-body\">
                                <div class=\"panel\">
                                <ul class=\"timeline\">
                                    ";
            // line 49
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->getSourceContext(), $context["position"], "trace", array()));
            foreach ($context['_seq'] as $context["i"] => $context["trace"]) {
                // line 50
                echo "                                        <li class=\"time-label\">
                                                    <span class=\"bg-red\">
                                                        Stack #";
                // line 52
                echo twig_escape_filter($this->env, $context["i"], "html", null, true);
                echo "
                                                    </span>
                                        </li>
                                        <li>
                                            <i class=\"fa fa-code bg-blue\"></i>

                                            <div class=\"timeline-item\">
                                                <h3 class=\"timeline-header\">
                                                    ";
                // line 60
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["trace"], "file", array()), "html", null, true);
                echo "
                                                </h3>

                                                <div class=\"timeline-body\">
                                                    ";
                // line 64
                if (twig_get_attribute($this->env, $this->getSourceContext(), $context["trace"], "function", array())) {
                    // line 65
                    echo "                                                        at
                                                        <strong>
                                                            <abbr title=\"";
                    // line 67
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["trace"], "class", array()), "html", null, true);
                    echo "\">";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["trace"], "short_class", array()), "html", null, true);
                    echo "</abbr>
                                                            ";
                    // line 68
                    echo twig_escape_filter($this->env, (twig_get_attribute($this->env, $this->getSourceContext(), $context["trace"], "type", array()) . twig_get_attribute($this->env, $this->getSourceContext(), $context["trace"], "function", array())), "html", null, true);
                    echo "
                                                        </strong>
                                                        (";
                    // line 70
                    echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\CodeExtension')->formatArgs(twig_get_attribute($this->env, $this->getSourceContext(), $context["trace"], "args", array()));
                    echo ")
                                                    ";
                }
                // line 72
                echo "
                                                    ";
                // line 73
                if ((((twig_get_attribute($this->env, $this->getSourceContext(), $context["trace"], "file", array(), "any", true, true) && twig_get_attribute($this->env, $this->getSourceContext(), $context["trace"], "file", array())) && twig_get_attribute($this->env, $this->getSourceContext(), $context["trace"], "line", array(), "any", true, true)) && twig_get_attribute($this->env, $this->getSourceContext(), $context["trace"], "line", array()))) {
                    // line 74
                    echo "                                                        ";
                    echo ((twig_get_attribute($this->env, $this->getSourceContext(), $context["trace"], "function", array())) ? ("<br />") : (""));
                    echo "
                                                        in ";
                    // line 75
                    echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\CodeExtension')->formatFile(twig_get_attribute($this->env, $this->getSourceContext(), $context["trace"], "file", array()), twig_get_attribute($this->env, $this->getSourceContext(), $context["trace"], "line", array()));
                    echo "&nbsp;
                                                        ";
                    // line 76
                    echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\CodeExtension')->fileExcerpt(twig_get_attribute($this->env, $this->getSourceContext(), $context["trace"], "file", array()), twig_get_attribute($this->env, $this->getSourceContext(), $context["trace"], "line", array()));
                    echo "

                                                    ";
                }
                // line 79
                echo "                                                </div>
                                            </div>
                                        </li>
                                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['i'], $context['trace'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 83
            echo "                                </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['n'], $context['position'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 93
        echo "
";
        
        $__internal_3f6cadc991c8b08d4747029e3501e8209169b5587c7942cad85f4f0b6fcb746c->leave($__internal_3f6cadc991c8b08d4747029e3501e8209169b5587c7942cad85f4f0b6fcb746c_prof);

        
        $__internal_11ccaf42c739dd930a361d0a523264b0fc74a265b6738a065944f1eb0cc8ae70->leave($__internal_11ccaf42c739dd930a361d0a523264b0fc74a265b6738a065944f1eb0cc8ae70_prof);

    }

    public function getTemplateName()
    {
        return "AvanzuAdminThemeBundle:Exception:exception_full.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  261 => 93,  246 => 83,  237 => 79,  231 => 76,  227 => 75,  222 => 74,  220 => 73,  217 => 72,  212 => 70,  207 => 68,  201 => 67,  197 => 65,  195 => 64,  188 => 60,  177 => 52,  173 => 50,  169 => 49,  162 => 45,  155 => 41,  151 => 40,  147 => 39,  137 => 32,  131 => 29,  123 => 24,  116 => 19,  112 => 18,  103 => 12,  98 => 10,  92 => 7,  89 => 6,  80 => 5,  60 => 3,  42 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'AvanzuAdminThemeBundle:layout:base-layout.html.twig' %}
{% block page_title %} Error {% endblock %}
{% block page_subtitle %} {{ status_code }} {% endblock %}

{% block page_content %}
    <div class=\"error-page\">
        <h2 class=\"headline\">{{ status_code }}</h2>

        <div class=\"error-content\">
            <h3>{{ 'Something seems to have gone wrong'|trans() }}</h3>

            <p>{{ exception.message }}</p>
        </div>
    </div>

    <div class=\"\">

    {% for n, position in exception.toarray %}

        <div class=\"box box-danger\">
            <div class=\"box-header\">
                <i class=\"fa fa-warning\"></i>

                <h3 class=\"box-title\">{{ position.class|abbr_class }}</h3>
            </div>
            <div class=\"box-body\">

                <div class=\"callout callout-danger\">
                    {{ position.message|nl2br|format_file_from_text }}
                </div>

                <div class=\"box-group\" id=\"box-{{ n }}\">


                    <!-- trace -->
                    <div class=\"panel box box-warning\">
                        <div class=\"box-header\">
                            <h4 class=\"box-title\">
                                <a data-toggle=\"collapse\" data-parent=\"box-{{ n }}\"
                                   href=\"#trace-{{ n }}\">
                                    {{ 'Stack Trace'|trans() }}
                                </a>
                            </h4>
                        </div>
                        <div id=\"trace-{{ n }}\" class=\"panel-collapse collapse\">
                            <div class=\"box-body\">
                                <div class=\"panel\">
                                <ul class=\"timeline\">
                                    {% for i, trace in position.trace %}
                                        <li class=\"time-label\">
                                                    <span class=\"bg-red\">
                                                        Stack #{{ i }}
                                                    </span>
                                        </li>
                                        <li>
                                            <i class=\"fa fa-code bg-blue\"></i>

                                            <div class=\"timeline-item\">
                                                <h3 class=\"timeline-header\">
                                                    {{ trace.file }}
                                                </h3>

                                                <div class=\"timeline-body\">
                                                    {% if trace.function %}
                                                        at
                                                        <strong>
                                                            <abbr title=\"{{ trace.class }}\">{{ trace.short_class }}</abbr>
                                                            {{ trace.type ~ trace.function }}
                                                        </strong>
                                                        ({{ trace.args|format_args }})
                                                    {% endif %}

                                                    {% if trace.file is defined and trace.file and trace.line is defined and trace.line %}
                                                        {{ trace.function ? '<br />' : '' }}
                                                        in {{ trace.file|format_file(trace.line) }}&nbsp;
                                                        {{ trace.file|file_excerpt(trace.line) }}

                                                    {% endif %}
                                                </div>
                                            </div>
                                        </li>
                                    {% endfor %}
                                </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
    {% endfor %}

{% endblock %}", "AvanzuAdminThemeBundle:Exception:exception_full.html.twig", "/home/sorina/Documents/work/movies_crowler/vendor/avanzu/admin-theme-bundle/Resources/views/Exception/exception_full.html.twig");
    }
}
