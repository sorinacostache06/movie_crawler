<?php

/* @Framework/Form/collection_widget.html.php */
class __TwigTemplate_b12bd99971de9b9455642a5867c954f1724f917303379f6f2a4866ff9efc20f4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_99641152354aabea6a5d1cb8b5ce4d4f760849deab43db8ba336503008282a26 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_99641152354aabea6a5d1cb8b5ce4d4f760849deab43db8ba336503008282a26->enter($__internal_99641152354aabea6a5d1cb8b5ce4d4f760849deab43db8ba336503008282a26_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/collection_widget.html.php"));

        $__internal_de80c381c5465b17d8750567aea0d0e23c48833b9c9358be559ac118d74bbe00 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_de80c381c5465b17d8750567aea0d0e23c48833b9c9358be559ac118d74bbe00->enter($__internal_de80c381c5465b17d8750567aea0d0e23c48833b9c9358be559ac118d74bbe00_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/collection_widget.html.php"));

        // line 1
        echo "<?php if (isset(\$prototype)): ?>
    <?php \$attr['data-prototype'] = \$view->escape(\$view['form']->row(\$prototype)) ?>
<?php endif ?>
<?php echo \$view['form']->widget(\$form, array('attr' => \$attr)) ?>
";
        
        $__internal_99641152354aabea6a5d1cb8b5ce4d4f760849deab43db8ba336503008282a26->leave($__internal_99641152354aabea6a5d1cb8b5ce4d4f760849deab43db8ba336503008282a26_prof);

        
        $__internal_de80c381c5465b17d8750567aea0d0e23c48833b9c9358be559ac118d74bbe00->leave($__internal_de80c381c5465b17d8750567aea0d0e23c48833b9c9358be559ac118d74bbe00_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/collection_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (isset(\$prototype)): ?>
    <?php \$attr['data-prototype'] = \$view->escape(\$view['form']->row(\$prototype)) ?>
<?php endif ?>
<?php echo \$view['form']->widget(\$form, array('attr' => \$attr)) ?>
", "@Framework/Form/collection_widget.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/collection_widget.html.php");
    }
}
