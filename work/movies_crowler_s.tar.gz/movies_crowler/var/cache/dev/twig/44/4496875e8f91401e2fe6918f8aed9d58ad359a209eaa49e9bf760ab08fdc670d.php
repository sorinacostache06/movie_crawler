<?php

/* AvanzuAdminThemeBundle:Breadcrumb:breadcrumb.html.twig */
class __TwigTemplate_3c0bd7f12bf7f63f9a2fa14db6d3d54ba9ddf09a7d24828e8ad429676a2b21ce extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7edd076a3364e58df5417527e4ca541ad82d939e4d6eed169865a27f242f8733 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7edd076a3364e58df5417527e4ca541ad82d939e4d6eed169865a27f242f8733->enter($__internal_7edd076a3364e58df5417527e4ca541ad82d939e4d6eed169865a27f242f8733_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AvanzuAdminThemeBundle:Breadcrumb:breadcrumb.html.twig"));

        $__internal_9745755f51631beed139ab002f21c8804c6614eb53f692eb7bd46114a71d20bd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9745755f51631beed139ab002f21c8804c6614eb53f692eb7bd46114a71d20bd->enter($__internal_9745755f51631beed139ab002f21c8804c6614eb53f692eb7bd46114a71d20bd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AvanzuAdminThemeBundle:Breadcrumb:breadcrumb.html.twig"));

        // line 1
        echo "<ol class=\"breadcrumb\">
    <li>
        <a href=\"";
        // line 3
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("avanzu_admin_home");
        echo "\">
            <i class=\"fa fa-dashboard\"></i>
            ";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Home", array(), "AvanzuAdminTheme"), "html", null, true);
        echo "
        </a>
    </li>
    ";
        // line 8
        if ((isset($context["active"]) || array_key_exists("active", $context) ? $context["active"] : (function () { throw new Twig_Error_Runtime('Variable "active" does not exist.', 8, $this->getSourceContext()); })())) {
            // line 9
            echo "        ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["active"]) || array_key_exists("active", $context) ? $context["active"] : (function () { throw new Twig_Error_Runtime('Variable "active" does not exist.', 9, $this->getSourceContext()); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                // line 10
                echo "            <li><a href=\"";
                echo twig_escape_filter($this->env, ((twig_test_empty(twig_get_attribute($this->env, $this->getSourceContext(), $context["item"], "route", array()))) ? ("#") : (((twig_in_filter("/", twig_get_attribute($this->env, $this->getSourceContext(), $context["item"], "route", array()))) ? (twig_get_attribute($this->env, $this->getSourceContext(), $context["item"], "route", array())) : ($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath(twig_get_attribute($this->env, $this->getSourceContext(), $context["item"], "route", array()), twig_get_attribute($this->env, $this->getSourceContext(), $context["item"], "routeArgs", array())))))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["item"], "label", array()), "html", null, true);
                echo "</a></li>
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 12
            echo "    ";
        }
        // line 13
        echo "    <li class=\"active\">";
        echo twig_escape_filter($this->env, (isset($context["title"]) || array_key_exists("title", $context) ? $context["title"] : (function () { throw new Twig_Error_Runtime('Variable "title" does not exist.', 13, $this->getSourceContext()); })()), "html", null, true);
        echo "</li>
</ol>";
        
        $__internal_7edd076a3364e58df5417527e4ca541ad82d939e4d6eed169865a27f242f8733->leave($__internal_7edd076a3364e58df5417527e4ca541ad82d939e4d6eed169865a27f242f8733_prof);

        
        $__internal_9745755f51631beed139ab002f21c8804c6614eb53f692eb7bd46114a71d20bd->leave($__internal_9745755f51631beed139ab002f21c8804c6614eb53f692eb7bd46114a71d20bd_prof);

    }

    public function getTemplateName()
    {
        return "AvanzuAdminThemeBundle:Breadcrumb:breadcrumb.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  61 => 13,  58 => 12,  47 => 10,  42 => 9,  40 => 8,  34 => 5,  29 => 3,  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<ol class=\"breadcrumb\">
    <li>
        <a href=\"{{ path('avanzu_admin_home') }}\">
            <i class=\"fa fa-dashboard\"></i>
            {{ 'Home'|trans({}, 'AvanzuAdminTheme') }}
        </a>
    </li>
    {% if active %}
        {% for item in active %}
            <li><a href=\"{{ item.route is empty ? '#' : '/' in item.route ? item.route : path(item.route, item.routeArgs) }}\">{{ item.label }}</a></li>
        {% endfor %}
    {% endif %}
    <li class=\"active\">{{ title }}</li>
</ol>", "AvanzuAdminThemeBundle:Breadcrumb:breadcrumb.html.twig", "/home/sorina/Documents/work/movies_crowler/vendor/avanzu/admin-theme-bundle/Resources/views/Breadcrumb/breadcrumb.html.twig");
    }
}
