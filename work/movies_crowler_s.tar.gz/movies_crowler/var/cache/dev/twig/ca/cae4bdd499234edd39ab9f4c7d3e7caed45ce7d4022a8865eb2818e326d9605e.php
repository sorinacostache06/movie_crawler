<?php

/* @Framework/Form/submit_widget.html.php */
class __TwigTemplate_90bd864ee72c16d4605a298e6e2244b0b7bf9e47946a5a9e7591059147a01182 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bdbd474959a4b7ecc90efe3973545ea7f98b8f9b6008a82029cb1587a4eb349a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bdbd474959a4b7ecc90efe3973545ea7f98b8f9b6008a82029cb1587a4eb349a->enter($__internal_bdbd474959a4b7ecc90efe3973545ea7f98b8f9b6008a82029cb1587a4eb349a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/submit_widget.html.php"));

        $__internal_508514a2a4be435042911fcc4969e57a8a259086751e9536adec9bd4952191da = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_508514a2a4be435042911fcc4969e57a8a259086751e9536adec9bd4952191da->enter($__internal_508514a2a4be435042911fcc4969e57a8a259086751e9536adec9bd4952191da_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/submit_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'submit')) ?>
";
        
        $__internal_bdbd474959a4b7ecc90efe3973545ea7f98b8f9b6008a82029cb1587a4eb349a->leave($__internal_bdbd474959a4b7ecc90efe3973545ea7f98b8f9b6008a82029cb1587a4eb349a_prof);

        
        $__internal_508514a2a4be435042911fcc4969e57a8a259086751e9536adec9bd4952191da->leave($__internal_508514a2a4be435042911fcc4969e57a8a259086751e9536adec9bd4952191da_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/submit_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'submit')) ?>
", "@Framework/Form/submit_widget.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/submit_widget.html.php");
    }
}
