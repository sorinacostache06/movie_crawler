<?php

/* :Admin:edit_movie.html.twig */
class __TwigTemplate_1cc7fde327ceb14e30923bcaa0a47ae28a3b4a33af05471aeb9812c20836b885 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base-layout.html.twig", ":Admin:edit_movie.html.twig", 1);
        $this->blocks = array(
            'page_title' => array($this, 'block_page_title'),
            'page_subtitle' => array($this, 'block_page_subtitle'),
            'page_content' => array($this, 'block_page_content'),
            'flashBag' => array($this, 'block_flashBag'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base-layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e933d13b0cda2ac132ee1ffa7d0ffcf8045e2a645d1cfad29f48c1f157768ca5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e933d13b0cda2ac132ee1ffa7d0ffcf8045e2a645d1cfad29f48c1f157768ca5->enter($__internal_e933d13b0cda2ac132ee1ffa7d0ffcf8045e2a645d1cfad29f48c1f157768ca5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Admin:edit_movie.html.twig"));

        $__internal_0c2d55ed82d4e0fc960e2cff5664aafd8b25431b7d3b55b58358b5e52d31dd1c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0c2d55ed82d4e0fc960e2cff5664aafd8b25431b7d3b55b58358b5e52d31dd1c->enter($__internal_0c2d55ed82d4e0fc960e2cff5664aafd8b25431b7d3b55b58358b5e52d31dd1c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Admin:edit_movie.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e933d13b0cda2ac132ee1ffa7d0ffcf8045e2a645d1cfad29f48c1f157768ca5->leave($__internal_e933d13b0cda2ac132ee1ffa7d0ffcf8045e2a645d1cfad29f48c1f157768ca5_prof);

        
        $__internal_0c2d55ed82d4e0fc960e2cff5664aafd8b25431b7d3b55b58358b5e52d31dd1c->leave($__internal_0c2d55ed82d4e0fc960e2cff5664aafd8b25431b7d3b55b58358b5e52d31dd1c_prof);

    }

    // line 2
    public function block_page_title($context, array $blocks = array())
    {
        $__internal_6cfb71331427ec828d76a1238eea6d03d88604d340443c0fa0b6de4757cec680 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6cfb71331427ec828d76a1238eea6d03d88604d340443c0fa0b6de4757cec680->enter($__internal_6cfb71331427ec828d76a1238eea6d03d88604d340443c0fa0b6de4757cec680_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_title"));

        $__internal_a6941de391325a3aec37e7846f8c79f0bfa32507d2bb4a8bbbda614ead5e78ec = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a6941de391325a3aec37e7846f8c79f0bfa32507d2bb4a8bbbda614ead5e78ec->enter($__internal_a6941de391325a3aec37e7846f8c79f0bfa32507d2bb4a8bbbda614ead5e78ec_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_title"));

        // line 3
        echo "    ";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("navigation.management_group_edit_page.title"), "html", null, true);
        echo "
";
        
        $__internal_a6941de391325a3aec37e7846f8c79f0bfa32507d2bb4a8bbbda614ead5e78ec->leave($__internal_a6941de391325a3aec37e7846f8c79f0bfa32507d2bb4a8bbbda614ead5e78ec_prof);

        
        $__internal_6cfb71331427ec828d76a1238eea6d03d88604d340443c0fa0b6de4757cec680->leave($__internal_6cfb71331427ec828d76a1238eea6d03d88604d340443c0fa0b6de4757cec680_prof);

    }

    // line 5
    public function block_page_subtitle($context, array $blocks = array())
    {
        $__internal_5c354b3e33fde1e7f05bdc09d16a529f6c2cb0563d61845decda52ac9d28e8b8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5c354b3e33fde1e7f05bdc09d16a529f6c2cb0563d61845decda52ac9d28e8b8->enter($__internal_5c354b3e33fde1e7f05bdc09d16a529f6c2cb0563d61845decda52ac9d28e8b8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_subtitle"));

        $__internal_86cffa81f1e26ea1570cf7d7ac65e72e08dc4dcc656e4c51afcb62cdb4bc80e7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_86cffa81f1e26ea1570cf7d7ac65e72e08dc4dcc656e4c51afcb62cdb4bc80e7->enter($__internal_86cffa81f1e26ea1570cf7d7ac65e72e08dc4dcc656e4c51afcb62cdb4bc80e7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_subtitle"));

        // line 6
        echo "    ";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("navigation.management_group_edit_page.subtitle"), "html", null, true);
        echo "
";
        
        $__internal_86cffa81f1e26ea1570cf7d7ac65e72e08dc4dcc656e4c51afcb62cdb4bc80e7->leave($__internal_86cffa81f1e26ea1570cf7d7ac65e72e08dc4dcc656e4c51afcb62cdb4bc80e7_prof);

        
        $__internal_5c354b3e33fde1e7f05bdc09d16a529f6c2cb0563d61845decda52ac9d28e8b8->leave($__internal_5c354b3e33fde1e7f05bdc09d16a529f6c2cb0563d61845decda52ac9d28e8b8_prof);

    }

    // line 8
    public function block_page_content($context, array $blocks = array())
    {
        $__internal_5e2f4cd821304f73da5763999152cd9e4f23d5db6da30bd187b226b8a4926005 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5e2f4cd821304f73da5763999152cd9e4f23d5db6da30bd187b226b8a4926005->enter($__internal_5e2f4cd821304f73da5763999152cd9e4f23d5db6da30bd187b226b8a4926005_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_content"));

        $__internal_d8c10d48c9d06594085c234b17d736aeb27fbad11589a5fff1f0a5825a484687 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d8c10d48c9d06594085c234b17d736aeb27fbad11589a5fff1f0a5825a484687->enter($__internal_d8c10d48c9d06594085c234b17d736aeb27fbad11589a5fff1f0a5825a484687_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_content"));

        // line 9
        echo "    ";
        $this->displayBlock('flashBag', $context, $blocks);
        // line 12
        echo "    <div class=\"row\">
        <div class=\"col-lg-4 col-lg-offset-4\">
            <div class=\"box box-success\">
                <div class=\"box-body\">
                    ";
        // line 16
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 16, $this->getSourceContext()); })()), 'form_start');
        echo "
                    ";
        // line 17
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 17, $this->getSourceContext()); })()), 'errors');
        echo "

                    ";
        // line 19
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 19, $this->getSourceContext()); })()), "id", array()), 'row');
        echo "
                    ";
        // line 20
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 20, $this->getSourceContext()); })()), "title", array()), 'row');
        echo "
                    <div class=\"row\">
                        <div class=\"col-xs-6 col-xs-offset-3\">
                            ";
        // line 23
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 23, $this->getSourceContext()); })()), "save", array()), 'row', array("label" => "manage_voucher.form.name_button_submit", "attr" => array("class" => "btn btn-primary btn-block btn-flat")));
        echo "
                        </div>
                    </div>
                    ";
        // line 26
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 26, $this->getSourceContext()); })()), 'form_end');
        echo "
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_d8c10d48c9d06594085c234b17d736aeb27fbad11589a5fff1f0a5825a484687->leave($__internal_d8c10d48c9d06594085c234b17d736aeb27fbad11589a5fff1f0a5825a484687_prof);

        
        $__internal_5e2f4cd821304f73da5763999152cd9e4f23d5db6da30bd187b226b8a4926005->leave($__internal_5e2f4cd821304f73da5763999152cd9e4f23d5db6da30bd187b226b8a4926005_prof);

    }

    // line 9
    public function block_flashBag($context, array $blocks = array())
    {
        $__internal_198f0533f1cec7ad5f1f84fbe747b80984c091feaf6e8fad22d2183a1442f6a1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_198f0533f1cec7ad5f1f84fbe747b80984c091feaf6e8fad22d2183a1442f6a1->enter($__internal_198f0533f1cec7ad5f1f84fbe747b80984c091feaf6e8fad22d2183a1442f6a1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "flashBag"));

        $__internal_fbe007e354acdb4721b52e8eff5b99821e14b3d2549ce241781d7b8c060d69da = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fbe007e354acdb4721b52e8eff5b99821e14b3d2549ce241781d7b8c060d69da->enter($__internal_fbe007e354acdb4721b52e8eff5b99821e14b3d2549ce241781d7b8c060d69da_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "flashBag"));

        // line 10
        echo "        ";
        $this->displayParentBlock("flashBag", $context, $blocks);
        echo "
    ";
        
        $__internal_fbe007e354acdb4721b52e8eff5b99821e14b3d2549ce241781d7b8c060d69da->leave($__internal_fbe007e354acdb4721b52e8eff5b99821e14b3d2549ce241781d7b8c060d69da_prof);

        
        $__internal_198f0533f1cec7ad5f1f84fbe747b80984c091feaf6e8fad22d2183a1442f6a1->leave($__internal_198f0533f1cec7ad5f1f84fbe747b80984c091feaf6e8fad22d2183a1442f6a1_prof);

    }

    public function getTemplateName()
    {
        return ":Admin:edit_movie.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  155 => 10,  146 => 9,  130 => 26,  124 => 23,  118 => 20,  114 => 19,  109 => 17,  105 => 16,  99 => 12,  96 => 9,  87 => 8,  74 => 6,  65 => 5,  52 => 3,  43 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '::base-layout.html.twig' %}
{% block page_title %}
    {{ 'navigation.management_group_edit_page.title'|trans }}
{% endblock %}
{% block page_subtitle %}
    {{ 'navigation.management_group_edit_page.subtitle'|trans }}
{% endblock %}
{% block page_content %}
    {% block flashBag %}
        {{ parent() }}
    {% endblock %}
    <div class=\"row\">
        <div class=\"col-lg-4 col-lg-offset-4\">
            <div class=\"box box-success\">
                <div class=\"box-body\">
                    {{ form_start(form) }}
                    {{ form_errors(form) }}

                    {{ form_row(form.id) }}
                    {{ form_row(form.title) }}
                    <div class=\"row\">
                        <div class=\"col-xs-6 col-xs-offset-3\">
                            {{ form_row(form.save, {'label':'manage_voucher.form.name_button_submit', 'attr': {'class': 'btn btn-primary btn-block btn-flat'}}) }}
                        </div>
                    </div>
                    {{ form_end(form) }}
                </div>
            </div>
        </div>
    </div>
{% endblock %}", ":Admin:edit_movie.html.twig", "/home/sorina/Documents/work/movies_crowler/app/Resources/views/Admin/edit_movie.html.twig");
    }
}
