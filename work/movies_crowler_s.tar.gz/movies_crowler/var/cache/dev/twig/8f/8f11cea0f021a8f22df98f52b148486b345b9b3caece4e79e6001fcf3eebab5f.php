<?php

/* @Framework/Form/form_rows.html.php */
class __TwigTemplate_b7861ed2c38fec4c050869f785cb1f3cf20b2e16ba3e79effe82ca78263f4e12 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5c3d8c012206975f2de74f4f1e1bbceeee3d7845267aee6fca5e3b21f607781b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5c3d8c012206975f2de74f4f1e1bbceeee3d7845267aee6fca5e3b21f607781b->enter($__internal_5c3d8c012206975f2de74f4f1e1bbceeee3d7845267aee6fca5e3b21f607781b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rows.html.php"));

        $__internal_b2cd09706f54327215e9539df0165fea7c7ca3f62fd9022572c598c00a68ce1a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b2cd09706f54327215e9539df0165fea7c7ca3f62fd9022572c598c00a68ce1a->enter($__internal_b2cd09706f54327215e9539df0165fea7c7ca3f62fd9022572c598c00a68ce1a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rows.html.php"));

        // line 1
        echo "<?php foreach (\$form as \$child) : ?>
    <?php echo \$view['form']->row(\$child) ?>
<?php endforeach; ?>
";
        
        $__internal_5c3d8c012206975f2de74f4f1e1bbceeee3d7845267aee6fca5e3b21f607781b->leave($__internal_5c3d8c012206975f2de74f4f1e1bbceeee3d7845267aee6fca5e3b21f607781b_prof);

        
        $__internal_b2cd09706f54327215e9539df0165fea7c7ca3f62fd9022572c598c00a68ce1a->leave($__internal_b2cd09706f54327215e9539df0165fea7c7ca3f62fd9022572c598c00a68ce1a_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_rows.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php foreach (\$form as \$child) : ?>
    <?php echo \$view['form']->row(\$child) ?>
<?php endforeach; ?>
", "@Framework/Form/form_rows.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_rows.html.php");
    }
}
