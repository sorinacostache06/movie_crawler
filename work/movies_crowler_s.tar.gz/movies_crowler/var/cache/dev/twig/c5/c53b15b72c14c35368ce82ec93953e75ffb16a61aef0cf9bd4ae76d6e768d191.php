<?php

/* @WebProfiler/Collector/ajax.html.twig */
class __TwigTemplate_f7d136161dceccdf2457bcedd1be96999566e56ceda6a334b5e1613e30fa5b28 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/ajax.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_23bf75560ccbf09eb7b762ae6a7b33cd0e78fbb1342309f9de865656094b0a7f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_23bf75560ccbf09eb7b762ae6a7b33cd0e78fbb1342309f9de865656094b0a7f->enter($__internal_23bf75560ccbf09eb7b762ae6a7b33cd0e78fbb1342309f9de865656094b0a7f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/ajax.html.twig"));

        $__internal_ed87db81bb3321c0a363285a477021f532e869bc4da3a3ae12dc224faf0198f4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ed87db81bb3321c0a363285a477021f532e869bc4da3a3ae12dc224faf0198f4->enter($__internal_ed87db81bb3321c0a363285a477021f532e869bc4da3a3ae12dc224faf0198f4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/ajax.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_23bf75560ccbf09eb7b762ae6a7b33cd0e78fbb1342309f9de865656094b0a7f->leave($__internal_23bf75560ccbf09eb7b762ae6a7b33cd0e78fbb1342309f9de865656094b0a7f_prof);

        
        $__internal_ed87db81bb3321c0a363285a477021f532e869bc4da3a3ae12dc224faf0198f4->leave($__internal_ed87db81bb3321c0a363285a477021f532e869bc4da3a3ae12dc224faf0198f4_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_15c887e09dffe21185c643882d3d4a49fec11a8d3562fea3d3c912180c12bad0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_15c887e09dffe21185c643882d3d4a49fec11a8d3562fea3d3c912180c12bad0->enter($__internal_15c887e09dffe21185c643882d3d4a49fec11a8d3562fea3d3c912180c12bad0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_b2b5b417943b2a0d61690e284990cf624b7bad7fe4cc3b8b5c61c4c45dffc3f5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b2b5b417943b2a0d61690e284990cf624b7bad7fe4cc3b8b5c61c4c45dffc3f5->enter($__internal_b2b5b417943b2a0d61690e284990cf624b7bad7fe4cc3b8b5c61c4c45dffc3f5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        // line 4
        echo "    ";
        ob_start();
        // line 5
        echo "        ";
        echo twig_include($this->env, $context, "@WebProfiler/Icon/ajax.svg");
        echo "
        <span class=\"sf-toolbar-value sf-toolbar-ajax-requests\">0</span>
    ";
        $context["icon"] = ('' === $tmp = ob_get_clean()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        // line 8
        echo "
    ";
        // line 9
        $context["text"] = ('' === $tmp = "        <div class=\"sf-toolbar-info-piece\">
            <b class=\"sf-toolbar-ajax-info\"></b>
        </div>
        <div class=\"sf-toolbar-info-piece\">
            <table class=\"sf-toolbar-ajax-requests\">
                <thead>
                    <tr>
                        <th>Method</th>
                        <th>Type</th>
                        <th>Status</th>
                        <th>URL</th>
                        <th>Time</th>
                        <th>Profile</th>
                    </tr>
                </thead>
                <tbody class=\"sf-toolbar-ajax-request-list\"></tbody>
            </table>
        </div>
    ") ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        // line 29
        echo "
    ";
        // line 30
        echo twig_include($this->env, $context, "@WebProfiler/Profiler/toolbar_item.html.twig", array("link" => false));
        echo "
";
        
        $__internal_b2b5b417943b2a0d61690e284990cf624b7bad7fe4cc3b8b5c61c4c45dffc3f5->leave($__internal_b2b5b417943b2a0d61690e284990cf624b7bad7fe4cc3b8b5c61c4c45dffc3f5_prof);

        
        $__internal_15c887e09dffe21185c643882d3d4a49fec11a8d3562fea3d3c912180c12bad0->leave($__internal_15c887e09dffe21185c643882d3d4a49fec11a8d3562fea3d3c912180c12bad0_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/ajax.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  85 => 30,  82 => 29,  62 => 9,  59 => 8,  52 => 5,  49 => 4,  40 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}
    {% set icon %}
        {{ include('@WebProfiler/Icon/ajax.svg') }}
        <span class=\"sf-toolbar-value sf-toolbar-ajax-requests\">0</span>
    {% endset %}

    {% set text %}
        <div class=\"sf-toolbar-info-piece\">
            <b class=\"sf-toolbar-ajax-info\"></b>
        </div>
        <div class=\"sf-toolbar-info-piece\">
            <table class=\"sf-toolbar-ajax-requests\">
                <thead>
                    <tr>
                        <th>Method</th>
                        <th>Type</th>
                        <th>Status</th>
                        <th>URL</th>
                        <th>Time</th>
                        <th>Profile</th>
                    </tr>
                </thead>
                <tbody class=\"sf-toolbar-ajax-request-list\"></tbody>
            </table>
        </div>
    {% endset %}

    {{ include('@WebProfiler/Profiler/toolbar_item.html.twig', { link: false }) }}
{% endblock %}
", "@WebProfiler/Collector/ajax.html.twig", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/ajax.html.twig");
    }
}
