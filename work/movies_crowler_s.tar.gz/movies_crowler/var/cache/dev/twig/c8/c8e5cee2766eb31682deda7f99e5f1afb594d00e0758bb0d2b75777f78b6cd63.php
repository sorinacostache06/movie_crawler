<?php

/* :Admin:login.html.twig */
class __TwigTemplate_47ceb7142267a569ecf03bee5d0db2a81913699bd7a532282d07322baad78788 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::login-layout.html.twig", ":Admin:login.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'page_content' => array($this, 'block_page_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::login-layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2954a9b7838381df01e9da555fd1f9a2d46abd46183c0e2cb10175760ca1932f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2954a9b7838381df01e9da555fd1f9a2d46abd46183c0e2cb10175760ca1932f->enter($__internal_2954a9b7838381df01e9da555fd1f9a2d46abd46183c0e2cb10175760ca1932f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Admin:login.html.twig"));

        $__internal_2e4158983bec9d9ca6fe7a09a843993efc51c0480e695f97d6ceb75d220f8899 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2e4158983bec9d9ca6fe7a09a843993efc51c0480e695f97d6ceb75d220f8899->enter($__internal_2e4158983bec9d9ca6fe7a09a843993efc51c0480e695f97d6ceb75d220f8899_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Admin:login.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_2954a9b7838381df01e9da555fd1f9a2d46abd46183c0e2cb10175760ca1932f->leave($__internal_2954a9b7838381df01e9da555fd1f9a2d46abd46183c0e2cb10175760ca1932f_prof);

        
        $__internal_2e4158983bec9d9ca6fe7a09a843993efc51c0480e695f97d6ceb75d220f8899->leave($__internal_2e4158983bec9d9ca6fe7a09a843993efc51c0480e695f97d6ceb75d220f8899_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_abd1f1ab2854aba1388c9fbafa9b5cdcf30d1c47b40c18c43b448927ce013cb8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_abd1f1ab2854aba1388c9fbafa9b5cdcf30d1c47b40c18c43b448927ce013cb8->enter($__internal_abd1f1ab2854aba1388c9fbafa9b5cdcf30d1c47b40c18c43b448927ce013cb8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_929b21e20aafacd3da167bcd42f494ae210296a27a9096ac62b65ac81a02d98a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_929b21e20aafacd3da167bcd42f494ae210296a27a9096ac62b65ac81a02d98a->enter($__internal_929b21e20aafacd3da167bcd42f494ae210296a27a9096ac62b65ac81a02d98a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 4
        echo "    ";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("login.title"), "html", null, true);
        echo "
";
        
        $__internal_929b21e20aafacd3da167bcd42f494ae210296a27a9096ac62b65ac81a02d98a->leave($__internal_929b21e20aafacd3da167bcd42f494ae210296a27a9096ac62b65ac81a02d98a_prof);

        
        $__internal_abd1f1ab2854aba1388c9fbafa9b5cdcf30d1c47b40c18c43b448927ce013cb8->leave($__internal_abd1f1ab2854aba1388c9fbafa9b5cdcf30d1c47b40c18c43b448927ce013cb8_prof);

    }

    // line 6
    public function block_page_content($context, array $blocks = array())
    {
        $__internal_30a90ea5eeccd1f8d829b0c4cbf7ba60df8e03613d6cf7369c32670ba7507b86 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_30a90ea5eeccd1f8d829b0c4cbf7ba60df8e03613d6cf7369c32670ba7507b86->enter($__internal_30a90ea5eeccd1f8d829b0c4cbf7ba60df8e03613d6cf7369c32670ba7507b86_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_content"));

        $__internal_fbd918b2651ae7780c6c0938da3dc4ce36ede17768890043eb2b72258bfb9a15 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fbd918b2651ae7780c6c0938da3dc4ce36ede17768890043eb2b72258bfb9a15->enter($__internal_fbd918b2651ae7780c6c0938da3dc4ce36ede17768890043eb2b72258bfb9a15_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_content"));

        // line 7
        echo "    <body class=\"hold-transition register-page\">
    <div class=\"register-box\">
        <div class=\"register-box-body\">
            <p class=\"login-box-msg\"><b>";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("login.title"), "html", null, true);
        echo "</b></p>
            ";
        // line 11
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 11, $this->getSourceContext()); })()), 'form_start');
        echo "
            ";
        // line 12
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 12, $this->getSourceContext()); })()), "username", array()), 'row', array("attr" => array("placeholder" => "login.form.firstandlast_name.placeholder"), "full_name" => "_username"));
        echo "
            ";
        // line 13
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 13, $this->getSourceContext()); })()), "password", array()), 'row', array("attr" => array("placeholder" => "login.form.password.placeholder"), "full_name" => "_password"));
        echo "
            <div class=\"row\">
                <div class=\"col-xs-6\">
                    ";
        // line 16
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 16, $this->getSourceContext()); })()), "remember_me", array()), 'row', array("label" => "login.form.remember_me", "full_name" => "_remember_me"));
        echo "
                </div>
                <div class=\"col-xs-6\">
                    ";
        // line 19
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 19, $this->getSourceContext()); })()), "login", array()), 'row', array("label" => "login.form.name_button_submit", "attr" => array("class" => "btn btn-primary btn-block btn-flat")));
        echo "
                </div>
                <br/>
                <a href=\"http://localhost:8000/create_account\">";
        // line 22
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("button.create.account"), "html", null, true);
        echo "</a>
            </div>
            ";
        // line 24
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 24, $this->getSourceContext()); })()), 'form_end');
        echo "
        </div>
    </div>
    </body>
";
        
        $__internal_fbd918b2651ae7780c6c0938da3dc4ce36ede17768890043eb2b72258bfb9a15->leave($__internal_fbd918b2651ae7780c6c0938da3dc4ce36ede17768890043eb2b72258bfb9a15_prof);

        
        $__internal_30a90ea5eeccd1f8d829b0c4cbf7ba60df8e03613d6cf7369c32670ba7507b86->leave($__internal_30a90ea5eeccd1f8d829b0c4cbf7ba60df8e03613d6cf7369c32670ba7507b86_prof);

    }

    public function getTemplateName()
    {
        return ":Admin:login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  112 => 24,  107 => 22,  101 => 19,  95 => 16,  89 => 13,  85 => 12,  81 => 11,  77 => 10,  72 => 7,  63 => 6,  50 => 4,  41 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '::login-layout.html.twig' %}

{% block title %}
    {{ 'login.title'|trans }}
{% endblock %}
{% block page_content %}
    <body class=\"hold-transition register-page\">
    <div class=\"register-box\">
        <div class=\"register-box-body\">
            <p class=\"login-box-msg\"><b>{{ 'login.title'|trans }}</b></p>
            {{ form_start(form) }}
            {{ form_row(form.username, {'attr':{'placeholder':'login.form.firstandlast_name.placeholder'}, 'full_name': '_username'}) }}
            {{ form_row(form.password, {'attr':{'placeholder':'login.form.password.placeholder'}, 'full_name': '_password'}) }}
            <div class=\"row\">
                <div class=\"col-xs-6\">
                    {{ form_row(form.remember_me, {'label':'login.form.remember_me', 'full_name': '_remember_me'}) }}
                </div>
                <div class=\"col-xs-6\">
                    {{ form_row(form.login, {'label':'login.form.name_button_submit', 'attr': {'class': 'btn btn-primary btn-block btn-flat'}}) }}
                </div>
                <br/>
                <a href=\"http://localhost:8000/create_account\">{{'button.create.account'|trans}}</a>
            </div>
            {{ form_end(form) }}
        </div>
    </div>
    </body>
{% endblock %}
", ":Admin:login.html.twig", "/home/sorina/Documents/work/movies_crowler/app/Resources/views/Admin/login.html.twig");
    }
}
