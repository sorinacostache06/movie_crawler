<?php

/* @Framework/Form/attributes.html.php */
class __TwigTemplate_ecb4c91d2e30afb79caee5dbf3d36f391aafa70b494ba20599e151b587e08de6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_670e06f2a160bae9d9d7afdc6d1c5164d47d6a5c7e40cb8eedf47de45cde228b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_670e06f2a160bae9d9d7afdc6d1c5164d47d6a5c7e40cb8eedf47de45cde228b->enter($__internal_670e06f2a160bae9d9d7afdc6d1c5164d47d6a5c7e40cb8eedf47de45cde228b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/attributes.html.php"));

        $__internal_2e7e9dcdaaf60e59c796d5c04d4c1e3f5eaeb072956066a6a4a87bade7430e88 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2e7e9dcdaaf60e59c796d5c04d4c1e3f5eaeb072956066a6a4a87bade7430e88->enter($__internal_2e7e9dcdaaf60e59c796d5c04d4c1e3f5eaeb072956066a6a4a87bade7430e88_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
";
        
        $__internal_670e06f2a160bae9d9d7afdc6d1c5164d47d6a5c7e40cb8eedf47de45cde228b->leave($__internal_670e06f2a160bae9d9d7afdc6d1c5164d47d6a5c7e40cb8eedf47de45cde228b_prof);

        
        $__internal_2e7e9dcdaaf60e59c796d5c04d4c1e3f5eaeb072956066a6a4a87bade7430e88->leave($__internal_2e7e9dcdaaf60e59c796d5c04d4c1e3f5eaeb072956066a6a4a87bade7430e88_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
", "@Framework/Form/attributes.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/attributes.html.php");
    }
}
