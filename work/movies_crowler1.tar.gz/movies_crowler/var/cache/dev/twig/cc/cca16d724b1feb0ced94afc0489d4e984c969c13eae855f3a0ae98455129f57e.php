<?php

/* ::base-layout.html.twig */
class __TwigTemplate_8a68661cc3736ca54c4d7f2fa414d28304984401dfbe3a6fa9fc1d2eeb552523 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("AvanzuAdminThemeBundle:layout:base-layout.html.twig", "::base-layout.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'flashBag' => array($this, 'block_flashBag'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'avanzu_navbar' => array($this, 'block_avanzu_navbar'),
            'avanzu_sidebar' => array($this, 'block_avanzu_sidebar'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "AvanzuAdminThemeBundle:layout:base-layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_934b417dbfbf639151d36e2ebce3e63731bbc3c900c20bbc835c6bcc583ad979 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_934b417dbfbf639151d36e2ebce3e63731bbc3c900c20bbc835c6bcc583ad979->enter($__internal_934b417dbfbf639151d36e2ebce3e63731bbc3c900c20bbc835c6bcc583ad979_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base-layout.html.twig"));

        $__internal_ab3a54f471d0784dbf0eac4e8c6a20c178046da127801fe72c49bebd4d5c5e9c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ab3a54f471d0784dbf0eac4e8c6a20c178046da127801fe72c49bebd4d5c5e9c->enter($__internal_ab3a54f471d0784dbf0eac4e8c6a20c178046da127801fe72c49bebd4d5c5e9c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base-layout.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_934b417dbfbf639151d36e2ebce3e63731bbc3c900c20bbc835c6bcc583ad979->leave($__internal_934b417dbfbf639151d36e2ebce3e63731bbc3c900c20bbc835c6bcc583ad979_prof);

        
        $__internal_ab3a54f471d0784dbf0eac4e8c6a20c178046da127801fe72c49bebd4d5c5e9c->leave($__internal_ab3a54f471d0784dbf0eac4e8c6a20c178046da127801fe72c49bebd4d5c5e9c_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_7eb376be358bec36938d5e3c318b2d57fe6aa08e0eff76f3a0691a8e1d3b8e10 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7eb376be358bec36938d5e3c318b2d57fe6aa08e0eff76f3a0691a8e1d3b8e10->enter($__internal_7eb376be358bec36938d5e3c318b2d57fe6aa08e0eff76f3a0691a8e1d3b8e10_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_4f2e6838f5f07436425b191c1e7d8df6245dff82d0e86577113553977ea2eb31 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4f2e6838f5f07436425b191c1e7d8df6245dff82d0e86577113553977ea2eb31->enter($__internal_4f2e6838f5f07436425b191c1e7d8df6245dff82d0e86577113553977ea2eb31_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 4
        echo "    Movies Crawler
";
        
        $__internal_4f2e6838f5f07436425b191c1e7d8df6245dff82d0e86577113553977ea2eb31->leave($__internal_4f2e6838f5f07436425b191c1e7d8df6245dff82d0e86577113553977ea2eb31_prof);

        
        $__internal_7eb376be358bec36938d5e3c318b2d57fe6aa08e0eff76f3a0691a8e1d3b8e10->leave($__internal_7eb376be358bec36938d5e3c318b2d57fe6aa08e0eff76f3a0691a8e1d3b8e10_prof);

    }

    // line 6
    public function block_flashBag($context, array $blocks = array())
    {
        $__internal_397c10c46f94a3252bce1fb72834a5767218e33a5ce5bd36317709bf140dd21e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_397c10c46f94a3252bce1fb72834a5767218e33a5ce5bd36317709bf140dd21e->enter($__internal_397c10c46f94a3252bce1fb72834a5767218e33a5ce5bd36317709bf140dd21e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "flashBag"));

        $__internal_fe29127c87b45b7dbf1a88bb4bd009db39a095a9f2bb52047d8c6aadd4ac6d6f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fe29127c87b45b7dbf1a88bb4bd009db39a095a9f2bb52047d8c6aadd4ac6d6f->enter($__internal_fe29127c87b45b7dbf1a88bb4bd009db39a095a9f2bb52047d8c6aadd4ac6d6f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "flashBag"));

        // line 7
        echo "    ";
        $this->loadTemplate("::flashBag.html.twig", "::base-layout.html.twig", 7)->display($context);
        
        $__internal_fe29127c87b45b7dbf1a88bb4bd009db39a095a9f2bb52047d8c6aadd4ac6d6f->leave($__internal_fe29127c87b45b7dbf1a88bb4bd009db39a095a9f2bb52047d8c6aadd4ac6d6f_prof);

        
        $__internal_397c10c46f94a3252bce1fb72834a5767218e33a5ce5bd36317709bf140dd21e->leave($__internal_397c10c46f94a3252bce1fb72834a5767218e33a5ce5bd36317709bf140dd21e_prof);

    }

    // line 9
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_ffd4bae3b935ac57dd827469b5933751b6b65d42148216d4af68b60bf430f3fd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ffd4bae3b935ac57dd827469b5933751b6b65d42148216d4af68b60bf430f3fd->enter($__internal_ffd4bae3b935ac57dd827469b5933751b6b65d42148216d4af68b60bf430f3fd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_aa5571ead57e6cf2f8c2da8748b4ae87e17f72107545c67edcdac0452c919c95 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_aa5571ead57e6cf2f8c2da8748b4ae87e17f72107545c67edcdac0452c919c95->enter($__internal_aa5571ead57e6cf2f8c2da8748b4ae87e17f72107545c67edcdac0452c919c95_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 10
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
    <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css\">
    <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.css\" />
    <link rel=\"stylesheet\" href=\"//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css\">
";
        
        $__internal_aa5571ead57e6cf2f8c2da8748b4ae87e17f72107545c67edcdac0452c919c95->leave($__internal_aa5571ead57e6cf2f8c2da8748b4ae87e17f72107545c67edcdac0452c919c95_prof);

        
        $__internal_ffd4bae3b935ac57dd827469b5933751b6b65d42148216d4af68b60bf430f3fd->leave($__internal_ffd4bae3b935ac57dd827469b5933751b6b65d42148216d4af68b60bf430f3fd_prof);

    }

    // line 15
    public function block_avanzu_navbar($context, array $blocks = array())
    {
        $__internal_c101645a7762979081130a54bed6dec7eb246df3fcf140ba14e1d234df267cb1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c101645a7762979081130a54bed6dec7eb246df3fcf140ba14e1d234df267cb1->enter($__internal_c101645a7762979081130a54bed6dec7eb246df3fcf140ba14e1d234df267cb1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "avanzu_navbar"));

        $__internal_d3583277c117a2bf83c135b742cb896cd6d8c66f70a0a17faa3f13482a835b3c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d3583277c117a2bf83c135b742cb896cd6d8c66f70a0a17faa3f13482a835b3c->enter($__internal_d3583277c117a2bf83c135b742cb896cd6d8c66f70a0a17faa3f13482a835b3c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "avanzu_navbar"));

        // line 16
        echo "    <div class=\"navbar-custom-menu\">
        <ul class=\"nav navbar-nav\">
            <li class=\"dropdown user user-menu\">
                <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">
                    <img src=\"https://image.freepik.com/free-icon/question-mark_318-52837.jpg\" class=\"user-image\" alt=\"User Image\">
                    <span class=\"hidden-xs\">";
        // line 21
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 21, $this->getSourceContext()); })()), "user", array()), "username", array()), "html", null, true);
        echo "</span>
                </a>
                <ul class=\"dropdown-menu\">
                    <li class=\"user-header\">
                        <img src=\"https://image.freepik.com/free-icon/question-mark_318-52837.jpg\" class=\"img-circle\" alt=\"User Image\">
                        <p>
                            ";
        // line 27
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 27, $this->getSourceContext()); })()), "user", array()), "username", array()), "html", null, true);
        echo "
                            <small>Member since ";
        // line 28
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 28, $this->getSourceContext()); })()), "user", array()), "joinDate", array()), "d/m/Y"), "html", null, true);
        echo "</small>
                        </p>
                    </li>
                    <li class=\"user-footer\">
                        <div class=\"pull-left\">
                            <a href=\"#\" class=\"btn btn-default btn-flat\">Profile</a>
                        </div>
                        <div class=\"pull-right\">
                            <a href=";
        // line 36
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("logout");
        echo "#\" class=\"btn btn-default btn-flat\">Sign out</a>
                        </div>
                    </li>
                </ul>
            </li>
        </ul>
    </div>
";
        
        $__internal_d3583277c117a2bf83c135b742cb896cd6d8c66f70a0a17faa3f13482a835b3c->leave($__internal_d3583277c117a2bf83c135b742cb896cd6d8c66f70a0a17faa3f13482a835b3c_prof);

        
        $__internal_c101645a7762979081130a54bed6dec7eb246df3fcf140ba14e1d234df267cb1->leave($__internal_c101645a7762979081130a54bed6dec7eb246df3fcf140ba14e1d234df267cb1_prof);

    }

    // line 44
    public function block_avanzu_sidebar($context, array $blocks = array())
    {
        $__internal_46dbd293b3a51a878ec84f184f14595dfc221d5ec0c7f50c8ac5bfa9851903ec = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_46dbd293b3a51a878ec84f184f14595dfc221d5ec0c7f50c8ac5bfa9851903ec->enter($__internal_46dbd293b3a51a878ec84f184f14595dfc221d5ec0c7f50c8ac5bfa9851903ec_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "avanzu_sidebar"));

        $__internal_15699e3678a4c697acc04a8c7bb5573c018add38aa853cee4cc0db36601ad50a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_15699e3678a4c697acc04a8c7bb5573c018add38aa853cee4cc0db36601ad50a->enter($__internal_15699e3678a4c697acc04a8c7bb5573c018add38aa853cee4cc0db36601ad50a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "avanzu_sidebar"));

        // line 45
        echo "    <ul class=\"sidebar-menu\">
        <li class=\"header\">";
        // line 46
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("sidebar.navigation.main_navigation"), "html", null, true);
        echo "</li>
        <li><a href=\"";
        // line 47
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("home");
        echo "\"><i class=\"fa fa-home\"></i>";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("sidebar.navigation.home"), "html", null, true);
        echo "</a></li>
        <li><a href=\"";
        // line 48
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("want_to_watch");
        echo "\"><i class=\"fa fa fa-file-movie-o\"></i>";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("sidebar.navigation.wanttowatch"), "html", null, true);
        echo "</a></li>
        ";
        // line 50
        echo "        <li><a href=\"";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("movie_management_list");
        echo "\"><i class=\"fa fa fa-file-movie-o\"></i>";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("sidebar.navigation.movie_managementc"), "html", null, true);
        echo "</a></li>
        <li class=\"";
        // line 51
        if ((twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 51, $this->getSourceContext()); })()), "request", array()), "get", array(0 => "_route"), "method") == "user_management_list")) {
            echo "active";
        }
        echo "\">
            <a href=\"";
        // line 52
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_management_list");
        echo "\"><i class=\"fa fa fa-file-movie-o\"></i>";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("sidebar.navigation.user_management"), "html", null, true);
        echo "</a> </li>        <li><a href=\"";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("logout");
        echo "\"><i class=\"fa fa-cog\"></i>";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("sidebar.logout"), "html", null, true);
        echo "</a></li>
        <li class=\"treeview\">
            <a href=\"#\"><i class=\"fa fa-language\"></i>";
        // line 54
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("sidebar.navigation.language"), "html", null, true);
        echo "</a>
            <ul class=\"treeview-menu\" style=\"display: none;\">
                <li><a href=\"";
        // line 56
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("switch_locale", array("locale" => "ro"));
        echo "\"><i class=\"fa fa-circle-o\"></i>";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("sidebar.navigation.language.ro"), "html", null, true);
        echo "</a></li>
                <li><a href=\"";
        // line 57
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("switch_locale", array("locale" => "en"));
        echo "\"><i class=\"fa fa-circle-o\"></i>";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("sidebar.navigation.language.en"), "html", null, true);
        echo "</a></li>
            </ul>
        </li>
    </ul>
";
        
        $__internal_15699e3678a4c697acc04a8c7bb5573c018add38aa853cee4cc0db36601ad50a->leave($__internal_15699e3678a4c697acc04a8c7bb5573c018add38aa853cee4cc0db36601ad50a_prof);

        
        $__internal_46dbd293b3a51a878ec84f184f14595dfc221d5ec0c7f50c8ac5bfa9851903ec->leave($__internal_46dbd293b3a51a878ec84f184f14595dfc221d5ec0c7f50c8ac5bfa9851903ec_prof);

    }

    // line 63
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_05a2eaae83df5722390c04488f6d23ee18fd6387036ec021dee1e845eab8f42f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_05a2eaae83df5722390c04488f6d23ee18fd6387036ec021dee1e845eab8f42f->enter($__internal_05a2eaae83df5722390c04488f6d23ee18fd6387036ec021dee1e845eab8f42f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_24e3442d6a513ff84f1fd96c8e257c92206ac28ace869ab70156211965e7b96b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_24e3442d6a513ff84f1fd96c8e257c92206ac28ace869ab70156211965e7b96b->enter($__internal_24e3442d6a513ff84f1fd96c8e257c92206ac28ace869ab70156211965e7b96b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 64
        echo "    ";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.42/js/bootstrap-datetimepicker.min.js\"></script>
";
        
        $__internal_24e3442d6a513ff84f1fd96c8e257c92206ac28ace869ab70156211965e7b96b->leave($__internal_24e3442d6a513ff84f1fd96c8e257c92206ac28ace869ab70156211965e7b96b_prof);

        
        $__internal_05a2eaae83df5722390c04488f6d23ee18fd6387036ec021dee1e845eab8f42f->leave($__internal_05a2eaae83df5722390c04488f6d23ee18fd6387036ec021dee1e845eab8f42f_prof);

    }

    public function getTemplateName()
    {
        return "::base-layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  257 => 64,  248 => 63,  231 => 57,  225 => 56,  220 => 54,  209 => 52,  203 => 51,  196 => 50,  190 => 48,  184 => 47,  180 => 46,  177 => 45,  168 => 44,  150 => 36,  139 => 28,  135 => 27,  126 => 21,  119 => 16,  110 => 15,  94 => 10,  85 => 9,  74 => 7,  65 => 6,  54 => 4,  45 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'AvanzuAdminThemeBundle:layout:base-layout.html.twig' %}

{% block title %}
    Movies Crawler
{% endblock %}
{% block flashBag %}
    {% include '::flashBag.html.twig' %}
{% endblock %}
{% block stylesheets %}
    {{ parent() }}
    <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css\">
    <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.css\" />
    <link rel=\"stylesheet\" href=\"//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css\">
{% endblock %}
{% block avanzu_navbar %}
    <div class=\"navbar-custom-menu\">
        <ul class=\"nav navbar-nav\">
            <li class=\"dropdown user user-menu\">
                <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">
                    <img src=\"https://image.freepik.com/free-icon/question-mark_318-52837.jpg\" class=\"user-image\" alt=\"User Image\">
                    <span class=\"hidden-xs\">{{ app.user.username }}</span>
                </a>
                <ul class=\"dropdown-menu\">
                    <li class=\"user-header\">
                        <img src=\"https://image.freepik.com/free-icon/question-mark_318-52837.jpg\" class=\"img-circle\" alt=\"User Image\">
                        <p>
                            {{ app.user.username}}
                            <small>Member since {{ app.user.joinDate|date(\"d/m/Y\") }}</small>
                        </p>
                    </li>
                    <li class=\"user-footer\">
                        <div class=\"pull-left\">
                            <a href=\"#\" class=\"btn btn-default btn-flat\">Profile</a>
                        </div>
                        <div class=\"pull-right\">
                            <a href={{ path('logout') }}#\" class=\"btn btn-default btn-flat\">Sign out</a>
                        </div>
                    </li>
                </ul>
            </li>
        </ul>
    </div>
{% endblock %}
{% block avanzu_sidebar %}
    <ul class=\"sidebar-menu\">
        <li class=\"header\">{{ 'sidebar.navigation.main_navigation'|trans }}</li>
        <li><a href=\"{{ path('home') }}\"><i class=\"fa fa-home\"></i>{{ 'sidebar.navigation.home'|trans }}</a></li>
        <li><a href=\"{{ path('want_to_watch') }}\"><i class=\"fa fa fa-file-movie-o\"></i>{{ 'sidebar.navigation.wanttowatch'|trans }}</a></li>
        {#<li><a href=\"{{ path('user_management_list') }}\"><i class=\"fa fa fa-file-movie-o\"></i>{{ 'sidebar.navigation.user_management'|trans }}</a></li>#}
        <li><a href=\"{{ path('movie_management_list') }}\"><i class=\"fa fa fa-file-movie-o\"></i>{{ 'sidebar.navigation.movie_managementc'|trans }}</a></li>
        <li class=\"{% if app.request.get('_route') == 'user_management_list' %}active{% endif %}\">
            <a href=\"{{ path('user_management_list') }}\"><i class=\"fa fa fa-file-movie-o\"></i>{{ 'sidebar.navigation.user_management'|trans }}</a> </li>        <li><a href=\"{{ path('logout') }}\"><i class=\"fa fa-cog\"></i>{{ 'sidebar.logout'|trans }}</a></li>
        <li class=\"treeview\">
            <a href=\"#\"><i class=\"fa fa-language\"></i>{{ 'sidebar.navigation.language'|trans }}</a>
            <ul class=\"treeview-menu\" style=\"display: none;\">
                <li><a href=\"{{ path('switch_locale', {'locale': 'ro' }) }}\"><i class=\"fa fa-circle-o\"></i>{{ 'sidebar.navigation.language.ro'|trans }}</a></li>
                <li><a href=\"{{ path('switch_locale', {'locale': 'en' }) }}\"><i class=\"fa fa-circle-o\"></i>{{ 'sidebar.navigation.language.en'|trans }}</a></li>
            </ul>
        </li>
    </ul>
{% endblock %}

{% block javascripts %}
    {{ parent() }}
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.42/js/bootstrap-datetimepicker.min.js\"></script>
{% endblock %}", "::base-layout.html.twig", "/home/sorina/Documents/work/movies_crowler/app/Resources/views/base-layout.html.twig");
    }
}
