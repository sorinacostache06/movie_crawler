<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_1bcec1624f7aceefedc75d593e3edb83d1627374cf65a1d6f5ae7b6a726c4b75 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8cfba3ff57d7660fc95ffff3d9cf2816586fd733608a33ab3db3dd048c6fb1f0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8cfba3ff57d7660fc95ffff3d9cf2816586fd733608a33ab3db3dd048c6fb1f0->enter($__internal_8cfba3ff57d7660fc95ffff3d9cf2816586fd733608a33ab3db3dd048c6fb1f0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        $__internal_c636d21f7841da3aee5fb5d37a84699e6c17c5727ceb7a526a9db5fa56ef94a4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c636d21f7841da3aee5fb5d37a84699e6c17c5727ceb7a526a9db5fa56ef94a4->enter($__internal_c636d21f7841da3aee5fb5d37a84699e6c17c5727ceb7a526a9db5fa56ef94a4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_8cfba3ff57d7660fc95ffff3d9cf2816586fd733608a33ab3db3dd048c6fb1f0->leave($__internal_8cfba3ff57d7660fc95ffff3d9cf2816586fd733608a33ab3db3dd048c6fb1f0_prof);

        
        $__internal_c636d21f7841da3aee5fb5d37a84699e6c17c5727ceb7a526a9db5fa56ef94a4->leave($__internal_c636d21f7841da3aee5fb5d37a84699e6c17c5727ceb7a526a9db5fa56ef94a4_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_8c374c7334551ee997a3225de3ca8bd56a8888b31026986b4598d6282b1ecab2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8c374c7334551ee997a3225de3ca8bd56a8888b31026986b4598d6282b1ecab2->enter($__internal_8c374c7334551ee997a3225de3ca8bd56a8888b31026986b4598d6282b1ecab2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_f2405341fdc91488e3a393781530bef52ca5818d0a9b119ba8f084d21be76671 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f2405341fdc91488e3a393781530bef52ca5818d0a9b119ba8f084d21be76671->enter($__internal_f2405341fdc91488e3a393781530bef52ca5818d0a9b119ba8f084d21be76671_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_f2405341fdc91488e3a393781530bef52ca5818d0a9b119ba8f084d21be76671->leave($__internal_f2405341fdc91488e3a393781530bef52ca5818d0a9b119ba8f084d21be76671_prof);

        
        $__internal_8c374c7334551ee997a3225de3ca8bd56a8888b31026986b4598d6282b1ecab2->leave($__internal_8c374c7334551ee997a3225de3ca8bd56a8888b31026986b4598d6282b1ecab2_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  26 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "WebProfilerBundle:Profiler:ajax_layout.html.twig", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Profiler/ajax_layout.html.twig");
    }
}
