<?php

/* TwigBundle:Exception:error.xml.twig */
class __TwigTemplate_7963e79df5d94f6bd22e0c7384577c1caaa6107ba8fa69911c0b60da18c6008d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_59978b4b4a578b274f600e5b809311cbd6e44afc10aa5ec23c29441aa059f162 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_59978b4b4a578b274f600e5b809311cbd6e44afc10aa5ec23c29441aa059f162->enter($__internal_59978b4b4a578b274f600e5b809311cbd6e44afc10aa5ec23c29441aa059f162_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.xml.twig"));

        $__internal_4929dafa03ba1e200375841671c5a1c259ff20026824a53a67957bf1afe25f38 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4929dafa03ba1e200375841671c5a1c259ff20026824a53a67957bf1afe25f38->enter($__internal_4929dafa03ba1e200375841671c5a1c259ff20026824a53a67957bf1afe25f38_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.xml.twig"));

        // line 1
        echo "<?xml version=\"1.0\" encoding=\"";
        echo twig_escape_filter($this->env, $this->env->getCharset(), "html", null, true);
        echo "\" ?>

<error code=\"";
        // line 3
        echo twig_escape_filter($this->env, (isset($context["status_code"]) || array_key_exists("status_code", $context) ? $context["status_code"] : (function () { throw new Twig_Error_Runtime('Variable "status_code" does not exist.', 3, $this->getSourceContext()); })()), "html", null, true);
        echo "\" message=\"";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) || array_key_exists("status_text", $context) ? $context["status_text"] : (function () { throw new Twig_Error_Runtime('Variable "status_text" does not exist.', 3, $this->getSourceContext()); })()), "html", null, true);
        echo "\" />
";
        
        $__internal_59978b4b4a578b274f600e5b809311cbd6e44afc10aa5ec23c29441aa059f162->leave($__internal_59978b4b4a578b274f600e5b809311cbd6e44afc10aa5ec23c29441aa059f162_prof);

        
        $__internal_4929dafa03ba1e200375841671c5a1c259ff20026824a53a67957bf1afe25f38->leave($__internal_4929dafa03ba1e200375841671c5a1c259ff20026824a53a67957bf1afe25f38_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.xml.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  31 => 3,  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?xml version=\"1.0\" encoding=\"{{ _charset }}\" ?>

<error code=\"{{ status_code }}\" message=\"{{ status_text }}\" />
", "TwigBundle:Exception:error.xml.twig", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/error.xml.twig");
    }
}
