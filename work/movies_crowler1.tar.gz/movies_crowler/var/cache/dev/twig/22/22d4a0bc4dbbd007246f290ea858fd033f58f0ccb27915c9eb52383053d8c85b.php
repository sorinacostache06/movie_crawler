<?php

/* @Framework/Form/radio_widget.html.php */
class __TwigTemplate_4c74c254d50f415bb54fe1ee0b1d9f908111b0109af35f77cf909e221a87e29a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ce57619e8a542f179a97003bda25473626700878683b63d06ca32d3eb45723fb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ce57619e8a542f179a97003bda25473626700878683b63d06ca32d3eb45723fb->enter($__internal_ce57619e8a542f179a97003bda25473626700878683b63d06ca32d3eb45723fb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/radio_widget.html.php"));

        $__internal_f3d1936c93e9d9e18ccedde0a2c5aa2523bf5bb80f38472e692d341ad68c8b45 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f3d1936c93e9d9e18ccedde0a2c5aa2523bf5bb80f38472e692d341ad68c8b45->enter($__internal_f3d1936c93e9d9e18ccedde0a2c5aa2523bf5bb80f38472e692d341ad68c8b45_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/radio_widget.html.php"));

        // line 1
        echo "<input type=\"radio\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    value=\"<?php echo \$view->escape(\$value) ?>\"
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_ce57619e8a542f179a97003bda25473626700878683b63d06ca32d3eb45723fb->leave($__internal_ce57619e8a542f179a97003bda25473626700878683b63d06ca32d3eb45723fb_prof);

        
        $__internal_f3d1936c93e9d9e18ccedde0a2c5aa2523bf5bb80f38472e692d341ad68c8b45->leave($__internal_f3d1936c93e9d9e18ccedde0a2c5aa2523bf5bb80f38472e692d341ad68c8b45_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/radio_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<input type=\"radio\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    value=\"<?php echo \$view->escape(\$value) ?>\"
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
", "@Framework/Form/radio_widget.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/radio_widget.html.php");
    }
}
