<?php

/* AvanzuAdminThemeBundle:layout:base-layout.html.twig */
class __TwigTemplate_4e0e98ab1d136db0f796a6efcbdcd4e8ca9511b45b27f3b2c117d1c9e235ab92 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts_head' => array($this, 'block_javascripts_head'),
            'avanzu_admin_header' => array($this, 'block_avanzu_admin_header'),
            'avanzu_logo' => array($this, 'block_avanzu_logo'),
            'avanzu_navbar' => array($this, 'block_avanzu_navbar'),
            'avanzu_sidebar' => array($this, 'block_avanzu_sidebar'),
            'page_title' => array($this, 'block_page_title'),
            'page_subtitle' => array($this, 'block_page_subtitle'),
            'avanzu_breadcrumb' => array($this, 'block_avanzu_breadcrumb'),
            'page_content' => array($this, 'block_page_content'),
            'avanzu_admin_footer' => array($this, 'block_avanzu_admin_footer'),
            'javascripts' => array($this, 'block_javascripts'),
            'javascripts_inline' => array($this, 'block_javascripts_inline'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9f5b560e54c2bef526912d306d60caf4bb988e797d1a8700852093b6c5b7b468 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9f5b560e54c2bef526912d306d60caf4bb988e797d1a8700852093b6c5b7b468->enter($__internal_9f5b560e54c2bef526912d306d60caf4bb988e797d1a8700852093b6c5b7b468_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AvanzuAdminThemeBundle:layout:base-layout.html.twig"));

        $__internal_22d2ceb19b5e989e02f56d5cb4b8755dc352a36125cb8471ab4d65bc32b5271f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_22d2ceb19b5e989e02f56d5cb4b8755dc352a36125cb8471ab4d65bc32b5271f->enter($__internal_22d2ceb19b5e989e02f56d5cb4b8755dc352a36125cb8471ab4d65bc32b5271f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AvanzuAdminThemeBundle:layout:base-layout.html.twig"));

        // line 1
        $context["macro"] = $this->loadTemplate("AvanzuAdminThemeBundle:layout:macros.html.twig", "AvanzuAdminThemeBundle:layout:base-layout.html.twig", 1);
        // line 2
        echo "<!doctype html>
<!--[if lt IE 7 ]><html lang=\"en\" class=\"no-js ie6\"> <![endif]-->
<!--[if IE 7 ]><html lang=\"en\" class=\"no-js ie7\"> <![endif]-->
<!--[if IE 8 ]><html lang=\"en\" class=\"no-js ie8\"> <![endif]-->
<!--[if IE 9 ]><html lang=\"en\" class=\"no-js ie9\"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--><html lang=\"en\" class=\"no-js\"> <!--<![endif]-->
<head>
    <meta charset=\"utf-8\">
    <meta name=\"author\" content=\"\">
    <meta name=\"keywords\" content=\"\">
    <meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">
    <title>";
        // line 13
        $this->displayBlock('title', $context, $blocks);
        echo "</title>

    ";
        // line 16
        echo "    ";
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 19
        echo "

    <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />

    ";
        // line 24
        echo "    ";
        $this->displayBlock('javascripts_head', $context, $blocks);
        // line 31
        echo "
</head>
<body class=\"";
        // line 33
        echo twig_escape_filter($this->env, ((array_key_exists("admin_skin", $context)) ? (_twig_default_filter((isset($context["admin_skin"]) || array_key_exists("admin_skin", $context) ? $context["admin_skin"] : (function () { throw new Twig_Error_Runtime('Variable "admin_skin" does not exist.', 33, $this->getSourceContext()); })()), "skin-blue")) : ("skin-blue")), "html", null, true);
        echo "\">
    <div class=\"wrapper\">

    ";
        // line 36
        $this->displayBlock('avanzu_admin_header', $context, $blocks);
        // line 65
        echo "
        <!-- Left side column. contains the logo and sidebar -->
        <aside class=\"main-sidebar sidebar-offcanvas\">
            <!-- sidebar: style can be found in sidebar.less -->
            <section class=\"sidebar\">
                ";
        // line 70
        $this->displayBlock('avanzu_sidebar', $context, $blocks);
        // line 77
        echo "            </section>
            <!-- /.sidebar -->
        </aside>

        <!-- Right side column. Contains the navbar and content of the page -->
        <div class=\"content-wrapper\">
            <!-- Content Header (Page header) -->
            <section class=\"content-header\">
                <h1>
                    ";
        // line 86
        $this->displayBlock('page_title', $context, $blocks);
        // line 87
        echo "                    <small>";
        $this->displayBlock('page_subtitle', $context, $blocks);
        echo "</small>
                </h1>
                ";
        // line 89
        $this->displayBlock('avanzu_breadcrumb', $context, $blocks);
        // line 92
        echo "            </section>

            <!-- Main content -->
            <section class=\"content\">
                ";
        // line 96
        $this->displayBlock('page_content', $context, $blocks);
        // line 97
        echo "            </section>
            <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->

    ";
        // line 102
        $this->displayBlock('avanzu_admin_footer', $context, $blocks);
        // line 110
        echo "
    </div>
<!-- ./wrapper -->

";
        // line 115
        $this->displayBlock('javascripts', $context, $blocks);
        // line 120
        echo "
";
        // line 122
        $this->displayBlock('javascripts_inline', $context, $blocks);
        // line 124
        echo "</body>
</html>
";
        
        $__internal_9f5b560e54c2bef526912d306d60caf4bb988e797d1a8700852093b6c5b7b468->leave($__internal_9f5b560e54c2bef526912d306d60caf4bb988e797d1a8700852093b6c5b7b468_prof);

        
        $__internal_22d2ceb19b5e989e02f56d5cb4b8755dc352a36125cb8471ab4d65bc32b5271f->leave($__internal_22d2ceb19b5e989e02f56d5cb4b8755dc352a36125cb8471ab4d65bc32b5271f_prof);

    }

    // line 13
    public function block_title($context, array $blocks = array())
    {
        $__internal_af60a6e593e55bf03ab94a20b1309de43596e5c256ce8583530e16ae972d2a26 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_af60a6e593e55bf03ab94a20b1309de43596e5c256ce8583530e16ae972d2a26->enter($__internal_af60a6e593e55bf03ab94a20b1309de43596e5c256ce8583530e16ae972d2a26_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_ff9aa5a05971f162fa8d9508a84623407ac8fe79ebedc46bd431d4284891fc8f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ff9aa5a05971f162fa8d9508a84623407ac8fe79ebedc46bd431d4284891fc8f->enter($__internal_ff9aa5a05971f162fa8d9508a84623407ac8fe79ebedc46bd431d4284891fc8f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Avanzu Admin!";
        
        $__internal_ff9aa5a05971f162fa8d9508a84623407ac8fe79ebedc46bd431d4284891fc8f->leave($__internal_ff9aa5a05971f162fa8d9508a84623407ac8fe79ebedc46bd431d4284891fc8f_prof);

        
        $__internal_af60a6e593e55bf03ab94a20b1309de43596e5c256ce8583530e16ae972d2a26->leave($__internal_af60a6e593e55bf03ab94a20b1309de43596e5c256ce8583530e16ae972d2a26_prof);

    }

    // line 16
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_436599f533e94a40c8421bd4f9bf9ffcc1bd18ff406e7ece11aeddab772e7fcb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_436599f533e94a40c8421bd4f9bf9ffcc1bd18ff406e7ece11aeddab772e7fcb->enter($__internal_436599f533e94a40c8421bd4f9bf9ffcc1bd18ff406e7ece11aeddab772e7fcb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_159096e4ea38c689010f2b2f26e224d3e5686e36ceb33cb91872b26e03d10bae = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_159096e4ea38c689010f2b2f26e224d3e5686e36ceb33cb91872b26e03d10bae->enter($__internal_159096e4ea38c689010f2b2f26e224d3e5686e36ceb33cb91872b26e03d10bae_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 17
        echo "        <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl((("bundles/avanzuadmintheme/static/" . twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 17, $this->getSourceContext()); })()), "environment", array())) . "/styles/admin-lte-all.css")), "html", null, true);
        echo "\" />
    ";
        
        $__internal_159096e4ea38c689010f2b2f26e224d3e5686e36ceb33cb91872b26e03d10bae->leave($__internal_159096e4ea38c689010f2b2f26e224d3e5686e36ceb33cb91872b26e03d10bae_prof);

        
        $__internal_436599f533e94a40c8421bd4f9bf9ffcc1bd18ff406e7ece11aeddab772e7fcb->leave($__internal_436599f533e94a40c8421bd4f9bf9ffcc1bd18ff406e7ece11aeddab772e7fcb_prof);

    }

    // line 24
    public function block_javascripts_head($context, array $blocks = array())
    {
        $__internal_74e4072484b71365554b6c7ab31ad830ba7f105cb3e90887dd008ec214b5fbe9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_74e4072484b71365554b6c7ab31ad830ba7f105cb3e90887dd008ec214b5fbe9->enter($__internal_74e4072484b71365554b6c7ab31ad830ba7f105cb3e90887dd008ec214b5fbe9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts_head"));

        $__internal_1dd979acbbc07e8dcca567ded0762e69adf1202434cde4ee333e180cafc8553c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1dd979acbbc07e8dcca567ded0762e69adf1202434cde4ee333e180cafc8553c->enter($__internal_1dd979acbbc07e8dcca567ded0762e69adf1202434cde4ee333e180cafc8553c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts_head"));

        // line 25
        echo "        <script type=\"text/javascript\" src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl((("bundles/avanzuadmintheme/static/" . twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 25, $this->getSourceContext()); })()), "environment", array())) . "/scripts/modernizr.js")), "html", null, true);
        echo "\"></script>
        <!--[if lt IE 9]>

        <![endif]-->

    ";
        
        $__internal_1dd979acbbc07e8dcca567ded0762e69adf1202434cde4ee333e180cafc8553c->leave($__internal_1dd979acbbc07e8dcca567ded0762e69adf1202434cde4ee333e180cafc8553c_prof);

        
        $__internal_74e4072484b71365554b6c7ab31ad830ba7f105cb3e90887dd008ec214b5fbe9->leave($__internal_74e4072484b71365554b6c7ab31ad830ba7f105cb3e90887dd008ec214b5fbe9_prof);

    }

    // line 36
    public function block_avanzu_admin_header($context, array $blocks = array())
    {
        $__internal_8e532f34114623515275cb902dce9cd7513883d3a6b5518bac8cf59d9ef016d9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8e532f34114623515275cb902dce9cd7513883d3a6b5518bac8cf59d9ef016d9->enter($__internal_8e532f34114623515275cb902dce9cd7513883d3a6b5518bac8cf59d9ef016d9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "avanzu_admin_header"));

        $__internal_282ebe9c6f0ebfd8f34167961871895aab8ae7971e557192977bc233887d75a0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_282ebe9c6f0ebfd8f34167961871895aab8ae7971e557192977bc233887d75a0->enter($__internal_282ebe9c6f0ebfd8f34167961871895aab8ae7971e557192977bc233887d75a0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "avanzu_admin_header"));

        // line 37
        echo "        <header class=\"main-header\">
            ";
        // line 38
        $this->displayBlock('avanzu_logo', $context, $blocks);
        // line 44
        echo "            <!-- Header Navbar: style can be found in header.less -->
            <nav class=\"navbar navbar-static-top\" role=\"navigation\">
                <!-- Sidebar toggle button-->
                <a href=\"#\" class=\"sidebar-toggle\" data-toggle=\"offcanvas\" role=\"button\">
                    <span class=\"sr-only\">Toggle navigation</span>
                </a>
                ";
        // line 50
        if (( !(null === twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 50, $this->getSourceContext()); })()), "user", array())) && $this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("IS_AUTHENTICATED_FULLY"))) {
            // line 51
            echo "                    <div class=\"navbar-custom-menu\">
                        <ul class=\"nav navbar-nav\">
                            ";
            // line 53
            $this->displayBlock('avanzu_navbar', $context, $blocks);
            // line 59
            echo "                        </ul>
                    </div>
                ";
        }
        // line 62
        echo "            </nav>
        </header>
    ";
        
        $__internal_282ebe9c6f0ebfd8f34167961871895aab8ae7971e557192977bc233887d75a0->leave($__internal_282ebe9c6f0ebfd8f34167961871895aab8ae7971e557192977bc233887d75a0_prof);

        
        $__internal_8e532f34114623515275cb902dce9cd7513883d3a6b5518bac8cf59d9ef016d9->leave($__internal_8e532f34114623515275cb902dce9cd7513883d3a6b5518bac8cf59d9ef016d9_prof);

    }

    // line 38
    public function block_avanzu_logo($context, array $blocks = array())
    {
        $__internal_106bda53fbc50d4b80a6c3b92c1dfb48c75337d78a3a4cf5d4a02e7ff8f63d30 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_106bda53fbc50d4b80a6c3b92c1dfb48c75337d78a3a4cf5d4a02e7ff8f63d30->enter($__internal_106bda53fbc50d4b80a6c3b92c1dfb48c75337d78a3a4cf5d4a02e7ff8f63d30_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "avanzu_logo"));

        $__internal_f135828e83e0fbee9a20393798b438e9b05f4a5ae17df7178a18398ac46e99c8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f135828e83e0fbee9a20393798b438e9b05f4a5ae17df7178a18398ac46e99c8->enter($__internal_f135828e83e0fbee9a20393798b438e9b05f4a5ae17df7178a18398ac46e99c8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "avanzu_logo"));

        // line 39
        echo "                <a href=\"#\" class=\"logo\">
                    <!-- Add the class icon to your logo image or logo icon to add the margining -->
                    ";
        // line 41
        $this->displayBlock("title", $context, $blocks);
        echo "
                </a>
            ";
        
        $__internal_f135828e83e0fbee9a20393798b438e9b05f4a5ae17df7178a18398ac46e99c8->leave($__internal_f135828e83e0fbee9a20393798b438e9b05f4a5ae17df7178a18398ac46e99c8_prof);

        
        $__internal_106bda53fbc50d4b80a6c3b92c1dfb48c75337d78a3a4cf5d4a02e7ff8f63d30->leave($__internal_106bda53fbc50d4b80a6c3b92c1dfb48c75337d78a3a4cf5d4a02e7ff8f63d30_prof);

    }

    // line 53
    public function block_avanzu_navbar($context, array $blocks = array())
    {
        $__internal_b4bd67bf480e4a678a4c3875ea4ab1f02b001685a07c9c03e339317d9f3c8322 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b4bd67bf480e4a678a4c3875ea4ab1f02b001685a07c9c03e339317d9f3c8322->enter($__internal_b4bd67bf480e4a678a4c3875ea4ab1f02b001685a07c9c03e339317d9f3c8322_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "avanzu_navbar"));

        $__internal_b2c961ebdee2f9df8d2fc2d302f5a5cd692628f1c81a8e3ea53e5625f7cf5c37 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b2c961ebdee2f9df8d2fc2d302f5a5cd692628f1c81a8e3ea53e5625f7cf5c37->enter($__internal_b2c961ebdee2f9df8d2fc2d302f5a5cd692628f1c81a8e3ea53e5625f7cf5c37_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "avanzu_navbar"));

        // line 54
        echo "                                ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AvanzuAdminThemeBundle:Navbar:messages"));
        echo "
                                ";
        // line 55
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AvanzuAdminThemeBundle:Navbar:notifications"));
        echo "
                                ";
        // line 56
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AvanzuAdminThemeBundle:Navbar:tasks"));
        echo "
                                ";
        // line 57
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AvanzuAdminThemeBundle:Navbar:user"));
        echo "
                            ";
        
        $__internal_b2c961ebdee2f9df8d2fc2d302f5a5cd692628f1c81a8e3ea53e5625f7cf5c37->leave($__internal_b2c961ebdee2f9df8d2fc2d302f5a5cd692628f1c81a8e3ea53e5625f7cf5c37_prof);

        
        $__internal_b4bd67bf480e4a678a4c3875ea4ab1f02b001685a07c9c03e339317d9f3c8322->leave($__internal_b4bd67bf480e4a678a4c3875ea4ab1f02b001685a07c9c03e339317d9f3c8322_prof);

    }

    // line 70
    public function block_avanzu_sidebar($context, array $blocks = array())
    {
        $__internal_651e8ff771a3a2f94387e3d7e36463a7c3107f8a61e837315f47c9241166cb31 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_651e8ff771a3a2f94387e3d7e36463a7c3107f8a61e837315f47c9241166cb31->enter($__internal_651e8ff771a3a2f94387e3d7e36463a7c3107f8a61e837315f47c9241166cb31_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "avanzu_sidebar"));

        $__internal_a519bcf7c4a0a09e39e52da0182d572a4be464a4b463c434e6f9107d947f10ea = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a519bcf7c4a0a09e39e52da0182d572a4be464a4b463c434e6f9107d947f10ea->enter($__internal_a519bcf7c4a0a09e39e52da0182d572a4be464a4b463c434e6f9107d947f10ea_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "avanzu_sidebar"));

        // line 71
        echo "                    ";
        if (( !(null === twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 71, $this->getSourceContext()); })()), "user", array())) && $this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("IS_AUTHENTICATED_FULLY"))) {
            // line 72
            echo "                        ";
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AvanzuAdminThemeBundle:Sidebar:userPanel"));
            echo "
                        ";
            // line 73
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AvanzuAdminThemeBundle:Sidebar:searchForm"));
            echo "
                    ";
        }
        // line 75
        echo "                    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AvanzuAdminThemeBundle:Sidebar:menu", array("request" => twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 75, $this->getSourceContext()); })()), "request", array()))));
        echo "
                ";
        
        $__internal_a519bcf7c4a0a09e39e52da0182d572a4be464a4b463c434e6f9107d947f10ea->leave($__internal_a519bcf7c4a0a09e39e52da0182d572a4be464a4b463c434e6f9107d947f10ea_prof);

        
        $__internal_651e8ff771a3a2f94387e3d7e36463a7c3107f8a61e837315f47c9241166cb31->leave($__internal_651e8ff771a3a2f94387e3d7e36463a7c3107f8a61e837315f47c9241166cb31_prof);

    }

    // line 86
    public function block_page_title($context, array $blocks = array())
    {
        $__internal_d6b2ffb399abc608a03f8891a4f8d2c486e70d9dc6d42901a1aece6aac80811b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d6b2ffb399abc608a03f8891a4f8d2c486e70d9dc6d42901a1aece6aac80811b->enter($__internal_d6b2ffb399abc608a03f8891a4f8d2c486e70d9dc6d42901a1aece6aac80811b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_title"));

        $__internal_af13c6c0b95d8e29e4b61fd4ab53db7dfe410c7336f508b8677a97159699ce6a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_af13c6c0b95d8e29e4b61fd4ab53db7dfe410c7336f508b8677a97159699ce6a->enter($__internal_af13c6c0b95d8e29e4b61fd4ab53db7dfe410c7336f508b8677a97159699ce6a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_title"));

        echo "Blank page";
        
        $__internal_af13c6c0b95d8e29e4b61fd4ab53db7dfe410c7336f508b8677a97159699ce6a->leave($__internal_af13c6c0b95d8e29e4b61fd4ab53db7dfe410c7336f508b8677a97159699ce6a_prof);

        
        $__internal_d6b2ffb399abc608a03f8891a4f8d2c486e70d9dc6d42901a1aece6aac80811b->leave($__internal_d6b2ffb399abc608a03f8891a4f8d2c486e70d9dc6d42901a1aece6aac80811b_prof);

    }

    // line 87
    public function block_page_subtitle($context, array $blocks = array())
    {
        $__internal_7689563c65d2bd42c5b752dd1a21993ae408b857dc038ed5badd2279554d8074 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7689563c65d2bd42c5b752dd1a21993ae408b857dc038ed5badd2279554d8074->enter($__internal_7689563c65d2bd42c5b752dd1a21993ae408b857dc038ed5badd2279554d8074_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_subtitle"));

        $__internal_112d9a8cc9d8438e3e7ddb3793916534ec25aa0b5ddc313069e4eebb1c2b9bf3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_112d9a8cc9d8438e3e7ddb3793916534ec25aa0b5ddc313069e4eebb1c2b9bf3->enter($__internal_112d9a8cc9d8438e3e7ddb3793916534ec25aa0b5ddc313069e4eebb1c2b9bf3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_subtitle"));

        echo "Control panel";
        
        $__internal_112d9a8cc9d8438e3e7ddb3793916534ec25aa0b5ddc313069e4eebb1c2b9bf3->leave($__internal_112d9a8cc9d8438e3e7ddb3793916534ec25aa0b5ddc313069e4eebb1c2b9bf3_prof);

        
        $__internal_7689563c65d2bd42c5b752dd1a21993ae408b857dc038ed5badd2279554d8074->leave($__internal_7689563c65d2bd42c5b752dd1a21993ae408b857dc038ed5badd2279554d8074_prof);

    }

    // line 89
    public function block_avanzu_breadcrumb($context, array $blocks = array())
    {
        $__internal_c56110e5542155dba5269cd3e3e436c455e6772291bdbc73b48aa06218bca794 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c56110e5542155dba5269cd3e3e436c455e6772291bdbc73b48aa06218bca794->enter($__internal_c56110e5542155dba5269cd3e3e436c455e6772291bdbc73b48aa06218bca794_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "avanzu_breadcrumb"));

        $__internal_5cc59e35ce8d72537dd2b72678abebc472739df52f0e34686802a9668d4a7eef = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5cc59e35ce8d72537dd2b72678abebc472739df52f0e34686802a9668d4a7eef->enter($__internal_5cc59e35ce8d72537dd2b72678abebc472739df52f0e34686802a9668d4a7eef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "avanzu_breadcrumb"));

        // line 90
        echo "                    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AvanzuAdminThemeBundle:Breadcrumb:breadcrumb", array("request" => twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 90, $this->getSourceContext()); })()), "request", array()), "title" =>         $this->renderBlock("page_title", $context, $blocks))));
        echo "
                ";
        
        $__internal_5cc59e35ce8d72537dd2b72678abebc472739df52f0e34686802a9668d4a7eef->leave($__internal_5cc59e35ce8d72537dd2b72678abebc472739df52f0e34686802a9668d4a7eef_prof);

        
        $__internal_c56110e5542155dba5269cd3e3e436c455e6772291bdbc73b48aa06218bca794->leave($__internal_c56110e5542155dba5269cd3e3e436c455e6772291bdbc73b48aa06218bca794_prof);

    }

    // line 96
    public function block_page_content($context, array $blocks = array())
    {
        $__internal_628d7ec1d25f0fb77c3714a436147aefbc34b0794c6501cb9c9c7e3d85699047 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_628d7ec1d25f0fb77c3714a436147aefbc34b0794c6501cb9c9c7e3d85699047->enter($__internal_628d7ec1d25f0fb77c3714a436147aefbc34b0794c6501cb9c9c7e3d85699047_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_content"));

        $__internal_447c26d3233b212ffc4f4f88085dfb0bab9a25708de5a2616eca4d7e7fda12d6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_447c26d3233b212ffc4f4f88085dfb0bab9a25708de5a2616eca4d7e7fda12d6->enter($__internal_447c26d3233b212ffc4f4f88085dfb0bab9a25708de5a2616eca4d7e7fda12d6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_content"));

        
        $__internal_447c26d3233b212ffc4f4f88085dfb0bab9a25708de5a2616eca4d7e7fda12d6->leave($__internal_447c26d3233b212ffc4f4f88085dfb0bab9a25708de5a2616eca4d7e7fda12d6_prof);

        
        $__internal_628d7ec1d25f0fb77c3714a436147aefbc34b0794c6501cb9c9c7e3d85699047->leave($__internal_628d7ec1d25f0fb77c3714a436147aefbc34b0794c6501cb9c9c7e3d85699047_prof);

    }

    // line 102
    public function block_avanzu_admin_footer($context, array $blocks = array())
    {
        $__internal_ab136303f8f7d5a3450aed21b0f95a5af2417b51dac241b3161e48ba05bca790 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ab136303f8f7d5a3450aed21b0f95a5af2417b51dac241b3161e48ba05bca790->enter($__internal_ab136303f8f7d5a3450aed21b0f95a5af2417b51dac241b3161e48ba05bca790_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "avanzu_admin_footer"));

        $__internal_87755cc3f3373edd7935f0caedfbaed23fa14a372b8ef4ae55e3d92ec1fcf088 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_87755cc3f3373edd7935f0caedfbaed23fa14a372b8ef4ae55e3d92ec1fcf088->enter($__internal_87755cc3f3373edd7935f0caedfbaed23fa14a372b8ef4ae55e3d92ec1fcf088_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "avanzu_admin_footer"));

        // line 103
        echo "        <footer class=\"main-footer\">
            <div class=\"pull-right hidden-xs\">
                <b>Version</b> 2.0
            </div>
            <strong>Copyright &copy; 2014-2015 <a href=\"http://almsaeedstudio.com\">Almsaeed Studio</a>.</strong> All rights reserved.
        </footer>
    ";
        
        $__internal_87755cc3f3373edd7935f0caedfbaed23fa14a372b8ef4ae55e3d92ec1fcf088->leave($__internal_87755cc3f3373edd7935f0caedfbaed23fa14a372b8ef4ae55e3d92ec1fcf088_prof);

        
        $__internal_ab136303f8f7d5a3450aed21b0f95a5af2417b51dac241b3161e48ba05bca790->leave($__internal_ab136303f8f7d5a3450aed21b0f95a5af2417b51dac241b3161e48ba05bca790_prof);

    }

    // line 115
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_cad9264190be18dec392c1ebbad586f87490d1bf1b14f3f619d222669e2e360b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cad9264190be18dec392c1ebbad586f87490d1bf1b14f3f619d222669e2e360b->enter($__internal_cad9264190be18dec392c1ebbad586f87490d1bf1b14f3f619d222669e2e360b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_9f0fb1f7f7affc926f68011f2a9c36f0a63460dca2d975c3cdba278b8f02dae5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9f0fb1f7f7affc926f68011f2a9c36f0a63460dca2d975c3cdba278b8f02dae5->enter($__internal_9f0fb1f7f7affc926f68011f2a9c36f0a63460dca2d975c3cdba278b8f02dae5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 116
        echo "
    <script src=\"";
        // line 117
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl((("bundles/avanzuadmintheme/static/" . twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 117, $this->getSourceContext()); })()), "environment", array())) . "/scripts/admin-lte-all.js")), "html", null, true);
        echo "\"></script>

";
        
        $__internal_9f0fb1f7f7affc926f68011f2a9c36f0a63460dca2d975c3cdba278b8f02dae5->leave($__internal_9f0fb1f7f7affc926f68011f2a9c36f0a63460dca2d975c3cdba278b8f02dae5_prof);

        
        $__internal_cad9264190be18dec392c1ebbad586f87490d1bf1b14f3f619d222669e2e360b->leave($__internal_cad9264190be18dec392c1ebbad586f87490d1bf1b14f3f619d222669e2e360b_prof);

    }

    // line 122
    public function block_javascripts_inline($context, array $blocks = array())
    {
        $__internal_f18f532212db593ad82e2420375fbb75ff9bf105e37807e94904e09aa3b591f5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f18f532212db593ad82e2420375fbb75ff9bf105e37807e94904e09aa3b591f5->enter($__internal_f18f532212db593ad82e2420375fbb75ff9bf105e37807e94904e09aa3b591f5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts_inline"));

        $__internal_3f8dcc408e3dc42c697d64246fbbca90db136e9a3fa1c7889678696b14d0f888 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3f8dcc408e3dc42c697d64246fbbca90db136e9a3fa1c7889678696b14d0f888->enter($__internal_3f8dcc408e3dc42c697d64246fbbca90db136e9a3fa1c7889678696b14d0f888_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts_inline"));

        
        $__internal_3f8dcc408e3dc42c697d64246fbbca90db136e9a3fa1c7889678696b14d0f888->leave($__internal_3f8dcc408e3dc42c697d64246fbbca90db136e9a3fa1c7889678696b14d0f888_prof);

        
        $__internal_f18f532212db593ad82e2420375fbb75ff9bf105e37807e94904e09aa3b591f5->leave($__internal_f18f532212db593ad82e2420375fbb75ff9bf105e37807e94904e09aa3b591f5_prof);

    }

    public function getTemplateName()
    {
        return "AvanzuAdminThemeBundle:layout:base-layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  491 => 122,  478 => 117,  475 => 116,  466 => 115,  450 => 103,  441 => 102,  424 => 96,  411 => 90,  402 => 89,  384 => 87,  366 => 86,  353 => 75,  348 => 73,  343 => 72,  340 => 71,  331 => 70,  319 => 57,  315 => 56,  311 => 55,  306 => 54,  297 => 53,  284 => 41,  280 => 39,  271 => 38,  259 => 62,  254 => 59,  252 => 53,  248 => 51,  246 => 50,  238 => 44,  236 => 38,  233 => 37,  224 => 36,  207 => 25,  198 => 24,  185 => 17,  176 => 16,  158 => 13,  146 => 124,  144 => 122,  141 => 120,  139 => 115,  133 => 110,  131 => 102,  124 => 97,  122 => 96,  116 => 92,  114 => 89,  108 => 87,  106 => 86,  95 => 77,  93 => 70,  86 => 65,  84 => 36,  78 => 33,  74 => 31,  71 => 24,  66 => 21,  62 => 19,  59 => 16,  54 => 13,  41 => 2,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% import \"AvanzuAdminThemeBundle:layout:macros.html.twig\" as macro %}
<!doctype html>
<!--[if lt IE 7 ]><html lang=\"en\" class=\"no-js ie6\"> <![endif]-->
<!--[if IE 7 ]><html lang=\"en\" class=\"no-js ie7\"> <![endif]-->
<!--[if IE 8 ]><html lang=\"en\" class=\"no-js ie8\"> <![endif]-->
<!--[if IE 9 ]><html lang=\"en\" class=\"no-js ie9\"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--><html lang=\"en\" class=\"no-js\"> <!--<![endif]-->
<head>
    <meta charset=\"utf-8\">
    <meta name=\"author\" content=\"\">
    <meta name=\"keywords\" content=\"\">
    <meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">
    <title>{% block title %}Avanzu Admin!{% endblock %}</title>

    {# -------------------------------------------------------------------------------------------------- STYLESHEETS #}
    {% block stylesheets %}
        <link rel=\"stylesheet\" href=\"{{ asset('bundles/avanzuadmintheme/static/'~ app.environment ~'/styles/admin-lte-all.css') }}\" />
    {% endblock %}


    <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />

    {# --------------------------------------------------------------------------------------------- JAVASCRIPTS_HEAD #}
    {%  block javascripts_head %}
        <script type=\"text/javascript\" src=\"{{ asset('bundles/avanzuadmintheme/static/'~app.environment~'/scripts/modernizr.js') }}\"></script>
        <!--[if lt IE 9]>

        <![endif]-->

    {% endblock %}

</head>
<body class=\"{{ admin_skin|default('skin-blue')}}\">
    <div class=\"wrapper\">

    {% block avanzu_admin_header %}
        <header class=\"main-header\">
            {% block avanzu_logo %}
                <a href=\"#\" class=\"logo\">
                    <!-- Add the class icon to your logo image or logo icon to add the margining -->
                    {{ block('title') }}
                </a>
            {% endblock %}
            <!-- Header Navbar: style can be found in header.less -->
            <nav class=\"navbar navbar-static-top\" role=\"navigation\">
                <!-- Sidebar toggle button-->
                <a href=\"#\" class=\"sidebar-toggle\" data-toggle=\"offcanvas\" role=\"button\">
                    <span class=\"sr-only\">Toggle navigation</span>
                </a>
                {% if app.user is not null and is_granted('IS_AUTHENTICATED_FULLY') %}
                    <div class=\"navbar-custom-menu\">
                        <ul class=\"nav navbar-nav\">
                            {% block avanzu_navbar %}
                                {{ render(controller('AvanzuAdminThemeBundle:Navbar:messages')) }}
                                {{ render(controller('AvanzuAdminThemeBundle:Navbar:notifications')) }}
                                {{ render(controller('AvanzuAdminThemeBundle:Navbar:tasks')) }}
                                {{ render(controller('AvanzuAdminThemeBundle:Navbar:user')) }}
                            {% endblock %}
                        </ul>
                    </div>
                {% endif %}
            </nav>
        </header>
    {% endblock %}

        <!-- Left side column. contains the logo and sidebar -->
        <aside class=\"main-sidebar sidebar-offcanvas\">
            <!-- sidebar: style can be found in sidebar.less -->
            <section class=\"sidebar\">
                {% block avanzu_sidebar %}
                    {% if app.user is not null and is_granted('IS_AUTHENTICATED_FULLY') %}
                        {{ render(controller('AvanzuAdminThemeBundle:Sidebar:userPanel')) }}
                        {{ render(controller('AvanzuAdminThemeBundle:Sidebar:searchForm')) }}
                    {% endif %}
                    {{ render(controller('AvanzuAdminThemeBundle:Sidebar:menu', {'request':app.request})) }}
                {% endblock %}
            </section>
            <!-- /.sidebar -->
        </aside>

        <!-- Right side column. Contains the navbar and content of the page -->
        <div class=\"content-wrapper\">
            <!-- Content Header (Page header) -->
            <section class=\"content-header\">
                <h1>
                    {% block page_title %}Blank page{% endblock %}
                    <small>{% block page_subtitle %}Control panel{% endblock %}</small>
                </h1>
                {% block avanzu_breadcrumb %}
                    {{ render(controller('AvanzuAdminThemeBundle:Breadcrumb:breadcrumb', {'request':app.request, 'title' : block('page_title')})) }}
                {% endblock %}
            </section>

            <!-- Main content -->
            <section class=\"content\">
                {% block page_content %}{% endblock %}
            </section>
            <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->

    {% block avanzu_admin_footer %}
        <footer class=\"main-footer\">
            <div class=\"pull-right hidden-xs\">
                <b>Version</b> 2.0
            </div>
            <strong>Copyright &copy; 2014-2015 <a href=\"http://almsaeedstudio.com\">Almsaeed Studio</a>.</strong> All rights reserved.
        </footer>
    {% endblock %}

    </div>
<!-- ./wrapper -->

{# ------------------------------------------------------------------------------------------------------ JAVASCRIPTS #}
{% block javascripts %}

    <script src=\"{{ asset('bundles/avanzuadmintheme/static/'~app.environment~'/scripts/admin-lte-all.js') }}\"></script>

{% endblock %}

{# ----------------------------------------------------------------------------------------------- JAVASCRIPTS_INLINE #}
{% block javascripts_inline %}
{% endblock %}
</body>
</html>
", "AvanzuAdminThemeBundle:layout:base-layout.html.twig", "/home/sorina/Documents/work/movies_crowler/vendor/avanzu/admin-theme-bundle/Resources/views/layout/base-layout.html.twig");
    }
}
