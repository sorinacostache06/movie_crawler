<?php

/* @Framework/Form/search_widget.html.php */
class __TwigTemplate_c2a679cd81e03cfc4c99fad3a0460001b075f6f00eea0a838454d7e22f6aeea9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_02006d585c9d6f50d93b1db231a55cb9da01c312f85e335a8101c750e1682d9d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_02006d585c9d6f50d93b1db231a55cb9da01c312f85e335a8101c750e1682d9d->enter($__internal_02006d585c9d6f50d93b1db231a55cb9da01c312f85e335a8101c750e1682d9d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/search_widget.html.php"));

        $__internal_6815cf00a66a69295310b7e6e3eb23c68d8eba7a675cb5688eb974d1867ad8d5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6815cf00a66a69295310b7e6e3eb23c68d8eba7a675cb5688eb974d1867ad8d5->enter($__internal_6815cf00a66a69295310b7e6e3eb23c68d8eba7a675cb5688eb974d1867ad8d5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/search_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'search')) ?>
";
        
        $__internal_02006d585c9d6f50d93b1db231a55cb9da01c312f85e335a8101c750e1682d9d->leave($__internal_02006d585c9d6f50d93b1db231a55cb9da01c312f85e335a8101c750e1682d9d_prof);

        
        $__internal_6815cf00a66a69295310b7e6e3eb23c68d8eba7a675cb5688eb974d1867ad8d5->leave($__internal_6815cf00a66a69295310b7e6e3eb23c68d8eba7a675cb5688eb974d1867ad8d5_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/search_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'search')) ?>
", "@Framework/Form/search_widget.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/search_widget.html.php");
    }
}
