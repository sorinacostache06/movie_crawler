<?php

/* :Admin:default_no_rights.html.twig */
class __TwigTemplate_13d3be99b9af5d6f5f4008ce7795a63e2240959e450f47fe11ade0228bf559fb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base-layout.html.twig", ":Admin:default_no_rights.html.twig", 1);
        $this->blocks = array(
            'page_title' => array($this, 'block_page_title'),
            'page_subtitle' => array($this, 'block_page_subtitle'),
            'page_content' => array($this, 'block_page_content'),
            'flashBag' => array($this, 'block_flashBag'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base-layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_041a75d2e015bfacad3b2d8ef62f22ae15f770f0dac7a337404c3d16260fbaa4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_041a75d2e015bfacad3b2d8ef62f22ae15f770f0dac7a337404c3d16260fbaa4->enter($__internal_041a75d2e015bfacad3b2d8ef62f22ae15f770f0dac7a337404c3d16260fbaa4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Admin:default_no_rights.html.twig"));

        $__internal_4642a77d9d94730106015d91512213a90a1244d5766c6b81a45406596e0d3802 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4642a77d9d94730106015d91512213a90a1244d5766c6b81a45406596e0d3802->enter($__internal_4642a77d9d94730106015d91512213a90a1244d5766c6b81a45406596e0d3802_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Admin:default_no_rights.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_041a75d2e015bfacad3b2d8ef62f22ae15f770f0dac7a337404c3d16260fbaa4->leave($__internal_041a75d2e015bfacad3b2d8ef62f22ae15f770f0dac7a337404c3d16260fbaa4_prof);

        
        $__internal_4642a77d9d94730106015d91512213a90a1244d5766c6b81a45406596e0d3802->leave($__internal_4642a77d9d94730106015d91512213a90a1244d5766c6b81a45406596e0d3802_prof);

    }

    // line 2
    public function block_page_title($context, array $blocks = array())
    {
        $__internal_b3a82ce989d7e106cde2f9e25848d7d2fc5dcec24b061a08e1e813091ff91089 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b3a82ce989d7e106cde2f9e25848d7d2fc5dcec24b061a08e1e813091ff91089->enter($__internal_b3a82ce989d7e106cde2f9e25848d7d2fc5dcec24b061a08e1e813091ff91089_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_title"));

        $__internal_a31e7baace9f7e92664e8219ae6d0075b6b75fd01e72e43c9f4d311e43b50b48 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a31e7baace9f7e92664e8219ae6d0075b6b75fd01e72e43c9f4d311e43b50b48->enter($__internal_a31e7baace9f7e92664e8219ae6d0075b6b75fd01e72e43c9f4d311e43b50b48_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_title"));

        echo "Error";
        
        $__internal_a31e7baace9f7e92664e8219ae6d0075b6b75fd01e72e43c9f4d311e43b50b48->leave($__internal_a31e7baace9f7e92664e8219ae6d0075b6b75fd01e72e43c9f4d311e43b50b48_prof);

        
        $__internal_b3a82ce989d7e106cde2f9e25848d7d2fc5dcec24b061a08e1e813091ff91089->leave($__internal_b3a82ce989d7e106cde2f9e25848d7d2fc5dcec24b061a08e1e813091ff91089_prof);

    }

    // line 3
    public function block_page_subtitle($context, array $blocks = array())
    {
        $__internal_cb9d8615231992ef327de50c0557d2496a7acc0d15e05e18a847891bf510889d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cb9d8615231992ef327de50c0557d2496a7acc0d15e05e18a847891bf510889d->enter($__internal_cb9d8615231992ef327de50c0557d2496a7acc0d15e05e18a847891bf510889d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_subtitle"));

        $__internal_be0e4eaf1af51f145d232f2bd68752d5755b93e3255e41aecdf53621c6461dca = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_be0e4eaf1af51f145d232f2bd68752d5755b93e3255e41aecdf53621c6461dca->enter($__internal_be0e4eaf1af51f145d232f2bd68752d5755b93e3255e41aecdf53621c6461dca_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_subtitle"));

        echo "no rights found";
        
        $__internal_be0e4eaf1af51f145d232f2bd68752d5755b93e3255e41aecdf53621c6461dca->leave($__internal_be0e4eaf1af51f145d232f2bd68752d5755b93e3255e41aecdf53621c6461dca_prof);

        
        $__internal_cb9d8615231992ef327de50c0557d2496a7acc0d15e05e18a847891bf510889d->leave($__internal_cb9d8615231992ef327de50c0557d2496a7acc0d15e05e18a847891bf510889d_prof);

    }

    // line 4
    public function block_page_content($context, array $blocks = array())
    {
        $__internal_08a25e1baf5c7223cc41018298643a4aabe4d8b57da840547a49071d09c5b4a6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_08a25e1baf5c7223cc41018298643a4aabe4d8b57da840547a49071d09c5b4a6->enter($__internal_08a25e1baf5c7223cc41018298643a4aabe4d8b57da840547a49071d09c5b4a6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_content"));

        $__internal_a86ebbc8442e5d632c62f95074ab68b7ca94ca60b03822db0e2885310009ae31 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a86ebbc8442e5d632c62f95074ab68b7ca94ca60b03822db0e2885310009ae31->enter($__internal_a86ebbc8442e5d632c62f95074ab68b7ca94ca60b03822db0e2885310009ae31_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_content"));

        // line 5
        echo "    ";
        $this->displayBlock('flashBag', $context, $blocks);
        
        $__internal_a86ebbc8442e5d632c62f95074ab68b7ca94ca60b03822db0e2885310009ae31->leave($__internal_a86ebbc8442e5d632c62f95074ab68b7ca94ca60b03822db0e2885310009ae31_prof);

        
        $__internal_08a25e1baf5c7223cc41018298643a4aabe4d8b57da840547a49071d09c5b4a6->leave($__internal_08a25e1baf5c7223cc41018298643a4aabe4d8b57da840547a49071d09c5b4a6_prof);

    }

    public function block_flashBag($context, array $blocks = array())
    {
        $__internal_713ada8e28e152a405a555399fb3f2f67702a1a09376fffa788da96918686543 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_713ada8e28e152a405a555399fb3f2f67702a1a09376fffa788da96918686543->enter($__internal_713ada8e28e152a405a555399fb3f2f67702a1a09376fffa788da96918686543_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "flashBag"));

        $__internal_2191bd27a64f26c1c8d0365c573b70da4f980dad085cc1a4b946e8a8346c461b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2191bd27a64f26c1c8d0365c573b70da4f980dad085cc1a4b946e8a8346c461b->enter($__internal_2191bd27a64f26c1c8d0365c573b70da4f980dad085cc1a4b946e8a8346c461b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "flashBag"));

        // line 6
        echo "        ";
        $this->displayParentBlock("flashBag", $context, $blocks);
        echo "
    ";
        
        $__internal_2191bd27a64f26c1c8d0365c573b70da4f980dad085cc1a4b946e8a8346c461b->leave($__internal_2191bd27a64f26c1c8d0365c573b70da4f980dad085cc1a4b946e8a8346c461b_prof);

        
        $__internal_713ada8e28e152a405a555399fb3f2f67702a1a09376fffa788da96918686543->leave($__internal_713ada8e28e152a405a555399fb3f2f67702a1a09376fffa788da96918686543_prof);

    }

    public function getTemplateName()
    {
        return ":Admin:default_no_rights.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  107 => 6,  88 => 5,  79 => 4,  61 => 3,  43 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '::base-layout.html.twig' %}
{% block page_title %}Error{% endblock %}
{% block page_subtitle %}no rights found{% endblock %}
{% block page_content %}
    {% block flashBag %}
        {{ parent() }}
    {% endblock %}
{% endblock %}", ":Admin:default_no_rights.html.twig", "/home/sorina/Documents/work/movies_crowler/app/Resources/views/Admin/default_no_rights.html.twig");
    }
}
