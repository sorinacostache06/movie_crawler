<?php

/* TwigBundle:Exception:exception.js.twig */
class __TwigTemplate_9f86c3600d3f4710dcf91e8635005e34d20e2e94f90c35a5fbfe1eeee52e4193 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2f304fcf2101798c08a0d681583dc118313209060b3c2e925fffc653c3a715da = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2f304fcf2101798c08a0d681583dc118313209060b3c2e925fffc653c3a715da->enter($__internal_2f304fcf2101798c08a0d681583dc118313209060b3c2e925fffc653c3a715da_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.js.twig"));

        $__internal_3509643270a5868b7c91a89757a7af09623a079c10d7b10d15b03d2ff0646768 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3509643270a5868b7c91a89757a7af09623a079c10d7b10d15b03d2ff0646768->enter($__internal_3509643270a5868b7c91a89757a7af09623a079c10d7b10d15b03d2ff0646768_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        $this->loadTemplate("@Twig/Exception/exception.txt.twig", "TwigBundle:Exception:exception.js.twig", 2)->display(array_merge($context, array("exception" => (isset($context["exception"]) || array_key_exists("exception", $context) ? $context["exception"] : (function () { throw new Twig_Error_Runtime('Variable "exception" does not exist.', 2, $this->getSourceContext()); })()))));
        // line 3
        echo "*/
";
        
        $__internal_2f304fcf2101798c08a0d681583dc118313209060b3c2e925fffc653c3a715da->leave($__internal_2f304fcf2101798c08a0d681583dc118313209060b3c2e925fffc653c3a715da_prof);

        
        $__internal_3509643270a5868b7c91a89757a7af09623a079c10d7b10d15b03d2ff0646768->leave($__internal_3509643270a5868b7c91a89757a7af09623a079c10d7b10d15b03d2ff0646768_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  30 => 3,  28 => 2,  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{% include '@Twig/Exception/exception.txt.twig' with { 'exception': exception } %}
*/
", "TwigBundle:Exception:exception.js.twig", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/exception.js.twig");
    }
}
