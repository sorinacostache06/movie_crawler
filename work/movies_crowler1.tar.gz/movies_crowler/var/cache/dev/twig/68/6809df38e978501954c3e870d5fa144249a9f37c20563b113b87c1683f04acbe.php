<?php

/* @Framework/Form/textarea_widget.html.php */
class __TwigTemplate_8c486e5d84e2b291421db1c113dadd54d62c27f55f7a2141b41db2f5e576cd9f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b8fde9d0254791d98ce674a8dcd39c58e66db3ec95cfd8b1663d8e1758761971 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b8fde9d0254791d98ce674a8dcd39c58e66db3ec95cfd8b1663d8e1758761971->enter($__internal_b8fde9d0254791d98ce674a8dcd39c58e66db3ec95cfd8b1663d8e1758761971_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        $__internal_1b7d7c97ca24fd38cf34ce4a8ba664f06581cf3217c8767617f070e1d176b8ef = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1b7d7c97ca24fd38cf34ce4a8ba664f06581cf3217c8767617f070e1d176b8ef->enter($__internal_1b7d7c97ca24fd38cf34ce4a8ba664f06581cf3217c8767617f070e1d176b8ef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        // line 1
        echo "<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
";
        
        $__internal_b8fde9d0254791d98ce674a8dcd39c58e66db3ec95cfd8b1663d8e1758761971->leave($__internal_b8fde9d0254791d98ce674a8dcd39c58e66db3ec95cfd8b1663d8e1758761971_prof);

        
        $__internal_1b7d7c97ca24fd38cf34ce4a8ba664f06581cf3217c8767617f070e1d176b8ef->leave($__internal_1b7d7c97ca24fd38cf34ce4a8ba664f06581cf3217c8767617f070e1d176b8ef_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/textarea_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
", "@Framework/Form/textarea_widget.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/textarea_widget.html.php");
    }
}
