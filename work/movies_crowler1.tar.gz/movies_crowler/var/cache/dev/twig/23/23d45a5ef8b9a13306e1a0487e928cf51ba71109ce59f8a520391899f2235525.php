<?php

/* WebProfilerBundle:Profiler:open.html.twig */
class __TwigTemplate_2cc5a0e35b859d059480edaa50c5084ab8b0defa9f5109e8c35aec8ba0be75b2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/base.html.twig", "WebProfilerBundle:Profiler:open.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e2d9b3bf99a0a966c762677059744646290d34d7c1f5c239919cf17290230429 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e2d9b3bf99a0a966c762677059744646290d34d7c1f5c239919cf17290230429->enter($__internal_e2d9b3bf99a0a966c762677059744646290d34d7c1f5c239919cf17290230429_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:open.html.twig"));

        $__internal_8de674d57b3bbd6f6d5754469777fa3ad4af0160f9f0d5362ae4c690503f91dd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8de674d57b3bbd6f6d5754469777fa3ad4af0160f9f0d5362ae4c690503f91dd->enter($__internal_8de674d57b3bbd6f6d5754469777fa3ad4af0160f9f0d5362ae4c690503f91dd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:open.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e2d9b3bf99a0a966c762677059744646290d34d7c1f5c239919cf17290230429->leave($__internal_e2d9b3bf99a0a966c762677059744646290d34d7c1f5c239919cf17290230429_prof);

        
        $__internal_8de674d57b3bbd6f6d5754469777fa3ad4af0160f9f0d5362ae4c690503f91dd->leave($__internal_8de674d57b3bbd6f6d5754469777fa3ad4af0160f9f0d5362ae4c690503f91dd_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_25bccd05c94f2ebdf2dcaba6f767f8c3dc8d4e5250fd68250ba6c3906ae29d29 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_25bccd05c94f2ebdf2dcaba6f767f8c3dc8d4e5250fd68250ba6c3906ae29d29->enter($__internal_25bccd05c94f2ebdf2dcaba6f767f8c3dc8d4e5250fd68250ba6c3906ae29d29_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_6cd9259c8aac9a1f68464921594dfeacb1bc69a161bee22f60a66d32e15e4191 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6cd9259c8aac9a1f68464921594dfeacb1bc69a161bee22f60a66d32e15e4191->enter($__internal_6cd9259c8aac9a1f68464921594dfeacb1bc69a161bee22f60a66d32e15e4191_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <style>
        ";
        // line 5
        echo twig_include($this->env, $context, "@WebProfiler/Profiler/open.css.twig");
        echo "
    </style>
";
        
        $__internal_6cd9259c8aac9a1f68464921594dfeacb1bc69a161bee22f60a66d32e15e4191->leave($__internal_6cd9259c8aac9a1f68464921594dfeacb1bc69a161bee22f60a66d32e15e4191_prof);

        
        $__internal_25bccd05c94f2ebdf2dcaba6f767f8c3dc8d4e5250fd68250ba6c3906ae29d29->leave($__internal_25bccd05c94f2ebdf2dcaba6f767f8c3dc8d4e5250fd68250ba6c3906ae29d29_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_fa94a65c602c474ba0fb630584f23b2e8f7efbda870488efb467a41c675903af = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fa94a65c602c474ba0fb630584f23b2e8f7efbda870488efb467a41c675903af->enter($__internal_fa94a65c602c474ba0fb630584f23b2e8f7efbda870488efb467a41c675903af_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_60212b3091afcd03c264a0d9daf4fcec04ba9c274d995aaf9f4af96857e92922 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_60212b3091afcd03c264a0d9daf4fcec04ba9c274d995aaf9f4af96857e92922->enter($__internal_60212b3091afcd03c264a0d9daf4fcec04ba9c274d995aaf9f4af96857e92922_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "<div class=\"header\">
    <h1>";
        // line 11
        echo twig_escape_filter($this->env, (isset($context["file"]) || array_key_exists("file", $context) ? $context["file"] : (function () { throw new Twig_Error_Runtime('Variable "file" does not exist.', 11, $this->getSourceContext()); })()), "html", null, true);
        echo " <small>line ";
        echo twig_escape_filter($this->env, (isset($context["line"]) || array_key_exists("line", $context) ? $context["line"] : (function () { throw new Twig_Error_Runtime('Variable "line" does not exist.', 11, $this->getSourceContext()); })()), "html", null, true);
        echo "</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/";
        // line 12
        echo twig_escape_filter($this->env, twig_constant("Symfony\\Component\\HttpKernel\\Kernel::VERSION"), "html", null, true);
        echo "/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    ";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\CodeExtension')->fileExcerpt((isset($context["filename"]) || array_key_exists("filename", $context) ? $context["filename"] : (function () { throw new Twig_Error_Runtime('Variable "filename" does not exist.', 15, $this->getSourceContext()); })()), (isset($context["line"]) || array_key_exists("line", $context) ? $context["line"] : (function () { throw new Twig_Error_Runtime('Variable "line" does not exist.', 15, $this->getSourceContext()); })()),  -1);
        echo "
</div>
";
        
        $__internal_60212b3091afcd03c264a0d9daf4fcec04ba9c274d995aaf9f4af96857e92922->leave($__internal_60212b3091afcd03c264a0d9daf4fcec04ba9c274d995aaf9f4af96857e92922_prof);

        
        $__internal_fa94a65c602c474ba0fb630584f23b2e8f7efbda870488efb467a41c675903af->leave($__internal_fa94a65c602c474ba0fb630584f23b2e8f7efbda870488efb467a41c675903af_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:open.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  90 => 15,  84 => 12,  78 => 11,  75 => 10,  66 => 9,  53 => 5,  50 => 4,  41 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/base.html.twig' %}

{% block head %}
    <style>
        {{ include('@WebProfiler/Profiler/open.css.twig') }}
    </style>
{% endblock %}

{% block body %}
<div class=\"header\">
    <h1>{{ file }} <small>line {{ line }}</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/{{ constant('Symfony\\\\Component\\\\HttpKernel\\\\Kernel::VERSION') }}/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    {{ filename|file_excerpt(line, -1) }}
</div>
{% endblock %}
", "WebProfilerBundle:Profiler:open.html.twig", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Profiler/open.html.twig");
    }
}
