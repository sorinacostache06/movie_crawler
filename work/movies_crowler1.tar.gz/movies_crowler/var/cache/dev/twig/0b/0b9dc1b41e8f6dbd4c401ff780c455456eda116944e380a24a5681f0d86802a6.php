<?php

/* @Framework/FormTable/hidden_row.html.php */
class __TwigTemplate_c851dbed3a335a621f4081d2a74899f487371adf2dbb11ae90aa06fa800eb21f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b4bfb7f5f20f77abbd5456ab64ebfbf1ad0337a66e15e2ee509d68908cc57060 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b4bfb7f5f20f77abbd5456ab64ebfbf1ad0337a66e15e2ee509d68908cc57060->enter($__internal_b4bfb7f5f20f77abbd5456ab64ebfbf1ad0337a66e15e2ee509d68908cc57060_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/hidden_row.html.php"));

        $__internal_2dc8913e00be4ba578d6b8c26de1a01fc08a15506845e833ce44c33f893e00f5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2dc8913e00be4ba578d6b8c26de1a01fc08a15506845e833ce44c33f893e00f5->enter($__internal_2dc8913e00be4ba578d6b8c26de1a01fc08a15506845e833ce44c33f893e00f5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/hidden_row.html.php"));

        // line 1
        echo "<tr style=\"display: none\">
    <td colspan=\"2\">
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_b4bfb7f5f20f77abbd5456ab64ebfbf1ad0337a66e15e2ee509d68908cc57060->leave($__internal_b4bfb7f5f20f77abbd5456ab64ebfbf1ad0337a66e15e2ee509d68908cc57060_prof);

        
        $__internal_2dc8913e00be4ba578d6b8c26de1a01fc08a15506845e833ce44c33f893e00f5->leave($__internal_2dc8913e00be4ba578d6b8c26de1a01fc08a15506845e833ce44c33f893e00f5_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr style=\"display: none\">
    <td colspan=\"2\">
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
", "@Framework/FormTable/hidden_row.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/FormTable/hidden_row.html.php");
    }
}
