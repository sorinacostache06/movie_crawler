<?php

/* AvanzuAdminThemeBundle:Sidebar:search-form.html.twig */
class __TwigTemplate_661d9f746a830fe357c7ec87b1a240cd1467ce3f4f73ccf370b61b0360e2d5b9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_95a0c1a8882d46ea3ae96c2f55a3f9f3e7d3f3d5a7134038b01187851d786739 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_95a0c1a8882d46ea3ae96c2f55a3f9f3e7d3f3d5a7134038b01187851d786739->enter($__internal_95a0c1a8882d46ea3ae96c2f55a3f9f3e7d3f3d5a7134038b01187851d786739_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AvanzuAdminThemeBundle:Sidebar:search-form.html.twig"));

        $__internal_dbdec225223b944e42562c6ee38aa615f798fefc9ed22e2d5ebe8648586c1abb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dbdec225223b944e42562c6ee38aa615f798fefc9ed22e2d5ebe8648586c1abb->enter($__internal_dbdec225223b944e42562c6ee38aa615f798fefc9ed22e2d5ebe8648586c1abb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AvanzuAdminThemeBundle:Sidebar:search-form.html.twig"));

        // line 1
        echo "<!-- search form -->
<form action=\"#\" method=\"get\" class=\"sidebar-form\">
    <div class=\"input-group\">
        <input type=\"text\" name=\"q\" class=\"form-control\" placeholder=\"Search...\"/>
        <span class=\"input-group-btn\">
            <button type='submit' name='search' id='search-btn' class=\"btn btn-flat\"><i class=\"fa fa-search\"></i></button>
        </span>
    </div>
</form>
<!-- /.search form -->";
        
        $__internal_95a0c1a8882d46ea3ae96c2f55a3f9f3e7d3f3d5a7134038b01187851d786739->leave($__internal_95a0c1a8882d46ea3ae96c2f55a3f9f3e7d3f3d5a7134038b01187851d786739_prof);

        
        $__internal_dbdec225223b944e42562c6ee38aa615f798fefc9ed22e2d5ebe8648586c1abb->leave($__internal_dbdec225223b944e42562c6ee38aa615f798fefc9ed22e2d5ebe8648586c1abb_prof);

    }

    public function getTemplateName()
    {
        return "AvanzuAdminThemeBundle:Sidebar:search-form.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!-- search form -->
<form action=\"#\" method=\"get\" class=\"sidebar-form\">
    <div class=\"input-group\">
        <input type=\"text\" name=\"q\" class=\"form-control\" placeholder=\"Search...\"/>
        <span class=\"input-group-btn\">
            <button type='submit' name='search' id='search-btn' class=\"btn btn-flat\"><i class=\"fa fa-search\"></i></button>
        </span>
    </div>
</form>
<!-- /.search form -->", "AvanzuAdminThemeBundle:Sidebar:search-form.html.twig", "/home/sorina/Documents/work/movies_crowler/vendor/avanzu/admin-theme-bundle/Resources/views/Sidebar/search-form.html.twig");
    }
}
