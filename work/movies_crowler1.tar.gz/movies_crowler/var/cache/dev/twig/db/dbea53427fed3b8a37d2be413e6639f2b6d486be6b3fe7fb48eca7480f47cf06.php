<?php

/* @Framework/Form/choice_options.html.php */
class __TwigTemplate_cce2f41d4bf9ffd4fc3b53fd8abb7fc91cf18436fe8cc20267e7d6bd1a0e6487 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7c53ed8d00d3b8f4a79fa7392358383f7c891082212e2bd9658891829f378c6d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7c53ed8d00d3b8f4a79fa7392358383f7c891082212e2bd9658891829f378c6d->enter($__internal_7c53ed8d00d3b8f4a79fa7392358383f7c891082212e2bd9658891829f378c6d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        $__internal_b2b55c7fdc2b7247cb3c15f5447c9d1114bb9ad5d4b9cdd0b9ec2e940bf81497 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b2b55c7fdc2b7247cb3c15f5447c9d1114bb9ad5d4b9cdd0b9ec2e940bf81497->enter($__internal_b2b55c7fdc2b7247cb3c15f5447c9d1114bb9ad5d4b9cdd0b9ec2e940bf81497_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
";
        
        $__internal_7c53ed8d00d3b8f4a79fa7392358383f7c891082212e2bd9658891829f378c6d->leave($__internal_7c53ed8d00d3b8f4a79fa7392358383f7c891082212e2bd9658891829f378c6d_prof);

        
        $__internal_b2b55c7fdc2b7247cb3c15f5447c9d1114bb9ad5d4b9cdd0b9ec2e940bf81497->leave($__internal_b2b55c7fdc2b7247cb3c15f5447c9d1114bb9ad5d4b9cdd0b9ec2e940bf81497_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_options.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
", "@Framework/Form/choice_options.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/choice_options.html.php");
    }
}
