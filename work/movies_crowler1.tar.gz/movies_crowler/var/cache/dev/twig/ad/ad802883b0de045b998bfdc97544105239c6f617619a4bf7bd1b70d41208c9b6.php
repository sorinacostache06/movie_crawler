<?php

/* KnpPaginatorBundle:Pagination:sortable_link.html.twig */
class __TwigTemplate_62f5d96072578ea727fbfe9bd2de4aa76baa13828c1bab5e97d2d0a95b8ed87f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9a4af8f5459e0778dc43ccf9bb936a8c3eb5b22ebad21d40196d4a5e253e637b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9a4af8f5459e0778dc43ccf9bb936a8c3eb5b22ebad21d40196d4a5e253e637b->enter($__internal_9a4af8f5459e0778dc43ccf9bb936a8c3eb5b22ebad21d40196d4a5e253e637b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "KnpPaginatorBundle:Pagination:sortable_link.html.twig"));

        $__internal_e3c797831cda35eeecd759052d1e7795f45db06dab349fcacbf5d4633617bd4a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e3c797831cda35eeecd759052d1e7795f45db06dab349fcacbf5d4633617bd4a->enter($__internal_e3c797831cda35eeecd759052d1e7795f45db06dab349fcacbf5d4633617bd4a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "KnpPaginatorBundle:Pagination:sortable_link.html.twig"));

        // line 1
        echo "<a";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["options"]) || array_key_exists("options", $context) ? $context["options"] : (function () { throw new Twig_Error_Runtime('Variable "options" does not exist.', 1, $this->getSourceContext()); })()));
        foreach ($context['_seq'] as $context["attr"] => $context["value"]) {
            echo " ";
            echo twig_escape_filter($this->env, $context["attr"], "html", null, true);
            echo "=\"";
            echo twig_escape_filter($this->env, $context["value"], "html", null, true);
            echo "\"";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['attr'], $context['value'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        echo ">";
        echo twig_escape_filter($this->env, (isset($context["title"]) || array_key_exists("title", $context) ? $context["title"] : (function () { throw new Twig_Error_Runtime('Variable "title" does not exist.', 1, $this->getSourceContext()); })()), "html", null, true);
        echo "</a>
";
        
        $__internal_9a4af8f5459e0778dc43ccf9bb936a8c3eb5b22ebad21d40196d4a5e253e637b->leave($__internal_9a4af8f5459e0778dc43ccf9bb936a8c3eb5b22ebad21d40196d4a5e253e637b_prof);

        
        $__internal_e3c797831cda35eeecd759052d1e7795f45db06dab349fcacbf5d4633617bd4a->leave($__internal_e3c797831cda35eeecd759052d1e7795f45db06dab349fcacbf5d4633617bd4a_prof);

    }

    public function getTemplateName()
    {
        return "KnpPaginatorBundle:Pagination:sortable_link.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<a{% for attr, value in options %} {{ attr }}=\"{{ value }}\"{% endfor %}>{{ title }}</a>
", "KnpPaginatorBundle:Pagination:sortable_link.html.twig", "/home/sorina/Documents/work/movies_crowler/vendor/knplabs/knp-paginator-bundle/Resources/views/Pagination/sortable_link.html.twig");
    }
}
