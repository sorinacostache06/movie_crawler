<?php

/* @Framework/Form/button_row.html.php */
class __TwigTemplate_9648cc2838c8482458cf5814bf6b60d20500d40cb153c9b8550a419822b40a53 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a35a9b3768f6c13436a2a13374115f389f3c9cc46d7b5799ac19586b2a365ee7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a35a9b3768f6c13436a2a13374115f389f3c9cc46d7b5799ac19586b2a365ee7->enter($__internal_a35a9b3768f6c13436a2a13374115f389f3c9cc46d7b5799ac19586b2a365ee7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        $__internal_6fe6babfffbadd2e955d0f53e96a965e4c6bea79a4c066c59c988f26fa37be40 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6fe6babfffbadd2e955d0f53e96a965e4c6bea79a4c066c59c988f26fa37be40->enter($__internal_6fe6babfffbadd2e955d0f53e96a965e4c6bea79a4c066c59c988f26fa37be40_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_a35a9b3768f6c13436a2a13374115f389f3c9cc46d7b5799ac19586b2a365ee7->leave($__internal_a35a9b3768f6c13436a2a13374115f389f3c9cc46d7b5799ac19586b2a365ee7_prof);

        
        $__internal_6fe6babfffbadd2e955d0f53e96a965e4c6bea79a4c066c59c988f26fa37be40->leave($__internal_6fe6babfffbadd2e955d0f53e96a965e4c6bea79a4c066c59c988f26fa37be40_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
", "@Framework/Form/button_row.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/button_row.html.php");
    }
}
