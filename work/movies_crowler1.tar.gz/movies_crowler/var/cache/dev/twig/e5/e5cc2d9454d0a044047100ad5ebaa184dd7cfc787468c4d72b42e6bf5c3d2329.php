<?php

/* @Framework/Form/reset_widget.html.php */
class __TwigTemplate_76c33e3d5f0a712baeae4da2aed5463def6ccfdb31cda04aac61554f117fc72f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_947f83246db9c31e0d8604aadbb0873e3514b053c4f52b9f4bae742dd24a4128 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_947f83246db9c31e0d8604aadbb0873e3514b053c4f52b9f4bae742dd24a4128->enter($__internal_947f83246db9c31e0d8604aadbb0873e3514b053c4f52b9f4bae742dd24a4128_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        $__internal_78d115d13b93149e2408d89f9ffae53522dc073f5485451529c2579dcd8c03c2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_78d115d13b93149e2408d89f9ffae53522dc073f5485451529c2579dcd8c03c2->enter($__internal_78d115d13b93149e2408d89f9ffae53522dc073f5485451529c2579dcd8c03c2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'reset')) ?>
";
        
        $__internal_947f83246db9c31e0d8604aadbb0873e3514b053c4f52b9f4bae742dd24a4128->leave($__internal_947f83246db9c31e0d8604aadbb0873e3514b053c4f52b9f4bae742dd24a4128_prof);

        
        $__internal_78d115d13b93149e2408d89f9ffae53522dc073f5485451529c2579dcd8c03c2->leave($__internal_78d115d13b93149e2408d89f9ffae53522dc073f5485451529c2579dcd8c03c2_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/reset_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'reset')) ?>
", "@Framework/Form/reset_widget.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/reset_widget.html.php");
    }
}
