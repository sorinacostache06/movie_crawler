<?php

/* :Form:fields.html.twig */
class __TwigTemplate_794f9c00e3bc249a9d205764edbc85e1f3decb1061acdc54f2642dd0def955f0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'datepicker_widget' => array($this, 'block_datepicker_widget'),
            'datetimepicker_widget' => array($this, 'block_datetimepicker_widget'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e583ab334b32125ff3ba281687112ec4d52cd359559c8880d1ce113a54b17f39 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e583ab334b32125ff3ba281687112ec4d52cd359559c8880d1ce113a54b17f39->enter($__internal_e583ab334b32125ff3ba281687112ec4d52cd359559c8880d1ce113a54b17f39_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Form:fields.html.twig"));

        $__internal_9aa5f7324d66af740de94d6d72b3d340f8ed7676fd902b7f6bd3fcf0bd56892e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9aa5f7324d66af740de94d6d72b3d340f8ed7676fd902b7f6bd3fcf0bd56892e->enter($__internal_9aa5f7324d66af740de94d6d72b3d340f8ed7676fd902b7f6bd3fcf0bd56892e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Form:fields.html.twig"));

        // line 2
        $this->displayBlock('datepicker_widget', $context, $blocks);
        // line 6
        $this->displayBlock('datetimepicker_widget', $context, $blocks);
        
        $__internal_e583ab334b32125ff3ba281687112ec4d52cd359559c8880d1ce113a54b17f39->leave($__internal_e583ab334b32125ff3ba281687112ec4d52cd359559c8880d1ce113a54b17f39_prof);

        
        $__internal_9aa5f7324d66af740de94d6d72b3d340f8ed7676fd902b7f6bd3fcf0bd56892e->leave($__internal_9aa5f7324d66af740de94d6d72b3d340f8ed7676fd902b7f6bd3fcf0bd56892e_prof);

    }

    // line 2
    public function block_datepicker_widget($context, array $blocks = array())
    {
        $__internal_8c3166649d70b50cb7361c09904c3e912411c402f414522c84846b232d2f62ba = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8c3166649d70b50cb7361c09904c3e912411c402f414522c84846b232d2f62ba->enter($__internal_8c3166649d70b50cb7361c09904c3e912411c402f414522c84846b232d2f62ba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datepicker_widget"));

        $__internal_712f1bf2ca2e13d7faca5a23fd5d25b7f99bc2201d518397197f38bb32f6f3b0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_712f1bf2ca2e13d7faca5a23fd5d25b7f99bc2201d518397197f38bb32f6f3b0->enter($__internal_712f1bf2ca2e13d7faca5a23fd5d25b7f99bc2201d518397197f38bb32f6f3b0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datepicker_widget"));

        // line 3
        echo "    <input placeholder=\"Date\" class=\"form-control datepicker\" type=\"text\" ";
        if ( !twig_test_empty((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 3, $this->getSourceContext()); })()))) {
            echo "value=\"";
            echo twig_escape_filter($this->env, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 3, $this->getSourceContext()); })()), "html", null, true);
            echo "\" ";
        }
        echo " ";
        $this->displayBlock("widget_attributes", $context, $blocks);
        echo "/>
";
        
        $__internal_712f1bf2ca2e13d7faca5a23fd5d25b7f99bc2201d518397197f38bb32f6f3b0->leave($__internal_712f1bf2ca2e13d7faca5a23fd5d25b7f99bc2201d518397197f38bb32f6f3b0_prof);

        
        $__internal_8c3166649d70b50cb7361c09904c3e912411c402f414522c84846b232d2f62ba->leave($__internal_8c3166649d70b50cb7361c09904c3e912411c402f414522c84846b232d2f62ba_prof);

    }

    // line 6
    public function block_datetimepicker_widget($context, array $blocks = array())
    {
        $__internal_ff3f9792c3e5737f8d5968738ffafd4a13bbad10fdee74a359f1ec21fd6c52e3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ff3f9792c3e5737f8d5968738ffafd4a13bbad10fdee74a359f1ec21fd6c52e3->enter($__internal_ff3f9792c3e5737f8d5968738ffafd4a13bbad10fdee74a359f1ec21fd6c52e3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datetimepicker_widget"));

        $__internal_8bc4a01003e4398e7fb6c6962c854d2a501f780981e1012e7dc8a73bcb9f45eb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8bc4a01003e4398e7fb6c6962c854d2a501f780981e1012e7dc8a73bcb9f45eb->enter($__internal_8bc4a01003e4398e7fb6c6962c854d2a501f780981e1012e7dc8a73bcb9f45eb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datetimepicker_widget"));

        // line 7
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 7, $this->getSourceContext()); })()), "date", array()), 'errors');
        echo "
    ";
        // line 8
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 8, $this->getSourceContext()); })()), "time", array()), 'errors');
        echo "
    <div class=\"input-group datetimepicker\">
        <span class=\"input-group-addon\">Le</span>
        ";
        // line 11
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 11, $this->getSourceContext()); })()), "date", array()), 'widget');
        echo "
        <span class=\"input-group-addon inner-addon\">à</span>
        ";
        // line 13
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 13, $this->getSourceContext()); })()), "time", array()), 'widget');
        echo "
    </div>
";
        
        $__internal_8bc4a01003e4398e7fb6c6962c854d2a501f780981e1012e7dc8a73bcb9f45eb->leave($__internal_8bc4a01003e4398e7fb6c6962c854d2a501f780981e1012e7dc8a73bcb9f45eb_prof);

        
        $__internal_ff3f9792c3e5737f8d5968738ffafd4a13bbad10fdee74a359f1ec21fd6c52e3->leave($__internal_ff3f9792c3e5737f8d5968738ffafd4a13bbad10fdee74a359f1ec21fd6c52e3_prof);

    }

    public function getTemplateName()
    {
        return ":Form:fields.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  92 => 13,  87 => 11,  81 => 8,  76 => 7,  67 => 6,  48 => 3,  39 => 2,  29 => 6,  27 => 2,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{# DATEPICKER #}
{% block datepicker_widget %}
    <input placeholder=\"Date\" class=\"form-control datepicker\" type=\"text\" {% if value is not empty %}value=\"{{ value }}\" {% endif %} {{ block('widget_attributes') }}/>
{% endblock %}
{# DATETIMEPICKER #}
{% block datetimepicker_widget %}
    {{ form_errors(form.date) }}
    {{ form_errors(form.time) }}
    <div class=\"input-group datetimepicker\">
        <span class=\"input-group-addon\">Le</span>
        {{ form_widget(form.date) }}
        <span class=\"input-group-addon inner-addon\">à</span>
        {{ form_widget(form.time) }}
    </div>
{% endblock %}", ":Form:fields.html.twig", "/home/sorina/Documents/work/movies_crowler/app/Resources/views/Form/fields.html.twig");
    }
}
