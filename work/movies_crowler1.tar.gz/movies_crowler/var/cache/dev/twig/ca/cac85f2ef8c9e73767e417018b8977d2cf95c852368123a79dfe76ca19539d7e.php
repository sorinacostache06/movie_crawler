<?php

/* @Framework/Form/repeated_row.html.php */
class __TwigTemplate_6e9345b5755c537bebbe5dda4894b23d9b4043243a38885a0920b6e96e0a2065 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7d585b2b0dd1ef9c7675cd91f0709368cf306018a9a22554db985bf8d716dd8e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7d585b2b0dd1ef9c7675cd91f0709368cf306018a9a22554db985bf8d716dd8e->enter($__internal_7d585b2b0dd1ef9c7675cd91f0709368cf306018a9a22554db985bf8d716dd8e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/repeated_row.html.php"));

        $__internal_814b1dc82c868e65bb134095d5d28928eb732676777c2ab5284ce020e7557490 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_814b1dc82c868e65bb134095d5d28928eb732676777c2ab5284ce020e7557490->enter($__internal_814b1dc82c868e65bb134095d5d28928eb732676777c2ab5284ce020e7557490_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/repeated_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_rows') ?>
";
        
        $__internal_7d585b2b0dd1ef9c7675cd91f0709368cf306018a9a22554db985bf8d716dd8e->leave($__internal_7d585b2b0dd1ef9c7675cd91f0709368cf306018a9a22554db985bf8d716dd8e_prof);

        
        $__internal_814b1dc82c868e65bb134095d5d28928eb732676777c2ab5284ce020e7557490->leave($__internal_814b1dc82c868e65bb134095d5d28928eb732676777c2ab5284ce020e7557490_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/repeated_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_rows') ?>
", "@Framework/Form/repeated_row.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/repeated_row.html.php");
    }
}
