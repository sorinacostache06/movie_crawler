<?php

/* ::movie_list.html.twig */
class __TwigTemplate_e73aadcfe6efce85bd8794158716615cfa6dd726f07b71a8340a99d141b29127 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base-layout.html.twig", "::movie_list.html.twig", 1);
        $this->blocks = array(
            'page_title' => array($this, 'block_page_title'),
            'page_content' => array($this, 'block_page_content'),
            'flashBag' => array($this, 'block_flashBag'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base-layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2543fe99feb3a49e9e13445eae07668fccd9cfb26774c06835a91280eeea2810 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2543fe99feb3a49e9e13445eae07668fccd9cfb26774c06835a91280eeea2810->enter($__internal_2543fe99feb3a49e9e13445eae07668fccd9cfb26774c06835a91280eeea2810_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::movie_list.html.twig"));

        $__internal_5e6be9edcb1631f0e403d7e79a6e15811c99ed172386fd91b483f8a607c70d49 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5e6be9edcb1631f0e403d7e79a6e15811c99ed172386fd91b483f8a607c70d49->enter($__internal_5e6be9edcb1631f0e403d7e79a6e15811c99ed172386fd91b483f8a607c70d49_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::movie_list.html.twig"));

        // line 4
        ob_start();
        // line 5
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["manageForm"]) || array_key_exists("manageForm", $context) ? $context["manageForm"] : (function () { throw new Twig_Error_Runtime('Variable "manageForm" does not exist.', 5, $this->getSourceContext()); })()), "_token", array()), 'row', array("id" => "#id#"));
        echo "
";
        $context["form_token"] = ('' === $tmp = ob_get_clean()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        // line 1
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_2543fe99feb3a49e9e13445eae07668fccd9cfb26774c06835a91280eeea2810->leave($__internal_2543fe99feb3a49e9e13445eae07668fccd9cfb26774c06835a91280eeea2810_prof);

        
        $__internal_5e6be9edcb1631f0e403d7e79a6e15811c99ed172386fd91b483f8a607c70d49->leave($__internal_5e6be9edcb1631f0e403d7e79a6e15811c99ed172386fd91b483f8a607c70d49_prof);

    }

    // line 8
    public function block_page_title($context, array $blocks = array())
    {
        $__internal_c089e3b96acb9935245d1e843ae5baa9e8592fb36124941990343e6dca6c687f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c089e3b96acb9935245d1e843ae5baa9e8592fb36124941990343e6dca6c687f->enter($__internal_c089e3b96acb9935245d1e843ae5baa9e8592fb36124941990343e6dca6c687f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_title"));

        $__internal_17f69754a0f912a8e4a53b19a690fa40026dc074ed91fb282a18d6efb8fca62a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_17f69754a0f912a8e4a53b19a690fa40026dc074ed91fb282a18d6efb8fca62a->enter($__internal_17f69754a0f912a8e4a53b19a690fa40026dc074ed91fb282a18d6efb8fca62a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_title"));

        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("navigation.management_movie.title"), "html", null, true);
        
        $__internal_17f69754a0f912a8e4a53b19a690fa40026dc074ed91fb282a18d6efb8fca62a->leave($__internal_17f69754a0f912a8e4a53b19a690fa40026dc074ed91fb282a18d6efb8fca62a_prof);

        
        $__internal_c089e3b96acb9935245d1e843ae5baa9e8592fb36124941990343e6dca6c687f->leave($__internal_c089e3b96acb9935245d1e843ae5baa9e8592fb36124941990343e6dca6c687f_prof);

    }

    // line 9
    public function block_page_content($context, array $blocks = array())
    {
        $__internal_2822333b8b17ffc374acbe99086f2d215ead20a5abfddc7dc778c0a190faf4bf = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2822333b8b17ffc374acbe99086f2d215ead20a5abfddc7dc778c0a190faf4bf->enter($__internal_2822333b8b17ffc374acbe99086f2d215ead20a5abfddc7dc778c0a190faf4bf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_content"));

        $__internal_2defeb6f9b3ba4a9d85fed12384fcf3f77575403de668a72b88cbf86f3bc22e0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2defeb6f9b3ba4a9d85fed12384fcf3f77575403de668a72b88cbf86f3bc22e0->enter($__internal_2defeb6f9b3ba4a9d85fed12384fcf3f77575403de668a72b88cbf86f3bc22e0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_content"));

        // line 10
        echo "    ";
        $this->displayBlock('flashBag', $context, $blocks);
        // line 13
        echo "    <div class=\"box\">
            ";
        // line 14
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["filterForm"]) || array_key_exists("filterForm", $context) ? $context["filterForm"] : (function () { throw new Twig_Error_Runtime('Variable "filterForm" does not exist.', 14, $this->getSourceContext()); })()), 'form_start', array("method" => "get"));
        echo "
            <table class=\"table table-bordered table-hover dataTable\" role=\"grid\">
                <thead>
                    <tr role=\"row\">
                        <td>";
        // line 18
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["filterForm"]) || array_key_exists("filterForm", $context) ? $context["filterForm"] : (function () { throw new Twig_Error_Runtime('Variable "filterForm" does not exist.', 18, $this->getSourceContext()); })()), "results", array()), 'row');
        echo "</td>
                    ";
        // line 19
        if ((isset($context["pagination"]) || array_key_exists("pagination", $context) ? $context["pagination"] : (function () { throw new Twig_Error_Runtime('Variable "pagination" does not exist.', 19, $this->getSourceContext()); })())) {
            // line 20
            echo "                        <td class=\"pagination pagination-sm no-margin pull-right\">
                            ";
            // line 21
            echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->render($this->env, (isset($context["pagination"]) || array_key_exists("pagination", $context) ? $context["pagination"] : (function () { throw new Twig_Error_Runtime('Variable "pagination" does not exist.', 21, $this->getSourceContext()); })()), "::adminlte_pagination.html.twig");
            echo "
                        </td>
                    ";
        }
        // line 24
        echo "                    </tr>
                </thead>
            </table>
            <table class=\"table table-bordered table-hover dataTable\" role=\"grid\" id=\"movies\">
                <thead>
                ";
        // line 29
        if ( !twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["filterForm"]) || array_key_exists("filterForm", $context) ? $context["filterForm"] : (function () { throw new Twig_Error_Runtime('Variable "filterForm" does not exist.', 29, $this->getSourceContext()); })()), "vars", array()), "valid", array())) {
            // line 30
            echo "                <tr role=\"row\" align=\"center\">
                    <td colspan=\"10\">
                        ";
            // line 32
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock((isset($context["filterForm"]) || array_key_exists("filterForm", $context) ? $context["filterForm"] : (function () { throw new Twig_Error_Runtime('Variable "filterForm" does not exist.', 32, $this->getSourceContext()); })()), 'errors');
            echo "
                    </td>
                </tr>
                ";
        }
        // line 36
        echo "                <tr role=\"row\" align=\"center\">
                    <td width=\"15%\">";
        // line 37
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("management_movie.table.title"), "html", null, true);
        echo "</td>
                    <td width=\"15%\">";
        // line 38
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("management_movie.table.year"), "html", null, true);
        echo "</td>
                    <td width=\"15%\">";
        // line 39
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("management_movie.table.rating"), "html", null, true);
        echo "</td>
                    <td width=\"15%\">";
        // line 40
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("management_movie.table.genre"), "html", null, true);
        echo "</td>
                    <td width=\"15%\">";
        // line 41
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("management_movie.table.actors"), "html", null, true);
        echo "</td>
                    <td width=\"15%\">";
        // line 42
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("management_movie.table.directors"), "html", null, true);
        echo "</td>
                </tr>
                <tr role=\"row\" align=\"center\">
                    <td>
                        ";
        // line 46
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["filterForm"]) || array_key_exists("filterForm", $context) ? $context["filterForm"] : (function () { throw new Twig_Error_Runtime('Variable "filterForm" does not exist.', 46, $this->getSourceContext()); })()), "title", array()), 'row', array("attr" => array("placeholder" => "management_voucher.form.placeholder.title")));
        echo "
                    </td>
                    <td>
                        ";
        // line 49
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["filterForm"]) || array_key_exists("filterForm", $context) ? $context["filterForm"] : (function () { throw new Twig_Error_Runtime('Variable "filterForm" does not exist.', 49, $this->getSourceContext()); })()), "year", array()), 'row', array("attr" => array("placeholder" => "management_voucher.form.placeholder.year")));
        echo "
                    </td>
                    <td>
                        ";
        // line 52
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["filterForm"]) || array_key_exists("filterForm", $context) ? $context["filterForm"] : (function () { throw new Twig_Error_Runtime('Variable "filterForm" does not exist.', 52, $this->getSourceContext()); })()), "rating", array()), 'row', array("attr" => array("placeholder" => "management_voucher.form.placeholder.rating")));
        echo "
                    </td>
                    <td>
                        ";
        // line 55
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["filterForm"]) || array_key_exists("filterForm", $context) ? $context["filterForm"] : (function () { throw new Twig_Error_Runtime('Variable "filterForm" does not exist.', 55, $this->getSourceContext()); })()), "genre", array()), 'row', array("attr" => array("placeholder" => "management_voucher.form.placeholder.genre")));
        echo "
                    </td>
                    <td>
                        ";
        // line 58
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["filterForm"]) || array_key_exists("filterForm", $context) ? $context["filterForm"] : (function () { throw new Twig_Error_Runtime('Variable "filterForm" does not exist.', 58, $this->getSourceContext()); })()), "actors", array()), 'row', array("attr" => array("placeholder" => "management_voucher.form.placeholder.actors")));
        echo "
                    </td> <td>
                        ";
        // line 60
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["filterForm"]) || array_key_exists("filterForm", $context) ? $context["filterForm"] : (function () { throw new Twig_Error_Runtime('Variable "filterForm" does not exist.', 60, $this->getSourceContext()); })()), "directors", array()), 'row', array("attr" => array("placeholder" => "management_voucher.form.placeholder.directors")));
        echo "
                    </td>
                    <td>
                        <button type=\"submit\" id=\"movie_filter_submit\" name=\"submit\"
                                class=\"btn btn-primary btn-flat\">
                            <i class=\"glyphicon glyphicon-filter\"></i>
                        </button>
                        ";
        // line 67
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["filterForm"]) || array_key_exists("filterForm", $context) ? $context["filterForm"] : (function () { throw new Twig_Error_Runtime('Variable "filterForm" does not exist.', 67, $this->getSourceContext()); })()), 'form_end');
        echo "
                    </td>
                </tr>
                </thead>
            </table>
        <div id=\"dom-target\" style=\"display: none\">
            ";
        // line 73
        $context["totalMovies"] = twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["pagination"]) || array_key_exists("pagination", $context) ? $context["pagination"] : (function () { throw new Twig_Error_Runtime('Variable "pagination" does not exist.', 73, $this->getSourceContext()); })()), "count", array());
        // line 74
        echo "            <p>";
        echo twig_escape_filter($this->env, (isset($context["totalMovies"]) || array_key_exists("totalMovies", $context) ? $context["totalMovies"] : (function () { throw new Twig_Error_Runtime('Variable "totalMovies" does not exist.', 74, $this->getSourceContext()); })()), "html", null, true);
        echo "</p>
        </div>
        <div class=\"box-body table-responsive no-padding\">
            <ul class=\"table table-bordered\">
                ";
        // line 78
        $context["i"] = 0;
        // line 79
        echo "                ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["pagination"]) || array_key_exists("pagination", $context) ? $context["pagination"] : (function () { throw new Twig_Error_Runtime('Variable "pagination" does not exist.', 79, $this->getSourceContext()); })()));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["movie"]) {
            // line 80
            echo "                    ";
            $context["i"] = ((isset($context["i"]) || array_key_exists("i", $context) ? $context["i"] : (function () { throw new Twig_Error_Runtime('Variable "i" does not exist.', 80, $this->getSourceContext()); })()) + 1);
            // line 81
            echo "                    <li class=\"info-box\">
                        <div class=\"box-title\">
                            <h2>";
            // line 83
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["movie"], "title", array()), "html", null, true);
            echo "  </h2>
                            <h4>(";
            // line 84
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["movie"], "year", array()), "html", null, true);
            echo ")</h4>
                        </div>
                        <div style=\"display: inline-block; width: 100%\">
                            <div style=\"float: left\">
                                <img src=";
            // line 88
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["movie"], "image", array()), "html", null, true);
            echo ">
                            </div>
                            <div style=\"float: left; width: 40%\">
                                <ul class=\"info-box-content\">
                                    <li class=\"list-unstyled\">
                                            ";
            // line 93
            if ( !(null === twig_get_attribute($this->env, $this->getSourceContext(), $context["movie"], "directors", array()))) {
                // line 94
                echo "                                                <span style = \"font-style: italic\">Regia : </span>
                                                ";
                // line 95
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->getSourceContext(), $context["movie"], "directors", array()));
                foreach ($context['_seq'] as $context["_key"] => $context["director"]) {
                    // line 96
                    echo "                                                    ";
                    if (($context["director"] != twig_last($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["movie"], "directors", array())))) {
                        // line 97
                        echo "                                                        ";
                        echo twig_escape_filter($this->env, $context["director"], "html", null, true);
                        echo ",
                                                    ";
                    } else {
                        // line 99
                        echo "                                                        ";
                        echo twig_escape_filter($this->env, $context["director"], "html", null, true);
                        echo "
                                                    ";
                    }
                    // line 101
                    echo "                                                ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['director'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 102
                echo "                                            ";
            }
            // line 103
            echo "                                    </li>

                                    <li class=\"list-unstyled\">
                                        ";
            // line 106
            if ( !(null === twig_get_attribute($this->env, $this->getSourceContext(), $context["movie"], "actors", array()))) {
                // line 107
                echo "                                            <span class=\"text-bold\">Actori : </span>
                                            ";
                // line 108
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->getSourceContext(), $context["movie"], "actors", array()));
                foreach ($context['_seq'] as $context["_key"] => $context["actor"]) {
                    // line 109
                    echo "                                                ";
                    if (($context["actor"] != twig_last($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["movie"], "actors", array())))) {
                        // line 110
                        echo "                                                    ";
                        echo twig_escape_filter($this->env, $context["actor"], "html", null, true);
                        echo ",
                                                ";
                    } else {
                        // line 112
                        echo "                                                    ";
                        echo twig_escape_filter($this->env, $context["actor"], "html", null, true);
                        echo "
                                                ";
                    }
                    // line 114
                    echo "                                            ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['actor'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 115
                echo "                                        ";
            }
            // line 116
            echo "                                    </li>

                                    <li class=\"list-unstyled\">
                                        ";
            // line 119
            if ( !twig_test_empty(twig_get_attribute($this->env, $this->getSourceContext(), $context["movie"], "genre", array()))) {
                // line 120
                echo "                                            <span class=\"text-bold\">Gen : </span>
                                            ";
                // line 121
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->getSourceContext(), $context["movie"], "genre", array()));
                foreach ($context['_seq'] as $context["_key"] => $context["gen"]) {
                    // line 122
                    echo "                                                ";
                    if (($context["gen"] != twig_last($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["movie"], "genre", array())))) {
                        // line 123
                        echo "                                                    ";
                        echo twig_escape_filter($this->env, $context["gen"], "html", null, true);
                        echo ",
                                                ";
                    } else {
                        // line 125
                        echo "                                                    ";
                        echo twig_escape_filter($this->env, $context["gen"], "html", null, true);
                        echo "
                                                ";
                    }
                    // line 127
                    echo "                                            ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['gen'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 128
                echo "                                        ";
            }
            // line 129
            echo "                                    </li>
                                    <li class=\"list-unstyled\">
                                        ";
            // line 131
            echo             $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["manageForm"]) || array_key_exists("manageForm", $context) ? $context["manageForm"] : (function () { throw new Twig_Error_Runtime('Variable "manageForm" does not exist.', 131, $this->getSourceContext()); })()), 'form_start', array("method" => "post", "attr" => array("class" => "form-inline")));
            echo "
                                        ";
            // line 132
            echo twig_replace_filter((isset($context["form_token"]) || array_key_exists("form_token", $context) ? $context["form_token"] : (function () { throw new Twig_Error_Runtime('Variable "form_token" does not exist.', 132, $this->getSourceContext()); })()), array("#id#" => ("add_to_watch__token_" . twig_get_attribute($this->env, $this->getSourceContext(), $context["movie"], "id", array()))));
            echo "
                                        <div class=\"btn btn-app\">
                                            ";
            // line 134
            $this->loadTemplate(":Components:popup.html.twig", "::movie_list.html.twig", 134)->display(array_merge($context, array("button" => "<i class='fa fa-star-o'></i>", "color" => "notice", "action" => $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("add_to_watch", array("id" => twig_get_attribute($this->env, $this->getSourceContext(),             // line 137
$context["movie"], "id", array()))), "id" => twig_get_attribute($this->env, $this->getSourceContext(),             // line 138
$context["movie"], "id", array()), "type" => "addMovie")));
            // line 142
            echo "                                        </div>
                                        ";
            // line 143
            echo             $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["manageForm"]) || array_key_exists("manageForm", $context) ? $context["manageForm"] : (function () { throw new Twig_Error_Runtime('Variable "manageForm" does not exist.', 143, $this->getSourceContext()); })()), 'form_end');
            echo "
                                    </li>
                                </ul>
                            </div>
                            <div style=\"float: left; width: 40%\">
                                <div class=\"caption\">
                                    <div class=\"info-box-content\">
                                        ";
            // line 150
            $context["name"] = "rating";
            // line 151
            echo "                                        ";
            $context["newId"] = ((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new Twig_Error_Runtime('Variable "name" does not exist.', 151, $this->getSourceContext()); })()) . (isset($context["i"]) || array_key_exists("i", $context) ? $context["i"] : (function () { throw new Twig_Error_Runtime('Variable "i" does not exist.', 151, $this->getSourceContext()); })()));
            // line 152
            echo "                                        <span class=\"info-box-icon bg-aqua\" id=";
            echo twig_escape_filter($this->env, (isset($context["newId"]) || array_key_exists("newId", $context) ? $context["newId"] : (function () { throw new Twig_Error_Runtime('Variable "newId" does not exist.', 152, $this->getSourceContext()); })()), "html", null, true);
            echo " >
                                            <i class=\"fa fa-video-camera\"></i>
                                        </span>
                                        <div class=\"info-box-content\">
                                            <span class=\"info-box-text\">Nota film</span>
                                            <span class=\"info-box-number\">";
            // line 157
            echo twig_escape_filter($this->env, ((twig_get_attribute($this->env, $this->getSourceContext(), $context["movie"], "rating", array()) + twig_get_attribute($this->env, $this->getSourceContext(), $context["movie"], "ratingImdb", array())) / 2), "html", null, true);
            echo "</span>
                                        </div>
                                    </div>
                                </div>
                            <div>
                        </div>
                    </div>
                </div>
                </li>
                ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['movie'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 167
        echo "            ";
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["filterForm"]) || array_key_exists("filterForm", $context) ? $context["filterForm"] : (function () { throw new Twig_Error_Runtime('Variable "filterForm" does not exist.', 167, $this->getSourceContext()); })()), 'form_end');
        echo "
            </ul>
        </div>
    </div>
    </div>
";
        
        $__internal_2defeb6f9b3ba4a9d85fed12384fcf3f77575403de668a72b88cbf86f3bc22e0->leave($__internal_2defeb6f9b3ba4a9d85fed12384fcf3f77575403de668a72b88cbf86f3bc22e0_prof);

        
        $__internal_2822333b8b17ffc374acbe99086f2d215ead20a5abfddc7dc778c0a190faf4bf->leave($__internal_2822333b8b17ffc374acbe99086f2d215ead20a5abfddc7dc778c0a190faf4bf_prof);

    }

    // line 10
    public function block_flashBag($context, array $blocks = array())
    {
        $__internal_f923d1778ab6b29bb3bcd4b72fa78220aa303d09a095380c4daf9ca499b1c61d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f923d1778ab6b29bb3bcd4b72fa78220aa303d09a095380c4daf9ca499b1c61d->enter($__internal_f923d1778ab6b29bb3bcd4b72fa78220aa303d09a095380c4daf9ca499b1c61d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "flashBag"));

        $__internal_320557af7eca150a1b02034c501b7eb09f48795a16f8daba2ee1039d9be77cbc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_320557af7eca150a1b02034c501b7eb09f48795a16f8daba2ee1039d9be77cbc->enter($__internal_320557af7eca150a1b02034c501b7eb09f48795a16f8daba2ee1039d9be77cbc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "flashBag"));

        // line 11
        echo "        ";
        $this->displayParentBlock("flashBag", $context, $blocks);
        echo "
    ";
        
        $__internal_320557af7eca150a1b02034c501b7eb09f48795a16f8daba2ee1039d9be77cbc->leave($__internal_320557af7eca150a1b02034c501b7eb09f48795a16f8daba2ee1039d9be77cbc_prof);

        
        $__internal_f923d1778ab6b29bb3bcd4b72fa78220aa303d09a095380c4daf9ca499b1c61d->leave($__internal_f923d1778ab6b29bb3bcd4b72fa78220aa303d09a095380c4daf9ca499b1c61d_prof);

    }

    // line 174
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_d7742c3cb7264c05f3af0f5379ad44d440cc72fde330691b64879ffd6e2577c5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d7742c3cb7264c05f3af0f5379ad44d440cc72fde330691b64879ffd6e2577c5->enter($__internal_d7742c3cb7264c05f3af0f5379ad44d440cc72fde330691b64879ffd6e2577c5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_067354cbaf932893c6e4eb2a10043450bab6df317d6a87b65ba6324f8526f517 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_067354cbaf932893c6e4eb2a10043450bab6df317d6a87b65ba6324f8526f517->enter($__internal_067354cbaf932893c6e4eb2a10043450bab6df317d6a87b65ba6324f8526f517_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 175
        echo "    ";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "
    <script type=\"text/javascript\">
        var div = document.getElementById(\"dom-target\");
        var total = div.textContent;

        var ids = []
        str1 = \"rating\";
        for (i=1; i<=total; i++) {
            ids[i] = str1.concat(i);
        }

        for (i=1; i<=total; i++){
            document.getElementById(ids[i]).onmouseover = function(){mouseOver1()};
            document.getElementById(ids[i]).onmouseout = function(){mouseOut1()};
        }

        function mouseOver() {
            document.getElementById(\"rating1\").style.color = \"red\";
        }

        function mouseOut(id) {
                document.getElementById(\"\").style.color = \"blue\";
        }
    </script>
";
        
        $__internal_067354cbaf932893c6e4eb2a10043450bab6df317d6a87b65ba6324f8526f517->leave($__internal_067354cbaf932893c6e4eb2a10043450bab6df317d6a87b65ba6324f8526f517_prof);

        
        $__internal_d7742c3cb7264c05f3af0f5379ad44d440cc72fde330691b64879ffd6e2577c5->leave($__internal_d7742c3cb7264c05f3af0f5379ad44d440cc72fde330691b64879ffd6e2577c5_prof);

    }

    public function getTemplateName()
    {
        return "::movie_list.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  486 => 175,  477 => 174,  464 => 11,  455 => 10,  438 => 167,  414 => 157,  405 => 152,  402 => 151,  400 => 150,  390 => 143,  387 => 142,  385 => 138,  384 => 137,  383 => 134,  378 => 132,  374 => 131,  370 => 129,  367 => 128,  361 => 127,  355 => 125,  349 => 123,  346 => 122,  342 => 121,  339 => 120,  337 => 119,  332 => 116,  329 => 115,  323 => 114,  317 => 112,  311 => 110,  308 => 109,  304 => 108,  301 => 107,  299 => 106,  294 => 103,  291 => 102,  285 => 101,  279 => 99,  273 => 97,  270 => 96,  266 => 95,  263 => 94,  261 => 93,  253 => 88,  246 => 84,  242 => 83,  238 => 81,  235 => 80,  217 => 79,  215 => 78,  207 => 74,  205 => 73,  196 => 67,  186 => 60,  181 => 58,  175 => 55,  169 => 52,  163 => 49,  157 => 46,  150 => 42,  146 => 41,  142 => 40,  138 => 39,  134 => 38,  130 => 37,  127 => 36,  120 => 32,  116 => 30,  114 => 29,  107 => 24,  101 => 21,  98 => 20,  96 => 19,  92 => 18,  85 => 14,  82 => 13,  79 => 10,  70 => 9,  52 => 8,  42 => 1,  36 => 5,  34 => 4,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '::base-layout.html.twig' %}


{% set form_token %}
    {{ form_row(manageForm._token, {'id': \"#id#\"}) }}
{% endset %}

{% block page_title %}{{ 'navigation.management_movie.title'|trans }}{% endblock %}
{% block page_content %}
    {% block flashBag %}
        {{ parent() }}
    {% endblock %}
    <div class=\"box\">
            {{ form_start(filterForm, { 'method' : 'get' }) }}
            <table class=\"table table-bordered table-hover dataTable\" role=\"grid\">
                <thead>
                    <tr role=\"row\">
                        <td>{{ form_row(filterForm.results) }}</td>
                    {% if pagination %}
                        <td class=\"pagination pagination-sm no-margin pull-right\">
                            {{ knp_pagination_render(pagination, '::adminlte_pagination.html.twig') }}
                        </td>
                    {% endif %}
                    </tr>
                </thead>
            </table>
            <table class=\"table table-bordered table-hover dataTable\" role=\"grid\" id=\"movies\">
                <thead>
                {% if not filterForm.vars.valid %}
                <tr role=\"row\" align=\"center\">
                    <td colspan=\"10\">
                        {{ form_errors(filterForm) }}
                    </td>
                </tr>
                {% endif %}
                <tr role=\"row\" align=\"center\">
                    <td width=\"15%\">{{ 'management_movie.table.title'|trans }}</td>
                    <td width=\"15%\">{{ 'management_movie.table.year'|trans }}</td>
                    <td width=\"15%\">{{ 'management_movie.table.rating'|trans }}</td>
                    <td width=\"15%\">{{ 'management_movie.table.genre'|trans }}</td>
                    <td width=\"15%\">{{ 'management_movie.table.actors'|trans }}</td>
                    <td width=\"15%\">{{ 'management_movie.table.directors'|trans }}</td>
                </tr>
                <tr role=\"row\" align=\"center\">
                    <td>
                        {{ form_row(filterForm.title, {'attr': {'placeholder' : 'management_voucher.form.placeholder.title'}}) }}
                    </td>
                    <td>
                        {{ form_row(filterForm.year, {'attr': {'placeholder' : 'management_voucher.form.placeholder.year'}}) }}
                    </td>
                    <td>
                        {{ form_row(filterForm.rating, {'attr': {'placeholder' : 'management_voucher.form.placeholder.rating'}}) }}
                    </td>
                    <td>
                        {{ form_row(filterForm.genre, {'attr': {'placeholder' : 'management_voucher.form.placeholder.genre'}}) }}
                    </td>
                    <td>
                        {{ form_row(filterForm.actors, {'attr': {'placeholder' : 'management_voucher.form.placeholder.actors'}}) }}
                    </td> <td>
                        {{ form_row(filterForm.directors, {'attr': {'placeholder' : 'management_voucher.form.placeholder.directors'}}) }}
                    </td>
                    <td>
                        <button type=\"submit\" id=\"movie_filter_submit\" name=\"submit\"
                                class=\"btn btn-primary btn-flat\">
                            <i class=\"glyphicon glyphicon-filter\"></i>
                        </button>
                        {{ form_end(filterForm) }}
                    </td>
                </tr>
                </thead>
            </table>
        <div id=\"dom-target\" style=\"display: none\">
            {% set totalMovies = pagination.count %}
            <p>{{ totalMovies }}</p>
        </div>
        <div class=\"box-body table-responsive no-padding\">
            <ul class=\"table table-bordered\">
                {% set i = 0 %}
                {% for movie in pagination %}
                    {% set i = i + 1 %}
                    <li class=\"info-box\">
                        <div class=\"box-title\">
                            <h2>{{ movie.title }}  </h2>
                            <h4>({{ movie.year }})</h4>
                        </div>
                        <div style=\"display: inline-block; width: 100%\">
                            <div style=\"float: left\">
                                <img src={{ movie.image }}>
                            </div>
                            <div style=\"float: left; width: 40%\">
                                <ul class=\"info-box-content\">
                                    <li class=\"list-unstyled\">
                                            {% if movie.directors is not null %}
                                                <span style = \"font-style: italic\">Regia : </span>
                                                {% for director in movie.directors %}
                                                    {% if director != movie.directors|last %}
                                                        {{ director }},
                                                    {% else %}
                                                        {{ director }}
                                                    {% endif %}
                                                {% endfor %}
                                            {% endif %}
                                    </li>

                                    <li class=\"list-unstyled\">
                                        {% if movie.actors is not null %}
                                            <span class=\"text-bold\">Actori : </span>
                                            {% for actor in movie.actors %}
                                                {% if actor != movie.actors|last %}
                                                    {{ actor }},
                                                {% else %}
                                                    {{ actor }}
                                                {% endif %}
                                            {% endfor %}
                                        {% endif %}
                                    </li>

                                    <li class=\"list-unstyled\">
                                        {% if movie.genre is not empty %}
                                            <span class=\"text-bold\">Gen : </span>
                                            {% for gen in movie.genre %}
                                                {% if gen != movie.genre|last %}
                                                    {{ gen }},
                                                {% else %}
                                                    {{ gen }}
                                                {% endif %}
                                            {% endfor %}
                                        {% endif %}
                                    </li>
                                    <li class=\"list-unstyled\">
                                        {{ form_start(manageForm, {'method' : 'post', 'attr' : {'class' : 'form-inline'}}) }}
                                        {{ form_token|replace({'#id#':'add_to_watch__token_'~movie.id})|raw }}
                                        <div class=\"btn btn-app\">
                                            {% include ':Components:popup.html.twig' with{
                                            'button' : \"<i class='fa fa-star-o'></i>\",
                                            'color' : 'notice',
                                            'action' : path('add_to_watch', {'id': movie.id }),
                                            'id' : movie.id,
                                            'type' : 'addMovie'
                                            }
                                            %}
                                        </div>
                                        {{ form_end(manageForm) }}
                                    </li>
                                </ul>
                            </div>
                            <div style=\"float: left; width: 40%\">
                                <div class=\"caption\">
                                    <div class=\"info-box-content\">
                                        {% set name = \"rating\"  %}
                                        {% set newId = name ~ i %}
                                        <span class=\"info-box-icon bg-aqua\" id={{ newId }} >
                                            <i class=\"fa fa-video-camera\"></i>
                                        </span>
                                        <div class=\"info-box-content\">
                                            <span class=\"info-box-text\">Nota film</span>
                                            <span class=\"info-box-number\">{{ (movie.rating+movie.ratingImdb)/2 }}</span>
                                        </div>
                                    </div>
                                </div>
                            <div>
                        </div>
                    </div>
                </div>
                </li>
                {% endfor %}
            {{ form_end(filterForm) }}
            </ul>
        </div>
    </div>
    </div>
{% endblock %}

{% block javascripts %}
    {{ parent() }}
    <script type=\"text/javascript\">
        var div = document.getElementById(\"dom-target\");
        var total = div.textContent;

        var ids = []
        str1 = \"rating\";
        for (i=1; i<=total; i++) {
            ids[i] = str1.concat(i);
        }

        for (i=1; i<=total; i++){
            document.getElementById(ids[i]).onmouseover = function(){mouseOver1()};
            document.getElementById(ids[i]).onmouseout = function(){mouseOut1()};
        }

        function mouseOver() {
            document.getElementById(\"rating1\").style.color = \"red\";
        }

        function mouseOut(id) {
                document.getElementById(\"\").style.color = \"blue\";
        }
    </script>
{% endblock %}

", "::movie_list.html.twig", "/home/sorina/Documents/work/movies_crowler/app/Resources/views/movie_list.html.twig");
    }
}
