<?php

/* WebProfilerBundle:Profiler:header.html.twig */
class __TwigTemplate_bdfd72660188bd8972fb444b583110906e536898799fca437523427a195b4851 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0ecc51c48398f2dbf1404ccebfe6a9ae269c460b4f70a10e023cfa5764f3d305 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0ecc51c48398f2dbf1404ccebfe6a9ae269c460b4f70a10e023cfa5764f3d305->enter($__internal_0ecc51c48398f2dbf1404ccebfe6a9ae269c460b4f70a10e023cfa5764f3d305_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:header.html.twig"));

        $__internal_b5a46ddf8fa6e8339dbedd5909de327025d9e6f2b193db81d9d3b8e98826356e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b5a46ddf8fa6e8339dbedd5909de327025d9e6f2b193db81d9d3b8e98826356e->enter($__internal_b5a46ddf8fa6e8339dbedd5909de327025d9e6f2b193db81d9d3b8e98826356e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:header.html.twig"));

        // line 1
        echo "<div id=\"header\">
    <div class=\"container\">
        <h1>";
        // line 3
        echo twig_include($this->env, $context, "@WebProfiler/Icon/symfony.svg");
        echo " Symfony <span>Profiler</span></h1>

        <div class=\"search\">
            <form method=\"get\" action=\"https://symfony.com/search\" target=\"_blank\">
                <div class=\"form-row\">
                    <input name=\"q\" id=\"search-id\" type=\"search\" placeholder=\"search on symfony.com\">
                    <button type=\"submit\" class=\"btn\">Search</button>
                </div>
           </form>
        </div>
    </div>
</div>
";
        
        $__internal_0ecc51c48398f2dbf1404ccebfe6a9ae269c460b4f70a10e023cfa5764f3d305->leave($__internal_0ecc51c48398f2dbf1404ccebfe6a9ae269c460b4f70a10e023cfa5764f3d305_prof);

        
        $__internal_b5a46ddf8fa6e8339dbedd5909de327025d9e6f2b193db81d9d3b8e98826356e->leave($__internal_b5a46ddf8fa6e8339dbedd5909de327025d9e6f2b193db81d9d3b8e98826356e_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:header.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  29 => 3,  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div id=\"header\">
    <div class=\"container\">
        <h1>{{ include('@WebProfiler/Icon/symfony.svg') }} Symfony <span>Profiler</span></h1>

        <div class=\"search\">
            <form method=\"get\" action=\"https://symfony.com/search\" target=\"_blank\">
                <div class=\"form-row\">
                    <input name=\"q\" id=\"search-id\" type=\"search\" placeholder=\"search on symfony.com\">
                    <button type=\"submit\" class=\"btn\">Search</button>
                </div>
           </form>
        </div>
    </div>
</div>
", "WebProfilerBundle:Profiler:header.html.twig", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Profiler/header.html.twig");
    }
}
