<?php

/* @Framework/Form/form_row.html.php */
class __TwigTemplate_71aecbefd0f4d541c2032ff8957d92b9b2a6b701fa608b81c6ade05661f17db1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_13b4a2b41489b3d6439373444ed7162ff286d973a5727ddbebedac6c5975ed86 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_13b4a2b41489b3d6439373444ed7162ff286d973a5727ddbebedac6c5975ed86->enter($__internal_13b4a2b41489b3d6439373444ed7162ff286d973a5727ddbebedac6c5975ed86_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_row.html.php"));

        $__internal_337f87fb55bd4aac808e48dcf1b35175f1d94bd93b1f7d560af337a061cb4123 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_337f87fb55bd4aac808e48dcf1b35175f1d94bd93b1f7d560af337a061cb4123->enter($__internal_337f87fb55bd4aac808e48dcf1b35175f1d94bd93b1f7d560af337a061cb4123_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->label(\$form) ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_13b4a2b41489b3d6439373444ed7162ff286d973a5727ddbebedac6c5975ed86->leave($__internal_13b4a2b41489b3d6439373444ed7162ff286d973a5727ddbebedac6c5975ed86_prof);

        
        $__internal_337f87fb55bd4aac808e48dcf1b35175f1d94bd93b1f7d560af337a061cb4123->leave($__internal_337f87fb55bd4aac808e48dcf1b35175f1d94bd93b1f7d560af337a061cb4123_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div>
    <?php echo \$view['form']->label(\$form) ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
", "@Framework/Form/form_row.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_row.html.php");
    }
}
