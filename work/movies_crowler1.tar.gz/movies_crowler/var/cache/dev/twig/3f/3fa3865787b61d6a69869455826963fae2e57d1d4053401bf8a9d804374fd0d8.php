<?php

/* AvanzuAdminThemeBundle:Widget:default-box.html.twig */
class __TwigTemplate_b93d1169c1bf044e4c2318205867ae9122035b0a9098b477122e3d08e041668c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2ed3e38d4de30e007dd9a1a894762163f4a9ba4a21fb41600ea7337f4118e6b0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2ed3e38d4de30e007dd9a1a894762163f4a9ba4a21fb41600ea7337f4118e6b0->enter($__internal_2ed3e38d4de30e007dd9a1a894762163f4a9ba4a21fb41600ea7337f4118e6b0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AvanzuAdminThemeBundle:Widget:default-box.html.twig"));

        $__internal_426258220251e28af20a304e3c6770a27e431ae6b97f27a50fbafa92e3ed2bd2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_426258220251e28af20a304e3c6770a27e431ae6b97f27a50fbafa92e3ed2bd2->enter($__internal_426258220251e28af20a304e3c6770a27e431ae6b97f27a50fbafa92e3ed2bd2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AvanzuAdminThemeBundle:Widget:default-box.html.twig"));

        
        $__internal_2ed3e38d4de30e007dd9a1a894762163f4a9ba4a21fb41600ea7337f4118e6b0->leave($__internal_2ed3e38d4de30e007dd9a1a894762163f4a9ba4a21fb41600ea7337f4118e6b0_prof);

        
        $__internal_426258220251e28af20a304e3c6770a27e431ae6b97f27a50fbafa92e3ed2bd2->leave($__internal_426258220251e28af20a304e3c6770a27e431ae6b97f27a50fbafa92e3ed2bd2_prof);

    }

    public function getTemplateName()
    {
        return "AvanzuAdminThemeBundle:Widget:default-box.html.twig";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "AvanzuAdminThemeBundle:Widget:default-box.html.twig", "/home/sorina/Documents/work/movies_crowler/vendor/avanzu/admin-theme-bundle/Resources/views/Widget/default-box.html.twig");
    }
}
