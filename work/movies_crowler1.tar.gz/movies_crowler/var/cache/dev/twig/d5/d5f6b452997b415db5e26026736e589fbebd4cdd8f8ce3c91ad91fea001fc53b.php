<?php

/* TwigBundle:Exception:error.atom.twig */
class __TwigTemplate_a6ca0b46ea15d70e2a75f2d3506dbe8a47a770b623f3a45c9a912ae975a8e4e4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_802c22e44f4547331334569a7f3ec2858eedda58de7944d401e7ceecf591fb3b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_802c22e44f4547331334569a7f3ec2858eedda58de7944d401e7ceecf591fb3b->enter($__internal_802c22e44f4547331334569a7f3ec2858eedda58de7944d401e7ceecf591fb3b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.atom.twig"));

        $__internal_09589b39111ad50fe116fd5843bef68750dbddc69c2b4c783e1ad9a37cce0853 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_09589b39111ad50fe116fd5843bef68750dbddc69c2b4c783e1ad9a37cce0853->enter($__internal_09589b39111ad50fe116fd5843bef68750dbddc69c2b4c783e1ad9a37cce0853_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "TwigBundle:Exception:error.atom.twig", 1)->display($context);
        
        $__internal_802c22e44f4547331334569a7f3ec2858eedda58de7944d401e7ceecf591fb3b->leave($__internal_802c22e44f4547331334569a7f3ec2858eedda58de7944d401e7ceecf591fb3b_prof);

        
        $__internal_09589b39111ad50fe116fd5843bef68750dbddc69c2b4c783e1ad9a37cce0853->leave($__internal_09589b39111ad50fe116fd5843bef68750dbddc69c2b4c783e1ad9a37cce0853_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.atom.twig";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include '@Twig/Exception/error.xml.twig' %}
", "TwigBundle:Exception:error.atom.twig", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/error.atom.twig");
    }
}
