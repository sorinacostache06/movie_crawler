<?php

/* TwigBundle:Exception:exception.atom.twig */
class __TwigTemplate_be9c9169cd86076fbd1c6c22a3d1c79b35f87fd34acf3274957eaf6ad5980eeb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_310063656feecb685f8d987a1f0748c45ab2f66bec44d4ce42297cc3d103df71 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_310063656feecb685f8d987a1f0748c45ab2f66bec44d4ce42297cc3d103df71->enter($__internal_310063656feecb685f8d987a1f0748c45ab2f66bec44d4ce42297cc3d103df71_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.atom.twig"));

        $__internal_e5b35064854b75f7edcfa49d565794e403023f4eaf8c4160b314fbd0d3386399 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e5b35064854b75f7edcfa49d565794e403023f4eaf8c4160b314fbd0d3386399->enter($__internal_e5b35064854b75f7edcfa49d565794e403023f4eaf8c4160b314fbd0d3386399_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/exception.xml.twig", "TwigBundle:Exception:exception.atom.twig", 1)->display(array_merge($context, array("exception" => (isset($context["exception"]) || array_key_exists("exception", $context) ? $context["exception"] : (function () { throw new Twig_Error_Runtime('Variable "exception" does not exist.', 1, $this->getSourceContext()); })()))));
        
        $__internal_310063656feecb685f8d987a1f0748c45ab2f66bec44d4ce42297cc3d103df71->leave($__internal_310063656feecb685f8d987a1f0748c45ab2f66bec44d4ce42297cc3d103df71_prof);

        
        $__internal_e5b35064854b75f7edcfa49d565794e403023f4eaf8c4160b314fbd0d3386399->leave($__internal_e5b35064854b75f7edcfa49d565794e403023f4eaf8c4160b314fbd0d3386399_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include '@Twig/Exception/exception.xml.twig' with { 'exception': exception } %}
", "TwigBundle:Exception:exception.atom.twig", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/exception.atom.twig");
    }
}
