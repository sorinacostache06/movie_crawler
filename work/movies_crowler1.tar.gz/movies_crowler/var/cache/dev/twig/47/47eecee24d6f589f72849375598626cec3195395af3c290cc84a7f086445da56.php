<?php

/* @Framework/Form/form_end.html.php */
class __TwigTemplate_aec9e9c1fd50175d5eb1c0d25625d799aa805e78471d0791d1c5c8d21663d4e8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f4c074568fed52837c42d190b9bc010b1f6c452562e1bebb0cb4dfcb17503189 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f4c074568fed52837c42d190b9bc010b1f6c452562e1bebb0cb4dfcb17503189->enter($__internal_f4c074568fed52837c42d190b9bc010b1f6c452562e1bebb0cb4dfcb17503189_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_end.html.php"));

        $__internal_10da6104f5bf1e38deb92fc545883cba8e8ad9746bff6468712ff997dd981f6c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_10da6104f5bf1e38deb92fc545883cba8e8ad9746bff6468712ff997dd981f6c->enter($__internal_10da6104f5bf1e38deb92fc545883cba8e8ad9746bff6468712ff997dd981f6c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_end.html.php"));

        // line 1
        echo "<?php if (!isset(\$render_rest) || \$render_rest): ?>
<?php echo \$view['form']->rest(\$form) ?>
<?php endif ?>
</form>
";
        
        $__internal_f4c074568fed52837c42d190b9bc010b1f6c452562e1bebb0cb4dfcb17503189->leave($__internal_f4c074568fed52837c42d190b9bc010b1f6c452562e1bebb0cb4dfcb17503189_prof);

        
        $__internal_10da6104f5bf1e38deb92fc545883cba8e8ad9746bff6468712ff997dd981f6c->leave($__internal_10da6104f5bf1e38deb92fc545883cba8e8ad9746bff6468712ff997dd981f6c_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_end.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (!isset(\$render_rest) || \$render_rest): ?>
<?php echo \$view['form']->rest(\$form) ?>
<?php endif ?>
</form>
", "@Framework/Form/form_end.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_end.html.php");
    }
}
