<?php

/* TwigBundle:Exception:exception.rdf.twig */
class __TwigTemplate_9c943912f794a155e2c19d4a4a615ca1f85ef8a0b7ae03a950591bcddfe8a943 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6d2c96a81ed7c3a315415ecd02167a320430e62b4e7dfbb06650ae8f6f129334 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6d2c96a81ed7c3a315415ecd02167a320430e62b4e7dfbb06650ae8f6f129334->enter($__internal_6d2c96a81ed7c3a315415ecd02167a320430e62b4e7dfbb06650ae8f6f129334_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.rdf.twig"));

        $__internal_c03fef6bbc72042696f0e9bc13cf306813a75ee417d3252d44376f7bf1db706b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c03fef6bbc72042696f0e9bc13cf306813a75ee417d3252d44376f7bf1db706b->enter($__internal_c03fef6bbc72042696f0e9bc13cf306813a75ee417d3252d44376f7bf1db706b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/exception.xml.twig", "TwigBundle:Exception:exception.rdf.twig", 1)->display(array_merge($context, array("exception" => (isset($context["exception"]) || array_key_exists("exception", $context) ? $context["exception"] : (function () { throw new Twig_Error_Runtime('Variable "exception" does not exist.', 1, $this->getSourceContext()); })()))));
        
        $__internal_6d2c96a81ed7c3a315415ecd02167a320430e62b4e7dfbb06650ae8f6f129334->leave($__internal_6d2c96a81ed7c3a315415ecd02167a320430e62b4e7dfbb06650ae8f6f129334_prof);

        
        $__internal_c03fef6bbc72042696f0e9bc13cf306813a75ee417d3252d44376f7bf1db706b->leave($__internal_c03fef6bbc72042696f0e9bc13cf306813a75ee417d3252d44376f7bf1db706b_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include '@Twig/Exception/exception.xml.twig' with { 'exception': exception } %}
", "TwigBundle:Exception:exception.rdf.twig", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/exception.rdf.twig");
    }
}
