<?php

/* @Framework/Form/hidden_row.html.php */
class __TwigTemplate_e6b9934b6f03bf4bd6db103549e8dd800a4c1eb7060a3ab710453a2836058c27 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_514d5862ac749cb4b3be80882473c66d7b5b5a0752c526aa348186debff10c5c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_514d5862ac749cb4b3be80882473c66d7b5b5a0752c526aa348186debff10c5c->enter($__internal_514d5862ac749cb4b3be80882473c66d7b5b5a0752c526aa348186debff10c5c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        $__internal_b1d88bd936633321ca1e98fef2eb7ed8ba767b620a3a8a2252e3aff44a49f532 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b1d88bd936633321ca1e98fef2eb7ed8ba767b620a3a8a2252e3aff44a49f532->enter($__internal_b1d88bd936633321ca1e98fef2eb7ed8ba767b620a3a8a2252e3aff44a49f532_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->widget(\$form) ?>
";
        
        $__internal_514d5862ac749cb4b3be80882473c66d7b5b5a0752c526aa348186debff10c5c->leave($__internal_514d5862ac749cb4b3be80882473c66d7b5b5a0752c526aa348186debff10c5c_prof);

        
        $__internal_b1d88bd936633321ca1e98fef2eb7ed8ba767b620a3a8a2252e3aff44a49f532->leave($__internal_b1d88bd936633321ca1e98fef2eb7ed8ba767b620a3a8a2252e3aff44a49f532_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->widget(\$form) ?>
", "@Framework/Form/hidden_row.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/hidden_row.html.php");
    }
}
