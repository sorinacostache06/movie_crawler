<?php

/* TwigBundle:Exception:error.txt.twig */
class __TwigTemplate_0435f572da3f34c8e81a405c62a7b6ef533a0c7ce874d1e147fd03d9a9539cdf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_487d90b091ba9ae209a5c41c8d2d84de41c508780ed865cb3e2dda00bde5fdff = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_487d90b091ba9ae209a5c41c8d2d84de41c508780ed865cb3e2dda00bde5fdff->enter($__internal_487d90b091ba9ae209a5c41c8d2d84de41c508780ed865cb3e2dda00bde5fdff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.txt.twig"));

        $__internal_e952defac72785257a7c010406eb8dd033f41057bad4afb607d071c1d3229421 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e952defac72785257a7c010406eb8dd033f41057bad4afb607d071c1d3229421->enter($__internal_e952defac72785257a7c010406eb8dd033f41057bad4afb607d071c1d3229421_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.txt.twig"));

        // line 1
        echo "Oops! An Error Occurred
=======================

The server returned a \"";
        // line 4
        echo (isset($context["status_code"]) || array_key_exists("status_code", $context) ? $context["status_code"] : (function () { throw new Twig_Error_Runtime('Variable "status_code" does not exist.', 4, $this->getSourceContext()); })());
        echo " ";
        echo (isset($context["status_text"]) || array_key_exists("status_text", $context) ? $context["status_text"] : (function () { throw new Twig_Error_Runtime('Variable "status_text" does not exist.', 4, $this->getSourceContext()); })());
        echo "\".

Something is broken. Please let us know what you were doing when this error occurred.
We will fix it as soon as possible. Sorry for any inconvenience caused.
";
        
        $__internal_487d90b091ba9ae209a5c41c8d2d84de41c508780ed865cb3e2dda00bde5fdff->leave($__internal_487d90b091ba9ae209a5c41c8d2d84de41c508780ed865cb3e2dda00bde5fdff_prof);

        
        $__internal_e952defac72785257a7c010406eb8dd033f41057bad4afb607d071c1d3229421->leave($__internal_e952defac72785257a7c010406eb8dd033f41057bad4afb607d071c1d3229421_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.txt.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  30 => 4,  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("Oops! An Error Occurred
=======================

The server returned a \"{{ status_code }} {{ status_text }}\".

Something is broken. Please let us know what you were doing when this error occurred.
We will fix it as soon as possible. Sorry for any inconvenience caused.
", "TwigBundle:Exception:error.txt.twig", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/error.txt.twig");
    }
}
