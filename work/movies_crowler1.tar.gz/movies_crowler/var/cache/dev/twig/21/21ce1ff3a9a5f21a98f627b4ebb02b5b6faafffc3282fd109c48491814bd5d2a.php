<?php

/* @Framework/Form/datetime_widget.html.php */
class __TwigTemplate_55db4f68c27571456f2f4a40ae917a65e0c7f91594ac38ba5852c8d351b88a26 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_dae813e6b15d55c21878554b07f283e1bd9a53c1d0e06431c5b494704afd69ff = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_dae813e6b15d55c21878554b07f283e1bd9a53c1d0e06431c5b494704afd69ff->enter($__internal_dae813e6b15d55c21878554b07f283e1bd9a53c1d0e06431c5b494704afd69ff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/datetime_widget.html.php"));

        $__internal_7f056ee9bf6b377b18787c69c2cc5e98f61aab05d0c42048e2b9d04dd5b5da25 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7f056ee9bf6b377b18787c69c2cc5e98f61aab05d0c42048e2b9d04dd5b5da25->enter($__internal_7f056ee9bf6b377b18787c69c2cc5e98f61aab05d0c42048e2b9d04dd5b5da25_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/datetime_widget.html.php"));

        // line 1
        echo "<?php if (\$widget == 'single_text'): ?>
    <?php echo \$view['form']->block(\$form, 'form_widget_simple'); ?>
<?php else: ?>
    <div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
        <?php echo \$view['form']->widget(\$form['date']).' '.\$view['form']->widget(\$form['time']) ?>
    </div>
<?php endif ?>
";
        
        $__internal_dae813e6b15d55c21878554b07f283e1bd9a53c1d0e06431c5b494704afd69ff->leave($__internal_dae813e6b15d55c21878554b07f283e1bd9a53c1d0e06431c5b494704afd69ff_prof);

        
        $__internal_7f056ee9bf6b377b18787c69c2cc5e98f61aab05d0c42048e2b9d04dd5b5da25->leave($__internal_7f056ee9bf6b377b18787c69c2cc5e98f61aab05d0c42048e2b9d04dd5b5da25_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/datetime_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$widget == 'single_text'): ?>
    <?php echo \$view['form']->block(\$form, 'form_widget_simple'); ?>
<?php else: ?>
    <div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
        <?php echo \$view['form']->widget(\$form['date']).' '.\$view['form']->widget(\$form['time']) ?>
    </div>
<?php endif ?>
", "@Framework/Form/datetime_widget.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/datetime_widget.html.php");
    }
}
