<?php

/* ::want_watch_list.html.twig */
class __TwigTemplate_b155c206eeeeb136c4096095e9bbbbfe864a9d6f7f29f585b6060c5ee7869404 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base-layout.html.twig", "::want_watch_list.html.twig", 1);
        $this->blocks = array(
            'page_title' => array($this, 'block_page_title'),
            'page_content' => array($this, 'block_page_content'),
            'flashBag' => array($this, 'block_flashBag'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base-layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1c11e50ffa9d57b8594d69cbbd6b103514f6d06db11882679fc8051cd075bf6b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1c11e50ffa9d57b8594d69cbbd6b103514f6d06db11882679fc8051cd075bf6b->enter($__internal_1c11e50ffa9d57b8594d69cbbd6b103514f6d06db11882679fc8051cd075bf6b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::want_watch_list.html.twig"));

        $__internal_02bf34ca707340ba022a825f92eef0718ea63df465f204f084e9fafae5b8c165 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_02bf34ca707340ba022a825f92eef0718ea63df465f204f084e9fafae5b8c165->enter($__internal_02bf34ca707340ba022a825f92eef0718ea63df465f204f084e9fafae5b8c165_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::want_watch_list.html.twig"));

        // line 3
        ob_start();
        // line 4
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["manageForm"]) || array_key_exists("manageForm", $context) ? $context["manageForm"] : (function () { throw new Twig_Error_Runtime('Variable "manageForm" does not exist.', 4, $this->getSourceContext()); })()), "_token", array()), 'row', array("id" => "#id#"));
        echo "
";
        $context["form_token"] = ('' === $tmp = ob_get_clean()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        // line 1
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_1c11e50ffa9d57b8594d69cbbd6b103514f6d06db11882679fc8051cd075bf6b->leave($__internal_1c11e50ffa9d57b8594d69cbbd6b103514f6d06db11882679fc8051cd075bf6b_prof);

        
        $__internal_02bf34ca707340ba022a825f92eef0718ea63df465f204f084e9fafae5b8c165->leave($__internal_02bf34ca707340ba022a825f92eef0718ea63df465f204f084e9fafae5b8c165_prof);

    }

    // line 7
    public function block_page_title($context, array $blocks = array())
    {
        $__internal_76812b3ef2bac9b2f9846e1382c0c9e3e4cda5e3f78fb092b190d2e7fed0452e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_76812b3ef2bac9b2f9846e1382c0c9e3e4cda5e3f78fb092b190d2e7fed0452e->enter($__internal_76812b3ef2bac9b2f9846e1382c0c9e3e4cda5e3f78fb092b190d2e7fed0452e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_title"));

        $__internal_83fec2161720bea3bfe5375f893e9d8ab742fdf19f2f3646e4071b57c616eb26 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_83fec2161720bea3bfe5375f893e9d8ab742fdf19f2f3646e4071b57c616eb26->enter($__internal_83fec2161720bea3bfe5375f893e9d8ab742fdf19f2f3646e4071b57c616eb26_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_title"));

        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("navigation.want_to_watch.title"), "html", null, true);
        
        $__internal_83fec2161720bea3bfe5375f893e9d8ab742fdf19f2f3646e4071b57c616eb26->leave($__internal_83fec2161720bea3bfe5375f893e9d8ab742fdf19f2f3646e4071b57c616eb26_prof);

        
        $__internal_76812b3ef2bac9b2f9846e1382c0c9e3e4cda5e3f78fb092b190d2e7fed0452e->leave($__internal_76812b3ef2bac9b2f9846e1382c0c9e3e4cda5e3f78fb092b190d2e7fed0452e_prof);

    }

    // line 9
    public function block_page_content($context, array $blocks = array())
    {
        $__internal_04c34c34d075f619386840b423766b5b702d026fc5b037589d80e21915c810a4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_04c34c34d075f619386840b423766b5b702d026fc5b037589d80e21915c810a4->enter($__internal_04c34c34d075f619386840b423766b5b702d026fc5b037589d80e21915c810a4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_content"));

        $__internal_759d96f848ae451e00022c3842399341c1b7c76611412e9846b756908e5621c5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_759d96f848ae451e00022c3842399341c1b7c76611412e9846b756908e5621c5->enter($__internal_759d96f848ae451e00022c3842399341c1b7c76611412e9846b756908e5621c5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_content"));

        // line 10
        echo "
    ";
        // line 11
        $this->displayBlock('flashBag', $context, $blocks);
        // line 14
        echo "
<div class=\"box\">
    <div class=\"row\">
        <table class=\"table table-bordered table-hover dataTable\" role=\"grid\">
            <thead>
                ";
        // line 19
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["listMovies"]) || array_key_exists("listMovies", $context) ? $context["listMovies"] : (function () { throw new Twig_Error_Runtime('Variable "listMovies" does not exist.', 19, $this->getSourceContext()); })()), 'form_start', array("method" => "get"));
        echo "
                <tr>
                    <td align=\"center\" style=\"font-weight: bold\">";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("wantwatch_management.table.title"), "html", null, true);
        echo "</td>
                    <td align=\"center\" style=\"font-weight: bold\">";
        // line 22
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("wantwatch_management.table.rating"), "html", null, true);
        echo "</td>
                    <td align=\"center\" style=\"font-weight: bold\">";
        // line 23
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("wantwatch_management.table.seen"), "html", null, true);
        echo "</td>
                    <td align=\"center\" style=\"font-weight: bold\">";
        // line 24
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("wantwatch_management.table.delete"), "html", null, true);
        echo "</td>
                </tr>
            </thead>
            <tbody>
                    ";
        // line 28
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["favorites"]) || array_key_exists("favorites", $context) ? $context["favorites"] : (function () { throw new Twig_Error_Runtime('Variable "favorites" does not exist.', 28, $this->getSourceContext()); })()));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["favorite"]) {
            // line 29
            echo "                    <tr role=\"row\" align=\"center\" style=\"padding:0\">
                         <td>";
            // line 30
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["favorite"], "title", array()), "html", null, true);
            echo "</td>
                         <td>";
            // line 31
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["favorite"], "rating", array()), "html", null, true);
            echo "</td>
                        <td>
                            <label class=\"switch\">
                                <input type=\"checkbox\">
                                <div class=\"slider round\"></div>
                            </label>
                        </td>
                        <td>
                            ";
            // line 39
            echo             $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["manageForm"]) || array_key_exists("manageForm", $context) ? $context["manageForm"] : (function () { throw new Twig_Error_Runtime('Variable "manageForm" does not exist.', 39, $this->getSourceContext()); })()), 'form_start', array("method" => "get"));
            echo "
                            ";
            // line 40
            echo twig_replace_filter((isset($context["form_token"]) || array_key_exists("form_token", $context) ? $context["form_token"] : (function () { throw new Twig_Error_Runtime('Variable "form_token" does not exist.', 40, $this->getSourceContext()); })()), array("#id#" => ("delete_to_watch__token_" . twig_get_attribute($this->env, $this->getSourceContext(), $context["favorite"], "id", array()))));
            echo "
                            <span style=\"float: none\">
                                ";
            // line 42
            $this->loadTemplate(":Components:popup.html.twig", "::want_watch_list.html.twig", 42)->display(array_merge($context, array("button" => "<i class='fa fa-close'></i>", "color" => "danger", "action" => $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("delete_to_watch", array("id" => twig_get_attribute($this->env, $this->getSourceContext(),             // line 45
$context["favorite"], "id", array()))), "id" => twig_get_attribute($this->env, $this->getSourceContext(),             // line 46
$context["favorite"], "id", array()), "type" => "deleteMovie")));
            // line 50
            echo "                            </span>
                        </td>
                            ";
            // line 52
            echo             $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["manageForm"]) || array_key_exists("manageForm", $context) ? $context["manageForm"] : (function () { throw new Twig_Error_Runtime('Variable "manageForm" does not exist.', 52, $this->getSourceContext()); })()), 'form_end');
            echo "
                    </tr>
                    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['favorite'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 55
        echo "            </tbody>
        </table>
    </div>
</div>
    <style>
        .switch {
            position: relative;
            display: inline-block;
            width: 60px;
            height: 34px;
        }

        .switch input {display:none;}

        .slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #ccc;
            -webkit-transition: .4s;
            transition: .4s;
        }

        .slider:before {
            position: absolute;
            content: \"\";
            height: 26px;
            width: 26px;
            left: 4px;
            bottom: 4px;
            background-color: white;
            -webkit-transition: .4s;
            transition: .4s;
        }

        input:checked + .slider {
            background-color: #2196F3;
        }

        input:focus + .slider {
            box-shadow: 0 0 1px #2196F3;
        }

        input:checked + .slider:before {
            -webkit-transform: translateX(26px);
            -ms-transform: translateX(26px);
            transform: translateX(26px);
        }

        /* Rounded sliders */
        .slider.round {
            border-radius: 34px;
        }

        .slider.round:before {
            border-radius: 50%;
        }
    </style>
";
        
        $__internal_759d96f848ae451e00022c3842399341c1b7c76611412e9846b756908e5621c5->leave($__internal_759d96f848ae451e00022c3842399341c1b7c76611412e9846b756908e5621c5_prof);

        
        $__internal_04c34c34d075f619386840b423766b5b702d026fc5b037589d80e21915c810a4->leave($__internal_04c34c34d075f619386840b423766b5b702d026fc5b037589d80e21915c810a4_prof);

    }

    // line 11
    public function block_flashBag($context, array $blocks = array())
    {
        $__internal_7a1c0f82d2e29c421e37ca1206c60ccfe5e4c2416dfda5229887c283b72ec895 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7a1c0f82d2e29c421e37ca1206c60ccfe5e4c2416dfda5229887c283b72ec895->enter($__internal_7a1c0f82d2e29c421e37ca1206c60ccfe5e4c2416dfda5229887c283b72ec895_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "flashBag"));

        $__internal_92ec2d88ee12f7a4609116d334f7df3e26748c90464db15411c9509e62907479 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_92ec2d88ee12f7a4609116d334f7df3e26748c90464db15411c9509e62907479->enter($__internal_92ec2d88ee12f7a4609116d334f7df3e26748c90464db15411c9509e62907479_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "flashBag"));

        // line 12
        echo "        ";
        $this->displayParentBlock("flashBag", $context, $blocks);
        echo "
    ";
        
        $__internal_92ec2d88ee12f7a4609116d334f7df3e26748c90464db15411c9509e62907479->leave($__internal_92ec2d88ee12f7a4609116d334f7df3e26748c90464db15411c9509e62907479_prof);

        
        $__internal_7a1c0f82d2e29c421e37ca1206c60ccfe5e4c2416dfda5229887c283b72ec895->leave($__internal_7a1c0f82d2e29c421e37ca1206c60ccfe5e4c2416dfda5229887c283b72ec895_prof);

    }

    public function getTemplateName()
    {
        return "::want_watch_list.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  263 => 12,  254 => 11,  183 => 55,  166 => 52,  162 => 50,  160 => 46,  159 => 45,  158 => 42,  153 => 40,  149 => 39,  138 => 31,  134 => 30,  131 => 29,  114 => 28,  107 => 24,  103 => 23,  99 => 22,  95 => 21,  90 => 19,  83 => 14,  81 => 11,  78 => 10,  69 => 9,  51 => 7,  41 => 1,  35 => 4,  33 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '::base-layout.html.twig' %}

{% set form_token %}
    {{ form_row(manageForm._token, {'id': \"#id#\"}) }}
{% endset %}

{% block page_title %}{{ 'navigation.want_to_watch.title'|trans }}{% endblock %}

{% block page_content %}

    {% block flashBag %}
        {{ parent() }}
    {% endblock %}

<div class=\"box\">
    <div class=\"row\">
        <table class=\"table table-bordered table-hover dataTable\" role=\"grid\">
            <thead>
                {{ form_start(listMovies, { 'method' : 'get'}) }}
                <tr>
                    <td align=\"center\" style=\"font-weight: bold\">{{ 'wantwatch_management.table.title'|trans }}</td>
                    <td align=\"center\" style=\"font-weight: bold\">{{ 'wantwatch_management.table.rating'|trans }}</td>
                    <td align=\"center\" style=\"font-weight: bold\">{{ 'wantwatch_management.table.seen'|trans }}</td>
                    <td align=\"center\" style=\"font-weight: bold\">{{ 'wantwatch_management.table.delete'|trans }}</td>
                </tr>
            </thead>
            <tbody>
                    {% for favorite in favorites %}
                    <tr role=\"row\" align=\"center\" style=\"padding:0\">
                         <td>{{ favorite.title }}</td>
                         <td>{{ favorite.rating }}</td>
                        <td>
                            <label class=\"switch\">
                                <input type=\"checkbox\">
                                <div class=\"slider round\"></div>
                            </label>
                        </td>
                        <td>
                            {{ form_start(manageForm, { 'method' : 'get'}) }}
                            {{ form_token|replace({'#id#':'delete_to_watch__token_'~favorite.id})|raw }}
                            <span style=\"float: none\">
                                {% include ':Components:popup.html.twig' with{
                                'button' : \"<i class='fa fa-close'></i>\",
                                'color' : 'danger',
                                'action' : path('delete_to_watch', {'id': favorite.id }),
                                'id' : favorite.id,
                                'type' : 'deleteMovie'
                                }
                                %}
                            </span>
                        </td>
                            {{ form_end(manageForm) }}
                    </tr>
                    {% endfor %}
            </tbody>
        </table>
    </div>
</div>
    <style>
        .switch {
            position: relative;
            display: inline-block;
            width: 60px;
            height: 34px;
        }

        .switch input {display:none;}

        .slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #ccc;
            -webkit-transition: .4s;
            transition: .4s;
        }

        .slider:before {
            position: absolute;
            content: \"\";
            height: 26px;
            width: 26px;
            left: 4px;
            bottom: 4px;
            background-color: white;
            -webkit-transition: .4s;
            transition: .4s;
        }

        input:checked + .slider {
            background-color: #2196F3;
        }

        input:focus + .slider {
            box-shadow: 0 0 1px #2196F3;
        }

        input:checked + .slider:before {
            -webkit-transform: translateX(26px);
            -ms-transform: translateX(26px);
            transform: translateX(26px);
        }

        /* Rounded sliders */
        .slider.round {
            border-radius: 34px;
        }

        .slider.round:before {
            border-radius: 50%;
        }
    </style>
{% endblock %}

", "::want_watch_list.html.twig", "/home/sorina/Documents/work/movies_crowler/app/Resources/views/want_watch_list.html.twig");
    }
}
