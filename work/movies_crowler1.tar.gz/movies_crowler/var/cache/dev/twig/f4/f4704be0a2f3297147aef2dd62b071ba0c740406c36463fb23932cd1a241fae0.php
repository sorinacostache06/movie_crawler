<?php

/* :Admin:user_list.html.twig */
class __TwigTemplate_dce2b18a422204a5b05234d4e2943dffbe344976f5ff38f80151c9b31a6485be extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base-layout.html.twig", ":Admin:user_list.html.twig", 1);
        $this->blocks = array(
            'page_title' => array($this, 'block_page_title'),
            'page_subtitle' => array($this, 'block_page_subtitle'),
            'page_content' => array($this, 'block_page_content'),
            'flashBag' => array($this, 'block_flashBag'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base-layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2cd28d198380cee7ecc4b40f2fde05585772a4fe78a516276c24f695052b2881 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2cd28d198380cee7ecc4b40f2fde05585772a4fe78a516276c24f695052b2881->enter($__internal_2cd28d198380cee7ecc4b40f2fde05585772a4fe78a516276c24f695052b2881_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Admin:user_list.html.twig"));

        $__internal_ba9f7967275df0eaec1ba410256f3ae0c86ca7c57bdf738c66d4d640cd733f38 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ba9f7967275df0eaec1ba410256f3ae0c86ca7c57bdf738c66d4d640cd733f38->enter($__internal_ba9f7967275df0eaec1ba410256f3ae0c86ca7c57bdf738c66d4d640cd733f38_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Admin:user_list.html.twig"));

        // line 2
        ob_start();
        // line 3
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["manageForm"]) || array_key_exists("manageForm", $context) ? $context["manageForm"] : (function () { throw new Twig_Error_Runtime('Variable "manageForm" does not exist.', 3, $this->getSourceContext()); })()), "_token", array()), 'row', array("id" => "#id#"));
        echo "
";
        $context["form_token"] = ('' === $tmp = ob_get_clean()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        // line 6
        $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->setTheme((isset($context["filterForm"]) || array_key_exists("filterForm", $context) ? $context["filterForm"] : (function () { throw new Twig_Error_Runtime('Variable "filterForm" does not exist.', 6, $this->getSourceContext()); })()), array(0 => ":Form:fields.html.twig"));
        // line 1
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_2cd28d198380cee7ecc4b40f2fde05585772a4fe78a516276c24f695052b2881->leave($__internal_2cd28d198380cee7ecc4b40f2fde05585772a4fe78a516276c24f695052b2881_prof);

        
        $__internal_ba9f7967275df0eaec1ba410256f3ae0c86ca7c57bdf738c66d4d640cd733f38->leave($__internal_ba9f7967275df0eaec1ba410256f3ae0c86ca7c57bdf738c66d4d640cd733f38_prof);

    }

    // line 7
    public function block_page_title($context, array $blocks = array())
    {
        $__internal_e8895d40feae5aa53500e1a18efb132545a4924e425c87cc4dd7d396104d6c37 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e8895d40feae5aa53500e1a18efb132545a4924e425c87cc4dd7d396104d6c37->enter($__internal_e8895d40feae5aa53500e1a18efb132545a4924e425c87cc4dd7d396104d6c37_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_title"));

        $__internal_5e42bb3c482db47c04aa7a3da86d55a1899a1a7fecee38837f819fdc968c023b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5e42bb3c482db47c04aa7a3da86d55a1899a1a7fecee38837f819fdc968c023b->enter($__internal_5e42bb3c482db47c04aa7a3da86d55a1899a1a7fecee38837f819fdc968c023b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_title"));

        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("navigation.user_management.title"), "html", null, true);
        
        $__internal_5e42bb3c482db47c04aa7a3da86d55a1899a1a7fecee38837f819fdc968c023b->leave($__internal_5e42bb3c482db47c04aa7a3da86d55a1899a1a7fecee38837f819fdc968c023b_prof);

        
        $__internal_e8895d40feae5aa53500e1a18efb132545a4924e425c87cc4dd7d396104d6c37->leave($__internal_e8895d40feae5aa53500e1a18efb132545a4924e425c87cc4dd7d396104d6c37_prof);

    }

    // line 8
    public function block_page_subtitle($context, array $blocks = array())
    {
        $__internal_ec70d1134e3e92bcf8f088d9c2da4a84c8ede69c178203e5186a930e3714ab0c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ec70d1134e3e92bcf8f088d9c2da4a84c8ede69c178203e5186a930e3714ab0c->enter($__internal_ec70d1134e3e92bcf8f088d9c2da4a84c8ede69c178203e5186a930e3714ab0c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_subtitle"));

        $__internal_3aa8e4a8aaf5a8808c60fb39b23e67f435ddf41be08d252d723078d821c188b2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3aa8e4a8aaf5a8808c60fb39b23e67f435ddf41be08d252d723078d821c188b2->enter($__internal_3aa8e4a8aaf5a8808c60fb39b23e67f435ddf41be08d252d723078d821c188b2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_subtitle"));

        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("navigation.user_management.subtitle"), "html", null, true);
        
        $__internal_3aa8e4a8aaf5a8808c60fb39b23e67f435ddf41be08d252d723078d821c188b2->leave($__internal_3aa8e4a8aaf5a8808c60fb39b23e67f435ddf41be08d252d723078d821c188b2_prof);

        
        $__internal_ec70d1134e3e92bcf8f088d9c2da4a84c8ede69c178203e5186a930e3714ab0c->leave($__internal_ec70d1134e3e92bcf8f088d9c2da4a84c8ede69c178203e5186a930e3714ab0c_prof);

    }

    // line 9
    public function block_page_content($context, array $blocks = array())
    {
        $__internal_100cab17d32af10933703f9d8c8ddb36b32aa762942a3ccac9f0cbaa6689d75f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_100cab17d32af10933703f9d8c8ddb36b32aa762942a3ccac9f0cbaa6689d75f->enter($__internal_100cab17d32af10933703f9d8c8ddb36b32aa762942a3ccac9f0cbaa6689d75f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_content"));

        $__internal_59c67848b40054bfe50f02b6da26ef80cf2d333fab38c5840eebf08dce607255 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_59c67848b40054bfe50f02b6da26ef80cf2d333fab38c5840eebf08dce607255->enter($__internal_59c67848b40054bfe50f02b6da26ef80cf2d333fab38c5840eebf08dce607255_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_content"));

        // line 10
        echo "    <div class=\"row\">
        <div class=\"col-lg-8 col-md-8 col-lg-offset-2 col-md-offset-2\">
            ";
        // line 12
        $this->displayBlock('flashBag', $context, $blocks);
        // line 15
        echo "        </div>
    </div>
    <div class=\"row\">
        <div class=\"col-lg-12 col-md-12\">
            <div class=\"box box-info\">
                <div class=\"box-header with-border\">
                    <h3 class=\"box-title\">";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("user_management.table.title"), "html", null, true);
        echo "</h3>
                </div>
                <div class=\"box-body table-bordered\">
                    <span style=\"float:left\">
                        ";
        // line 25
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["filterForm"]) || array_key_exists("filterForm", $context) ? $context["filterForm"] : (function () { throw new Twig_Error_Runtime('Variable "filterForm" does not exist.', 25, $this->getSourceContext()); })()), 'form_start', array("method" => "get"));
        echo "
                        <div class=\"row\" style=\"margin-left: 20px; margin-right: 20px;\">
                        <div class=\"col-lg-2\">
                            ";
        // line 28
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["filterForm"]) || array_key_exists("filterForm", $context) ? $context["filterForm"] : (function () { throw new Twig_Error_Runtime('Variable "filterForm" does not exist.', 28, $this->getSourceContext()); })()), "results", array()), 'row');
        echo "
                        </div>
                        <div class=\"col-lg-11\">
                            ";
        // line 31
        if ((isset($context["pagination"]) || array_key_exists("pagination", $context) ? $context["pagination"] : (function () { throw new Twig_Error_Runtime('Variable "pagination" does not exist.', 31, $this->getSourceContext()); })())) {
            // line 32
            echo "                                <ul class=\"pagination pagination-sm no-margin pull-right\">
                                    ";
            // line 33
            echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->render($this->env, (isset($context["pagination"]) || array_key_exists("pagination", $context) ? $context["pagination"] : (function () { throw new Twig_Error_Runtime('Variable "pagination" does not exist.', 33, $this->getSourceContext()); })()), "::adminlte_pagination.html.twig");
            echo "
                                </ul>
                            ";
        }
        // line 36
        echo "                        </div>
                    </div>
                    <table class=\"table table-bordered table-hover dataTable\" role=\"grid\" id=\"voucher_requests\">
                        <thead>
                        ";
        // line 40
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["filterForm"]) || array_key_exists("filterForm", $context) ? $context["filterForm"] : (function () { throw new Twig_Error_Runtime('Variable "filterForm" does not exist.', 40, $this->getSourceContext()); })()), 'form_start', array("method" => "get"));
        echo "
                        ";
        // line 41
        if ( !twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["filterForm"]) || array_key_exists("filterForm", $context) ? $context["filterForm"] : (function () { throw new Twig_Error_Runtime('Variable "filterForm" does not exist.', 41, $this->getSourceContext()); })()), "vars", array()), "valid", array())) {
            // line 42
            echo "                            <tr role=\"row\" align=\"center\">
                            <td colspan=\"6\">
                                ";
            // line 44
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock((isset($context["filterForm"]) || array_key_exists("filterForm", $context) ? $context["filterForm"] : (function () { throw new Twig_Error_Runtime('Variable "filterForm" does not exist.', 44, $this->getSourceContext()); })()), 'errors', array("method" => "get", "attr" => array("class" => "form-inline")));
            echo "
                            </td>
                        </tr>
                        ";
        }
        // line 48
        echo "                        ";
        if ((isset($context["pagination"]) || array_key_exists("pagination", $context) ? $context["pagination"] : (function () { throw new Twig_Error_Runtime('Variable "pagination" does not exist.', 48, $this->getSourceContext()); })())) {
            // line 49
            echo "                        <tr role=\"row\" align=\"center\" style=\"padding:0\">
                            <th width=\"10%\">";
            // line 50
            echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) || array_key_exists("pagination", $context) ? $context["pagination"] : (function () { throw new Twig_Error_Runtime('Variable "pagination" does not exist.', 50, $this->getSourceContext()); })()), $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("user_management.table.id"), "u.id");
            echo "</th>
                            <th width=\"10%\">";
            // line 51
            echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) || array_key_exists("pagination", $context) ? $context["pagination"] : (function () { throw new Twig_Error_Runtime('Variable "pagination" does not exist.', 51, $this->getSourceContext()); })()), $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("user_management.table.name"), "u.username");
            echo "</th>
                            <th width=\"30%\">";
            // line 52
            echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) || array_key_exists("pagination", $context) ? $context["pagination"] : (function () { throw new Twig_Error_Runtime('Variable "pagination" does not exist.', 52, $this->getSourceContext()); })()), $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("user_management.table.join_date"), "u.joinDate");
            echo "</th>
                            <th width=\"10%\">";
            // line 53
            echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) || array_key_exists("pagination", $context) ? $context["pagination"] : (function () { throw new Twig_Error_Runtime('Variable "pagination" does not exist.', 53, $this->getSourceContext()); })()), $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("user_management.table.email"), "u.email");
            echo "</th>
                            <th width=\"10%\">";
            // line 54
            echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) || array_key_exists("pagination", $context) ? $context["pagination"] : (function () { throw new Twig_Error_Runtime('Variable "pagination" does not exist.', 54, $this->getSourceContext()); })()), $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("user_management.table.user_enabled"), "u.enabled");
            echo "</th>
                            <th width=\"10%\">";
            // line 55
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("user_management.table.actions"), "html", null, true);
            echo "</th>
                        </tr>
                        </thead>
                        <tbody>
                    ";
            // line 59
            if (twig_test_empty((isset($context["pagination"]) || array_key_exists("pagination", $context) ? $context["pagination"] : (function () { throw new Twig_Error_Runtime('Variable "pagination" does not exist.', 59, $this->getSourceContext()); })()))) {
                // line 60
                echo "                    <tr role=\"row\" align=\"center\">
                            <td colspan=\"7\">
                                <div class=\"alert alert-info alert-dismissible\">
                                <button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>
                                <h4><i class=\"icon fa fa-info\"></i> Alert!</h4>
                                    ";
                // line 65
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("generic.table.no_results"), "html", null, true);
                echo "
                                </div>
                            </td>
                        </tr>
                    ";
            } else {
                // line 70
                echo "                    <tr role=\"row\" align=\"center\" style=\"padding:0\">
                            <td>
                                ";
                // line 72
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["filterForm"]) || array_key_exists("filterForm", $context) ? $context["filterForm"] : (function () { throw new Twig_Error_Runtime('Variable "filterForm" does not exist.', 72, $this->getSourceContext()); })()), "id", array()), 'row', array("attr" => array("placeholder" => "user_management.form.placeholder.id")));
                echo "
                            </td>
                            <td>
                                ";
                // line 75
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["filterForm"]) || array_key_exists("filterForm", $context) ? $context["filterForm"] : (function () { throw new Twig_Error_Runtime('Variable "filterForm" does not exist.', 75, $this->getSourceContext()); })()), "username", array()), 'row', array("attr" => array("placeholder" => "user_management.form.placeholder.username")));
                echo "
                            </td>
                            <td>
                                ";
                // line 78
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["filterForm"]) || array_key_exists("filterForm", $context) ? $context["filterForm"] : (function () { throw new Twig_Error_Runtime('Variable "filterForm" does not exist.', 78, $this->getSourceContext()); })()), "joinDate", array()), 'row', array("attr" => array("placeholder" => "user_management.form.placeholder.joinDate")));
                echo "
                            </td>
                            <td>
                                ";
                // line 81
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["filterForm"]) || array_key_exists("filterForm", $context) ? $context["filterForm"] : (function () { throw new Twig_Error_Runtime('Variable "filterForm" does not exist.', 81, $this->getSourceContext()); })()), "email", array()), 'row', array("attr" => array("placeholder" => "user_management.form.placeholder.email")));
                echo "
                            </td>
                            <td>
                                ";
                // line 84
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["filterForm"]) || array_key_exists("filterForm", $context) ? $context["filterForm"] : (function () { throw new Twig_Error_Runtime('Variable "filterForm" does not exist.', 84, $this->getSourceContext()); })()), "enabled", array()), 'row');
                echo "
                            </td>
                            <td>
                                <button type=\"submit\" id=\"user_filter_submit\" name=\"submit\"
                                        class=\"btn btn-primary btn-flat\">
                                    <i class=\"glyphicon glyphicon-filter\"></i></button>
                                ";
                // line 90
                echo                 $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["filterForm"]) || array_key_exists("filterForm", $context) ? $context["filterForm"] : (function () { throw new Twig_Error_Runtime('Variable "filterForm" does not exist.', 90, $this->getSourceContext()); })()), 'form_end');
                echo "
                            </td>
                        </tr>
                    ";
                // line 93
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable((isset($context["pagination"]) || array_key_exists("pagination", $context) ? $context["pagination"] : (function () { throw new Twig_Error_Runtime('Variable "pagination" does not exist.', 93, $this->getSourceContext()); })()));
                $context['loop'] = array(
                  'parent' => $context['_parent'],
                  'index0' => 0,
                  'index'  => 1,
                  'first'  => true,
                );
                if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                    $length = count($context['_seq']);
                    $context['loop']['revindex0'] = $length - 1;
                    $context['loop']['revindex'] = $length;
                    $context['loop']['length'] = $length;
                    $context['loop']['last'] = 1 === $length;
                }
                foreach ($context['_seq'] as $context["_key"] => $context["user"]) {
                    // line 94
                    echo "                        <tr role=\"row\" align=\"center\" style=\"padding:0\">
                                <td>";
                    // line 95
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["user"], "id", array()), "html", null, true);
                    echo "</td>
                                <td>";
                    // line 96
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["user"], "username", array()), "html", null, true);
                    echo "</td>
                                <td>";
                    // line 97
                    echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["user"], "joinDate", array()), "d/m/Y H:i:s"), "html", null, true);
                    echo "</td>
                                <td>";
                    // line 98
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["user"], "email", array()), "html", null, true);
                    echo "</td>
                                <td>";
                    // line 99
                    if ((twig_get_attribute($this->env, $this->getSourceContext(), $context["user"], "enabled", array()) == 1)) {
                        // line 100
                        echo "                                        <span class=\"label label-success\" style=\"font-size: 12px\">Enabled</span>
                                    ";
                    } else {
                        // line 102
                        echo "                                        <span class=\"label label-danger\" style=\"font-size: 12px\">Disabled</span>
                                    ";
                    }
                    // line 104
                    echo "                                </td>
                                <td>
                                    <span style=\"float: none\">
                                    ";
                    // line 107
                    echo                     $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["manageForm"]) || array_key_exists("manageForm", $context) ? $context["manageForm"] : (function () { throw new Twig_Error_Runtime('Variable "manageForm" does not exist.', 107, $this->getSourceContext()); })()), 'form_start', array("method" => "post", "attr" => array("class" => "form-inline")));
                    echo "
                                        ";
                    // line 108
                    echo twig_replace_filter((isset($context["form_token"]) || array_key_exists("form_token", $context) ? $context["form_token"] : (function () { throw new Twig_Error_Runtime('Variable "form_token" does not exist.', 108, $this->getSourceContext()); })()), array("#id#" => ("user_management__token_" . twig_get_attribute($this->env, $this->getSourceContext(), $context["user"], "id", array()))));
                    echo "
                                        ";
                    // line 109
                    if ((twig_get_attribute($this->env, $this->getSourceContext(), $context["user"], "enabled", array()) == 0)) {
                        // line 110
                        echo "                                            ";
                        // line 111
                        echo "                                            ";
                        // line 112
                        echo "                                            ";
                        // line 113
                        echo "                                            ";
                        $this->loadTemplate(":Components:popup.html.twig", ":Admin:user_list.html.twig", 113)->display(array_merge($context, array("color" => "success", "button" => "<i class='fa fa-check'></i>", "action" => $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_management_activate", array("id" => twig_get_attribute($this->env, $this->getSourceContext(),                         // line 116
$context["user"], "id", array()))), "id" => twig_get_attribute($this->env, $this->getSourceContext(),                         // line 117
$context["user"], "id", array()), "type" => "activateUser")));
                        // line 121
                        echo "                                        ";
                    } else {
                        // line 122
                        echo "                                            ";
                        $this->loadTemplate(":Components:popup.html.twig", ":Admin:user_list.html.twig", 122)->display(array_merge($context, array("color" => "danger", "button" => "<i class='fa fa-close'></i>", "action" => $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_management_deactivate", array("id" => twig_get_attribute($this->env, $this->getSourceContext(),                         // line 125
$context["user"], "id", array()))), "id" => twig_get_attribute($this->env, $this->getSourceContext(),                         // line 126
$context["user"], "id", array()), "type" => "deactivateUser")));
                        // line 130
                        echo "                                        ";
                    }
                    // line 131
                    echo "                                        ";
                    echo                     $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["manageForm"]) || array_key_exists("manageForm", $context) ? $context["manageForm"] : (function () { throw new Twig_Error_Runtime('Variable "manageForm" does not exist.', 131, $this->getSourceContext()); })()), 'form_end');
                    echo "
                                    </span>
                                </td>
                            </tr>
                    ";
                    ++$context['loop']['index0'];
                    ++$context['loop']['index'];
                    $context['loop']['first'] = false;
                    if (isset($context['loop']['length'])) {
                        --$context['loop']['revindex0'];
                        --$context['loop']['revindex'];
                        $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                    }
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['user'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 136
                echo "                        </tbody>
                        ";
            }
            // line 138
            echo "                        ";
        }
        // line 139
        echo "                    </table>
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_59c67848b40054bfe50f02b6da26ef80cf2d333fab38c5840eebf08dce607255->leave($__internal_59c67848b40054bfe50f02b6da26ef80cf2d333fab38c5840eebf08dce607255_prof);

        
        $__internal_100cab17d32af10933703f9d8c8ddb36b32aa762942a3ccac9f0cbaa6689d75f->leave($__internal_100cab17d32af10933703f9d8c8ddb36b32aa762942a3ccac9f0cbaa6689d75f_prof);

    }

    // line 12
    public function block_flashBag($context, array $blocks = array())
    {
        $__internal_dc3241cd827fb27078f7a43a1ed864d1d231897c622d2751e3352a8de823d5eb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_dc3241cd827fb27078f7a43a1ed864d1d231897c622d2751e3352a8de823d5eb->enter($__internal_dc3241cd827fb27078f7a43a1ed864d1d231897c622d2751e3352a8de823d5eb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "flashBag"));

        $__internal_4f8920fbdec695c9f42b5de59e54c612a93f6ec1326c90056cafb6926d750c71 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4f8920fbdec695c9f42b5de59e54c612a93f6ec1326c90056cafb6926d750c71->enter($__internal_4f8920fbdec695c9f42b5de59e54c612a93f6ec1326c90056cafb6926d750c71_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "flashBag"));

        // line 13
        echo "                ";
        $this->displayParentBlock("flashBag", $context, $blocks);
        echo "
            ";
        
        $__internal_4f8920fbdec695c9f42b5de59e54c612a93f6ec1326c90056cafb6926d750c71->leave($__internal_4f8920fbdec695c9f42b5de59e54c612a93f6ec1326c90056cafb6926d750c71_prof);

        
        $__internal_dc3241cd827fb27078f7a43a1ed864d1d231897c622d2751e3352a8de823d5eb->leave($__internal_dc3241cd827fb27078f7a43a1ed864d1d231897c622d2751e3352a8de823d5eb_prof);

    }

    // line 146
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_229b42d720145be7c2cdda61636d10ab1ccaaae56202ec0e2b225fc574731eaa = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_229b42d720145be7c2cdda61636d10ab1ccaaae56202ec0e2b225fc574731eaa->enter($__internal_229b42d720145be7c2cdda61636d10ab1ccaaae56202ec0e2b225fc574731eaa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_9ee15832d722c2d36be0610034ac0145b42107df533680ec10df4b7c4726db7c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9ee15832d722c2d36be0610034ac0145b42107df533680ec10df4b7c4726db7c->enter($__internal_9ee15832d722c2d36be0610034ac0145b42107df533680ec10df4b7c4726db7c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 147
        echo "     ";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "
     <script type=\"text/javascript\">
         \$(function () {
             \$('#user_filter_joinDate').datetimepicker();
             \$(joinDate)({
                 useCurrent: false});
         });
     </script>
 ";
        
        $__internal_9ee15832d722c2d36be0610034ac0145b42107df533680ec10df4b7c4726db7c->leave($__internal_9ee15832d722c2d36be0610034ac0145b42107df533680ec10df4b7c4726db7c_prof);

        
        $__internal_229b42d720145be7c2cdda61636d10ab1ccaaae56202ec0e2b225fc574731eaa->leave($__internal_229b42d720145be7c2cdda61636d10ab1ccaaae56202ec0e2b225fc574731eaa_prof);

    }

    public function getTemplateName()
    {
        return ":Admin:user_list.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  416 => 147,  407 => 146,  394 => 13,  385 => 12,  370 => 139,  367 => 138,  363 => 136,  343 => 131,  340 => 130,  338 => 126,  337 => 125,  335 => 122,  332 => 121,  330 => 117,  329 => 116,  327 => 113,  325 => 112,  323 => 111,  321 => 110,  319 => 109,  315 => 108,  311 => 107,  306 => 104,  302 => 102,  298 => 100,  296 => 99,  292 => 98,  288 => 97,  284 => 96,  280 => 95,  277 => 94,  260 => 93,  254 => 90,  245 => 84,  239 => 81,  233 => 78,  227 => 75,  221 => 72,  217 => 70,  209 => 65,  202 => 60,  200 => 59,  193 => 55,  189 => 54,  185 => 53,  181 => 52,  177 => 51,  173 => 50,  170 => 49,  167 => 48,  160 => 44,  156 => 42,  154 => 41,  150 => 40,  144 => 36,  138 => 33,  135 => 32,  133 => 31,  127 => 28,  121 => 25,  114 => 21,  106 => 15,  104 => 12,  100 => 10,  91 => 9,  73 => 8,  55 => 7,  45 => 1,  43 => 6,  37 => 3,  35 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '::base-layout.html.twig' %}
{% set form_token %}
    {{ form_row(manageForm._token, {'id': \"#id#\"}) }}
{% endset %}

{% form_theme filterForm ':Form:fields.html.twig' %}
{% block page_title %}{{ 'navigation.user_management.title'|trans }}{% endblock %}
{% block page_subtitle %}{{ 'navigation.user_management.subtitle'|trans }}{% endblock %}
{% block page_content %}
    <div class=\"row\">
        <div class=\"col-lg-8 col-md-8 col-lg-offset-2 col-md-offset-2\">
            {% block flashBag %}
                {{ parent() }}
            {% endblock %}
        </div>
    </div>
    <div class=\"row\">
        <div class=\"col-lg-12 col-md-12\">
            <div class=\"box box-info\">
                <div class=\"box-header with-border\">
                    <h3 class=\"box-title\">{{ 'user_management.table.title'|trans }}</h3>
                </div>
                <div class=\"box-body table-bordered\">
                    <span style=\"float:left\">
                        {{ form_start(filterForm, { 'method' : 'get' }) }}
                        <div class=\"row\" style=\"margin-left: 20px; margin-right: 20px;\">
                        <div class=\"col-lg-2\">
                            {{ form_row(filterForm.results) }}
                        </div>
                        <div class=\"col-lg-11\">
                            {% if pagination %}
                                <ul class=\"pagination pagination-sm no-margin pull-right\">
                                    {{ knp_pagination_render(pagination, '::adminlte_pagination.html.twig') }}
                                </ul>
                            {% endif %}
                        </div>
                    </div>
                    <table class=\"table table-bordered table-hover dataTable\" role=\"grid\" id=\"voucher_requests\">
                        <thead>
                        {{ form_start(filterForm, { 'method' : 'get'}) }}
                        {% if not filterForm.vars.valid %}
                            <tr role=\"row\" align=\"center\">
                            <td colspan=\"6\">
                                {{ form_errors(filterForm, { 'method' : 'get', 'attr': {'class' : 'form-inline'}}) }}
                            </td>
                        </tr>
                        {% endif %}
                        {% if pagination %}
                        <tr role=\"row\" align=\"center\" style=\"padding:0\">
                            <th width=\"10%\">{{ knp_pagination_sortable(pagination, 'user_management.table.id'|trans, 'u.id') }}</th>
                            <th width=\"10%\">{{ knp_pagination_sortable(pagination, 'user_management.table.name'|trans, 'u.username') }}</th>
                            <th width=\"30%\">{{ knp_pagination_sortable(pagination, 'user_management.table.join_date'|trans, 'u.joinDate') }}</th>
                            <th width=\"10%\">{{ knp_pagination_sortable(pagination, 'user_management.table.email'|trans, 'u.email') }}</th>
                            <th width=\"10%\">{{ knp_pagination_sortable(pagination, 'user_management.table.user_enabled'|trans, 'u.enabled') }}</th>
                            <th width=\"10%\">{{ 'user_management.table.actions'|trans }}</th>
                        </tr>
                        </thead>
                        <tbody>
                    {% if pagination is empty %}
                    <tr role=\"row\" align=\"center\">
                            <td colspan=\"7\">
                                <div class=\"alert alert-info alert-dismissible\">
                                <button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>
                                <h4><i class=\"icon fa fa-info\"></i> Alert!</h4>
                                    {{ 'generic.table.no_results'|trans }}
                                </div>
                            </td>
                        </tr>
                    {% else %}
                    <tr role=\"row\" align=\"center\" style=\"padding:0\">
                            <td>
                                {{ form_row(filterForm.id, {'attr': {'placeholder' : 'user_management.form.placeholder.id'}}) }}
                            </td>
                            <td>
                                {{ form_row(filterForm.username, {'attr': {'placeholder' : 'user_management.form.placeholder.username'}}) }}
                            </td>
                            <td>
                                {{ form_row(filterForm.joinDate, {'attr': {'placeholder' : 'user_management.form.placeholder.joinDate'}}) }}
                            </td>
                            <td>
                                {{ form_row(filterForm.email, {'attr': {'placeholder' : 'user_management.form.placeholder.email'}}) }}
                            </td>
                            <td>
                                {{ form_row(filterForm.enabled) }}
                            </td>
                            <td>
                                <button type=\"submit\" id=\"user_filter_submit\" name=\"submit\"
                                        class=\"btn btn-primary btn-flat\">
                                    <i class=\"glyphicon glyphicon-filter\"></i></button>
                                {{ form_end(filterForm) }}
                            </td>
                        </tr>
                    {% for user in pagination %}
                        <tr role=\"row\" align=\"center\" style=\"padding:0\">
                                <td>{{ user.id }}</td>
                                <td>{{ user.username }}</td>
                                <td>{{ user.joinDate|date(\"d/m/Y H:i:s\") }}</td>
                                <td>{{ user.email }}</td>
                                <td>{% if user.enabled == 1 %}
                                        <span class=\"label label-success\" style=\"font-size: 12px\">Enabled</span>
                                    {% else %}
                                        <span class=\"label label-danger\" style=\"font-size: 12px\">Disabled</span>
                                    {% endif %}
                                </td>
                                <td>
                                    <span style=\"float: none\">
                                    {{ form_start(manageForm, { 'method' : 'post', 'attr' : {'class' : 'form-inline'}}) }}
                                        {{ form_token|replace({'#id#': 'user_management__token_'~user.id})|raw }}
                                        {% if user.enabled == 0 %}
                                            {#<button type=\"submit\" class=\"btn btn-success btn-flat form-control\"#}
                                            {#formaction=\"{{ path('user_management_activate', {'id': user.id }) }}\">#}
                                            {#<i class=\"fa fa-check\"></i></button>#}
                                            {% include ':Components:popup.html.twig' with{
                                            'color' : 'success',
                                            'button' : \"<i class='fa fa-check'></i>\",
                                            'action' : path('user_management_activate', {'id': user.id }),
                                            'id' : user.id,
                                            'type' : 'activateUser'
                                            }
                                            %}
                                        {% else %}
                                            {% include ':Components:popup.html.twig' with{
                                            'color' : 'danger',
                                            'button' : \"<i class='fa fa-close'></i>\",
                                            'action' : path('user_management_deactivate', {'id': user.id }),
                                            'id' : user.id,
                                            'type' : 'deactivateUser'
                                            }
                                            %}
                                        {% endif %}
                                        {{ form_end(manageForm) }}
                                    </span>
                                </td>
                            </tr>
                    {% endfor %}
                        </tbody>
                        {% endif %}
                        {% endif %}
                    </table>
                </div>
            </div>
        </div>
    </div>
{% endblock %}

 {% block javascripts %}
     {{ parent() }}
     <script type=\"text/javascript\">
         \$(function () {
             \$('#user_filter_joinDate').datetimepicker();
             \$(joinDate)({
                 useCurrent: false});
         });
     </script>
 {% endblock %}", ":Admin:user_list.html.twig", "/home/sorina/Documents/work/movies_crowler/app/Resources/views/Admin/user_list.html.twig");
    }
}
