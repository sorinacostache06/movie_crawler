<?php

/* TwigBundle:Exception:error.rdf.twig */
class __TwigTemplate_782164d0d424a216024f85bd9f975f1f8b64ce652214ef37705f27996ebafca6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d8fc2e6dca3297b6bf2a7615d9e2a97bdd4f257ee9f8615e3cb1a260c666660f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d8fc2e6dca3297b6bf2a7615d9e2a97bdd4f257ee9f8615e3cb1a260c666660f->enter($__internal_d8fc2e6dca3297b6bf2a7615d9e2a97bdd4f257ee9f8615e3cb1a260c666660f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        $__internal_dee9c65caa5b94edc3b3c4fb0257c8bcf5e32757c53bb8959af52e77f04c7a26 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dee9c65caa5b94edc3b3c4fb0257c8bcf5e32757c53bb8959af52e77f04c7a26->enter($__internal_dee9c65caa5b94edc3b3c4fb0257c8bcf5e32757c53bb8959af52e77f04c7a26_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "TwigBundle:Exception:error.rdf.twig", 1)->display($context);
        
        $__internal_d8fc2e6dca3297b6bf2a7615d9e2a97bdd4f257ee9f8615e3cb1a260c666660f->leave($__internal_d8fc2e6dca3297b6bf2a7615d9e2a97bdd4f257ee9f8615e3cb1a260c666660f_prof);

        
        $__internal_dee9c65caa5b94edc3b3c4fb0257c8bcf5e32757c53bb8959af52e77f04c7a26->leave($__internal_dee9c65caa5b94edc3b3c4fb0257c8bcf5e32757c53bb8959af52e77f04c7a26_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.rdf.twig";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include '@Twig/Exception/error.xml.twig' %}
", "TwigBundle:Exception:error.rdf.twig", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/error.rdf.twig");
    }
}
