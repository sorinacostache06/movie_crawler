<?php

/* @Framework/Form/form_enctype.html.php */
class __TwigTemplate_d7a709c3dbd30f8f4e2efc9a0b002cca616d2c819fef32c9926a7a22368973d3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8432f608f8b03fc07bacb65df2feb60b78a730717f1312d8c55c8fd821b064b4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8432f608f8b03fc07bacb65df2feb60b78a730717f1312d8c55c8fd821b064b4->enter($__internal_8432f608f8b03fc07bacb65df2feb60b78a730717f1312d8c55c8fd821b064b4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        $__internal_b1220bece635a3a3bedef39bca1f276a96162a50bd6ad91a5ce4b28c68b19bb0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b1220bece635a3a3bedef39bca1f276a96162a50bd6ad91a5ce4b28c68b19bb0->enter($__internal_b1220bece635a3a3bedef39bca1f276a96162a50bd6ad91a5ce4b28c68b19bb0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        // line 1
        echo "<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
";
        
        $__internal_8432f608f8b03fc07bacb65df2feb60b78a730717f1312d8c55c8fd821b064b4->leave($__internal_8432f608f8b03fc07bacb65df2feb60b78a730717f1312d8c55c8fd821b064b4_prof);

        
        $__internal_b1220bece635a3a3bedef39bca1f276a96162a50bd6ad91a5ce4b28c68b19bb0->leave($__internal_b1220bece635a3a3bedef39bca1f276a96162a50bd6ad91a5ce4b28c68b19bb0_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_enctype.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
", "@Framework/Form/form_enctype.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_enctype.html.php");
    }
}
