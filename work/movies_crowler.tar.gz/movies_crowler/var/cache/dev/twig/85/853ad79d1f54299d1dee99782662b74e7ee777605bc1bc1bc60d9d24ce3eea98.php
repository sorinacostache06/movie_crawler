<?php

/* ::language_picker.html.twig */
class __TwigTemplate_c11c6d14913163d7cb88113d92df1626d789e7e0d57fe598279650b77632404e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_623ac244cfdd94241e2ca3ddbc1f439f2b4ba2db1cda905ac63eac23ddaea670 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_623ac244cfdd94241e2ca3ddbc1f439f2b4ba2db1cda905ac63eac23ddaea670->enter($__internal_623ac244cfdd94241e2ca3ddbc1f439f2b4ba2db1cda905ac63eac23ddaea670_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::language_picker.html.twig"));

        $__internal_e763e493c7cd54146bbcb332bdc5c8c3bca7f603515e3a74e2883ffcc20844b7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e763e493c7cd54146bbcb332bdc5c8c3bca7f603515e3a74e2883ffcc20844b7->enter($__internal_e763e493c7cd54146bbcb332bdc5c8c3bca7f603515e3a74e2883ffcc20844b7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::language_picker.html.twig"));

        // line 1
        echo "<div class=\"row\">
    <div class=\"col-xs-6 col-xs-offset-4\">
        ";
        // line 3
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["language_list"]) || array_key_exists("language_list", $context) ? $context["language_list"] : (function () { throw new Twig_Error_Runtime('Variable "language_list" does not exist.', 3, $this->getSourceContext()); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["language"]) {
            // line 4
            echo "            <a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("switch_locale", array("locale" => $context["language"])), "html", null, true);
            echo "\" class=\"btn btn-primary btn-flat\">";
            echo twig_escape_filter($this->env, $context["language"], "html", null, true);
            echo "</a>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['language'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 6
        echo "    </div>
</div>
<br>";
        
        $__internal_623ac244cfdd94241e2ca3ddbc1f439f2b4ba2db1cda905ac63eac23ddaea670->leave($__internal_623ac244cfdd94241e2ca3ddbc1f439f2b4ba2db1cda905ac63eac23ddaea670_prof);

        
        $__internal_e763e493c7cd54146bbcb332bdc5c8c3bca7f603515e3a74e2883ffcc20844b7->leave($__internal_e763e493c7cd54146bbcb332bdc5c8c3bca7f603515e3a74e2883ffcc20844b7_prof);

    }

    public function getTemplateName()
    {
        return "::language_picker.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  44 => 6,  33 => 4,  29 => 3,  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"row\">
    <div class=\"col-xs-6 col-xs-offset-4\">
        {% for language in language_list %}
            <a href=\"{{ path('switch_locale', {'locale': language }) }}\" class=\"btn btn-primary btn-flat\">{{ language }}</a>
        {% endfor %}
    </div>
</div>
<br>", "::language_picker.html.twig", "/home/sorina/Documents/work/movies_crowler/app/Resources/views/language_picker.html.twig");
    }
}
