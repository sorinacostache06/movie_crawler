<?php

/* AvanzuAdminThemeBundle:Default:form.html.twig */
class __TwigTemplate_53d79175febc9a7b36b02d883505d1e8c8dbe8180acef79a80e8444107445550 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("AvanzuAdminThemeBundle:layout:base-layout.html.twig", "AvanzuAdminThemeBundle:Default:form.html.twig", 1);
        $this->blocks = array(
            'page_content' => array($this, 'block_page_content'),
            'page_title' => array($this, 'block_page_title'),
            'page_subtitle' => array($this, 'block_page_subtitle'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "AvanzuAdminThemeBundle:layout:base-layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bb7bb39c6b37bab3ee3e74b542048819170321ad64f145e00509532a31e49704 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bb7bb39c6b37bab3ee3e74b542048819170321ad64f145e00509532a31e49704->enter($__internal_bb7bb39c6b37bab3ee3e74b542048819170321ad64f145e00509532a31e49704_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AvanzuAdminThemeBundle:Default:form.html.twig"));

        $__internal_269bef400ce0057e86c53c7887886c1118cb859acd9985cbed4997e9b2833d9d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_269bef400ce0057e86c53c7887886c1118cb859acd9985cbed4997e9b2833d9d->enter($__internal_269bef400ce0057e86c53c7887886c1118cb859acd9985cbed4997e9b2833d9d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AvanzuAdminThemeBundle:Default:form.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_bb7bb39c6b37bab3ee3e74b542048819170321ad64f145e00509532a31e49704->leave($__internal_bb7bb39c6b37bab3ee3e74b542048819170321ad64f145e00509532a31e49704_prof);

        
        $__internal_269bef400ce0057e86c53c7887886c1118cb859acd9985cbed4997e9b2833d9d->leave($__internal_269bef400ce0057e86c53c7887886c1118cb859acd9985cbed4997e9b2833d9d_prof);

    }

    // line 3
    public function block_page_content($context, array $blocks = array())
    {
        $__internal_ead499e9660facf44e90b0f4271cf1d918e5995a28b18fec5a40eceb5adfadbc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ead499e9660facf44e90b0f4271cf1d918e5995a28b18fec5a40eceb5adfadbc->enter($__internal_ead499e9660facf44e90b0f4271cf1d918e5995a28b18fec5a40eceb5adfadbc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_content"));

        $__internal_7edfb4636c8c9d04f7b87a4452b90d8767706fc98748e8a9cd319cf7d04d46f1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7edfb4636c8c9d04f7b87a4452b90d8767706fc98748e8a9cd319cf7d04d46f1->enter($__internal_7edfb4636c8c9d04f7b87a4452b90d8767706fc98748e8a9cd319cf7d04d46f1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_content"));

        // line 4
        echo "
    <div class=\"row\">
        <div class=\"col-md-4\">


        </div>
        <div class=\"col-md-4\">

        </div>
        <div class=\"col-md-4\">

        </div>
    </div>

    <div class=\"row\">
        <div class=\"col-md-6\">

            <div class=\"box box-primary\">
                <div class=\"box-header\">
                    <h3 class=\"box-title\">Form Theme</h3>
                </div>
                <div class=\"box-body\">
                    ";
        // line 26
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 26, $this->getSourceContext()); })()), 'form');
        echo "
                </div>
                <div class=\"box-footer clearfix\">

                        <button type=\"reset\" class=\"btn btn-warning pull-left\"><i class=\"fa fa-times\"></i> Cancel</button>
                        <button type=\"submit\" class=\"btn btn-primary pull-right\"><i class=\"fa fa-check-square\"></i> Submit</button>


                </div>
            </div>

        </div>
        <div class=\"col-md-6\">
            <div class=\"box box-solid box-primary\">
                ";
        // line 40
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["macro"]) || array_key_exists("macro", $context) ? $context["macro"] : (function () { throw new Twig_Error_Runtime('Variable "macro" does not exist.', 40, $this->getSourceContext()); })()), "box_header", array(0 => "built from macro", 1 => true, 2 => false, 3 => "primary"), "method"), "html", null, true);
        echo "
                <div class=\"box-body\">
                    some content...
                </div>
            </div>
        </div>
    </div>


";
        
        $__internal_7edfb4636c8c9d04f7b87a4452b90d8767706fc98748e8a9cd319cf7d04d46f1->leave($__internal_7edfb4636c8c9d04f7b87a4452b90d8767706fc98748e8a9cd319cf7d04d46f1_prof);

        
        $__internal_ead499e9660facf44e90b0f4271cf1d918e5995a28b18fec5a40eceb5adfadbc->leave($__internal_ead499e9660facf44e90b0f4271cf1d918e5995a28b18fec5a40eceb5adfadbc_prof);

    }

    // line 51
    public function block_page_title($context, array $blocks = array())
    {
        $__internal_9848842e70c34b5e2b91f0a18513dd37bce0bc9862515a3b3705678bdc8dfd13 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9848842e70c34b5e2b91f0a18513dd37bce0bc9862515a3b3705678bdc8dfd13->enter($__internal_9848842e70c34b5e2b91f0a18513dd37bce0bc9862515a3b3705678bdc8dfd13_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_title"));

        $__internal_79ee8acbd77acf8b0012f62b67e4a6e32dc3a55aabf1cafc744e26991fde5992 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_79ee8acbd77acf8b0012f62b67e4a6e32dc3a55aabf1cafc744e26991fde5992->enter($__internal_79ee8acbd77acf8b0012f62b67e4a6e32dc3a55aabf1cafc744e26991fde5992_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_title"));

        echo " Forms ";
        
        $__internal_79ee8acbd77acf8b0012f62b67e4a6e32dc3a55aabf1cafc744e26991fde5992->leave($__internal_79ee8acbd77acf8b0012f62b67e4a6e32dc3a55aabf1cafc744e26991fde5992_prof);

        
        $__internal_9848842e70c34b5e2b91f0a18513dd37bce0bc9862515a3b3705678bdc8dfd13->leave($__internal_9848842e70c34b5e2b91f0a18513dd37bce0bc9862515a3b3705678bdc8dfd13_prof);

    }

    // line 52
    public function block_page_subtitle($context, array $blocks = array())
    {
        $__internal_efbc1fa1d16280c95ab706223b5e1e5e9e624cb6602cd7b42167087503bfc832 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_efbc1fa1d16280c95ab706223b5e1e5e9e624cb6602cd7b42167087503bfc832->enter($__internal_efbc1fa1d16280c95ab706223b5e1e5e9e624cb6602cd7b42167087503bfc832_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_subtitle"));

        $__internal_7d3fb6aa6231bee8597b2118d14c876324bc83128ee852cdd699b1bf4dcc5cef = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7d3fb6aa6231bee8597b2118d14c876324bc83128ee852cdd699b1bf4dcc5cef->enter($__internal_7d3fb6aa6231bee8597b2118d14c876324bc83128ee852cdd699b1bf4dcc5cef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_subtitle"));

        echo " demonstration ";
        
        $__internal_7d3fb6aa6231bee8597b2118d14c876324bc83128ee852cdd699b1bf4dcc5cef->leave($__internal_7d3fb6aa6231bee8597b2118d14c876324bc83128ee852cdd699b1bf4dcc5cef_prof);

        
        $__internal_efbc1fa1d16280c95ab706223b5e1e5e9e624cb6602cd7b42167087503bfc832->leave($__internal_efbc1fa1d16280c95ab706223b5e1e5e9e624cb6602cd7b42167087503bfc832_prof);

    }

    public function getTemplateName()
    {
        return "AvanzuAdminThemeBundle:Default:form.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  130 => 52,  112 => 51,  92 => 40,  75 => 26,  51 => 4,  42 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'AvanzuAdminThemeBundle:layout:base-layout.html.twig' %}

{% block page_content %}

    <div class=\"row\">
        <div class=\"col-md-4\">


        </div>
        <div class=\"col-md-4\">

        </div>
        <div class=\"col-md-4\">

        </div>
    </div>

    <div class=\"row\">
        <div class=\"col-md-6\">

            <div class=\"box box-primary\">
                <div class=\"box-header\">
                    <h3 class=\"box-title\">Form Theme</h3>
                </div>
                <div class=\"box-body\">
                    {{ form(form) }}
                </div>
                <div class=\"box-footer clearfix\">

                        <button type=\"reset\" class=\"btn btn-warning pull-left\"><i class=\"fa fa-times\"></i> Cancel</button>
                        <button type=\"submit\" class=\"btn btn-primary pull-right\"><i class=\"fa fa-check-square\"></i> Submit</button>


                </div>
            </div>

        </div>
        <div class=\"col-md-6\">
            <div class=\"box box-solid box-primary\">
                {{ macro.box_header('built from macro', true, false, 'primary') }}
                <div class=\"box-body\">
                    some content...
                </div>
            </div>
        </div>
    </div>


{% endblock %}

{% block page_title %} Forms {% endblock %}
{% block page_subtitle %} demonstration {% endblock %}", "AvanzuAdminThemeBundle:Default:form.html.twig", "/home/sorina/Documents/work/movies_crowler/vendor/avanzu/admin-theme-bundle/Resources/views/Default/form.html.twig");
    }
}
