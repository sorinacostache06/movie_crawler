<?php

/* @Framework/Form/button_row.html.php */
class __TwigTemplate_9648cc2838c8482458cf5814bf6b60d20500d40cb153c9b8550a419822b40a53 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d29193cb72529f5d915bc956d54b3e28955d91990d3a1898de05c26e8e29650a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d29193cb72529f5d915bc956d54b3e28955d91990d3a1898de05c26e8e29650a->enter($__internal_d29193cb72529f5d915bc956d54b3e28955d91990d3a1898de05c26e8e29650a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        $__internal_8f42f18788977c956767cc6608b5fd24f39fe4c9acbdc0e6cf695ff4c43aef16 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8f42f18788977c956767cc6608b5fd24f39fe4c9acbdc0e6cf695ff4c43aef16->enter($__internal_8f42f18788977c956767cc6608b5fd24f39fe4c9acbdc0e6cf695ff4c43aef16_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_d29193cb72529f5d915bc956d54b3e28955d91990d3a1898de05c26e8e29650a->leave($__internal_d29193cb72529f5d915bc956d54b3e28955d91990d3a1898de05c26e8e29650a_prof);

        
        $__internal_8f42f18788977c956767cc6608b5fd24f39fe4c9acbdc0e6cf695ff4c43aef16->leave($__internal_8f42f18788977c956767cc6608b5fd24f39fe4c9acbdc0e6cf695ff4c43aef16_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
", "@Framework/Form/button_row.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/button_row.html.php");
    }
}
