<?php

/* AvanzuAdminThemeBundle:Sidebar:search-form.html.twig */
class __TwigTemplate_661d9f746a830fe357c7ec87b1a240cd1467ce3f4f73ccf370b61b0360e2d5b9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d0ad4c1c592fd725c063ef58f45932d4ba96ebd93d13ae46339c851bace50c4a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d0ad4c1c592fd725c063ef58f45932d4ba96ebd93d13ae46339c851bace50c4a->enter($__internal_d0ad4c1c592fd725c063ef58f45932d4ba96ebd93d13ae46339c851bace50c4a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AvanzuAdminThemeBundle:Sidebar:search-form.html.twig"));

        $__internal_eda14164b980fd0614c65d54a3745d338635b9e62878980691d06989db3f0e7c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_eda14164b980fd0614c65d54a3745d338635b9e62878980691d06989db3f0e7c->enter($__internal_eda14164b980fd0614c65d54a3745d338635b9e62878980691d06989db3f0e7c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AvanzuAdminThemeBundle:Sidebar:search-form.html.twig"));

        // line 1
        echo "<!-- search form -->
<form action=\"#\" method=\"get\" class=\"sidebar-form\">
    <div class=\"input-group\">
        <input type=\"text\" name=\"q\" class=\"form-control\" placeholder=\"Search...\"/>
        <span class=\"input-group-btn\">
            <button type='submit' name='search' id='search-btn' class=\"btn btn-flat\"><i class=\"fa fa-search\"></i></button>
        </span>
    </div>
</form>
<!-- /.search form -->";
        
        $__internal_d0ad4c1c592fd725c063ef58f45932d4ba96ebd93d13ae46339c851bace50c4a->leave($__internal_d0ad4c1c592fd725c063ef58f45932d4ba96ebd93d13ae46339c851bace50c4a_prof);

        
        $__internal_eda14164b980fd0614c65d54a3745d338635b9e62878980691d06989db3f0e7c->leave($__internal_eda14164b980fd0614c65d54a3745d338635b9e62878980691d06989db3f0e7c_prof);

    }

    public function getTemplateName()
    {
        return "AvanzuAdminThemeBundle:Sidebar:search-form.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!-- search form -->
<form action=\"#\" method=\"get\" class=\"sidebar-form\">
    <div class=\"input-group\">
        <input type=\"text\" name=\"q\" class=\"form-control\" placeholder=\"Search...\"/>
        <span class=\"input-group-btn\">
            <button type='submit' name='search' id='search-btn' class=\"btn btn-flat\"><i class=\"fa fa-search\"></i></button>
        </span>
    </div>
</form>
<!-- /.search form -->", "AvanzuAdminThemeBundle:Sidebar:search-form.html.twig", "/home/sorina/Documents/work/movies_crowler/vendor/avanzu/admin-theme-bundle/Resources/views/Sidebar/search-form.html.twig");
    }
}
