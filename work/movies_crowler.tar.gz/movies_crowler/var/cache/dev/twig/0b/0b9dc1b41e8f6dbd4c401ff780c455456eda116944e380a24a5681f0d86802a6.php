<?php

/* @Framework/FormTable/hidden_row.html.php */
class __TwigTemplate_c851dbed3a335a621f4081d2a74899f487371adf2dbb11ae90aa06fa800eb21f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9d5d92eb66567e24e35c2f7ef778c5b551f2573935138cb19a1c7cff98617e66 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9d5d92eb66567e24e35c2f7ef778c5b551f2573935138cb19a1c7cff98617e66->enter($__internal_9d5d92eb66567e24e35c2f7ef778c5b551f2573935138cb19a1c7cff98617e66_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/hidden_row.html.php"));

        $__internal_a0eca83da1f9fc38f25472c806915111c3264b840fedf43eaa53e272518a5479 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a0eca83da1f9fc38f25472c806915111c3264b840fedf43eaa53e272518a5479->enter($__internal_a0eca83da1f9fc38f25472c806915111c3264b840fedf43eaa53e272518a5479_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/hidden_row.html.php"));

        // line 1
        echo "<tr style=\"display: none\">
    <td colspan=\"2\">
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_9d5d92eb66567e24e35c2f7ef778c5b551f2573935138cb19a1c7cff98617e66->leave($__internal_9d5d92eb66567e24e35c2f7ef778c5b551f2573935138cb19a1c7cff98617e66_prof);

        
        $__internal_a0eca83da1f9fc38f25472c806915111c3264b840fedf43eaa53e272518a5479->leave($__internal_a0eca83da1f9fc38f25472c806915111c3264b840fedf43eaa53e272518a5479_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr style=\"display: none\">
    <td colspan=\"2\">
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
", "@Framework/FormTable/hidden_row.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/FormTable/hidden_row.html.php");
    }
}
