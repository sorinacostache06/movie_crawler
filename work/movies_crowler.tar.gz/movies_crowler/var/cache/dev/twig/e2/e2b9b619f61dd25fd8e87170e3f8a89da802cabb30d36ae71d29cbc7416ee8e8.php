<?php

/* @Framework/Form/container_attributes.html.php */
class __TwigTemplate_e0874cebc4b81ce5ef6b9e851575327ae38be7a644e1abd4799ed578e129a165 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_dfe302b2efd9085897256de4cb4445fb143aa5146f4e684d58ed93087b599570 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_dfe302b2efd9085897256de4cb4445fb143aa5146f4e684d58ed93087b599570->enter($__internal_dfe302b2efd9085897256de4cb4445fb143aa5146f4e684d58ed93087b599570_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/container_attributes.html.php"));

        $__internal_3e159e728ddd90e3ca2a83019f8c61a02986796d2336f68c6004a47833f187f7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3e159e728ddd90e3ca2a83019f8c61a02986796d2336f68c6004a47833f187f7->enter($__internal_3e159e728ddd90e3ca2a83019f8c61a02986796d2336f68c6004a47833f187f7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/container_attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>
";
        
        $__internal_dfe302b2efd9085897256de4cb4445fb143aa5146f4e684d58ed93087b599570->leave($__internal_dfe302b2efd9085897256de4cb4445fb143aa5146f4e684d58ed93087b599570_prof);

        
        $__internal_3e159e728ddd90e3ca2a83019f8c61a02986796d2336f68c6004a47833f187f7->leave($__internal_3e159e728ddd90e3ca2a83019f8c61a02986796d2336f68c6004a47833f187f7_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/container_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>
", "@Framework/Form/container_attributes.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/container_attributes.html.php");
    }
}
