<?php

/* WebProfilerBundle:Profiler:toolbar_redirect.html.twig */
class __TwigTemplate_09d0f02fc37d26aea3056ecd1eeb1d2575b417bf42dbf5159f3c6cc9392f0c6d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_decff835ad52ce33c5a0e58733c235a452a79d0d0eff9ea2d658d6688e5946af = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_decff835ad52ce33c5a0e58733c235a452a79d0d0eff9ea2d658d6688e5946af->enter($__internal_decff835ad52ce33c5a0e58733c235a452a79d0d0eff9ea2d658d6688e5946af_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig"));

        $__internal_c5694d5b731e32132b99597dbb35663fb608675c86a4631888343f7eed13d7be = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c5694d5b731e32132b99597dbb35663fb608675c86a4631888343f7eed13d7be->enter($__internal_c5694d5b731e32132b99597dbb35663fb608675c86a4631888343f7eed13d7be_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_decff835ad52ce33c5a0e58733c235a452a79d0d0eff9ea2d658d6688e5946af->leave($__internal_decff835ad52ce33c5a0e58733c235a452a79d0d0eff9ea2d658d6688e5946af_prof);

        
        $__internal_c5694d5b731e32132b99597dbb35663fb608675c86a4631888343f7eed13d7be->leave($__internal_c5694d5b731e32132b99597dbb35663fb608675c86a4631888343f7eed13d7be_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_2b5f923e7ef850c4260573b22fa84679c309d988386cb21bd748d01ff56c1b82 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2b5f923e7ef850c4260573b22fa84679c309d988386cb21bd748d01ff56c1b82->enter($__internal_2b5f923e7ef850c4260573b22fa84679c309d988386cb21bd748d01ff56c1b82_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_be824f53594ca41959c053bcf324da000d59de0cd00a9f0952c8608e491635d8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_be824f53594ca41959c053bcf324da000d59de0cd00a9f0952c8608e491635d8->enter($__internal_be824f53594ca41959c053bcf324da000d59de0cd00a9f0952c8608e491635d8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Redirection Intercepted";
        
        $__internal_be824f53594ca41959c053bcf324da000d59de0cd00a9f0952c8608e491635d8->leave($__internal_be824f53594ca41959c053bcf324da000d59de0cd00a9f0952c8608e491635d8_prof);

        
        $__internal_2b5f923e7ef850c4260573b22fa84679c309d988386cb21bd748d01ff56c1b82->leave($__internal_2b5f923e7ef850c4260573b22fa84679c309d988386cb21bd748d01ff56c1b82_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_1aeca486edff68b89874859cfe11dfd7e8f17a8dcdb6632b872cc720558dcdbc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1aeca486edff68b89874859cfe11dfd7e8f17a8dcdb6632b872cc720558dcdbc->enter($__internal_1aeca486edff68b89874859cfe11dfd7e8f17a8dcdb6632b872cc720558dcdbc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_7484ed67eeeda534eb0b6b32abd76b5a1a13fb44a2132d6e01c5c1c8e489fc03 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7484ed67eeeda534eb0b6b32abd76b5a1a13fb44a2132d6e01c5c1c8e489fc03->enter($__internal_7484ed67eeeda534eb0b6b32abd76b5a1a13fb44a2132d6e01c5c1c8e489fc03_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"";
        // line 8
        echo twig_escape_filter($this->env, (isset($context["location"]) || array_key_exists("location", $context) ? $context["location"] : (function () { throw new Twig_Error_Runtime('Variable "location" does not exist.', 8, $this->getSourceContext()); })()), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, (isset($context["location"]) || array_key_exists("location", $context) ? $context["location"] : (function () { throw new Twig_Error_Runtime('Variable "location" does not exist.', 8, $this->getSourceContext()); })()), "html", null, true);
        echo "</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
";
        
        $__internal_7484ed67eeeda534eb0b6b32abd76b5a1a13fb44a2132d6e01c5c1c8e489fc03->leave($__internal_7484ed67eeeda534eb0b6b32abd76b5a1a13fb44a2132d6e01c5c1c8e489fc03_prof);

        
        $__internal_1aeca486edff68b89874859cfe11dfd7e8f17a8dcdb6632b872cc720558dcdbc->leave($__internal_1aeca486edff68b89874859cfe11dfd7e8f17a8dcdb6632b872cc720558dcdbc_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:toolbar_redirect.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  72 => 8,  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block title 'Redirection Intercepted' %}

{% block body %}
    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"{{ location }}\">{{ location }}</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
{% endblock %}
", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Profiler/toolbar_redirect.html.twig");
    }
}
