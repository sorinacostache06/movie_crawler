<?php

/* AvanzuAdminThemeBundle:layout:base-layout.html.twig */
class __TwigTemplate_4e0e98ab1d136db0f796a6efcbdcd4e8ca9511b45b27f3b2c117d1c9e235ab92 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts_head' => array($this, 'block_javascripts_head'),
            'avanzu_admin_header' => array($this, 'block_avanzu_admin_header'),
            'avanzu_logo' => array($this, 'block_avanzu_logo'),
            'avanzu_navbar' => array($this, 'block_avanzu_navbar'),
            'avanzu_sidebar' => array($this, 'block_avanzu_sidebar'),
            'page_title' => array($this, 'block_page_title'),
            'page_subtitle' => array($this, 'block_page_subtitle'),
            'avanzu_breadcrumb' => array($this, 'block_avanzu_breadcrumb'),
            'page_content' => array($this, 'block_page_content'),
            'avanzu_admin_footer' => array($this, 'block_avanzu_admin_footer'),
            'javascripts' => array($this, 'block_javascripts'),
            'javascripts_inline' => array($this, 'block_javascripts_inline'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ea1442edac5173ad829fac78f0f2948e9dbc4c73f89812a60d3dfc047be0be95 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ea1442edac5173ad829fac78f0f2948e9dbc4c73f89812a60d3dfc047be0be95->enter($__internal_ea1442edac5173ad829fac78f0f2948e9dbc4c73f89812a60d3dfc047be0be95_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AvanzuAdminThemeBundle:layout:base-layout.html.twig"));

        $__internal_104d2ef75d6db334c498ec49b58a1f5cc4cb0ea4214f78bf5b83dcce9f430d24 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_104d2ef75d6db334c498ec49b58a1f5cc4cb0ea4214f78bf5b83dcce9f430d24->enter($__internal_104d2ef75d6db334c498ec49b58a1f5cc4cb0ea4214f78bf5b83dcce9f430d24_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AvanzuAdminThemeBundle:layout:base-layout.html.twig"));

        // line 1
        $context["macro"] = $this->loadTemplate("AvanzuAdminThemeBundle:layout:macros.html.twig", "AvanzuAdminThemeBundle:layout:base-layout.html.twig", 1);
        // line 2
        echo "<!doctype html>
<!--[if lt IE 7 ]><html lang=\"en\" class=\"no-js ie6\"> <![endif]-->
<!--[if IE 7 ]><html lang=\"en\" class=\"no-js ie7\"> <![endif]-->
<!--[if IE 8 ]><html lang=\"en\" class=\"no-js ie8\"> <![endif]-->
<!--[if IE 9 ]><html lang=\"en\" class=\"no-js ie9\"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--><html lang=\"en\" class=\"no-js\"> <!--<![endif]-->
<head>
    <meta charset=\"utf-8\">
    <meta name=\"author\" content=\"\">
    <meta name=\"keywords\" content=\"\">
    <meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">
    <title>";
        // line 13
        $this->displayBlock('title', $context, $blocks);
        echo "</title>

    ";
        // line 16
        echo "    ";
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 19
        echo "

    <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />

    ";
        // line 24
        echo "    ";
        $this->displayBlock('javascripts_head', $context, $blocks);
        // line 31
        echo "
</head>
<body class=\"";
        // line 33
        echo twig_escape_filter($this->env, ((array_key_exists("admin_skin", $context)) ? (_twig_default_filter((isset($context["admin_skin"]) || array_key_exists("admin_skin", $context) ? $context["admin_skin"] : (function () { throw new Twig_Error_Runtime('Variable "admin_skin" does not exist.', 33, $this->getSourceContext()); })()), "skin-blue")) : ("skin-blue")), "html", null, true);
        echo "\">
    <div class=\"wrapper\">

    ";
        // line 36
        $this->displayBlock('avanzu_admin_header', $context, $blocks);
        // line 65
        echo "
        <!-- Left side column. contains the logo and sidebar -->
        <aside class=\"main-sidebar sidebar-offcanvas\">
            <!-- sidebar: style can be found in sidebar.less -->
            <section class=\"sidebar\">
                ";
        // line 70
        $this->displayBlock('avanzu_sidebar', $context, $blocks);
        // line 77
        echo "            </section>
            <!-- /.sidebar -->
        </aside>

        <!-- Right side column. Contains the navbar and content of the page -->
        <div class=\"content-wrapper\">
            <!-- Content Header (Page header) -->
            <section class=\"content-header\">
                <h1>
                    ";
        // line 86
        $this->displayBlock('page_title', $context, $blocks);
        // line 87
        echo "                    <small>";
        $this->displayBlock('page_subtitle', $context, $blocks);
        echo "</small>
                </h1>
                ";
        // line 89
        $this->displayBlock('avanzu_breadcrumb', $context, $blocks);
        // line 92
        echo "            </section>

            <!-- Main content -->
            <section class=\"content\">
                ";
        // line 96
        $this->displayBlock('page_content', $context, $blocks);
        // line 97
        echo "            </section>
            <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->

    ";
        // line 102
        $this->displayBlock('avanzu_admin_footer', $context, $blocks);
        // line 110
        echo "
    </div>
<!-- ./wrapper -->

";
        // line 115
        $this->displayBlock('javascripts', $context, $blocks);
        // line 120
        echo "
";
        // line 122
        $this->displayBlock('javascripts_inline', $context, $blocks);
        // line 124
        echo "</body>
</html>
";
        
        $__internal_ea1442edac5173ad829fac78f0f2948e9dbc4c73f89812a60d3dfc047be0be95->leave($__internal_ea1442edac5173ad829fac78f0f2948e9dbc4c73f89812a60d3dfc047be0be95_prof);

        
        $__internal_104d2ef75d6db334c498ec49b58a1f5cc4cb0ea4214f78bf5b83dcce9f430d24->leave($__internal_104d2ef75d6db334c498ec49b58a1f5cc4cb0ea4214f78bf5b83dcce9f430d24_prof);

    }

    // line 13
    public function block_title($context, array $blocks = array())
    {
        $__internal_87f9ee397004005fedf97db2bdf482a865eb4f14d209f1d19b17f0e558ef0ef2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_87f9ee397004005fedf97db2bdf482a865eb4f14d209f1d19b17f0e558ef0ef2->enter($__internal_87f9ee397004005fedf97db2bdf482a865eb4f14d209f1d19b17f0e558ef0ef2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_9a97a0b090556ad73995359fda730c4eb89b668c38416795335c9cd17acdbfce = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9a97a0b090556ad73995359fda730c4eb89b668c38416795335c9cd17acdbfce->enter($__internal_9a97a0b090556ad73995359fda730c4eb89b668c38416795335c9cd17acdbfce_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Avanzu Admin!";
        
        $__internal_9a97a0b090556ad73995359fda730c4eb89b668c38416795335c9cd17acdbfce->leave($__internal_9a97a0b090556ad73995359fda730c4eb89b668c38416795335c9cd17acdbfce_prof);

        
        $__internal_87f9ee397004005fedf97db2bdf482a865eb4f14d209f1d19b17f0e558ef0ef2->leave($__internal_87f9ee397004005fedf97db2bdf482a865eb4f14d209f1d19b17f0e558ef0ef2_prof);

    }

    // line 16
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_5d9d076667735580054a410011b3a0bb8d7fbcf58752a8b58965eb777137d806 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5d9d076667735580054a410011b3a0bb8d7fbcf58752a8b58965eb777137d806->enter($__internal_5d9d076667735580054a410011b3a0bb8d7fbcf58752a8b58965eb777137d806_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_46a03f8f5205942056c933b8be7c279d3f0e4cf0b97a632b871a608217b5658b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_46a03f8f5205942056c933b8be7c279d3f0e4cf0b97a632b871a608217b5658b->enter($__internal_46a03f8f5205942056c933b8be7c279d3f0e4cf0b97a632b871a608217b5658b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 17
        echo "        <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl((("bundles/avanzuadmintheme/static/" . twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 17, $this->getSourceContext()); })()), "environment", array())) . "/styles/admin-lte-all.css")), "html", null, true);
        echo "\" />
    ";
        
        $__internal_46a03f8f5205942056c933b8be7c279d3f0e4cf0b97a632b871a608217b5658b->leave($__internal_46a03f8f5205942056c933b8be7c279d3f0e4cf0b97a632b871a608217b5658b_prof);

        
        $__internal_5d9d076667735580054a410011b3a0bb8d7fbcf58752a8b58965eb777137d806->leave($__internal_5d9d076667735580054a410011b3a0bb8d7fbcf58752a8b58965eb777137d806_prof);

    }

    // line 24
    public function block_javascripts_head($context, array $blocks = array())
    {
        $__internal_42b236a9b76a210489205ed2bb3e4e4da808f7b62f8bc16378f807102b77f2ab = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_42b236a9b76a210489205ed2bb3e4e4da808f7b62f8bc16378f807102b77f2ab->enter($__internal_42b236a9b76a210489205ed2bb3e4e4da808f7b62f8bc16378f807102b77f2ab_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts_head"));

        $__internal_2b804c9843af6ddf96c78611bcd65137456829efd058fdecc52db6469805a733 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2b804c9843af6ddf96c78611bcd65137456829efd058fdecc52db6469805a733->enter($__internal_2b804c9843af6ddf96c78611bcd65137456829efd058fdecc52db6469805a733_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts_head"));

        // line 25
        echo "        <script type=\"text/javascript\" src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl((("bundles/avanzuadmintheme/static/" . twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 25, $this->getSourceContext()); })()), "environment", array())) . "/scripts/modernizr.js")), "html", null, true);
        echo "\"></script>
        <!--[if lt IE 9]>

        <![endif]-->

    ";
        
        $__internal_2b804c9843af6ddf96c78611bcd65137456829efd058fdecc52db6469805a733->leave($__internal_2b804c9843af6ddf96c78611bcd65137456829efd058fdecc52db6469805a733_prof);

        
        $__internal_42b236a9b76a210489205ed2bb3e4e4da808f7b62f8bc16378f807102b77f2ab->leave($__internal_42b236a9b76a210489205ed2bb3e4e4da808f7b62f8bc16378f807102b77f2ab_prof);

    }

    // line 36
    public function block_avanzu_admin_header($context, array $blocks = array())
    {
        $__internal_a2da298a13b50271cd7e0fa371c39378369c88f2b12b5f147a8059f39134119b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a2da298a13b50271cd7e0fa371c39378369c88f2b12b5f147a8059f39134119b->enter($__internal_a2da298a13b50271cd7e0fa371c39378369c88f2b12b5f147a8059f39134119b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "avanzu_admin_header"));

        $__internal_d4bc361c739bb07bbe6a97392545c8ef7b4a887fbeb7324b412bee65445a4dd9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d4bc361c739bb07bbe6a97392545c8ef7b4a887fbeb7324b412bee65445a4dd9->enter($__internal_d4bc361c739bb07bbe6a97392545c8ef7b4a887fbeb7324b412bee65445a4dd9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "avanzu_admin_header"));

        // line 37
        echo "        <header class=\"main-header\">
            ";
        // line 38
        $this->displayBlock('avanzu_logo', $context, $blocks);
        // line 44
        echo "            <!-- Header Navbar: style can be found in header.less -->
            <nav class=\"navbar navbar-static-top\" role=\"navigation\">
                <!-- Sidebar toggle button-->
                <a href=\"#\" class=\"sidebar-toggle\" data-toggle=\"offcanvas\" role=\"button\">
                    <span class=\"sr-only\">Toggle navigation</span>
                </a>
                ";
        // line 50
        if (( !(null === twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 50, $this->getSourceContext()); })()), "user", array())) && $this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("IS_AUTHENTICATED_FULLY"))) {
            // line 51
            echo "                    <div class=\"navbar-custom-menu\">
                        <ul class=\"nav navbar-nav\">
                            ";
            // line 53
            $this->displayBlock('avanzu_navbar', $context, $blocks);
            // line 59
            echo "                        </ul>
                    </div>
                ";
        }
        // line 62
        echo "            </nav>
        </header>
    ";
        
        $__internal_d4bc361c739bb07bbe6a97392545c8ef7b4a887fbeb7324b412bee65445a4dd9->leave($__internal_d4bc361c739bb07bbe6a97392545c8ef7b4a887fbeb7324b412bee65445a4dd9_prof);

        
        $__internal_a2da298a13b50271cd7e0fa371c39378369c88f2b12b5f147a8059f39134119b->leave($__internal_a2da298a13b50271cd7e0fa371c39378369c88f2b12b5f147a8059f39134119b_prof);

    }

    // line 38
    public function block_avanzu_logo($context, array $blocks = array())
    {
        $__internal_0d62648b0bc71109f9b448498fec37eef7b75a6c89a1cbef6f6cca059618dab7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0d62648b0bc71109f9b448498fec37eef7b75a6c89a1cbef6f6cca059618dab7->enter($__internal_0d62648b0bc71109f9b448498fec37eef7b75a6c89a1cbef6f6cca059618dab7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "avanzu_logo"));

        $__internal_465bdb1596df74369cc478d16dba086e4b49e3d7acb1294b865f27815ce01131 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_465bdb1596df74369cc478d16dba086e4b49e3d7acb1294b865f27815ce01131->enter($__internal_465bdb1596df74369cc478d16dba086e4b49e3d7acb1294b865f27815ce01131_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "avanzu_logo"));

        // line 39
        echo "                <a href=\"#\" class=\"logo\">
                    <!-- Add the class icon to your logo image or logo icon to add the margining -->
                    ";
        // line 41
        $this->displayBlock("title", $context, $blocks);
        echo "
                </a>
            ";
        
        $__internal_465bdb1596df74369cc478d16dba086e4b49e3d7acb1294b865f27815ce01131->leave($__internal_465bdb1596df74369cc478d16dba086e4b49e3d7acb1294b865f27815ce01131_prof);

        
        $__internal_0d62648b0bc71109f9b448498fec37eef7b75a6c89a1cbef6f6cca059618dab7->leave($__internal_0d62648b0bc71109f9b448498fec37eef7b75a6c89a1cbef6f6cca059618dab7_prof);

    }

    // line 53
    public function block_avanzu_navbar($context, array $blocks = array())
    {
        $__internal_60914566cf7602ccaa966f0a42f9afe61682a103bc1abb051bc0e456a51e9799 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_60914566cf7602ccaa966f0a42f9afe61682a103bc1abb051bc0e456a51e9799->enter($__internal_60914566cf7602ccaa966f0a42f9afe61682a103bc1abb051bc0e456a51e9799_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "avanzu_navbar"));

        $__internal_dae8026b923225182bb60f389187774c7ec54b3a55191f96729942feffb89c28 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dae8026b923225182bb60f389187774c7ec54b3a55191f96729942feffb89c28->enter($__internal_dae8026b923225182bb60f389187774c7ec54b3a55191f96729942feffb89c28_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "avanzu_navbar"));

        // line 54
        echo "                                ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AvanzuAdminThemeBundle:Navbar:messages"));
        echo "
                                ";
        // line 55
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AvanzuAdminThemeBundle:Navbar:notifications"));
        echo "
                                ";
        // line 56
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AvanzuAdminThemeBundle:Navbar:tasks"));
        echo "
                                ";
        // line 57
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AvanzuAdminThemeBundle:Navbar:user"));
        echo "
                            ";
        
        $__internal_dae8026b923225182bb60f389187774c7ec54b3a55191f96729942feffb89c28->leave($__internal_dae8026b923225182bb60f389187774c7ec54b3a55191f96729942feffb89c28_prof);

        
        $__internal_60914566cf7602ccaa966f0a42f9afe61682a103bc1abb051bc0e456a51e9799->leave($__internal_60914566cf7602ccaa966f0a42f9afe61682a103bc1abb051bc0e456a51e9799_prof);

    }

    // line 70
    public function block_avanzu_sidebar($context, array $blocks = array())
    {
        $__internal_9dcfb046dd4427865ccb15533926eb11ef841e593536ffaf15e69c4366ad24c9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9dcfb046dd4427865ccb15533926eb11ef841e593536ffaf15e69c4366ad24c9->enter($__internal_9dcfb046dd4427865ccb15533926eb11ef841e593536ffaf15e69c4366ad24c9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "avanzu_sidebar"));

        $__internal_7f746149cc7c5d838678fef64755adf881181b1ba87111259d3b31485614709d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7f746149cc7c5d838678fef64755adf881181b1ba87111259d3b31485614709d->enter($__internal_7f746149cc7c5d838678fef64755adf881181b1ba87111259d3b31485614709d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "avanzu_sidebar"));

        // line 71
        echo "                    ";
        if (( !(null === twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 71, $this->getSourceContext()); })()), "user", array())) && $this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("IS_AUTHENTICATED_FULLY"))) {
            // line 72
            echo "                        ";
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AvanzuAdminThemeBundle:Sidebar:userPanel"));
            echo "
                        ";
            // line 73
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AvanzuAdminThemeBundle:Sidebar:searchForm"));
            echo "
                    ";
        }
        // line 75
        echo "                    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AvanzuAdminThemeBundle:Sidebar:menu", array("request" => twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 75, $this->getSourceContext()); })()), "request", array()))));
        echo "
                ";
        
        $__internal_7f746149cc7c5d838678fef64755adf881181b1ba87111259d3b31485614709d->leave($__internal_7f746149cc7c5d838678fef64755adf881181b1ba87111259d3b31485614709d_prof);

        
        $__internal_9dcfb046dd4427865ccb15533926eb11ef841e593536ffaf15e69c4366ad24c9->leave($__internal_9dcfb046dd4427865ccb15533926eb11ef841e593536ffaf15e69c4366ad24c9_prof);

    }

    // line 86
    public function block_page_title($context, array $blocks = array())
    {
        $__internal_e59a2b5edd1956250d89e055150b82620b7ad0c0c3c8fbe6ca5e451705235de8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e59a2b5edd1956250d89e055150b82620b7ad0c0c3c8fbe6ca5e451705235de8->enter($__internal_e59a2b5edd1956250d89e055150b82620b7ad0c0c3c8fbe6ca5e451705235de8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_title"));

        $__internal_d8bcd0bb06675d9084bb2ca649caa758185e5cab3dfc8c98550af07e6824f483 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d8bcd0bb06675d9084bb2ca649caa758185e5cab3dfc8c98550af07e6824f483->enter($__internal_d8bcd0bb06675d9084bb2ca649caa758185e5cab3dfc8c98550af07e6824f483_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_title"));

        echo "Blank page";
        
        $__internal_d8bcd0bb06675d9084bb2ca649caa758185e5cab3dfc8c98550af07e6824f483->leave($__internal_d8bcd0bb06675d9084bb2ca649caa758185e5cab3dfc8c98550af07e6824f483_prof);

        
        $__internal_e59a2b5edd1956250d89e055150b82620b7ad0c0c3c8fbe6ca5e451705235de8->leave($__internal_e59a2b5edd1956250d89e055150b82620b7ad0c0c3c8fbe6ca5e451705235de8_prof);

    }

    // line 87
    public function block_page_subtitle($context, array $blocks = array())
    {
        $__internal_ee2a521718f930e9bae2a5b436c28280e46ba993a8ee193f73f666456fa0d016 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ee2a521718f930e9bae2a5b436c28280e46ba993a8ee193f73f666456fa0d016->enter($__internal_ee2a521718f930e9bae2a5b436c28280e46ba993a8ee193f73f666456fa0d016_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_subtitle"));

        $__internal_3142283032c270e89765a41c04c1cd479e01312f1545fcdedd21b08b6c80d0b1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3142283032c270e89765a41c04c1cd479e01312f1545fcdedd21b08b6c80d0b1->enter($__internal_3142283032c270e89765a41c04c1cd479e01312f1545fcdedd21b08b6c80d0b1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_subtitle"));

        echo "Control panel";
        
        $__internal_3142283032c270e89765a41c04c1cd479e01312f1545fcdedd21b08b6c80d0b1->leave($__internal_3142283032c270e89765a41c04c1cd479e01312f1545fcdedd21b08b6c80d0b1_prof);

        
        $__internal_ee2a521718f930e9bae2a5b436c28280e46ba993a8ee193f73f666456fa0d016->leave($__internal_ee2a521718f930e9bae2a5b436c28280e46ba993a8ee193f73f666456fa0d016_prof);

    }

    // line 89
    public function block_avanzu_breadcrumb($context, array $blocks = array())
    {
        $__internal_d5dd9134c78af11be7e28cb7016be0da3ec928eba5499b63eb61eeab5d1b6af3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d5dd9134c78af11be7e28cb7016be0da3ec928eba5499b63eb61eeab5d1b6af3->enter($__internal_d5dd9134c78af11be7e28cb7016be0da3ec928eba5499b63eb61eeab5d1b6af3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "avanzu_breadcrumb"));

        $__internal_588eedd2df3b4e342b40734338fc20af1c1fd5a34d33f1017bde2122520d52b9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_588eedd2df3b4e342b40734338fc20af1c1fd5a34d33f1017bde2122520d52b9->enter($__internal_588eedd2df3b4e342b40734338fc20af1c1fd5a34d33f1017bde2122520d52b9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "avanzu_breadcrumb"));

        // line 90
        echo "                    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AvanzuAdminThemeBundle:Breadcrumb:breadcrumb", array("request" => twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 90, $this->getSourceContext()); })()), "request", array()), "title" =>         $this->renderBlock("page_title", $context, $blocks))));
        echo "
                ";
        
        $__internal_588eedd2df3b4e342b40734338fc20af1c1fd5a34d33f1017bde2122520d52b9->leave($__internal_588eedd2df3b4e342b40734338fc20af1c1fd5a34d33f1017bde2122520d52b9_prof);

        
        $__internal_d5dd9134c78af11be7e28cb7016be0da3ec928eba5499b63eb61eeab5d1b6af3->leave($__internal_d5dd9134c78af11be7e28cb7016be0da3ec928eba5499b63eb61eeab5d1b6af3_prof);

    }

    // line 96
    public function block_page_content($context, array $blocks = array())
    {
        $__internal_298a05f40f59c6fcaf85a5b1fe7360e688a3942612ffab1ad8b04ba05c869826 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_298a05f40f59c6fcaf85a5b1fe7360e688a3942612ffab1ad8b04ba05c869826->enter($__internal_298a05f40f59c6fcaf85a5b1fe7360e688a3942612ffab1ad8b04ba05c869826_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_content"));

        $__internal_81d51415271b8b8aa853e9d1e514e3a5a422df02c3e6ab3cb34fdc4087dd537c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_81d51415271b8b8aa853e9d1e514e3a5a422df02c3e6ab3cb34fdc4087dd537c->enter($__internal_81d51415271b8b8aa853e9d1e514e3a5a422df02c3e6ab3cb34fdc4087dd537c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_content"));

        
        $__internal_81d51415271b8b8aa853e9d1e514e3a5a422df02c3e6ab3cb34fdc4087dd537c->leave($__internal_81d51415271b8b8aa853e9d1e514e3a5a422df02c3e6ab3cb34fdc4087dd537c_prof);

        
        $__internal_298a05f40f59c6fcaf85a5b1fe7360e688a3942612ffab1ad8b04ba05c869826->leave($__internal_298a05f40f59c6fcaf85a5b1fe7360e688a3942612ffab1ad8b04ba05c869826_prof);

    }

    // line 102
    public function block_avanzu_admin_footer($context, array $blocks = array())
    {
        $__internal_843a55d232c5b155bcc457f991444a7323de85a8a4c9ff0150f3283de4f55a65 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_843a55d232c5b155bcc457f991444a7323de85a8a4c9ff0150f3283de4f55a65->enter($__internal_843a55d232c5b155bcc457f991444a7323de85a8a4c9ff0150f3283de4f55a65_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "avanzu_admin_footer"));

        $__internal_56a0cb7983ec4542906926d9166381bfa5dd03a67f731ee72d1d0bf118e53f00 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_56a0cb7983ec4542906926d9166381bfa5dd03a67f731ee72d1d0bf118e53f00->enter($__internal_56a0cb7983ec4542906926d9166381bfa5dd03a67f731ee72d1d0bf118e53f00_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "avanzu_admin_footer"));

        // line 103
        echo "        <footer class=\"main-footer\">
            <div class=\"pull-right hidden-xs\">
                <b>Version</b> 2.0
            </div>
            <strong>Copyright &copy; 2014-2015 <a href=\"http://almsaeedstudio.com\">Almsaeed Studio</a>.</strong> All rights reserved.
        </footer>
    ";
        
        $__internal_56a0cb7983ec4542906926d9166381bfa5dd03a67f731ee72d1d0bf118e53f00->leave($__internal_56a0cb7983ec4542906926d9166381bfa5dd03a67f731ee72d1d0bf118e53f00_prof);

        
        $__internal_843a55d232c5b155bcc457f991444a7323de85a8a4c9ff0150f3283de4f55a65->leave($__internal_843a55d232c5b155bcc457f991444a7323de85a8a4c9ff0150f3283de4f55a65_prof);

    }

    // line 115
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_62502ead1e2352cbbdcaa6acf860cdc4da8f8b676723e9d74596d04c678b0443 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_62502ead1e2352cbbdcaa6acf860cdc4da8f8b676723e9d74596d04c678b0443->enter($__internal_62502ead1e2352cbbdcaa6acf860cdc4da8f8b676723e9d74596d04c678b0443_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_5d6c5dc0f2b6c197a0f9fd68615a0ece992c60aaf225424004b5e051b545b81e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5d6c5dc0f2b6c197a0f9fd68615a0ece992c60aaf225424004b5e051b545b81e->enter($__internal_5d6c5dc0f2b6c197a0f9fd68615a0ece992c60aaf225424004b5e051b545b81e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 116
        echo "
    <script src=\"";
        // line 117
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl((("bundles/avanzuadmintheme/static/" . twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 117, $this->getSourceContext()); })()), "environment", array())) . "/scripts/admin-lte-all.js")), "html", null, true);
        echo "\"></script>

";
        
        $__internal_5d6c5dc0f2b6c197a0f9fd68615a0ece992c60aaf225424004b5e051b545b81e->leave($__internal_5d6c5dc0f2b6c197a0f9fd68615a0ece992c60aaf225424004b5e051b545b81e_prof);

        
        $__internal_62502ead1e2352cbbdcaa6acf860cdc4da8f8b676723e9d74596d04c678b0443->leave($__internal_62502ead1e2352cbbdcaa6acf860cdc4da8f8b676723e9d74596d04c678b0443_prof);

    }

    // line 122
    public function block_javascripts_inline($context, array $blocks = array())
    {
        $__internal_470eaac5be220ddf3b7ec2ecaa190e73fd3c4d453c2fbe7e4d191c507fe9ebe3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_470eaac5be220ddf3b7ec2ecaa190e73fd3c4d453c2fbe7e4d191c507fe9ebe3->enter($__internal_470eaac5be220ddf3b7ec2ecaa190e73fd3c4d453c2fbe7e4d191c507fe9ebe3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts_inline"));

        $__internal_a8ef04dedf5f1f0233698e3b2e3b400a109969397db1d25cc6ccc255e7de1a5f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a8ef04dedf5f1f0233698e3b2e3b400a109969397db1d25cc6ccc255e7de1a5f->enter($__internal_a8ef04dedf5f1f0233698e3b2e3b400a109969397db1d25cc6ccc255e7de1a5f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts_inline"));

        
        $__internal_a8ef04dedf5f1f0233698e3b2e3b400a109969397db1d25cc6ccc255e7de1a5f->leave($__internal_a8ef04dedf5f1f0233698e3b2e3b400a109969397db1d25cc6ccc255e7de1a5f_prof);

        
        $__internal_470eaac5be220ddf3b7ec2ecaa190e73fd3c4d453c2fbe7e4d191c507fe9ebe3->leave($__internal_470eaac5be220ddf3b7ec2ecaa190e73fd3c4d453c2fbe7e4d191c507fe9ebe3_prof);

    }

    public function getTemplateName()
    {
        return "AvanzuAdminThemeBundle:layout:base-layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  491 => 122,  478 => 117,  475 => 116,  466 => 115,  450 => 103,  441 => 102,  424 => 96,  411 => 90,  402 => 89,  384 => 87,  366 => 86,  353 => 75,  348 => 73,  343 => 72,  340 => 71,  331 => 70,  319 => 57,  315 => 56,  311 => 55,  306 => 54,  297 => 53,  284 => 41,  280 => 39,  271 => 38,  259 => 62,  254 => 59,  252 => 53,  248 => 51,  246 => 50,  238 => 44,  236 => 38,  233 => 37,  224 => 36,  207 => 25,  198 => 24,  185 => 17,  176 => 16,  158 => 13,  146 => 124,  144 => 122,  141 => 120,  139 => 115,  133 => 110,  131 => 102,  124 => 97,  122 => 96,  116 => 92,  114 => 89,  108 => 87,  106 => 86,  95 => 77,  93 => 70,  86 => 65,  84 => 36,  78 => 33,  74 => 31,  71 => 24,  66 => 21,  62 => 19,  59 => 16,  54 => 13,  41 => 2,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% import \"AvanzuAdminThemeBundle:layout:macros.html.twig\" as macro %}
<!doctype html>
<!--[if lt IE 7 ]><html lang=\"en\" class=\"no-js ie6\"> <![endif]-->
<!--[if IE 7 ]><html lang=\"en\" class=\"no-js ie7\"> <![endif]-->
<!--[if IE 8 ]><html lang=\"en\" class=\"no-js ie8\"> <![endif]-->
<!--[if IE 9 ]><html lang=\"en\" class=\"no-js ie9\"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--><html lang=\"en\" class=\"no-js\"> <!--<![endif]-->
<head>
    <meta charset=\"utf-8\">
    <meta name=\"author\" content=\"\">
    <meta name=\"keywords\" content=\"\">
    <meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">
    <title>{% block title %}Avanzu Admin!{% endblock %}</title>

    {# -------------------------------------------------------------------------------------------------- STYLESHEETS #}
    {% block stylesheets %}
        <link rel=\"stylesheet\" href=\"{{ asset('bundles/avanzuadmintheme/static/'~ app.environment ~'/styles/admin-lte-all.css') }}\" />
    {% endblock %}


    <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />

    {# --------------------------------------------------------------------------------------------- JAVASCRIPTS_HEAD #}
    {%  block javascripts_head %}
        <script type=\"text/javascript\" src=\"{{ asset('bundles/avanzuadmintheme/static/'~app.environment~'/scripts/modernizr.js') }}\"></script>
        <!--[if lt IE 9]>

        <![endif]-->

    {% endblock %}

</head>
<body class=\"{{ admin_skin|default('skin-blue')}}\">
    <div class=\"wrapper\">

    {% block avanzu_admin_header %}
        <header class=\"main-header\">
            {% block avanzu_logo %}
                <a href=\"#\" class=\"logo\">
                    <!-- Add the class icon to your logo image or logo icon to add the margining -->
                    {{ block('title') }}
                </a>
            {% endblock %}
            <!-- Header Navbar: style can be found in header.less -->
            <nav class=\"navbar navbar-static-top\" role=\"navigation\">
                <!-- Sidebar toggle button-->
                <a href=\"#\" class=\"sidebar-toggle\" data-toggle=\"offcanvas\" role=\"button\">
                    <span class=\"sr-only\">Toggle navigation</span>
                </a>
                {% if app.user is not null and is_granted('IS_AUTHENTICATED_FULLY') %}
                    <div class=\"navbar-custom-menu\">
                        <ul class=\"nav navbar-nav\">
                            {% block avanzu_navbar %}
                                {{ render(controller('AvanzuAdminThemeBundle:Navbar:messages')) }}
                                {{ render(controller('AvanzuAdminThemeBundle:Navbar:notifications')) }}
                                {{ render(controller('AvanzuAdminThemeBundle:Navbar:tasks')) }}
                                {{ render(controller('AvanzuAdminThemeBundle:Navbar:user')) }}
                            {% endblock %}
                        </ul>
                    </div>
                {% endif %}
            </nav>
        </header>
    {% endblock %}

        <!-- Left side column. contains the logo and sidebar -->
        <aside class=\"main-sidebar sidebar-offcanvas\">
            <!-- sidebar: style can be found in sidebar.less -->
            <section class=\"sidebar\">
                {% block avanzu_sidebar %}
                    {% if app.user is not null and is_granted('IS_AUTHENTICATED_FULLY') %}
                        {{ render(controller('AvanzuAdminThemeBundle:Sidebar:userPanel')) }}
                        {{ render(controller('AvanzuAdminThemeBundle:Sidebar:searchForm')) }}
                    {% endif %}
                    {{ render(controller('AvanzuAdminThemeBundle:Sidebar:menu', {'request':app.request})) }}
                {% endblock %}
            </section>
            <!-- /.sidebar -->
        </aside>

        <!-- Right side column. Contains the navbar and content of the page -->
        <div class=\"content-wrapper\">
            <!-- Content Header (Page header) -->
            <section class=\"content-header\">
                <h1>
                    {% block page_title %}Blank page{% endblock %}
                    <small>{% block page_subtitle %}Control panel{% endblock %}</small>
                </h1>
                {% block avanzu_breadcrumb %}
                    {{ render(controller('AvanzuAdminThemeBundle:Breadcrumb:breadcrumb', {'request':app.request, 'title' : block('page_title')})) }}
                {% endblock %}
            </section>

            <!-- Main content -->
            <section class=\"content\">
                {% block page_content %}{% endblock %}
            </section>
            <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->

    {% block avanzu_admin_footer %}
        <footer class=\"main-footer\">
            <div class=\"pull-right hidden-xs\">
                <b>Version</b> 2.0
            </div>
            <strong>Copyright &copy; 2014-2015 <a href=\"http://almsaeedstudio.com\">Almsaeed Studio</a>.</strong> All rights reserved.
        </footer>
    {% endblock %}

    </div>
<!-- ./wrapper -->

{# ------------------------------------------------------------------------------------------------------ JAVASCRIPTS #}
{% block javascripts %}

    <script src=\"{{ asset('bundles/avanzuadmintheme/static/'~app.environment~'/scripts/admin-lte-all.js') }}\"></script>

{% endblock %}

{# ----------------------------------------------------------------------------------------------- JAVASCRIPTS_INLINE #}
{% block javascripts_inline %}
{% endblock %}
</body>
</html>
", "AvanzuAdminThemeBundle:layout:base-layout.html.twig", "/home/sorina/Documents/work/movies_crowler/vendor/avanzu/admin-theme-bundle/Resources/views/layout/base-layout.html.twig");
    }
}
