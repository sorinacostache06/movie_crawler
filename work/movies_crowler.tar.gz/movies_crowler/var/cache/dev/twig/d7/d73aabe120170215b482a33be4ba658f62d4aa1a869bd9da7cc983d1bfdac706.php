<?php

/* @Framework/Form/form_rest.html.php */
class __TwigTemplate_733b662b263224fa1e482ff05bf48f9d8ea37542381400db0b53f37a134f6281 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_487752883e514db850b2635b6fcfb77dd6b56f011ab691b04081657f6189f015 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_487752883e514db850b2635b6fcfb77dd6b56f011ab691b04081657f6189f015->enter($__internal_487752883e514db850b2635b6fcfb77dd6b56f011ab691b04081657f6189f015_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rest.html.php"));

        $__internal_704929d54685a61de992a82ab484fdc3b6f2e47a6a5b43b05ec442c6a7d6aff2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_704929d54685a61de992a82ab484fdc3b6f2e47a6a5b43b05ec442c6a7d6aff2->enter($__internal_704929d54685a61de992a82ab484fdc3b6f2e47a6a5b43b05ec442c6a7d6aff2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rest.html.php"));

        // line 1
        echo "<?php foreach (\$form as \$child): ?>
    <?php if (!\$child->isRendered()): ?>
        <?php echo \$view['form']->row(\$child) ?>
    <?php endif; ?>
<?php endforeach; ?>
";
        
        $__internal_487752883e514db850b2635b6fcfb77dd6b56f011ab691b04081657f6189f015->leave($__internal_487752883e514db850b2635b6fcfb77dd6b56f011ab691b04081657f6189f015_prof);

        
        $__internal_704929d54685a61de992a82ab484fdc3b6f2e47a6a5b43b05ec442c6a7d6aff2->leave($__internal_704929d54685a61de992a82ab484fdc3b6f2e47a6a5b43b05ec442c6a7d6aff2_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_rest.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php foreach (\$form as \$child): ?>
    <?php if (!\$child->isRendered()): ?>
        <?php echo \$view['form']->row(\$child) ?>
    <?php endif; ?>
<?php endforeach; ?>
", "@Framework/Form/form_rest.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_rest.html.php");
    }
}
