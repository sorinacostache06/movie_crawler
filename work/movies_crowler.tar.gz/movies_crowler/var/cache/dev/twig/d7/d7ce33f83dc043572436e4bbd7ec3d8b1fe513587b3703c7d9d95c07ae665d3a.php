<?php

/* @Twig/Exception/traces.txt.twig */
class __TwigTemplate_eda3e8a1e47c8dc3b8194ea55eb19194d30d7d40386d5e39742920fb0f60b03d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0b6efb70de85427713b8be7869dec28bb8583c07af8ecb45203b844f2f7c277c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0b6efb70de85427713b8be7869dec28bb8583c07af8ecb45203b844f2f7c277c->enter($__internal_0b6efb70de85427713b8be7869dec28bb8583c07af8ecb45203b844f2f7c277c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/traces.txt.twig"));

        $__internal_b7d6a1b6f3b726fcd2ca28ed4d44d6841098fc7dec1be4a118d68cce04993054 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b7d6a1b6f3b726fcd2ca28ed4d44d6841098fc7dec1be4a118d68cce04993054->enter($__internal_b7d6a1b6f3b726fcd2ca28ed4d44d6841098fc7dec1be4a118d68cce04993054_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/traces.txt.twig"));

        // line 1
        if (twig_length_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["exception"]) || array_key_exists("exception", $context) ? $context["exception"] : (function () { throw new Twig_Error_Runtime('Variable "exception" does not exist.', 1, $this->getSourceContext()); })()), "trace", array()))) {
            // line 2
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["exception"]) || array_key_exists("exception", $context) ? $context["exception"] : (function () { throw new Twig_Error_Runtime('Variable "exception" does not exist.', 2, $this->getSourceContext()); })()), "trace", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["trace"]) {
                // line 3
                $this->loadTemplate("@Twig/Exception/trace.txt.twig", "@Twig/Exception/traces.txt.twig", 3)->display(array("trace" => $context["trace"]));
                // line 4
                echo "
";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['trace'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
        }
        
        $__internal_0b6efb70de85427713b8be7869dec28bb8583c07af8ecb45203b844f2f7c277c->leave($__internal_0b6efb70de85427713b8be7869dec28bb8583c07af8ecb45203b844f2f7c277c_prof);

        
        $__internal_b7d6a1b6f3b726fcd2ca28ed4d44d6841098fc7dec1be4a118d68cce04993054->leave($__internal_b7d6a1b6f3b726fcd2ca28ed4d44d6841098fc7dec1be4a118d68cce04993054_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/traces.txt.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  33 => 4,  31 => 3,  27 => 2,  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% if exception.trace|length %}
{% for trace in exception.trace %}
{% include '@Twig/Exception/trace.txt.twig' with { 'trace': trace } only %}

{% endfor %}
{% endif %}
", "@Twig/Exception/traces.txt.twig", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/traces.txt.twig");
    }
}
