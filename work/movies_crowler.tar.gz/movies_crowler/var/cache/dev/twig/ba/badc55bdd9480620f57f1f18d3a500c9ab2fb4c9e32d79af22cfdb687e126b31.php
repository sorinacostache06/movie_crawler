<?php

/* @Framework/Form/url_widget.html.php */
class __TwigTemplate_43c30fad5edaa4f45e321086cc91dc0ea38755beb667a257bfc4494e2413dd64 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f09bbe4596428f0ff157e508da6cd07da3d859dfc4c7e9dd3626a64767df7eed = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f09bbe4596428f0ff157e508da6cd07da3d859dfc4c7e9dd3626a64767df7eed->enter($__internal_f09bbe4596428f0ff157e508da6cd07da3d859dfc4c7e9dd3626a64767df7eed_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/url_widget.html.php"));

        $__internal_9785d4ea8b71d9a7f5a7af613735c322239ed4339f64a3176db8492aef5e157c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9785d4ea8b71d9a7f5a7af613735c322239ed4339f64a3176db8492aef5e157c->enter($__internal_9785d4ea8b71d9a7f5a7af613735c322239ed4339f64a3176db8492aef5e157c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/url_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'url')) ?>
";
        
        $__internal_f09bbe4596428f0ff157e508da6cd07da3d859dfc4c7e9dd3626a64767df7eed->leave($__internal_f09bbe4596428f0ff157e508da6cd07da3d859dfc4c7e9dd3626a64767df7eed_prof);

        
        $__internal_9785d4ea8b71d9a7f5a7af613735c322239ed4339f64a3176db8492aef5e157c->leave($__internal_9785d4ea8b71d9a7f5a7af613735c322239ed4339f64a3176db8492aef5e157c_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/url_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'url')) ?>
", "@Framework/Form/url_widget.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/url_widget.html.php");
    }
}
