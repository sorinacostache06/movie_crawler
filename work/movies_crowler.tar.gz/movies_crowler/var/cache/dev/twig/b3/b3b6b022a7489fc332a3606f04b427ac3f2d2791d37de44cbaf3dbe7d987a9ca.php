<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_b63320d36f11c5333dbb783c202aa74d7c31d187b871f300f5fada9c9734d22f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b3da78f880a353e060721c17480788225059ef647f140efe71f17a95168d661e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b3da78f880a353e060721c17480788225059ef647f140efe71f17a95168d661e->enter($__internal_b3da78f880a353e060721c17480788225059ef647f140efe71f17a95168d661e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_781da1c5910b282c707e497d5b1c927b762871744d5281075e6ddb0bffd147cd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_781da1c5910b282c707e497d5b1c927b762871744d5281075e6ddb0bffd147cd->enter($__internal_781da1c5910b282c707e497d5b1c927b762871744d5281075e6ddb0bffd147cd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b3da78f880a353e060721c17480788225059ef647f140efe71f17a95168d661e->leave($__internal_b3da78f880a353e060721c17480788225059ef647f140efe71f17a95168d661e_prof);

        
        $__internal_781da1c5910b282c707e497d5b1c927b762871744d5281075e6ddb0bffd147cd->leave($__internal_781da1c5910b282c707e497d5b1c927b762871744d5281075e6ddb0bffd147cd_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_a1770216a88293e01500088a80f0727df30f0380c32f255c896b8498d2c2163c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a1770216a88293e01500088a80f0727df30f0380c32f255c896b8498d2c2163c->enter($__internal_a1770216a88293e01500088a80f0727df30f0380c32f255c896b8498d2c2163c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_77a1677b446971245e495301e9b7503aaadfd837b4d00e5cc9da1e8538de9a15 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_77a1677b446971245e495301e9b7503aaadfd837b4d00e5cc9da1e8538de9a15->enter($__internal_77a1677b446971245e495301e9b7503aaadfd837b4d00e5cc9da1e8538de9a15_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_77a1677b446971245e495301e9b7503aaadfd837b4d00e5cc9da1e8538de9a15->leave($__internal_77a1677b446971245e495301e9b7503aaadfd837b4d00e5cc9da1e8538de9a15_prof);

        
        $__internal_a1770216a88293e01500088a80f0727df30f0380c32f255c896b8498d2c2163c->leave($__internal_a1770216a88293e01500088a80f0727df30f0380c32f255c896b8498d2c2163c_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_aab6b2a0e94cc1005a7573e8da507ad6f9d624f74f065f1582cdc4b68610fc40 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_aab6b2a0e94cc1005a7573e8da507ad6f9d624f74f065f1582cdc4b68610fc40->enter($__internal_aab6b2a0e94cc1005a7573e8da507ad6f9d624f74f065f1582cdc4b68610fc40_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_a8899a1def7f866587163c88868fdf94a48d82a1dbded4ea6dcb1095536f6c37 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a8899a1def7f866587163c88868fdf94a48d82a1dbded4ea6dcb1095536f6c37->enter($__internal_a8899a1def7f866587163c88868fdf94a48d82a1dbded4ea6dcb1095536f6c37_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_a8899a1def7f866587163c88868fdf94a48d82a1dbded4ea6dcb1095536f6c37->leave($__internal_a8899a1def7f866587163c88868fdf94a48d82a1dbded4ea6dcb1095536f6c37_prof);

        
        $__internal_aab6b2a0e94cc1005a7573e8da507ad6f9d624f74f065f1582cdc4b68610fc40->leave($__internal_aab6b2a0e94cc1005a7573e8da507ad6f9d624f74f065f1582cdc4b68610fc40_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_27a8d0626224bf551681ef7bfa8ea151760d8fa84de1ad983fd525002a4b5c28 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_27a8d0626224bf551681ef7bfa8ea151760d8fa84de1ad983fd525002a4b5c28->enter($__internal_27a8d0626224bf551681ef7bfa8ea151760d8fa84de1ad983fd525002a4b5c28_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_a03ca2a3955bbde6da2530e17034e3f53e6a6481f8a0646eb2e2d32ad0ea90bb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a03ca2a3955bbde6da2530e17034e3f53e6a6481f8a0646eb2e2d32ad0ea90bb->enter($__internal_a03ca2a3955bbde6da2530e17034e3f53e6a6481f8a0646eb2e2d32ad0ea90bb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) || array_key_exists("token", $context) ? $context["token"] : (function () { throw new Twig_Error_Runtime('Variable "token" does not exist.', 13, $this->getSourceContext()); })()))));
        echo "
";
        
        $__internal_a03ca2a3955bbde6da2530e17034e3f53e6a6481f8a0646eb2e2d32ad0ea90bb->leave($__internal_a03ca2a3955bbde6da2530e17034e3f53e6a6481f8a0646eb2e2d32ad0ea90bb_prof);

        
        $__internal_27a8d0626224bf551681ef7bfa8ea151760d8fa84de1ad983fd525002a4b5c28->leave($__internal_27a8d0626224bf551681ef7bfa8ea151760d8fa84de1ad983fd525002a4b5c28_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/router.html.twig");
    }
}
