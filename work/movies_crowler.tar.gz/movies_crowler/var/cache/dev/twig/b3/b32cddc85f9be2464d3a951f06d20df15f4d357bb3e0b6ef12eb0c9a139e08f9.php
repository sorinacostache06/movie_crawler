<?php

/* TwigBundle:Exception:exception.js.twig */
class __TwigTemplate_9f86c3600d3f4710dcf91e8635005e34d20e2e94f90c35a5fbfe1eeee52e4193 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_863dd70f766cd30282c6428eeb25b4ea0240591f3b296c485e5bb5badd78719b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_863dd70f766cd30282c6428eeb25b4ea0240591f3b296c485e5bb5badd78719b->enter($__internal_863dd70f766cd30282c6428eeb25b4ea0240591f3b296c485e5bb5badd78719b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.js.twig"));

        $__internal_073e153cc716b0a56b43793773f328847603f6f610447025331b104cf9aaec3d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_073e153cc716b0a56b43793773f328847603f6f610447025331b104cf9aaec3d->enter($__internal_073e153cc716b0a56b43793773f328847603f6f610447025331b104cf9aaec3d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        $this->loadTemplate("@Twig/Exception/exception.txt.twig", "TwigBundle:Exception:exception.js.twig", 2)->display(array_merge($context, array("exception" => (isset($context["exception"]) || array_key_exists("exception", $context) ? $context["exception"] : (function () { throw new Twig_Error_Runtime('Variable "exception" does not exist.', 2, $this->getSourceContext()); })()))));
        // line 3
        echo "*/
";
        
        $__internal_863dd70f766cd30282c6428eeb25b4ea0240591f3b296c485e5bb5badd78719b->leave($__internal_863dd70f766cd30282c6428eeb25b4ea0240591f3b296c485e5bb5badd78719b_prof);

        
        $__internal_073e153cc716b0a56b43793773f328847603f6f610447025331b104cf9aaec3d->leave($__internal_073e153cc716b0a56b43793773f328847603f6f610447025331b104cf9aaec3d_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  30 => 3,  28 => 2,  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{% include '@Twig/Exception/exception.txt.twig' with { 'exception': exception } %}
*/
", "TwigBundle:Exception:exception.js.twig", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/exception.js.twig");
    }
}
