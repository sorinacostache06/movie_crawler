<?php

/* @Framework/Form/form_start.html.php */
class __TwigTemplate_a7ec606807621abe51ade85baf245b9178580aeeae7681ffb6b1da39d418e62a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0cb4c95c5bf758e54cc498b08f6464099c6747ccea68bf608eb60211c77919f8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0cb4c95c5bf758e54cc498b08f6464099c6747ccea68bf608eb60211c77919f8->enter($__internal_0cb4c95c5bf758e54cc498b08f6464099c6747ccea68bf608eb60211c77919f8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_start.html.php"));

        $__internal_aa7eed45b8cd53e89dc2b69c94eb6332cf3e9a50e5c30bdd0299fe3c542d0b55 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_aa7eed45b8cd53e89dc2b69c94eb6332cf3e9a50e5c30bdd0299fe3c542d0b55->enter($__internal_aa7eed45b8cd53e89dc2b69c94eb6332cf3e9a50e5c30bdd0299fe3c542d0b55_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_start.html.php"));

        // line 1
        echo "<?php \$method = strtoupper(\$method) ?>
<?php \$form_method = \$method === 'GET' || \$method === 'POST' ? \$method : 'POST' ?>
<form name=\"<?php echo \$name ?>\" method=\"<?php echo strtolower(\$form_method) ?>\"<?php if (\$action !== ''): ?> action=\"<?php echo \$action ?>\"<?php endif ?><?php foreach (\$attr as \$k => \$v) { printf(' %s=\"%s\"', \$view->escape(\$k), \$view->escape(\$v)); } ?><?php if (\$multipart): ?> enctype=\"multipart/form-data\"<?php endif ?>>
<?php if (\$form_method !== \$method): ?>
    <input type=\"hidden\" name=\"_method\" value=\"<?php echo \$method ?>\" />
<?php endif ?>
";
        
        $__internal_0cb4c95c5bf758e54cc498b08f6464099c6747ccea68bf608eb60211c77919f8->leave($__internal_0cb4c95c5bf758e54cc498b08f6464099c6747ccea68bf608eb60211c77919f8_prof);

        
        $__internal_aa7eed45b8cd53e89dc2b69c94eb6332cf3e9a50e5c30bdd0299fe3c542d0b55->leave($__internal_aa7eed45b8cd53e89dc2b69c94eb6332cf3e9a50e5c30bdd0299fe3c542d0b55_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_start.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php \$method = strtoupper(\$method) ?>
<?php \$form_method = \$method === 'GET' || \$method === 'POST' ? \$method : 'POST' ?>
<form name=\"<?php echo \$name ?>\" method=\"<?php echo strtolower(\$form_method) ?>\"<?php if (\$action !== ''): ?> action=\"<?php echo \$action ?>\"<?php endif ?><?php foreach (\$attr as \$k => \$v) { printf(' %s=\"%s\"', \$view->escape(\$k), \$view->escape(\$v)); } ?><?php if (\$multipart): ?> enctype=\"multipart/form-data\"<?php endif ?>>
<?php if (\$form_method !== \$method): ?>
    <input type=\"hidden\" name=\"_method\" value=\"<?php echo \$method ?>\" />
<?php endif ?>
", "@Framework/Form/form_start.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_start.html.php");
    }
}
