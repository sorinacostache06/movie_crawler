<?php

/* TwigBundle:Exception:error.json.twig */
class __TwigTemplate_e852424769c4171122a458ee5cee2e4f43aa44b51c1e0650ae92795579b6591f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1535d3ac34ecbf28c11fb4609f38d0053ba5f3f540f0b16f3a66b2ba2b97da1b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1535d3ac34ecbf28c11fb4609f38d0053ba5f3f540f0b16f3a66b2ba2b97da1b->enter($__internal_1535d3ac34ecbf28c11fb4609f38d0053ba5f3f540f0b16f3a66b2ba2b97da1b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.json.twig"));

        $__internal_6ff949004dffa09bcb1507a0aff7dd9db1455f8fa1a35ded7d60a20bdcc7aa27 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6ff949004dffa09bcb1507a0aff7dd9db1455f8fa1a35ded7d60a20bdcc7aa27->enter($__internal_6ff949004dffa09bcb1507a0aff7dd9db1455f8fa1a35ded7d60a20bdcc7aa27_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.json.twig"));

        // line 1
        echo json_encode(array("error" => array("code" => (isset($context["status_code"]) || array_key_exists("status_code", $context) ? $context["status_code"] : (function () { throw new Twig_Error_Runtime('Variable "status_code" does not exist.', 1, $this->getSourceContext()); })()), "message" => (isset($context["status_text"]) || array_key_exists("status_text", $context) ? $context["status_text"] : (function () { throw new Twig_Error_Runtime('Variable "status_text" does not exist.', 1, $this->getSourceContext()); })()))));
        echo "
";
        
        $__internal_1535d3ac34ecbf28c11fb4609f38d0053ba5f3f540f0b16f3a66b2ba2b97da1b->leave($__internal_1535d3ac34ecbf28c11fb4609f38d0053ba5f3f540f0b16f3a66b2ba2b97da1b_prof);

        
        $__internal_6ff949004dffa09bcb1507a0aff7dd9db1455f8fa1a35ded7d60a20bdcc7aa27->leave($__internal_6ff949004dffa09bcb1507a0aff7dd9db1455f8fa1a35ded7d60a20bdcc7aa27_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ { 'error': { 'code': status_code, 'message': status_text } }|json_encode|raw }}
", "TwigBundle:Exception:error.json.twig", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/error.json.twig");
    }
}
