<?php

/* AvanzuAdminThemeBundle:Default:index.html.twig */
class __TwigTemplate_81210bd941a4034c60c257632bc6bdfa6645fc78ad92c9f66f825d1d45f28851 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("AvanzuAdminThemeBundle:layout:base-layout.html.twig", "AvanzuAdminThemeBundle:Default:index.html.twig", 1);
        $this->blocks = array(
        );
    }

    protected function doGetParent(array $context)
    {
        return "AvanzuAdminThemeBundle:layout:base-layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_76a4d580d478eae129f9cc2363bca322226959e2a4de1959c301200805bbff1d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_76a4d580d478eae129f9cc2363bca322226959e2a4de1959c301200805bbff1d->enter($__internal_76a4d580d478eae129f9cc2363bca322226959e2a4de1959c301200805bbff1d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AvanzuAdminThemeBundle:Default:index.html.twig"));

        $__internal_5c8a45475758b0b108a31e8601af20807dbdf3ee50af1a3f4815cb499302d7da = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5c8a45475758b0b108a31e8601af20807dbdf3ee50af1a3f4815cb499302d7da->enter($__internal_5c8a45475758b0b108a31e8601af20807dbdf3ee50af1a3f4815cb499302d7da_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AvanzuAdminThemeBundle:Default:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_76a4d580d478eae129f9cc2363bca322226959e2a4de1959c301200805bbff1d->leave($__internal_76a4d580d478eae129f9cc2363bca322226959e2a4de1959c301200805bbff1d_prof);

        
        $__internal_5c8a45475758b0b108a31e8601af20807dbdf3ee50af1a3f4815cb499302d7da->leave($__internal_5c8a45475758b0b108a31e8601af20807dbdf3ee50af1a3f4815cb499302d7da_prof);

    }

    public function getTemplateName()
    {
        return "AvanzuAdminThemeBundle:Default:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'AvanzuAdminThemeBundle:layout:base-layout.html.twig' %}



", "AvanzuAdminThemeBundle:Default:index.html.twig", "/home/sorina/Documents/work/movies_crowler/vendor/avanzu/admin-theme-bundle/Resources/views/Default/index.html.twig");
    }
}
