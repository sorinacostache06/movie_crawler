<?php

/* @Framework/Form/choice_widget.html.php */
class __TwigTemplate_8802177ad37f73b34a3aa8b69bc74ad2d1601db2d0aec373642e784d584157c0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6a3a3d3cd2d92bfaa36bba6b78e82a854c5e001d1e859cd3a8e632c930ff6b52 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6a3a3d3cd2d92bfaa36bba6b78e82a854c5e001d1e859cd3a8e632c930ff6b52->enter($__internal_6a3a3d3cd2d92bfaa36bba6b78e82a854c5e001d1e859cd3a8e632c930ff6b52_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget.html.php"));

        $__internal_ca3e66b45de4823e6ef45db71a878918473024d45e85a289d3a10bbaa7a1d641 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ca3e66b45de4823e6ef45db71a878918473024d45e85a289d3a10bbaa7a1d641->enter($__internal_ca3e66b45de4823e6ef45db71a878918473024d45e85a289d3a10bbaa7a1d641_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget.html.php"));

        // line 1
        echo "<?php if (\$expanded): ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_expanded') ?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_collapsed') ?>
<?php endif ?>
";
        
        $__internal_6a3a3d3cd2d92bfaa36bba6b78e82a854c5e001d1e859cd3a8e632c930ff6b52->leave($__internal_6a3a3d3cd2d92bfaa36bba6b78e82a854c5e001d1e859cd3a8e632c930ff6b52_prof);

        
        $__internal_ca3e66b45de4823e6ef45db71a878918473024d45e85a289d3a10bbaa7a1d641->leave($__internal_ca3e66b45de4823e6ef45db71a878918473024d45e85a289d3a10bbaa7a1d641_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$expanded): ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_expanded') ?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_collapsed') ?>
<?php endif ?>
", "@Framework/Form/choice_widget.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/choice_widget.html.php");
    }
}
