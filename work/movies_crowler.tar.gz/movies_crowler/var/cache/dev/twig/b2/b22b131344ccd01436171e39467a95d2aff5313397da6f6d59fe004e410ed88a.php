<?php

/* @Framework/Form/checkbox_widget.html.php */
class __TwigTemplate_e88b71971367df2fae30964ba057f7663ea4d6b7342d07734c7e66107adf1eff extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f497c664ea0c09613a302c67222f789ed768dd66b0c37d88fc4b6daa7e5b3902 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f497c664ea0c09613a302c67222f789ed768dd66b0c37d88fc4b6daa7e5b3902->enter($__internal_f497c664ea0c09613a302c67222f789ed768dd66b0c37d88fc4b6daa7e5b3902_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/checkbox_widget.html.php"));

        $__internal_1a25c5c3d333514699bff4411fe78cb085eb2b61d2dec0a3ee5ec9cdb0165882 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1a25c5c3d333514699bff4411fe78cb085eb2b61d2dec0a3ee5ec9cdb0165882->enter($__internal_1a25c5c3d333514699bff4411fe78cb085eb2b61d2dec0a3ee5ec9cdb0165882_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/checkbox_widget.html.php"));

        // line 1
        echo "<input type=\"checkbox\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    <?php if (strlen(\$value) > 0): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?>
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_f497c664ea0c09613a302c67222f789ed768dd66b0c37d88fc4b6daa7e5b3902->leave($__internal_f497c664ea0c09613a302c67222f789ed768dd66b0c37d88fc4b6daa7e5b3902_prof);

        
        $__internal_1a25c5c3d333514699bff4411fe78cb085eb2b61d2dec0a3ee5ec9cdb0165882->leave($__internal_1a25c5c3d333514699bff4411fe78cb085eb2b61d2dec0a3ee5ec9cdb0165882_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/checkbox_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<input type=\"checkbox\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    <?php if (strlen(\$value) > 0): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?>
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
", "@Framework/Form/checkbox_widget.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/checkbox_widget.html.php");
    }
}
