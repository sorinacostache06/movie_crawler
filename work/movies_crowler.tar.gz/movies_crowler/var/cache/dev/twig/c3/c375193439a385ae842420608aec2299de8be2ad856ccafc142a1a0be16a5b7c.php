<?php

/* @Framework/Form/password_widget.html.php */
class __TwigTemplate_3508c8957ec80f5f2e23a2997d3c9fc5fcfe6d548c4eab5549fe3293e74a671a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_13192c2f2ea3c45b069f6bcfbcd6d508be49051464ac941b8bc0e9bc1174200a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_13192c2f2ea3c45b069f6bcfbcd6d508be49051464ac941b8bc0e9bc1174200a->enter($__internal_13192c2f2ea3c45b069f6bcfbcd6d508be49051464ac941b8bc0e9bc1174200a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/password_widget.html.php"));

        $__internal_15ef775c5722f6ea6ece852285c4fad37df9091db1f8cb7cd3cc4fc0dc77716e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_15ef775c5722f6ea6ece852285c4fad37df9091db1f8cb7cd3cc4fc0dc77716e->enter($__internal_15ef775c5722f6ea6ece852285c4fad37df9091db1f8cb7cd3cc4fc0dc77716e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/password_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'password')) ?>
";
        
        $__internal_13192c2f2ea3c45b069f6bcfbcd6d508be49051464ac941b8bc0e9bc1174200a->leave($__internal_13192c2f2ea3c45b069f6bcfbcd6d508be49051464ac941b8bc0e9bc1174200a_prof);

        
        $__internal_15ef775c5722f6ea6ece852285c4fad37df9091db1f8cb7cd3cc4fc0dc77716e->leave($__internal_15ef775c5722f6ea6ece852285c4fad37df9091db1f8cb7cd3cc4fc0dc77716e_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/password_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'password')) ?>
", "@Framework/Form/password_widget.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/password_widget.html.php");
    }
}
