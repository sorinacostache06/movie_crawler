<?php

/* TwigBundle:Exception:error.atom.twig */
class __TwigTemplate_a6ca0b46ea15d70e2a75f2d3506dbe8a47a770b623f3a45c9a912ae975a8e4e4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_46fae265a36ab9730c1231fe4e9a35431fe32f120ab1dd16b07b25a091009df0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_46fae265a36ab9730c1231fe4e9a35431fe32f120ab1dd16b07b25a091009df0->enter($__internal_46fae265a36ab9730c1231fe4e9a35431fe32f120ab1dd16b07b25a091009df0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.atom.twig"));

        $__internal_727c5a18a06eef0b7c6ab0656bed49cf2be91d3597e949ecbd3cbd65968489ba = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_727c5a18a06eef0b7c6ab0656bed49cf2be91d3597e949ecbd3cbd65968489ba->enter($__internal_727c5a18a06eef0b7c6ab0656bed49cf2be91d3597e949ecbd3cbd65968489ba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "TwigBundle:Exception:error.atom.twig", 1)->display($context);
        
        $__internal_46fae265a36ab9730c1231fe4e9a35431fe32f120ab1dd16b07b25a091009df0->leave($__internal_46fae265a36ab9730c1231fe4e9a35431fe32f120ab1dd16b07b25a091009df0_prof);

        
        $__internal_727c5a18a06eef0b7c6ab0656bed49cf2be91d3597e949ecbd3cbd65968489ba->leave($__internal_727c5a18a06eef0b7c6ab0656bed49cf2be91d3597e949ecbd3cbd65968489ba_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.atom.twig";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include '@Twig/Exception/error.xml.twig' %}
", "TwigBundle:Exception:error.atom.twig", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/error.atom.twig");
    }
}
