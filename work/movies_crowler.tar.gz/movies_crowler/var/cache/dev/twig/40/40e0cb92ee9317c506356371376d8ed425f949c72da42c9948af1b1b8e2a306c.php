<?php

/* @Framework/Form/choice_widget_expanded.html.php */
class __TwigTemplate_73f2f2ed92773cbbea90a0b8debe28d99f6e57e02079f5a2417e2b6a0655e996 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_04d832630f3288596318b8f30fef436584ad9213b59b27149924357074c73f6b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_04d832630f3288596318b8f30fef436584ad9213b59b27149924357074c73f6b->enter($__internal_04d832630f3288596318b8f30fef436584ad9213b59b27149924357074c73f6b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget_expanded.html.php"));

        $__internal_a8ab613ddbdac570d70a08bcee03e7d3e807798419c88ad5f8f1a83573706b37 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a8ab613ddbdac570d70a08bcee03e7d3e807798419c88ad5f8f1a83573706b37->enter($__internal_a8ab613ddbdac570d70a08bcee03e7d3e807798419c88ad5f8f1a83573706b37_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget_expanded.html.php"));

        // line 1
        echo "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
<?php foreach (\$form as \$child): ?>
    <?php echo \$view['form']->widget(\$child) ?>
    <?php echo \$view['form']->label(\$child, null, array('translation_domain' => \$choice_translation_domain)) ?>
<?php endforeach ?>
</div>
";
        
        $__internal_04d832630f3288596318b8f30fef436584ad9213b59b27149924357074c73f6b->leave($__internal_04d832630f3288596318b8f30fef436584ad9213b59b27149924357074c73f6b_prof);

        
        $__internal_a8ab613ddbdac570d70a08bcee03e7d3e807798419c88ad5f8f1a83573706b37->leave($__internal_a8ab613ddbdac570d70a08bcee03e7d3e807798419c88ad5f8f1a83573706b37_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_widget_expanded.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
<?php foreach (\$form as \$child): ?>
    <?php echo \$view['form']->widget(\$child) ?>
    <?php echo \$view['form']->label(\$child, null, array('translation_domain' => \$choice_translation_domain)) ?>
<?php endforeach ?>
</div>
", "@Framework/Form/choice_widget_expanded.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/choice_widget_expanded.html.php");
    }
}
