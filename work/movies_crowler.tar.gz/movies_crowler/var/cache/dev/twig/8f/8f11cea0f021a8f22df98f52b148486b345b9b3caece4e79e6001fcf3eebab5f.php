<?php

/* @Framework/Form/form_rows.html.php */
class __TwigTemplate_b7861ed2c38fec4c050869f785cb1f3cf20b2e16ba3e79effe82ca78263f4e12 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_90c3d6a338f65477b9e3c041992265a2e93100d25a642dc9a6402c7da5e0384f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_90c3d6a338f65477b9e3c041992265a2e93100d25a642dc9a6402c7da5e0384f->enter($__internal_90c3d6a338f65477b9e3c041992265a2e93100d25a642dc9a6402c7da5e0384f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rows.html.php"));

        $__internal_7e21a2b88a92066fea6709266365cd2f63c9ee8fbbcfdb354ff464c17bd94fe8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7e21a2b88a92066fea6709266365cd2f63c9ee8fbbcfdb354ff464c17bd94fe8->enter($__internal_7e21a2b88a92066fea6709266365cd2f63c9ee8fbbcfdb354ff464c17bd94fe8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rows.html.php"));

        // line 1
        echo "<?php foreach (\$form as \$child) : ?>
    <?php echo \$view['form']->row(\$child) ?>
<?php endforeach; ?>
";
        
        $__internal_90c3d6a338f65477b9e3c041992265a2e93100d25a642dc9a6402c7da5e0384f->leave($__internal_90c3d6a338f65477b9e3c041992265a2e93100d25a642dc9a6402c7da5e0384f_prof);

        
        $__internal_7e21a2b88a92066fea6709266365cd2f63c9ee8fbbcfdb354ff464c17bd94fe8->leave($__internal_7e21a2b88a92066fea6709266365cd2f63c9ee8fbbcfdb354ff464c17bd94fe8_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_rows.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php foreach (\$form as \$child) : ?>
    <?php echo \$view['form']->row(\$child) ?>
<?php endforeach; ?>
", "@Framework/Form/form_rows.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_rows.html.php");
    }
}
