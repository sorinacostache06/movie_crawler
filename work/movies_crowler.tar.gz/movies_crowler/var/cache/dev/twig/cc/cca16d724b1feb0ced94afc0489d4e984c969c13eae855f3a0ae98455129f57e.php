<?php

/* ::base-layout.html.twig */
class __TwigTemplate_8a68661cc3736ca54c4d7f2fa414d28304984401dfbe3a6fa9fc1d2eeb552523 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("AvanzuAdminThemeBundle:layout:base-layout.html.twig", "::base-layout.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'flashBag' => array($this, 'block_flashBag'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'avanzu_navbar' => array($this, 'block_avanzu_navbar'),
            'avanzu_sidebar' => array($this, 'block_avanzu_sidebar'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "AvanzuAdminThemeBundle:layout:base-layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_58ca98127006f6968fc9a81929939b41ba41158ad8b4486e8d8d6a1d39ffc740 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_58ca98127006f6968fc9a81929939b41ba41158ad8b4486e8d8d6a1d39ffc740->enter($__internal_58ca98127006f6968fc9a81929939b41ba41158ad8b4486e8d8d6a1d39ffc740_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base-layout.html.twig"));

        $__internal_3238c262e8c8e9cde2aea159f0e64bbfa4d91b9782d44c356f4880829b8458ad = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3238c262e8c8e9cde2aea159f0e64bbfa4d91b9782d44c356f4880829b8458ad->enter($__internal_3238c262e8c8e9cde2aea159f0e64bbfa4d91b9782d44c356f4880829b8458ad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base-layout.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_58ca98127006f6968fc9a81929939b41ba41158ad8b4486e8d8d6a1d39ffc740->leave($__internal_58ca98127006f6968fc9a81929939b41ba41158ad8b4486e8d8d6a1d39ffc740_prof);

        
        $__internal_3238c262e8c8e9cde2aea159f0e64bbfa4d91b9782d44c356f4880829b8458ad->leave($__internal_3238c262e8c8e9cde2aea159f0e64bbfa4d91b9782d44c356f4880829b8458ad_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_eb43bca09cb17e52374a20ced03904968f764a486e0d733f16dcd51ce366eb38 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_eb43bca09cb17e52374a20ced03904968f764a486e0d733f16dcd51ce366eb38->enter($__internal_eb43bca09cb17e52374a20ced03904968f764a486e0d733f16dcd51ce366eb38_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_2f0e902bcaf21b17bc35989a071e5440978c297c4d6a2ff0e608150a4ca41cfe = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2f0e902bcaf21b17bc35989a071e5440978c297c4d6a2ff0e608150a4ca41cfe->enter($__internal_2f0e902bcaf21b17bc35989a071e5440978c297c4d6a2ff0e608150a4ca41cfe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 4
        echo "    Movies Crawler
";
        
        $__internal_2f0e902bcaf21b17bc35989a071e5440978c297c4d6a2ff0e608150a4ca41cfe->leave($__internal_2f0e902bcaf21b17bc35989a071e5440978c297c4d6a2ff0e608150a4ca41cfe_prof);

        
        $__internal_eb43bca09cb17e52374a20ced03904968f764a486e0d733f16dcd51ce366eb38->leave($__internal_eb43bca09cb17e52374a20ced03904968f764a486e0d733f16dcd51ce366eb38_prof);

    }

    // line 6
    public function block_flashBag($context, array $blocks = array())
    {
        $__internal_ec987784f5da4d26115f71fc70f51396ee7dfff15680008c89119ff71389ec98 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ec987784f5da4d26115f71fc70f51396ee7dfff15680008c89119ff71389ec98->enter($__internal_ec987784f5da4d26115f71fc70f51396ee7dfff15680008c89119ff71389ec98_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "flashBag"));

        $__internal_c603efcbb04e0665352e32f4ddff122350de1c0e88534bdb84e85e792c3b0cde = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c603efcbb04e0665352e32f4ddff122350de1c0e88534bdb84e85e792c3b0cde->enter($__internal_c603efcbb04e0665352e32f4ddff122350de1c0e88534bdb84e85e792c3b0cde_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "flashBag"));

        // line 7
        echo "    ";
        $this->loadTemplate("::flashBag.html.twig", "::base-layout.html.twig", 7)->display($context);
        
        $__internal_c603efcbb04e0665352e32f4ddff122350de1c0e88534bdb84e85e792c3b0cde->leave($__internal_c603efcbb04e0665352e32f4ddff122350de1c0e88534bdb84e85e792c3b0cde_prof);

        
        $__internal_ec987784f5da4d26115f71fc70f51396ee7dfff15680008c89119ff71389ec98->leave($__internal_ec987784f5da4d26115f71fc70f51396ee7dfff15680008c89119ff71389ec98_prof);

    }

    // line 9
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_77228cb59a3d19412223018f67097e006676ca6b0010bddc681675721810668d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_77228cb59a3d19412223018f67097e006676ca6b0010bddc681675721810668d->enter($__internal_77228cb59a3d19412223018f67097e006676ca6b0010bddc681675721810668d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_13c2ff83f6becef8f5654dff57ee441fabe42edf0c093df6bb0f772d2572e5a3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_13c2ff83f6becef8f5654dff57ee441fabe42edf0c093df6bb0f772d2572e5a3->enter($__internal_13c2ff83f6becef8f5654dff57ee441fabe42edf0c093df6bb0f772d2572e5a3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 10
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
    <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css\">
    <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.css\" />
    <link rel=\"stylesheet\" href=\"//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css\">
";
        
        $__internal_13c2ff83f6becef8f5654dff57ee441fabe42edf0c093df6bb0f772d2572e5a3->leave($__internal_13c2ff83f6becef8f5654dff57ee441fabe42edf0c093df6bb0f772d2572e5a3_prof);

        
        $__internal_77228cb59a3d19412223018f67097e006676ca6b0010bddc681675721810668d->leave($__internal_77228cb59a3d19412223018f67097e006676ca6b0010bddc681675721810668d_prof);

    }

    // line 15
    public function block_avanzu_navbar($context, array $blocks = array())
    {
        $__internal_d16303c65438b7336b313e12ee999402e0890ff4951857213ab605c88a1213c4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d16303c65438b7336b313e12ee999402e0890ff4951857213ab605c88a1213c4->enter($__internal_d16303c65438b7336b313e12ee999402e0890ff4951857213ab605c88a1213c4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "avanzu_navbar"));

        $__internal_ff4cb5a247b511b58343c31ed5cffc0e7db382a792e88d66d6a283d83e5146c7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ff4cb5a247b511b58343c31ed5cffc0e7db382a792e88d66d6a283d83e5146c7->enter($__internal_ff4cb5a247b511b58343c31ed5cffc0e7db382a792e88d66d6a283d83e5146c7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "avanzu_navbar"));

        // line 16
        echo "    <div class=\"navbar-custom-menu\">
        <ul class=\"nav navbar-nav\">
            <li class=\"dropdown user user-menu\">
                <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">
                    <img src=\"https://image.freepik.com/free-icon/question-mark_318-52837.jpg\" class=\"user-image\" alt=\"User Image\">
                    <span class=\"hidden-xs\">";
        // line 21
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 21, $this->getSourceContext()); })()), "user", array()), "username", array()), "html", null, true);
        echo "</span>
                </a>
                <ul class=\"dropdown-menu\">
                    <li class=\"user-header\">
                        <img src=\"https://image.freepik.com/free-icon/question-mark_318-52837.jpg\" class=\"img-circle\" alt=\"User Image\">
                        <p>
                            ";
        // line 27
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 27, $this->getSourceContext()); })()), "user", array()), "username", array()), "html", null, true);
        echo "
                            <small>Member since ";
        // line 28
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 28, $this->getSourceContext()); })()), "user", array()), "joinDate", array()), "d/m/Y"), "html", null, true);
        echo "</small>
                        </p>
                    </li>
                    <li class=\"user-footer\">
                        <div class=\"pull-left\">
                            <a href=\"#\" class=\"btn btn-default btn-flat\">Profile</a>
                        </div>
                        <div class=\"pull-right\">
                            <a href=";
        // line 36
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("logout");
        echo "#\" class=\"btn btn-default btn-flat\">Sign out</a>
                        </div>
                    </li>
                </ul>
            </li>
        </ul>
    </div>
";
        
        $__internal_ff4cb5a247b511b58343c31ed5cffc0e7db382a792e88d66d6a283d83e5146c7->leave($__internal_ff4cb5a247b511b58343c31ed5cffc0e7db382a792e88d66d6a283d83e5146c7_prof);

        
        $__internal_d16303c65438b7336b313e12ee999402e0890ff4951857213ab605c88a1213c4->leave($__internal_d16303c65438b7336b313e12ee999402e0890ff4951857213ab605c88a1213c4_prof);

    }

    // line 44
    public function block_avanzu_sidebar($context, array $blocks = array())
    {
        $__internal_004800d6946b0fcd449f693ba7f3413cf1035dd308a17284162fb5630213d6ee = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_004800d6946b0fcd449f693ba7f3413cf1035dd308a17284162fb5630213d6ee->enter($__internal_004800d6946b0fcd449f693ba7f3413cf1035dd308a17284162fb5630213d6ee_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "avanzu_sidebar"));

        $__internal_f5f8560f6974be5a237b14e61dfeafe321af702ecf4ae5333d99da2cb688424f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f5f8560f6974be5a237b14e61dfeafe321af702ecf4ae5333d99da2cb688424f->enter($__internal_f5f8560f6974be5a237b14e61dfeafe321af702ecf4ae5333d99da2cb688424f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "avanzu_sidebar"));

        // line 45
        echo "    <ul class=\"sidebar-menu\">
        <li class=\"header\">";
        // line 46
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("sidebar.navigation.main_navigation"), "html", null, true);
        echo "</li>
        <li><a href=\"";
        // line 47
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("home");
        echo "\"><i class=\"fa fa-home\"></i>";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("sidebar.navigation.home"), "html", null, true);
        echo "</a></li>
        <li><a href=\"";
        // line 48
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("want_to_watch");
        echo "\"><i class=\"fa fa fa-file-movie-o\"></i>";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("sidebar.navigation.wanttowatch"), "html", null, true);
        echo "</a></li>
        ";
        // line 50
        echo "        <li class=\"";
        if ((twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 50, $this->getSourceContext()); })()), "request", array()), "get", array(0 => "_route"), "method") == "user_management_list")) {
            echo "active";
        }
        echo "\">
            <a href=\"";
        // line 51
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_management_list");
        echo "\"><i class=\"fa fa fa-file-movie-o\"></i>";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("sidebar.navigation.user_management"), "html", null, true);
        echo "</a> </li>        <li><a href=\"";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("logout");
        echo "\"><i class=\"fa fa-cog\"></i>";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("sidebar.logout"), "html", null, true);
        echo "</a></li>
        <li class=\"treeview\">
            <a href=\"#\"><i class=\"fa fa-language\"></i>";
        // line 53
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("sidebar.navigation.language"), "html", null, true);
        echo "</a>
            <ul class=\"treeview-menu\" style=\"display: none;\">
                <li><a href=\"";
        // line 55
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("switch_locale", array("locale" => "ro"));
        echo "\"><i class=\"fa fa-circle-o\"></i>";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("sidebar.navigation.language.ro"), "html", null, true);
        echo "</a></li>
                <li><a href=\"";
        // line 56
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("switch_locale", array("locale" => "en"));
        echo "\"><i class=\"fa fa-circle-o\"></i>";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("sidebar.navigation.language.en"), "html", null, true);
        echo "</a></li>
            </ul>
        </li>
    </ul>
";
        
        $__internal_f5f8560f6974be5a237b14e61dfeafe321af702ecf4ae5333d99da2cb688424f->leave($__internal_f5f8560f6974be5a237b14e61dfeafe321af702ecf4ae5333d99da2cb688424f_prof);

        
        $__internal_004800d6946b0fcd449f693ba7f3413cf1035dd308a17284162fb5630213d6ee->leave($__internal_004800d6946b0fcd449f693ba7f3413cf1035dd308a17284162fb5630213d6ee_prof);

    }

    // line 62
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_be124032b9bd48256c9ef5a6c7244c6282e012578913b3b1661f0322e188140a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_be124032b9bd48256c9ef5a6c7244c6282e012578913b3b1661f0322e188140a->enter($__internal_be124032b9bd48256c9ef5a6c7244c6282e012578913b3b1661f0322e188140a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_9572dcd01e711bceebe994886b219d3b5c7fc0f93e08429ef716bb096a9a2dc9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9572dcd01e711bceebe994886b219d3b5c7fc0f93e08429ef716bb096a9a2dc9->enter($__internal_9572dcd01e711bceebe994886b219d3b5c7fc0f93e08429ef716bb096a9a2dc9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 63
        echo "    ";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.42/js/bootstrap-datetimepicker.min.js\"></script>
";
        
        $__internal_9572dcd01e711bceebe994886b219d3b5c7fc0f93e08429ef716bb096a9a2dc9->leave($__internal_9572dcd01e711bceebe994886b219d3b5c7fc0f93e08429ef716bb096a9a2dc9_prof);

        
        $__internal_be124032b9bd48256c9ef5a6c7244c6282e012578913b3b1661f0322e188140a->leave($__internal_be124032b9bd48256c9ef5a6c7244c6282e012578913b3b1661f0322e188140a_prof);

    }

    public function getTemplateName()
    {
        return "::base-layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  251 => 63,  242 => 62,  225 => 56,  219 => 55,  214 => 53,  203 => 51,  196 => 50,  190 => 48,  184 => 47,  180 => 46,  177 => 45,  168 => 44,  150 => 36,  139 => 28,  135 => 27,  126 => 21,  119 => 16,  110 => 15,  94 => 10,  85 => 9,  74 => 7,  65 => 6,  54 => 4,  45 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'AvanzuAdminThemeBundle:layout:base-layout.html.twig' %}

{% block title %}
    Movies Crawler
{% endblock %}
{% block flashBag %}
    {% include '::flashBag.html.twig' %}
{% endblock %}
{% block stylesheets %}
    {{ parent() }}
    <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css\">
    <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.css\" />
    <link rel=\"stylesheet\" href=\"//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css\">
{% endblock %}
{% block avanzu_navbar %}
    <div class=\"navbar-custom-menu\">
        <ul class=\"nav navbar-nav\">
            <li class=\"dropdown user user-menu\">
                <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">
                    <img src=\"https://image.freepik.com/free-icon/question-mark_318-52837.jpg\" class=\"user-image\" alt=\"User Image\">
                    <span class=\"hidden-xs\">{{ app.user.username }}</span>
                </a>
                <ul class=\"dropdown-menu\">
                    <li class=\"user-header\">
                        <img src=\"https://image.freepik.com/free-icon/question-mark_318-52837.jpg\" class=\"img-circle\" alt=\"User Image\">
                        <p>
                            {{ app.user.username}}
                            <small>Member since {{ app.user.joinDate|date(\"d/m/Y\") }}</small>
                        </p>
                    </li>
                    <li class=\"user-footer\">
                        <div class=\"pull-left\">
                            <a href=\"#\" class=\"btn btn-default btn-flat\">Profile</a>
                        </div>
                        <div class=\"pull-right\">
                            <a href={{ path('logout') }}#\" class=\"btn btn-default btn-flat\">Sign out</a>
                        </div>
                    </li>
                </ul>
            </li>
        </ul>
    </div>
{% endblock %}
{% block avanzu_sidebar %}
    <ul class=\"sidebar-menu\">
        <li class=\"header\">{{ 'sidebar.navigation.main_navigation'|trans }}</li>
        <li><a href=\"{{ path('home') }}\"><i class=\"fa fa-home\"></i>{{ 'sidebar.navigation.home'|trans }}</a></li>
        <li><a href=\"{{ path('want_to_watch') }}\"><i class=\"fa fa fa-file-movie-o\"></i>{{ 'sidebar.navigation.wanttowatch'|trans }}</a></li>
        {#<li><a href=\"{{ path('user_management_list') }}\"><i class=\"fa fa fa-file-movie-o\"></i>{{ 'sidebar.navigation.user_management'|trans }}</a></li>#}
        <li class=\"{% if app.request.get('_route') == 'user_management_list' %}active{% endif %}\">
            <a href=\"{{ path('user_management_list') }}\"><i class=\"fa fa fa-file-movie-o\"></i>{{ 'sidebar.navigation.user_management'|trans }}</a> </li>        <li><a href=\"{{ path('logout') }}\"><i class=\"fa fa-cog\"></i>{{ 'sidebar.logout'|trans }}</a></li>
        <li class=\"treeview\">
            <a href=\"#\"><i class=\"fa fa-language\"></i>{{ 'sidebar.navigation.language'|trans }}</a>
            <ul class=\"treeview-menu\" style=\"display: none;\">
                <li><a href=\"{{ path('switch_locale', {'locale': 'ro' }) }}\"><i class=\"fa fa-circle-o\"></i>{{ 'sidebar.navigation.language.ro'|trans }}</a></li>
                <li><a href=\"{{ path('switch_locale', {'locale': 'en' }) }}\"><i class=\"fa fa-circle-o\"></i>{{ 'sidebar.navigation.language.en'|trans }}</a></li>
            </ul>
        </li>
    </ul>
{% endblock %}

{% block javascripts %}
    {{ parent() }}
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.42/js/bootstrap-datetimepicker.min.js\"></script>
{% endblock %}", "::base-layout.html.twig", "/home/sorina/Documents/work/movies_crowler/app/Resources/views/base-layout.html.twig");
    }
}
