<?php

/* @Framework/FormTable/form_widget_compound.html.php */
class __TwigTemplate_ff22f877a3c45968a5803e5eb1654e495089abc2e08794087e303dcb63d754b6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f77724ce518f1c567f028d4bd5e61af6fb87d4864179527abb2c356291392576 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f77724ce518f1c567f028d4bd5e61af6fb87d4864179527abb2c356291392576->enter($__internal_f77724ce518f1c567f028d4bd5e61af6fb87d4864179527abb2c356291392576_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_widget_compound.html.php"));

        $__internal_bf489d4c0cb1258d615731343fb6fe8e96e12dab501a8c5f0616bcafa3330b41 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bf489d4c0cb1258d615731343fb6fe8e96e12dab501a8c5f0616bcafa3330b41->enter($__internal_bf489d4c0cb1258d615731343fb6fe8e96e12dab501a8c5f0616bcafa3330b41_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_widget_compound.html.php"));

        // line 1
        echo "<table <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <tr>
        <td colspan=\"2\">
            <?php echo \$view['form']->errors(\$form) ?>
        </td>
    </tr>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</table>
";
        
        $__internal_f77724ce518f1c567f028d4bd5e61af6fb87d4864179527abb2c356291392576->leave($__internal_f77724ce518f1c567f028d4bd5e61af6fb87d4864179527abb2c356291392576_prof);

        
        $__internal_bf489d4c0cb1258d615731343fb6fe8e96e12dab501a8c5f0616bcafa3330b41->leave($__internal_bf489d4c0cb1258d615731343fb6fe8e96e12dab501a8c5f0616bcafa3330b41_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_widget_compound.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<table <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <tr>
        <td colspan=\"2\">
            <?php echo \$view['form']->errors(\$form) ?>
        </td>
    </tr>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</table>
", "@Framework/FormTable/form_widget_compound.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/FormTable/form_widget_compound.html.php");
    }
}
