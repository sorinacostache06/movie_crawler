<?php

/* KnpPaginatorBundle:Pagination:sortable_link.html.twig */
class __TwigTemplate_62f5d96072578ea727fbfe9bd2de4aa76baa13828c1bab5e97d2d0a95b8ed87f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cb5227bfb3d84ff1d2124e3681d117e2d8feb024b922b1f37bf52de9f783bf23 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cb5227bfb3d84ff1d2124e3681d117e2d8feb024b922b1f37bf52de9f783bf23->enter($__internal_cb5227bfb3d84ff1d2124e3681d117e2d8feb024b922b1f37bf52de9f783bf23_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "KnpPaginatorBundle:Pagination:sortable_link.html.twig"));

        $__internal_e157464ea934721b4c511a05fb62199685dde4f503af18d9ca9dcf73ecd1057f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e157464ea934721b4c511a05fb62199685dde4f503af18d9ca9dcf73ecd1057f->enter($__internal_e157464ea934721b4c511a05fb62199685dde4f503af18d9ca9dcf73ecd1057f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "KnpPaginatorBundle:Pagination:sortable_link.html.twig"));

        // line 1
        echo "<a";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["options"]) || array_key_exists("options", $context) ? $context["options"] : (function () { throw new Twig_Error_Runtime('Variable "options" does not exist.', 1, $this->getSourceContext()); })()));
        foreach ($context['_seq'] as $context["attr"] => $context["value"]) {
            echo " ";
            echo twig_escape_filter($this->env, $context["attr"], "html", null, true);
            echo "=\"";
            echo twig_escape_filter($this->env, $context["value"], "html", null, true);
            echo "\"";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['attr'], $context['value'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        echo ">";
        echo twig_escape_filter($this->env, (isset($context["title"]) || array_key_exists("title", $context) ? $context["title"] : (function () { throw new Twig_Error_Runtime('Variable "title" does not exist.', 1, $this->getSourceContext()); })()), "html", null, true);
        echo "</a>
";
        
        $__internal_cb5227bfb3d84ff1d2124e3681d117e2d8feb024b922b1f37bf52de9f783bf23->leave($__internal_cb5227bfb3d84ff1d2124e3681d117e2d8feb024b922b1f37bf52de9f783bf23_prof);

        
        $__internal_e157464ea934721b4c511a05fb62199685dde4f503af18d9ca9dcf73ecd1057f->leave($__internal_e157464ea934721b4c511a05fb62199685dde4f503af18d9ca9dcf73ecd1057f_prof);

    }

    public function getTemplateName()
    {
        return "KnpPaginatorBundle:Pagination:sortable_link.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<a{% for attr, value in options %} {{ attr }}=\"{{ value }}\"{% endfor %}>{{ title }}</a>
", "KnpPaginatorBundle:Pagination:sortable_link.html.twig", "/home/sorina/Documents/work/movies_crowler/vendor/knplabs/knp-paginator-bundle/Resources/views/Pagination/sortable_link.html.twig");
    }
}
