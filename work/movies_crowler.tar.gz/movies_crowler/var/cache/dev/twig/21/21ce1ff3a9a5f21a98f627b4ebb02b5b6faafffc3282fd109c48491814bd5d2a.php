<?php

/* @Framework/Form/datetime_widget.html.php */
class __TwigTemplate_55db4f68c27571456f2f4a40ae917a65e0c7f91594ac38ba5852c8d351b88a26 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a8251e4e883baf72834cc3968fd7de0a1092b3b35d760a4c1f377e2129132817 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a8251e4e883baf72834cc3968fd7de0a1092b3b35d760a4c1f377e2129132817->enter($__internal_a8251e4e883baf72834cc3968fd7de0a1092b3b35d760a4c1f377e2129132817_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/datetime_widget.html.php"));

        $__internal_505540e7adf2008dfa91d9d4fe1b9c8e046a266c5fd2ae127e611372dd81f2e5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_505540e7adf2008dfa91d9d4fe1b9c8e046a266c5fd2ae127e611372dd81f2e5->enter($__internal_505540e7adf2008dfa91d9d4fe1b9c8e046a266c5fd2ae127e611372dd81f2e5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/datetime_widget.html.php"));

        // line 1
        echo "<?php if (\$widget == 'single_text'): ?>
    <?php echo \$view['form']->block(\$form, 'form_widget_simple'); ?>
<?php else: ?>
    <div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
        <?php echo \$view['form']->widget(\$form['date']).' '.\$view['form']->widget(\$form['time']) ?>
    </div>
<?php endif ?>
";
        
        $__internal_a8251e4e883baf72834cc3968fd7de0a1092b3b35d760a4c1f377e2129132817->leave($__internal_a8251e4e883baf72834cc3968fd7de0a1092b3b35d760a4c1f377e2129132817_prof);

        
        $__internal_505540e7adf2008dfa91d9d4fe1b9c8e046a266c5fd2ae127e611372dd81f2e5->leave($__internal_505540e7adf2008dfa91d9d4fe1b9c8e046a266c5fd2ae127e611372dd81f2e5_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/datetime_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$widget == 'single_text'): ?>
    <?php echo \$view['form']->block(\$form, 'form_widget_simple'); ?>
<?php else: ?>
    <div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
        <?php echo \$view['form']->widget(\$form['date']).' '.\$view['form']->widget(\$form['time']) ?>
    </div>
<?php endif ?>
", "@Framework/Form/datetime_widget.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/datetime_widget.html.php");
    }
}
