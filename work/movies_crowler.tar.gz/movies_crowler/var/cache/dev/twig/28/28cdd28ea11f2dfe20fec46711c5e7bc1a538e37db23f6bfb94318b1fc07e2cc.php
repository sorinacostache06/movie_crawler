<?php

/* @Framework/Form/percent_widget.html.php */
class __TwigTemplate_2cc954170bbc62b40e86b440fa7bf240f656222edb04662add8b1b76e5afc1ec extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cb54ba54f9f99fab651ee136a4e688213bcf1185e27f050af11a99d0bb696704 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cb54ba54f9f99fab651ee136a4e688213bcf1185e27f050af11a99d0bb696704->enter($__internal_cb54ba54f9f99fab651ee136a4e688213bcf1185e27f050af11a99d0bb696704_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/percent_widget.html.php"));

        $__internal_aae23b055fad0831627a9cf18b4ffff63d6485aa5d7ee731c7531b06bde3e26f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_aae23b055fad0831627a9cf18b4ffff63d6485aa5d7ee731c7531b06bde3e26f->enter($__internal_aae23b055fad0831627a9cf18b4ffff63d6485aa5d7ee731c7531b06bde3e26f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/percent_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'text')) ?> %
";
        
        $__internal_cb54ba54f9f99fab651ee136a4e688213bcf1185e27f050af11a99d0bb696704->leave($__internal_cb54ba54f9f99fab651ee136a4e688213bcf1185e27f050af11a99d0bb696704_prof);

        
        $__internal_aae23b055fad0831627a9cf18b4ffff63d6485aa5d7ee731c7531b06bde3e26f->leave($__internal_aae23b055fad0831627a9cf18b4ffff63d6485aa5d7ee731c7531b06bde3e26f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/percent_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'text')) ?> %
", "@Framework/Form/percent_widget.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/percent_widget.html.php");
    }
}
