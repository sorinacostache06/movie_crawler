<?php

/* @Framework/Form/hidden_row.html.php */
class __TwigTemplate_e6b9934b6f03bf4bd6db103549e8dd800a4c1eb7060a3ab710453a2836058c27 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_428512cc28123ea036a068cc58bf53843480628a03b30663386c2ef166a693af = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_428512cc28123ea036a068cc58bf53843480628a03b30663386c2ef166a693af->enter($__internal_428512cc28123ea036a068cc58bf53843480628a03b30663386c2ef166a693af_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        $__internal_48ddad593b96756facc148c73da1376d2a6bd34bb28b8e402ea6fb562a14433b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_48ddad593b96756facc148c73da1376d2a6bd34bb28b8e402ea6fb562a14433b->enter($__internal_48ddad593b96756facc148c73da1376d2a6bd34bb28b8e402ea6fb562a14433b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->widget(\$form) ?>
";
        
        $__internal_428512cc28123ea036a068cc58bf53843480628a03b30663386c2ef166a693af->leave($__internal_428512cc28123ea036a068cc58bf53843480628a03b30663386c2ef166a693af_prof);

        
        $__internal_48ddad593b96756facc148c73da1376d2a6bd34bb28b8e402ea6fb562a14433b->leave($__internal_48ddad593b96756facc148c73da1376d2a6bd34bb28b8e402ea6fb562a14433b_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->widget(\$form) ?>
", "@Framework/Form/hidden_row.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/hidden_row.html.php");
    }
}
