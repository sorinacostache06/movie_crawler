<?php

/* :Form:fields.html.twig */
class __TwigTemplate_794f9c00e3bc249a9d205764edbc85e1f3decb1061acdc54f2642dd0def955f0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'datepicker_widget' => array($this, 'block_datepicker_widget'),
            'datetimepicker_widget' => array($this, 'block_datetimepicker_widget'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4f1ffd2d83dfd9a3592195456bc5bc5aed06bcc4d27d4e7a6197b0d7e224c4e4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4f1ffd2d83dfd9a3592195456bc5bc5aed06bcc4d27d4e7a6197b0d7e224c4e4->enter($__internal_4f1ffd2d83dfd9a3592195456bc5bc5aed06bcc4d27d4e7a6197b0d7e224c4e4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Form:fields.html.twig"));

        $__internal_6edacfe678899eafe395438fc3cc9b7729b42283d75dcf8881333d2455d1373c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6edacfe678899eafe395438fc3cc9b7729b42283d75dcf8881333d2455d1373c->enter($__internal_6edacfe678899eafe395438fc3cc9b7729b42283d75dcf8881333d2455d1373c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Form:fields.html.twig"));

        // line 2
        $this->displayBlock('datepicker_widget', $context, $blocks);
        // line 6
        $this->displayBlock('datetimepicker_widget', $context, $blocks);
        
        $__internal_4f1ffd2d83dfd9a3592195456bc5bc5aed06bcc4d27d4e7a6197b0d7e224c4e4->leave($__internal_4f1ffd2d83dfd9a3592195456bc5bc5aed06bcc4d27d4e7a6197b0d7e224c4e4_prof);

        
        $__internal_6edacfe678899eafe395438fc3cc9b7729b42283d75dcf8881333d2455d1373c->leave($__internal_6edacfe678899eafe395438fc3cc9b7729b42283d75dcf8881333d2455d1373c_prof);

    }

    // line 2
    public function block_datepicker_widget($context, array $blocks = array())
    {
        $__internal_76f368c43e1cf50a29b4d2c2d5005c678103b2eb139eb5e9a511b6efed4662db = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_76f368c43e1cf50a29b4d2c2d5005c678103b2eb139eb5e9a511b6efed4662db->enter($__internal_76f368c43e1cf50a29b4d2c2d5005c678103b2eb139eb5e9a511b6efed4662db_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datepicker_widget"));

        $__internal_2f79a5ad2e5fd55604e94bd64edd7a90bb0bd2fe87e59095115c7427d1ea8f52 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2f79a5ad2e5fd55604e94bd64edd7a90bb0bd2fe87e59095115c7427d1ea8f52->enter($__internal_2f79a5ad2e5fd55604e94bd64edd7a90bb0bd2fe87e59095115c7427d1ea8f52_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datepicker_widget"));

        // line 3
        echo "    <input placeholder=\"Date\" class=\"form-control datepicker\" type=\"text\" ";
        if ( !twig_test_empty((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 3, $this->getSourceContext()); })()))) {
            echo "value=\"";
            echo twig_escape_filter($this->env, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 3, $this->getSourceContext()); })()), "html", null, true);
            echo "\" ";
        }
        echo " ";
        $this->displayBlock("widget_attributes", $context, $blocks);
        echo "/>
";
        
        $__internal_2f79a5ad2e5fd55604e94bd64edd7a90bb0bd2fe87e59095115c7427d1ea8f52->leave($__internal_2f79a5ad2e5fd55604e94bd64edd7a90bb0bd2fe87e59095115c7427d1ea8f52_prof);

        
        $__internal_76f368c43e1cf50a29b4d2c2d5005c678103b2eb139eb5e9a511b6efed4662db->leave($__internal_76f368c43e1cf50a29b4d2c2d5005c678103b2eb139eb5e9a511b6efed4662db_prof);

    }

    // line 6
    public function block_datetimepicker_widget($context, array $blocks = array())
    {
        $__internal_354086dd6e0f87f8921629b6f65ab8b128f4f042e9c413671dc22e38bbe8242c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_354086dd6e0f87f8921629b6f65ab8b128f4f042e9c413671dc22e38bbe8242c->enter($__internal_354086dd6e0f87f8921629b6f65ab8b128f4f042e9c413671dc22e38bbe8242c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datetimepicker_widget"));

        $__internal_e88fb2da509634e4eeff31263532911ce4d95bb6a2ce691c7ee4bef92967d5e0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e88fb2da509634e4eeff31263532911ce4d95bb6a2ce691c7ee4bef92967d5e0->enter($__internal_e88fb2da509634e4eeff31263532911ce4d95bb6a2ce691c7ee4bef92967d5e0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datetimepicker_widget"));

        // line 7
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 7, $this->getSourceContext()); })()), "date", array()), 'errors');
        echo "
    ";
        // line 8
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 8, $this->getSourceContext()); })()), "time", array()), 'errors');
        echo "
    <div class=\"input-group datetimepicker\">
        <span class=\"input-group-addon\">Le</span>
        ";
        // line 11
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 11, $this->getSourceContext()); })()), "date", array()), 'widget');
        echo "
        <span class=\"input-group-addon inner-addon\">à</span>
        ";
        // line 13
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 13, $this->getSourceContext()); })()), "time", array()), 'widget');
        echo "
    </div>
";
        
        $__internal_e88fb2da509634e4eeff31263532911ce4d95bb6a2ce691c7ee4bef92967d5e0->leave($__internal_e88fb2da509634e4eeff31263532911ce4d95bb6a2ce691c7ee4bef92967d5e0_prof);

        
        $__internal_354086dd6e0f87f8921629b6f65ab8b128f4f042e9c413671dc22e38bbe8242c->leave($__internal_354086dd6e0f87f8921629b6f65ab8b128f4f042e9c413671dc22e38bbe8242c_prof);

    }

    public function getTemplateName()
    {
        return ":Form:fields.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  92 => 13,  87 => 11,  81 => 8,  76 => 7,  67 => 6,  48 => 3,  39 => 2,  29 => 6,  27 => 2,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{# DATEPICKER #}
{% block datepicker_widget %}
    <input placeholder=\"Date\" class=\"form-control datepicker\" type=\"text\" {% if value is not empty %}value=\"{{ value }}\" {% endif %} {{ block('widget_attributes') }}/>
{% endblock %}
{# DATETIMEPICKER #}
{% block datetimepicker_widget %}
    {{ form_errors(form.date) }}
    {{ form_errors(form.time) }}
    <div class=\"input-group datetimepicker\">
        <span class=\"input-group-addon\">Le</span>
        {{ form_widget(form.date) }}
        <span class=\"input-group-addon inner-addon\">à</span>
        {{ form_widget(form.time) }}
    </div>
{% endblock %}", ":Form:fields.html.twig", "/home/sorina/Documents/work/movies_crowler/app/Resources/views/Form/fields.html.twig");
    }
}
