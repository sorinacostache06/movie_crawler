<?php

/* :Admin:user_list.html.twig */
class __TwigTemplate_dce2b18a422204a5b05234d4e2943dffbe344976f5ff38f80151c9b31a6485be extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base-layout.html.twig", ":Admin:user_list.html.twig", 1);
        $this->blocks = array(
            'page_title' => array($this, 'block_page_title'),
            'page_subtitle' => array($this, 'block_page_subtitle'),
            'page_content' => array($this, 'block_page_content'),
            'flashBag' => array($this, 'block_flashBag'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base-layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_dbe9d99c1e7d66617c9ab529779914e8c97f58d14c18e3f29c0d6a5d1f75cf1e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_dbe9d99c1e7d66617c9ab529779914e8c97f58d14c18e3f29c0d6a5d1f75cf1e->enter($__internal_dbe9d99c1e7d66617c9ab529779914e8c97f58d14c18e3f29c0d6a5d1f75cf1e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Admin:user_list.html.twig"));

        $__internal_911bc551b00726362a19f09713c232f2a0b12bffcb74c24cfb80c44fd41741f6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_911bc551b00726362a19f09713c232f2a0b12bffcb74c24cfb80c44fd41741f6->enter($__internal_911bc551b00726362a19f09713c232f2a0b12bffcb74c24cfb80c44fd41741f6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Admin:user_list.html.twig"));

        // line 2
        ob_start();
        // line 3
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["manageForm"]) || array_key_exists("manageForm", $context) ? $context["manageForm"] : (function () { throw new Twig_Error_Runtime('Variable "manageForm" does not exist.', 3, $this->getSourceContext()); })()), "_token", array()), 'row', array("id" => "#id#"));
        echo "
";
        $context["form_token"] = ('' === $tmp = ob_get_clean()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        // line 6
        $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->setTheme((isset($context["filterForm"]) || array_key_exists("filterForm", $context) ? $context["filterForm"] : (function () { throw new Twig_Error_Runtime('Variable "filterForm" does not exist.', 6, $this->getSourceContext()); })()), array(0 => ":Form:fields.html.twig"));
        // line 1
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_dbe9d99c1e7d66617c9ab529779914e8c97f58d14c18e3f29c0d6a5d1f75cf1e->leave($__internal_dbe9d99c1e7d66617c9ab529779914e8c97f58d14c18e3f29c0d6a5d1f75cf1e_prof);

        
        $__internal_911bc551b00726362a19f09713c232f2a0b12bffcb74c24cfb80c44fd41741f6->leave($__internal_911bc551b00726362a19f09713c232f2a0b12bffcb74c24cfb80c44fd41741f6_prof);

    }

    // line 7
    public function block_page_title($context, array $blocks = array())
    {
        $__internal_05e4abbbca0bafa669af4cfa359316921a7d24a220b0bac6a34afddfdf462a36 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_05e4abbbca0bafa669af4cfa359316921a7d24a220b0bac6a34afddfdf462a36->enter($__internal_05e4abbbca0bafa669af4cfa359316921a7d24a220b0bac6a34afddfdf462a36_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_title"));

        $__internal_85581b9f6763050f12339cedac47f94b79f30be72fd9360f6520d87f16622553 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_85581b9f6763050f12339cedac47f94b79f30be72fd9360f6520d87f16622553->enter($__internal_85581b9f6763050f12339cedac47f94b79f30be72fd9360f6520d87f16622553_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_title"));

        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("navigation.user_management.title"), "html", null, true);
        
        $__internal_85581b9f6763050f12339cedac47f94b79f30be72fd9360f6520d87f16622553->leave($__internal_85581b9f6763050f12339cedac47f94b79f30be72fd9360f6520d87f16622553_prof);

        
        $__internal_05e4abbbca0bafa669af4cfa359316921a7d24a220b0bac6a34afddfdf462a36->leave($__internal_05e4abbbca0bafa669af4cfa359316921a7d24a220b0bac6a34afddfdf462a36_prof);

    }

    // line 8
    public function block_page_subtitle($context, array $blocks = array())
    {
        $__internal_b9dbb2b36c1d2d9f9e035a7626fc9bda848f46559e61c10529c2f7f550149d5a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b9dbb2b36c1d2d9f9e035a7626fc9bda848f46559e61c10529c2f7f550149d5a->enter($__internal_b9dbb2b36c1d2d9f9e035a7626fc9bda848f46559e61c10529c2f7f550149d5a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_subtitle"));

        $__internal_86ee6e1c27ad27954d212240c2f4fbe944f34a439e752b6dee239f115dfb773e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_86ee6e1c27ad27954d212240c2f4fbe944f34a439e752b6dee239f115dfb773e->enter($__internal_86ee6e1c27ad27954d212240c2f4fbe944f34a439e752b6dee239f115dfb773e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_subtitle"));

        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("navigation.user_management.subtitle"), "html", null, true);
        
        $__internal_86ee6e1c27ad27954d212240c2f4fbe944f34a439e752b6dee239f115dfb773e->leave($__internal_86ee6e1c27ad27954d212240c2f4fbe944f34a439e752b6dee239f115dfb773e_prof);

        
        $__internal_b9dbb2b36c1d2d9f9e035a7626fc9bda848f46559e61c10529c2f7f550149d5a->leave($__internal_b9dbb2b36c1d2d9f9e035a7626fc9bda848f46559e61c10529c2f7f550149d5a_prof);

    }

    // line 9
    public function block_page_content($context, array $blocks = array())
    {
        $__internal_03c835127bbb11b33746821f90dbd2c9d1957e3af5af57af72bb4609cce5fabe = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_03c835127bbb11b33746821f90dbd2c9d1957e3af5af57af72bb4609cce5fabe->enter($__internal_03c835127bbb11b33746821f90dbd2c9d1957e3af5af57af72bb4609cce5fabe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_content"));

        $__internal_0f5a46f219706971facdfaa80f51b87a07939a076d825cf2f32a1c7a1eb00875 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0f5a46f219706971facdfaa80f51b87a07939a076d825cf2f32a1c7a1eb00875->enter($__internal_0f5a46f219706971facdfaa80f51b87a07939a076d825cf2f32a1c7a1eb00875_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_content"));

        // line 10
        echo "    <div class=\"row\">
        <div class=\"col-lg-8 col-md-8 col-lg-offset-2 col-md-offset-2\">
            ";
        // line 12
        $this->displayBlock('flashBag', $context, $blocks);
        // line 15
        echo "        </div>
    </div>
    <div class=\"row\">
        <div class=\"col-lg-12 col-md-12\">
            <div class=\"box box-info\">
                <div class=\"box-header with-border\">
                    <h3 class=\"box-title\">";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("user_management.table.title"), "html", null, true);
        echo "</h3>
                </div>
                <div class=\"box-body table-bordered\">
                    <span style=\"float:left\">
                        ";
        // line 25
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["filterForm"]) || array_key_exists("filterForm", $context) ? $context["filterForm"] : (function () { throw new Twig_Error_Runtime('Variable "filterForm" does not exist.', 25, $this->getSourceContext()); })()), 'form_start', array("method" => "get"));
        echo "
                        <div class=\"row\" style=\"margin-left: 20px; margin-right: 20px;\">
                        <div class=\"col-lg-2\">
                            ";
        // line 28
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["filterForm"]) || array_key_exists("filterForm", $context) ? $context["filterForm"] : (function () { throw new Twig_Error_Runtime('Variable "filterForm" does not exist.', 28, $this->getSourceContext()); })()), "results", array()), 'row');
        echo "
                        </div>
                        <div class=\"col-lg-11\">
                            ";
        // line 31
        if ((isset($context["pagination"]) || array_key_exists("pagination", $context) ? $context["pagination"] : (function () { throw new Twig_Error_Runtime('Variable "pagination" does not exist.', 31, $this->getSourceContext()); })())) {
            // line 32
            echo "                                <ul class=\"pagination pagination-sm no-margin pull-right\">
                                    ";
            // line 33
            echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->render($this->env, (isset($context["pagination"]) || array_key_exists("pagination", $context) ? $context["pagination"] : (function () { throw new Twig_Error_Runtime('Variable "pagination" does not exist.', 33, $this->getSourceContext()); })()), "::adminlte_pagination.html.twig");
            echo "
                                </ul>
                            ";
        }
        // line 36
        echo "                        </div>
                    </div>
                    <table class=\"table table-bordered table-hover dataTable\" role=\"grid\" id=\"voucher_requests\">
                        <thead>
                        ";
        // line 40
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["filterForm"]) || array_key_exists("filterForm", $context) ? $context["filterForm"] : (function () { throw new Twig_Error_Runtime('Variable "filterForm" does not exist.', 40, $this->getSourceContext()); })()), 'form_start', array("method" => "get"));
        echo "
                        ";
        // line 41
        if ( !twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["filterForm"]) || array_key_exists("filterForm", $context) ? $context["filterForm"] : (function () { throw new Twig_Error_Runtime('Variable "filterForm" does not exist.', 41, $this->getSourceContext()); })()), "vars", array()), "valid", array())) {
            // line 42
            echo "                            <tr role=\"row\" align=\"center\">
                            <td colspan=\"6\">
                                ";
            // line 44
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock((isset($context["filterForm"]) || array_key_exists("filterForm", $context) ? $context["filterForm"] : (function () { throw new Twig_Error_Runtime('Variable "filterForm" does not exist.', 44, $this->getSourceContext()); })()), 'errors', array("method" => "get", "attr" => array("class" => "form-inline")));
            echo "
                            </td>
                        </tr>
                        ";
        }
        // line 48
        echo "                        ";
        if ((isset($context["pagination"]) || array_key_exists("pagination", $context) ? $context["pagination"] : (function () { throw new Twig_Error_Runtime('Variable "pagination" does not exist.', 48, $this->getSourceContext()); })())) {
            // line 49
            echo "                        <tr role=\"row\" align=\"center\" style=\"padding:0\">
                            <th width=\"10%\">";
            // line 50
            echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) || array_key_exists("pagination", $context) ? $context["pagination"] : (function () { throw new Twig_Error_Runtime('Variable "pagination" does not exist.', 50, $this->getSourceContext()); })()), $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("user_management.table.id"), "u.id");
            echo "</th>
                            <th width=\"10%\">";
            // line 51
            echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) || array_key_exists("pagination", $context) ? $context["pagination"] : (function () { throw new Twig_Error_Runtime('Variable "pagination" does not exist.', 51, $this->getSourceContext()); })()), $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("user_management.table.name"), "u.username");
            echo "</th>
                            <th width=\"30%\">";
            // line 52
            echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) || array_key_exists("pagination", $context) ? $context["pagination"] : (function () { throw new Twig_Error_Runtime('Variable "pagination" does not exist.', 52, $this->getSourceContext()); })()), $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("user_management.table.join_date"), "u.joinDate");
            echo "</th>
                            <th width=\"10%\">";
            // line 53
            echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) || array_key_exists("pagination", $context) ? $context["pagination"] : (function () { throw new Twig_Error_Runtime('Variable "pagination" does not exist.', 53, $this->getSourceContext()); })()), $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("user_management.table.email"), "u.email");
            echo "</th>
                            <th width=\"10%\">";
            // line 54
            echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->sortable($this->env, (isset($context["pagination"]) || array_key_exists("pagination", $context) ? $context["pagination"] : (function () { throw new Twig_Error_Runtime('Variable "pagination" does not exist.', 54, $this->getSourceContext()); })()), $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("user_management.table.user_enabled"), "u.enabled");
            echo "</th>
                            <th width=\"10%\">";
            // line 55
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("user_management.table.actions"), "html", null, true);
            echo "</th>
                        </tr>
                        </thead>
                        <tbody>
                    ";
            // line 59
            if (twig_test_empty((isset($context["pagination"]) || array_key_exists("pagination", $context) ? $context["pagination"] : (function () { throw new Twig_Error_Runtime('Variable "pagination" does not exist.', 59, $this->getSourceContext()); })()))) {
                // line 60
                echo "                    <tr role=\"row\" align=\"center\">
                            <td colspan=\"7\">
                                <div class=\"alert alert-info alert-dismissible\">
                                <button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>
                                <h4><i class=\"icon fa fa-info\"></i> Alert!</h4>
                                    ";
                // line 65
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("generic.table.no_results"), "html", null, true);
                echo "
                                </div>
                            </td>
                        </tr>
                    ";
            } else {
                // line 70
                echo "                    <tr role=\"row\" align=\"center\" style=\"padding:0\">
                            <td>
                                ";
                // line 72
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["filterForm"]) || array_key_exists("filterForm", $context) ? $context["filterForm"] : (function () { throw new Twig_Error_Runtime('Variable "filterForm" does not exist.', 72, $this->getSourceContext()); })()), "id", array()), 'row', array("attr" => array("placeholder" => "user_management.form.placeholder.id")));
                echo "
                            </td>
                            <td>
                                ";
                // line 75
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["filterForm"]) || array_key_exists("filterForm", $context) ? $context["filterForm"] : (function () { throw new Twig_Error_Runtime('Variable "filterForm" does not exist.', 75, $this->getSourceContext()); })()), "username", array()), 'row', array("attr" => array("placeholder" => "user_management.form.placeholder.username")));
                echo "
                            </td>
                            <td>
                                ";
                // line 78
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["filterForm"]) || array_key_exists("filterForm", $context) ? $context["filterForm"] : (function () { throw new Twig_Error_Runtime('Variable "filterForm" does not exist.', 78, $this->getSourceContext()); })()), "joinDate", array()), 'row', array("attr" => array("placeholder" => "user_management.form.placeholder.joinDate")));
                echo "
                            </td>
                            <td>
                                ";
                // line 81
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["filterForm"]) || array_key_exists("filterForm", $context) ? $context["filterForm"] : (function () { throw new Twig_Error_Runtime('Variable "filterForm" does not exist.', 81, $this->getSourceContext()); })()), "email", array()), 'row', array("attr" => array("placeholder" => "user_management.form.placeholder.email")));
                echo "
                            </td>
                            <td>
                                ";
                // line 84
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["filterForm"]) || array_key_exists("filterForm", $context) ? $context["filterForm"] : (function () { throw new Twig_Error_Runtime('Variable "filterForm" does not exist.', 84, $this->getSourceContext()); })()), "enabled", array()), 'row');
                echo "
                            </td>
                            <td>
                                <button type=\"submit\" id=\"user_filter_submit\" name=\"submit\"
                                        class=\"btn btn-primary btn-flat\">
                                    <i class=\"glyphicon glyphicon-filter\"></i></button>
                                ";
                // line 90
                echo                 $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["filterForm"]) || array_key_exists("filterForm", $context) ? $context["filterForm"] : (function () { throw new Twig_Error_Runtime('Variable "filterForm" does not exist.', 90, $this->getSourceContext()); })()), 'form_end');
                echo "
                            </td>
                        </tr>
                    ";
                // line 93
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable((isset($context["pagination"]) || array_key_exists("pagination", $context) ? $context["pagination"] : (function () { throw new Twig_Error_Runtime('Variable "pagination" does not exist.', 93, $this->getSourceContext()); })()));
                $context['loop'] = array(
                  'parent' => $context['_parent'],
                  'index0' => 0,
                  'index'  => 1,
                  'first'  => true,
                );
                if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                    $length = count($context['_seq']);
                    $context['loop']['revindex0'] = $length - 1;
                    $context['loop']['revindex'] = $length;
                    $context['loop']['length'] = $length;
                    $context['loop']['last'] = 1 === $length;
                }
                foreach ($context['_seq'] as $context["_key"] => $context["user"]) {
                    // line 94
                    echo "                        <tr role=\"row\" align=\"center\" style=\"padding:0\">
                                <td>";
                    // line 95
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["user"], "id", array()), "html", null, true);
                    echo "</td>
                                <td>";
                    // line 96
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["user"], "username", array()), "html", null, true);
                    echo "</td>
                                <td>";
                    // line 97
                    echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["user"], "joinDate", array()), "d/m/Y H:i:s"), "html", null, true);
                    echo "</td>
                                <td>";
                    // line 98
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["user"], "email", array()), "html", null, true);
                    echo "</td>
                                <td>";
                    // line 99
                    if ((twig_get_attribute($this->env, $this->getSourceContext(), $context["user"], "enabled", array()) == 1)) {
                        // line 100
                        echo "                                        <span class=\"label label-success\" style=\"font-size: 12px\">Enabled</span>
                                    ";
                    } else {
                        // line 102
                        echo "                                        <span class=\"label label-danger\" style=\"font-size: 12px\">Disabled</span>
                                    ";
                    }
                    // line 104
                    echo "                                </td>
                                <td>
                                    <span style=\"float: none\">
                                    ";
                    // line 107
                    echo                     $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["manageForm"]) || array_key_exists("manageForm", $context) ? $context["manageForm"] : (function () { throw new Twig_Error_Runtime('Variable "manageForm" does not exist.', 107, $this->getSourceContext()); })()), 'form_start', array("method" => "post", "attr" => array("class" => "form-inline")));
                    echo "
                                        ";
                    // line 108
                    echo twig_replace_filter((isset($context["form_token"]) || array_key_exists("form_token", $context) ? $context["form_token"] : (function () { throw new Twig_Error_Runtime('Variable "form_token" does not exist.', 108, $this->getSourceContext()); })()), array("#id#" => ("user_management__token_" . twig_get_attribute($this->env, $this->getSourceContext(), $context["user"], "id", array()))));
                    echo "
                                        ";
                    // line 109
                    if ((twig_get_attribute($this->env, $this->getSourceContext(), $context["user"], "enabled", array()) == 0)) {
                        // line 110
                        echo "                                            ";
                        // line 111
                        echo "                                            ";
                        // line 112
                        echo "                                            ";
                        // line 113
                        echo "                                            ";
                        $this->loadTemplate(":Components:popup.html.twig", ":Admin:user_list.html.twig", 113)->display(array_merge($context, array("color" => "success", "button" => "<i class='fa fa-check'></i>", "action" => $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_management_activate", array("id" => twig_get_attribute($this->env, $this->getSourceContext(),                         // line 116
$context["user"], "id", array()))), "id" => twig_get_attribute($this->env, $this->getSourceContext(),                         // line 117
$context["user"], "id", array()), "type" => "activateUser")));
                        // line 121
                        echo "                                        ";
                    } else {
                        // line 122
                        echo "                                            ";
                        $this->loadTemplate(":Components:popup.html.twig", ":Admin:user_list.html.twig", 122)->display(array_merge($context, array("color" => "danger", "button" => "<i class='fa fa-close'></i>", "action" => $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_management_deactivate", array("id" => twig_get_attribute($this->env, $this->getSourceContext(),                         // line 125
$context["user"], "id", array()))), "id" => twig_get_attribute($this->env, $this->getSourceContext(),                         // line 126
$context["user"], "id", array()), "type" => "deactivateUser")));
                        // line 130
                        echo "                                        ";
                    }
                    // line 131
                    echo "                                        ";
                    echo                     $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["manageForm"]) || array_key_exists("manageForm", $context) ? $context["manageForm"] : (function () { throw new Twig_Error_Runtime('Variable "manageForm" does not exist.', 131, $this->getSourceContext()); })()), 'form_end');
                    echo "
                                    </span>
                                </td>
                            </tr>
                    ";
                    ++$context['loop']['index0'];
                    ++$context['loop']['index'];
                    $context['loop']['first'] = false;
                    if (isset($context['loop']['length'])) {
                        --$context['loop']['revindex0'];
                        --$context['loop']['revindex'];
                        $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                    }
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['user'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 136
                echo "                        </tbody>
                        ";
            }
            // line 138
            echo "                        ";
        }
        // line 139
        echo "                    </table>
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_0f5a46f219706971facdfaa80f51b87a07939a076d825cf2f32a1c7a1eb00875->leave($__internal_0f5a46f219706971facdfaa80f51b87a07939a076d825cf2f32a1c7a1eb00875_prof);

        
        $__internal_03c835127bbb11b33746821f90dbd2c9d1957e3af5af57af72bb4609cce5fabe->leave($__internal_03c835127bbb11b33746821f90dbd2c9d1957e3af5af57af72bb4609cce5fabe_prof);

    }

    // line 12
    public function block_flashBag($context, array $blocks = array())
    {
        $__internal_b3aa2f11bf3e5b1be7ee8dae885d9bb6ebd5c892b9f8075ceb8909b2f7e956a9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b3aa2f11bf3e5b1be7ee8dae885d9bb6ebd5c892b9f8075ceb8909b2f7e956a9->enter($__internal_b3aa2f11bf3e5b1be7ee8dae885d9bb6ebd5c892b9f8075ceb8909b2f7e956a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "flashBag"));

        $__internal_9c322daffc5e34459be44e9c507dd37d306524c0146a1e8d38677dc3db7d0381 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9c322daffc5e34459be44e9c507dd37d306524c0146a1e8d38677dc3db7d0381->enter($__internal_9c322daffc5e34459be44e9c507dd37d306524c0146a1e8d38677dc3db7d0381_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "flashBag"));

        // line 13
        echo "                ";
        $this->displayParentBlock("flashBag", $context, $blocks);
        echo "
            ";
        
        $__internal_9c322daffc5e34459be44e9c507dd37d306524c0146a1e8d38677dc3db7d0381->leave($__internal_9c322daffc5e34459be44e9c507dd37d306524c0146a1e8d38677dc3db7d0381_prof);

        
        $__internal_b3aa2f11bf3e5b1be7ee8dae885d9bb6ebd5c892b9f8075ceb8909b2f7e956a9->leave($__internal_b3aa2f11bf3e5b1be7ee8dae885d9bb6ebd5c892b9f8075ceb8909b2f7e956a9_prof);

    }

    // line 146
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_89332d4c8739eb936097146158082979130038040e510698488c8f413325782b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_89332d4c8739eb936097146158082979130038040e510698488c8f413325782b->enter($__internal_89332d4c8739eb936097146158082979130038040e510698488c8f413325782b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_72aeb663e64be9157f7d7c0f1509dae9d2f430e48651142af7aec1e87e2151d9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_72aeb663e64be9157f7d7c0f1509dae9d2f430e48651142af7aec1e87e2151d9->enter($__internal_72aeb663e64be9157f7d7c0f1509dae9d2f430e48651142af7aec1e87e2151d9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 147
        echo "     ";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "
     <script type=\"text/javascript\">
         \$(function () {
             \$('#user_filter_joinDate').datetimepicker();
             \$(joinDate)({
                 useCurrent: false});
         });
     </script>
 ";
        
        $__internal_72aeb663e64be9157f7d7c0f1509dae9d2f430e48651142af7aec1e87e2151d9->leave($__internal_72aeb663e64be9157f7d7c0f1509dae9d2f430e48651142af7aec1e87e2151d9_prof);

        
        $__internal_89332d4c8739eb936097146158082979130038040e510698488c8f413325782b->leave($__internal_89332d4c8739eb936097146158082979130038040e510698488c8f413325782b_prof);

    }

    public function getTemplateName()
    {
        return ":Admin:user_list.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  416 => 147,  407 => 146,  394 => 13,  385 => 12,  370 => 139,  367 => 138,  363 => 136,  343 => 131,  340 => 130,  338 => 126,  337 => 125,  335 => 122,  332 => 121,  330 => 117,  329 => 116,  327 => 113,  325 => 112,  323 => 111,  321 => 110,  319 => 109,  315 => 108,  311 => 107,  306 => 104,  302 => 102,  298 => 100,  296 => 99,  292 => 98,  288 => 97,  284 => 96,  280 => 95,  277 => 94,  260 => 93,  254 => 90,  245 => 84,  239 => 81,  233 => 78,  227 => 75,  221 => 72,  217 => 70,  209 => 65,  202 => 60,  200 => 59,  193 => 55,  189 => 54,  185 => 53,  181 => 52,  177 => 51,  173 => 50,  170 => 49,  167 => 48,  160 => 44,  156 => 42,  154 => 41,  150 => 40,  144 => 36,  138 => 33,  135 => 32,  133 => 31,  127 => 28,  121 => 25,  114 => 21,  106 => 15,  104 => 12,  100 => 10,  91 => 9,  73 => 8,  55 => 7,  45 => 1,  43 => 6,  37 => 3,  35 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '::base-layout.html.twig' %}
{% set form_token %}
    {{ form_row(manageForm._token, {'id': \"#id#\"}) }}
{% endset %}

{% form_theme filterForm ':Form:fields.html.twig' %}
{% block page_title %}{{ 'navigation.user_management.title'|trans }}{% endblock %}
{% block page_subtitle %}{{ 'navigation.user_management.subtitle'|trans }}{% endblock %}
{% block page_content %}
    <div class=\"row\">
        <div class=\"col-lg-8 col-md-8 col-lg-offset-2 col-md-offset-2\">
            {% block flashBag %}
                {{ parent() }}
            {% endblock %}
        </div>
    </div>
    <div class=\"row\">
        <div class=\"col-lg-12 col-md-12\">
            <div class=\"box box-info\">
                <div class=\"box-header with-border\">
                    <h3 class=\"box-title\">{{ 'user_management.table.title'|trans }}</h3>
                </div>
                <div class=\"box-body table-bordered\">
                    <span style=\"float:left\">
                        {{ form_start(filterForm, { 'method' : 'get' }) }}
                        <div class=\"row\" style=\"margin-left: 20px; margin-right: 20px;\">
                        <div class=\"col-lg-2\">
                            {{ form_row(filterForm.results) }}
                        </div>
                        <div class=\"col-lg-11\">
                            {% if pagination %}
                                <ul class=\"pagination pagination-sm no-margin pull-right\">
                                    {{ knp_pagination_render(pagination, '::adminlte_pagination.html.twig') }}
                                </ul>
                            {% endif %}
                        </div>
                    </div>
                    <table class=\"table table-bordered table-hover dataTable\" role=\"grid\" id=\"voucher_requests\">
                        <thead>
                        {{ form_start(filterForm, { 'method' : 'get'}) }}
                        {% if not filterForm.vars.valid %}
                            <tr role=\"row\" align=\"center\">
                            <td colspan=\"6\">
                                {{ form_errors(filterForm, { 'method' : 'get', 'attr': {'class' : 'form-inline'}}) }}
                            </td>
                        </tr>
                        {% endif %}
                        {% if pagination %}
                        <tr role=\"row\" align=\"center\" style=\"padding:0\">
                            <th width=\"10%\">{{ knp_pagination_sortable(pagination, 'user_management.table.id'|trans, 'u.id') }}</th>
                            <th width=\"10%\">{{ knp_pagination_sortable(pagination, 'user_management.table.name'|trans, 'u.username') }}</th>
                            <th width=\"30%\">{{ knp_pagination_sortable(pagination, 'user_management.table.join_date'|trans, 'u.joinDate') }}</th>
                            <th width=\"10%\">{{ knp_pagination_sortable(pagination, 'user_management.table.email'|trans, 'u.email') }}</th>
                            <th width=\"10%\">{{ knp_pagination_sortable(pagination, 'user_management.table.user_enabled'|trans, 'u.enabled') }}</th>
                            <th width=\"10%\">{{ 'user_management.table.actions'|trans }}</th>
                        </tr>
                        </thead>
                        <tbody>
                    {% if pagination is empty %}
                    <tr role=\"row\" align=\"center\">
                            <td colspan=\"7\">
                                <div class=\"alert alert-info alert-dismissible\">
                                <button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>
                                <h4><i class=\"icon fa fa-info\"></i> Alert!</h4>
                                    {{ 'generic.table.no_results'|trans }}
                                </div>
                            </td>
                        </tr>
                    {% else %}
                    <tr role=\"row\" align=\"center\" style=\"padding:0\">
                            <td>
                                {{ form_row(filterForm.id, {'attr': {'placeholder' : 'user_management.form.placeholder.id'}}) }}
                            </td>
                            <td>
                                {{ form_row(filterForm.username, {'attr': {'placeholder' : 'user_management.form.placeholder.username'}}) }}
                            </td>
                            <td>
                                {{ form_row(filterForm.joinDate, {'attr': {'placeholder' : 'user_management.form.placeholder.joinDate'}}) }}
                            </td>
                            <td>
                                {{ form_row(filterForm.email, {'attr': {'placeholder' : 'user_management.form.placeholder.email'}}) }}
                            </td>
                            <td>
                                {{ form_row(filterForm.enabled) }}
                            </td>
                            <td>
                                <button type=\"submit\" id=\"user_filter_submit\" name=\"submit\"
                                        class=\"btn btn-primary btn-flat\">
                                    <i class=\"glyphicon glyphicon-filter\"></i></button>
                                {{ form_end(filterForm) }}
                            </td>
                        </tr>
                    {% for user in pagination %}
                        <tr role=\"row\" align=\"center\" style=\"padding:0\">
                                <td>{{ user.id }}</td>
                                <td>{{ user.username }}</td>
                                <td>{{ user.joinDate|date(\"d/m/Y H:i:s\") }}</td>
                                <td>{{ user.email }}</td>
                                <td>{% if user.enabled == 1 %}
                                        <span class=\"label label-success\" style=\"font-size: 12px\">Enabled</span>
                                    {% else %}
                                        <span class=\"label label-danger\" style=\"font-size: 12px\">Disabled</span>
                                    {% endif %}
                                </td>
                                <td>
                                    <span style=\"float: none\">
                                    {{ form_start(manageForm, { 'method' : 'post', 'attr' : {'class' : 'form-inline'}}) }}
                                        {{ form_token|replace({'#id#': 'user_management__token_'~user.id})|raw }}
                                        {% if user.enabled == 0 %}
                                            {#<button type=\"submit\" class=\"btn btn-success btn-flat form-control\"#}
                                            {#formaction=\"{{ path('user_management_activate', {'id': user.id }) }}\">#}
                                            {#<i class=\"fa fa-check\"></i></button>#}
                                            {% include ':Components:popup.html.twig' with{
                                            'color' : 'success',
                                            'button' : \"<i class='fa fa-check'></i>\",
                                            'action' : path('user_management_activate', {'id': user.id }),
                                            'id' : user.id,
                                            'type' : 'activateUser'
                                            }
                                            %}
                                        {% else %}
                                            {% include ':Components:popup.html.twig' with{
                                            'color' : 'danger',
                                            'button' : \"<i class='fa fa-close'></i>\",
                                            'action' : path('user_management_deactivate', {'id': user.id }),
                                            'id' : user.id,
                                            'type' : 'deactivateUser'
                                            }
                                            %}
                                        {% endif %}
                                        {{ form_end(manageForm) }}
                                    </span>
                                </td>
                            </tr>
                    {% endfor %}
                        </tbody>
                        {% endif %}
                        {% endif %}
                    </table>
                </div>
            </div>
        </div>
    </div>
{% endblock %}

 {% block javascripts %}
     {{ parent() }}
     <script type=\"text/javascript\">
         \$(function () {
             \$('#user_filter_joinDate').datetimepicker();
             \$(joinDate)({
                 useCurrent: false});
         });
     </script>
 {% endblock %}", ":Admin:user_list.html.twig", "/home/sorina/Documents/work/movies_crowler/app/Resources/views/Admin/user_list.html.twig");
    }
}
