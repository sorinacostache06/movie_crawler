<?php

/* TwigBundle:Exception:error.js.twig */
class __TwigTemplate_214f30eded20b357efb5ce5a2355345626de776ff3c9947170cc1c6f68876929 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_61159e4c3e5b8be17f0a025d848cbd3c3c99e0262ce23e00b4aed32d0624dab0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_61159e4c3e5b8be17f0a025d848cbd3c3c99e0262ce23e00b4aed32d0624dab0->enter($__internal_61159e4c3e5b8be17f0a025d848cbd3c3c99e0262ce23e00b4aed32d0624dab0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.js.twig"));

        $__internal_78c4b31d0a9c59ef4b7703412331b226043c73ef55dbb92f9b70677f14a045f1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_78c4b31d0a9c59ef4b7703412331b226043c73ef55dbb92f9b70677f14a045f1->enter($__internal_78c4b31d0a9c59ef4b7703412331b226043c73ef55dbb92f9b70677f14a045f1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, (isset($context["status_code"]) || array_key_exists("status_code", $context) ? $context["status_code"] : (function () { throw new Twig_Error_Runtime('Variable "status_code" does not exist.', 2, $this->getSourceContext()); })()), "js", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) || array_key_exists("status_text", $context) ? $context["status_text"] : (function () { throw new Twig_Error_Runtime('Variable "status_text" does not exist.', 2, $this->getSourceContext()); })()), "js", null, true);
        echo "

*/
";
        
        $__internal_61159e4c3e5b8be17f0a025d848cbd3c3c99e0262ce23e00b4aed32d0624dab0->leave($__internal_61159e4c3e5b8be17f0a025d848cbd3c3c99e0262ce23e00b4aed32d0624dab0_prof);

        
        $__internal_78c4b31d0a9c59ef4b7703412331b226043c73ef55dbb92f9b70677f14a045f1->leave($__internal_78c4b31d0a9c59ef4b7703412331b226043c73ef55dbb92f9b70677f14a045f1_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ status_code }} {{ status_text }}

*/
", "TwigBundle:Exception:error.js.twig", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/error.js.twig");
    }
}
