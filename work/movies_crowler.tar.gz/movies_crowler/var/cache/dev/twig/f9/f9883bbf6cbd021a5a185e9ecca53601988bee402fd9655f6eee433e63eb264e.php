<?php

/* @Framework/FormTable/button_row.html.php */
class __TwigTemplate_85eff6a1862f26d56477c559f201128cf98de680ce4054a606becc97d9a071e4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2f30dc60d1d6ff750118f59dce9a1f84e642a53e8a24ef2b5115dab5d85dfb80 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2f30dc60d1d6ff750118f59dce9a1f84e642a53e8a24ef2b5115dab5d85dfb80->enter($__internal_2f30dc60d1d6ff750118f59dce9a1f84e642a53e8a24ef2b5115dab5d85dfb80_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        $__internal_e7430f835ee29045a89963d95e55279d2d220b7f200660313638fe16f8035d6b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e7430f835ee29045a89963d95e55279d2d220b7f200660313638fe16f8035d6b->enter($__internal_e7430f835ee29045a89963d95e55279d2d220b7f200660313638fe16f8035d6b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        // line 1
        echo "<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_2f30dc60d1d6ff750118f59dce9a1f84e642a53e8a24ef2b5115dab5d85dfb80->leave($__internal_2f30dc60d1d6ff750118f59dce9a1f84e642a53e8a24ef2b5115dab5d85dfb80_prof);

        
        $__internal_e7430f835ee29045a89963d95e55279d2d220b7f200660313638fe16f8035d6b->leave($__internal_e7430f835ee29045a89963d95e55279d2d220b7f200660313638fe16f8035d6b_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
", "@Framework/FormTable/button_row.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/FormTable/button_row.html.php");
    }
}
