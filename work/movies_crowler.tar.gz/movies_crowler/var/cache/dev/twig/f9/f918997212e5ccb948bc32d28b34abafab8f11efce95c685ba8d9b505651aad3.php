<?php

/* @Framework/Form/attributes.html.php */
class __TwigTemplate_ecb4c91d2e30afb79caee5dbf3d36f391aafa70b494ba20599e151b587e08de6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_663da5d14eeefea52f6802bde6a51b3406ebb9e322531cc87c666af3284243ae = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_663da5d14eeefea52f6802bde6a51b3406ebb9e322531cc87c666af3284243ae->enter($__internal_663da5d14eeefea52f6802bde6a51b3406ebb9e322531cc87c666af3284243ae_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/attributes.html.php"));

        $__internal_d51eb2c89cc97ff281d22753396773baefbb10982f358585cf7cff3becb854f7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d51eb2c89cc97ff281d22753396773baefbb10982f358585cf7cff3becb854f7->enter($__internal_d51eb2c89cc97ff281d22753396773baefbb10982f358585cf7cff3becb854f7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
";
        
        $__internal_663da5d14eeefea52f6802bde6a51b3406ebb9e322531cc87c666af3284243ae->leave($__internal_663da5d14eeefea52f6802bde6a51b3406ebb9e322531cc87c666af3284243ae_prof);

        
        $__internal_d51eb2c89cc97ff281d22753396773baefbb10982f358585cf7cff3becb854f7->leave($__internal_d51eb2c89cc97ff281d22753396773baefbb10982f358585cf7cff3becb854f7_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
", "@Framework/Form/attributes.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/attributes.html.php");
    }
}
