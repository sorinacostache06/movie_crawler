<?php

/* @Framework/FormTable/form_row.html.php */
class __TwigTemplate_d84221b824af51745a99c41ddaca074e24728ca17abbac226e2bf8e265deb51d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_284f855e8b105e8fffd0fdf2d2080d904677aacd9b00c17fc71ed652bc4568bc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_284f855e8b105e8fffd0fdf2d2080d904677aacd9b00c17fc71ed652bc4568bc->enter($__internal_284f855e8b105e8fffd0fdf2d2080d904677aacd9b00c17fc71ed652bc4568bc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_row.html.php"));

        $__internal_fc5514c48663c965a5c7bdcd84e26036341561112f097d22a9f6e48c49bfb2fc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fc5514c48663c965a5c7bdcd84e26036341561112f097d22a9f6e48c49bfb2fc->enter($__internal_fc5514c48663c965a5c7bdcd84e26036341561112f097d22a9f6e48c49bfb2fc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_row.html.php"));

        // line 1
        echo "<tr>
    <td>
        <?php echo \$view['form']->label(\$form) ?>
    </td>
    <td>
        <?php echo \$view['form']->errors(\$form) ?>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_284f855e8b105e8fffd0fdf2d2080d904677aacd9b00c17fc71ed652bc4568bc->leave($__internal_284f855e8b105e8fffd0fdf2d2080d904677aacd9b00c17fc71ed652bc4568bc_prof);

        
        $__internal_fc5514c48663c965a5c7bdcd84e26036341561112f097d22a9f6e48c49bfb2fc->leave($__internal_fc5514c48663c965a5c7bdcd84e26036341561112f097d22a9f6e48c49bfb2fc_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr>
    <td>
        <?php echo \$view['form']->label(\$form) ?>
    </td>
    <td>
        <?php echo \$view['form']->errors(\$form) ?>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
", "@Framework/FormTable/form_row.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/FormTable/form_row.html.php");
    }
}
