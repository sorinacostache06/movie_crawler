<?php

/* TwigBundle:Exception:error.css.twig */
class __TwigTemplate_de72991a1e1897445a01bef40498f34e919708e7f6d624d5be8fbe6eca56536f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_38b396e4db7f53de7fd73c889c134d9cd45fc70a0fead952aa9dd079b5c59418 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_38b396e4db7f53de7fd73c889c134d9cd45fc70a0fead952aa9dd079b5c59418->enter($__internal_38b396e4db7f53de7fd73c889c134d9cd45fc70a0fead952aa9dd079b5c59418_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.css.twig"));

        $__internal_e0f4956b07d5f4c61f9b6a72a04b17a2d3f0c0531ba9560ec0f4444bbd6ea54a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e0f4956b07d5f4c61f9b6a72a04b17a2d3f0c0531ba9560ec0f4444bbd6ea54a->enter($__internal_e0f4956b07d5f4c61f9b6a72a04b17a2d3f0c0531ba9560ec0f4444bbd6ea54a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, (isset($context["status_code"]) || array_key_exists("status_code", $context) ? $context["status_code"] : (function () { throw new Twig_Error_Runtime('Variable "status_code" does not exist.', 2, $this->getSourceContext()); })()), "css", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) || array_key_exists("status_text", $context) ? $context["status_text"] : (function () { throw new Twig_Error_Runtime('Variable "status_text" does not exist.', 2, $this->getSourceContext()); })()), "css", null, true);
        echo "

*/
";
        
        $__internal_38b396e4db7f53de7fd73c889c134d9cd45fc70a0fead952aa9dd079b5c59418->leave($__internal_38b396e4db7f53de7fd73c889c134d9cd45fc70a0fead952aa9dd079b5c59418_prof);

        
        $__internal_e0f4956b07d5f4c61f9b6a72a04b17a2d3f0c0531ba9560ec0f4444bbd6ea54a->leave($__internal_e0f4956b07d5f4c61f9b6a72a04b17a2d3f0c0531ba9560ec0f4444bbd6ea54a_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ status_code }} {{ status_text }}

*/
", "TwigBundle:Exception:error.css.twig", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/error.css.twig");
    }
}
