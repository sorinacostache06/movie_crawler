<?php

/* @Framework/Form/radio_widget.html.php */
class __TwigTemplate_4c74c254d50f415bb54fe1ee0b1d9f908111b0109af35f77cf909e221a87e29a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fdaed339f507100e9af64dee09291fc4f0bf1b6651cf61fa52837f4a5b38a97c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fdaed339f507100e9af64dee09291fc4f0bf1b6651cf61fa52837f4a5b38a97c->enter($__internal_fdaed339f507100e9af64dee09291fc4f0bf1b6651cf61fa52837f4a5b38a97c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/radio_widget.html.php"));

        $__internal_10eeb51ba11cce68df6817501f81db6db0d26422c46aa3388c61539271431129 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_10eeb51ba11cce68df6817501f81db6db0d26422c46aa3388c61539271431129->enter($__internal_10eeb51ba11cce68df6817501f81db6db0d26422c46aa3388c61539271431129_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/radio_widget.html.php"));

        // line 1
        echo "<input type=\"radio\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    value=\"<?php echo \$view->escape(\$value) ?>\"
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_fdaed339f507100e9af64dee09291fc4f0bf1b6651cf61fa52837f4a5b38a97c->leave($__internal_fdaed339f507100e9af64dee09291fc4f0bf1b6651cf61fa52837f4a5b38a97c_prof);

        
        $__internal_10eeb51ba11cce68df6817501f81db6db0d26422c46aa3388c61539271431129->leave($__internal_10eeb51ba11cce68df6817501f81db6db0d26422c46aa3388c61539271431129_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/radio_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<input type=\"radio\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    value=\"<?php echo \$view->escape(\$value) ?>\"
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
", "@Framework/Form/radio_widget.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/radio_widget.html.php");
    }
}
