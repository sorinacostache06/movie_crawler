<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_1bcec1624f7aceefedc75d593e3edb83d1627374cf65a1d6f5ae7b6a726c4b75 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a581095999a0c301e2489473502b2a763c95bf782b9a47e110871ec7c9398faf = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a581095999a0c301e2489473502b2a763c95bf782b9a47e110871ec7c9398faf->enter($__internal_a581095999a0c301e2489473502b2a763c95bf782b9a47e110871ec7c9398faf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        $__internal_3746d767c957a9847f7905dd48bc913fc0362f3d4f781af2cd6c7551c9fbcf83 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3746d767c957a9847f7905dd48bc913fc0362f3d4f781af2cd6c7551c9fbcf83->enter($__internal_3746d767c957a9847f7905dd48bc913fc0362f3d4f781af2cd6c7551c9fbcf83_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_a581095999a0c301e2489473502b2a763c95bf782b9a47e110871ec7c9398faf->leave($__internal_a581095999a0c301e2489473502b2a763c95bf782b9a47e110871ec7c9398faf_prof);

        
        $__internal_3746d767c957a9847f7905dd48bc913fc0362f3d4f781af2cd6c7551c9fbcf83->leave($__internal_3746d767c957a9847f7905dd48bc913fc0362f3d4f781af2cd6c7551c9fbcf83_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_8d92c9073b814157a862d24cfe8dd84945f7175f22f04a353d793cedbd27f700 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8d92c9073b814157a862d24cfe8dd84945f7175f22f04a353d793cedbd27f700->enter($__internal_8d92c9073b814157a862d24cfe8dd84945f7175f22f04a353d793cedbd27f700_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_be36292655c10f8255763f63c5753d988f4fd4c3a301f3cd229d00d42769c865 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_be36292655c10f8255763f63c5753d988f4fd4c3a301f3cd229d00d42769c865->enter($__internal_be36292655c10f8255763f63c5753d988f4fd4c3a301f3cd229d00d42769c865_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_be36292655c10f8255763f63c5753d988f4fd4c3a301f3cd229d00d42769c865->leave($__internal_be36292655c10f8255763f63c5753d988f4fd4c3a301f3cd229d00d42769c865_prof);

        
        $__internal_8d92c9073b814157a862d24cfe8dd84945f7175f22f04a353d793cedbd27f700->leave($__internal_8d92c9073b814157a862d24cfe8dd84945f7175f22f04a353d793cedbd27f700_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  26 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "WebProfilerBundle:Profiler:ajax_layout.html.twig", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Profiler/ajax_layout.html.twig");
    }
}
