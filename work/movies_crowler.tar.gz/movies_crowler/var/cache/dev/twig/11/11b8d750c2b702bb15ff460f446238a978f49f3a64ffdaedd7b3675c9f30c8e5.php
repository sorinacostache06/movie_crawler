<?php

/* @WebProfiler/Collector/exception.html.twig */
class __TwigTemplate_7ca3ada4da8f60d8f3dbd3ab3a217f4d90e48bbc267ad11a642dec168fcd8f72 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0f5b6ebe840fb9bd9bdc1751438cc53b37d3706b801e47bf2b42107deeb42010 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0f5b6ebe840fb9bd9bdc1751438cc53b37d3706b801e47bf2b42107deeb42010->enter($__internal_0f5b6ebe840fb9bd9bdc1751438cc53b37d3706b801e47bf2b42107deeb42010_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $__internal_f6253ad96d1e794dede0f6f695a2efbd0a07d5985526940c01a75d05cb53618d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f6253ad96d1e794dede0f6f695a2efbd0a07d5985526940c01a75d05cb53618d->enter($__internal_f6253ad96d1e794dede0f6f695a2efbd0a07d5985526940c01a75d05cb53618d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_0f5b6ebe840fb9bd9bdc1751438cc53b37d3706b801e47bf2b42107deeb42010->leave($__internal_0f5b6ebe840fb9bd9bdc1751438cc53b37d3706b801e47bf2b42107deeb42010_prof);

        
        $__internal_f6253ad96d1e794dede0f6f695a2efbd0a07d5985526940c01a75d05cb53618d->leave($__internal_f6253ad96d1e794dede0f6f695a2efbd0a07d5985526940c01a75d05cb53618d_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_a20569e2cd6c31b5bd35eba798b17e1caf3bba216ddafffaf647ec796e56d32b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a20569e2cd6c31b5bd35eba798b17e1caf3bba216ddafffaf647ec796e56d32b->enter($__internal_a20569e2cd6c31b5bd35eba798b17e1caf3bba216ddafffaf647ec796e56d32b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_f05372d901ff1748252fe2e42f8b2ccc5a8ee5314181a5e647c571fc8bcbfd37 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f05372d901ff1748252fe2e42f8b2ccc5a8ee5314181a5e647c571fc8bcbfd37->enter($__internal_f05372d901ff1748252fe2e42f8b2ccc5a8ee5314181a5e647c571fc8bcbfd37_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if (twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["collector"]) || array_key_exists("collector", $context) ? $context["collector"] : (function () { throw new Twig_Error_Runtime('Variable "collector" does not exist.', 4, $this->getSourceContext()); })()), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => (isset($context["token"]) || array_key_exists("token", $context) ? $context["token"] : (function () { throw new Twig_Error_Runtime('Variable "token" does not exist.', 6, $this->getSourceContext()); })()))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_f05372d901ff1748252fe2e42f8b2ccc5a8ee5314181a5e647c571fc8bcbfd37->leave($__internal_f05372d901ff1748252fe2e42f8b2ccc5a8ee5314181a5e647c571fc8bcbfd37_prof);

        
        $__internal_a20569e2cd6c31b5bd35eba798b17e1caf3bba216ddafffaf647ec796e56d32b->leave($__internal_a20569e2cd6c31b5bd35eba798b17e1caf3bba216ddafffaf647ec796e56d32b_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_407b5c449d16105c646f17f5dd97d143c46f76c33f343a5646282c180f29b076 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_407b5c449d16105c646f17f5dd97d143c46f76c33f343a5646282c180f29b076->enter($__internal_407b5c449d16105c646f17f5dd97d143c46f76c33f343a5646282c180f29b076_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_fa79cfaeca3f63f6be3104d092a36663f6c56bdb48220e795c3c0914e53e67f4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fa79cfaeca3f63f6be3104d092a36663f6c56bdb48220e795c3c0914e53e67f4->enter($__internal_fa79cfaeca3f63f6be3104d092a36663f6c56bdb48220e795c3c0914e53e67f4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo ((twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["collector"]) || array_key_exists("collector", $context) ? $context["collector"] : (function () { throw new Twig_Error_Runtime('Variable "collector" does not exist.', 13, $this->getSourceContext()); })()), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if (twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["collector"]) || array_key_exists("collector", $context) ? $context["collector"] : (function () { throw new Twig_Error_Runtime('Variable "collector" does not exist.', 16, $this->getSourceContext()); })()), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_fa79cfaeca3f63f6be3104d092a36663f6c56bdb48220e795c3c0914e53e67f4->leave($__internal_fa79cfaeca3f63f6be3104d092a36663f6c56bdb48220e795c3c0914e53e67f4_prof);

        
        $__internal_407b5c449d16105c646f17f5dd97d143c46f76c33f343a5646282c180f29b076->leave($__internal_407b5c449d16105c646f17f5dd97d143c46f76c33f343a5646282c180f29b076_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_f5997fd532e32c8524df0cbe895d2e725b931076ebc68d9de37ea796e6d2cea3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f5997fd532e32c8524df0cbe895d2e725b931076ebc68d9de37ea796e6d2cea3->enter($__internal_f5997fd532e32c8524df0cbe895d2e725b931076ebc68d9de37ea796e6d2cea3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_a99c4797e6626dcb5d959e21db8a996f4c9f1c479c3d01e7f20d48010653fff0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a99c4797e6626dcb5d959e21db8a996f4c9f1c479c3d01e7f20d48010653fff0->enter($__internal_a99c4797e6626dcb5d959e21db8a996f4c9f1c479c3d01e7f20d48010653fff0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["collector"]) || array_key_exists("collector", $context) ? $context["collector"] : (function () { throw new Twig_Error_Runtime('Variable "collector" does not exist.', 27, $this->getSourceContext()); })()), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => (isset($context["token"]) || array_key_exists("token", $context) ? $context["token"] : (function () { throw new Twig_Error_Runtime('Variable "token" does not exist.', 33, $this->getSourceContext()); })()))));
            echo "
        </div>
    ";
        }
        
        $__internal_a99c4797e6626dcb5d959e21db8a996f4c9f1c479c3d01e7f20d48010653fff0->leave($__internal_a99c4797e6626dcb5d959e21db8a996f4c9f1c479c3d01e7f20d48010653fff0_prof);

        
        $__internal_f5997fd532e32c8524df0cbe895d2e725b931076ebc68d9de37ea796e6d2cea3->leave($__internal_f5997fd532e32c8524df0cbe895d2e725b931076ebc68d9de37ea796e6d2cea3_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "@WebProfiler/Collector/exception.html.twig", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/exception.html.twig");
    }
}
