<?php

/* @Security/Collector/icon.svg */
class __TwigTemplate_5b77423b21b34121f3a797d0b60b51b3d65389a402ee1e24ab9ec5c4a25b0787 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4897b3b16fd6d7a4cf8e748d4ca94a182778d645b9d9bef2254b23ea1f764007 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4897b3b16fd6d7a4cf8e748d4ca94a182778d645b9d9bef2254b23ea1f764007->enter($__internal_4897b3b16fd6d7a4cf8e748d4ca94a182778d645b9d9bef2254b23ea1f764007_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Security/Collector/icon.svg"));

        $__internal_b8ab9fc97070cfc4d4c7a3292f3baea44b49fe8cbb990ea885e0c41c098cde42 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b8ab9fc97070cfc4d4c7a3292f3baea44b49fe8cbb990ea885e0c41c098cde42->enter($__internal_b8ab9fc97070cfc4d4c7a3292f3baea44b49fe8cbb990ea885e0c41c098cde42_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Security/Collector/icon.svg"));

        // line 1
        echo "<svg version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" x=\"0px\" y=\"0px\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" enable-background=\"new 0 0 24 24\" xml:space=\"preserve\">
    <path fill=\"#AAAAAA\" d=\"M21,20.4V22H3v-1.6c0-3.7,2.4-6.9,5.8-8c-1.7-1.1-2.9-3-2.9-5.2c0-3.4,2.7-6.1,6.1-6.1s6.1,2.7,6.1,6.1c0,2.2-1.2,4.1-2.9,5.2C18.6,13.5,21,16.7,21,20.4z\"/>
</svg>
";
        
        $__internal_4897b3b16fd6d7a4cf8e748d4ca94a182778d645b9d9bef2254b23ea1f764007->leave($__internal_4897b3b16fd6d7a4cf8e748d4ca94a182778d645b9d9bef2254b23ea1f764007_prof);

        
        $__internal_b8ab9fc97070cfc4d4c7a3292f3baea44b49fe8cbb990ea885e0c41c098cde42->leave($__internal_b8ab9fc97070cfc4d4c7a3292f3baea44b49fe8cbb990ea885e0c41c098cde42_prof);

    }

    public function getTemplateName()
    {
        return "@Security/Collector/icon.svg";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<svg version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" x=\"0px\" y=\"0px\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" enable-background=\"new 0 0 24 24\" xml:space=\"preserve\">
    <path fill=\"#AAAAAA\" d=\"M21,20.4V22H3v-1.6c0-3.7,2.4-6.9,5.8-8c-1.7-1.1-2.9-3-2.9-5.2c0-3.4,2.7-6.1,6.1-6.1s6.1,2.7,6.1,6.1c0,2.2-1.2,4.1-2.9,5.2C18.6,13.5,21,16.7,21,20.4z\"/>
</svg>
", "@Security/Collector/icon.svg", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/SecurityBundle/Resources/views/Collector/icon.svg");
    }
}
