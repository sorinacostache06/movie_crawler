<?php

/* base.html.twig */
class __TwigTemplate_717249bbfe4c48f707efcb3abcff871720306f8bd73086303dc7a5873951212a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'flashBag' => array($this, 'block_flashBag'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_79e14278424d29823ca24aa48dafd13ccacdb7f7efdf4f101380d6b9eecbc286 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_79e14278424d29823ca24aa48dafd13ccacdb7f7efdf4f101380d6b9eecbc286->enter($__internal_79e14278424d29823ca24aa48dafd13ccacdb7f7efdf4f101380d6b9eecbc286_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_b73260271672ce4685e7915b3402851cac7eb3087d9ccd9dbba2159f300123b1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b73260271672ce4685e7915b3402851cac7eb3087d9ccd9dbba2159f300123b1->enter($__internal_b73260271672ce4685e7915b3402851cac7eb3087d9ccd9dbba2159f300123b1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
<head>
    <meta charset=\"UTF-8\" />
    <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "    <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
</head>
<body>
";
        // line 10
        $this->displayBlock('flashBag', $context, $blocks);
        // line 33
        $this->displayBlock('body', $context, $blocks);
        // line 34
        $this->displayBlock('javascripts', $context, $blocks);
        // line 35
        echo "</body>
</html>
";
        
        $__internal_79e14278424d29823ca24aa48dafd13ccacdb7f7efdf4f101380d6b9eecbc286->leave($__internal_79e14278424d29823ca24aa48dafd13ccacdb7f7efdf4f101380d6b9eecbc286_prof);

        
        $__internal_b73260271672ce4685e7915b3402851cac7eb3087d9ccd9dbba2159f300123b1->leave($__internal_b73260271672ce4685e7915b3402851cac7eb3087d9ccd9dbba2159f300123b1_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_acb677c7157fb6c179645a074e98920b2bb64e58ce2a7cae4e28de847cbc26c5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_acb677c7157fb6c179645a074e98920b2bb64e58ce2a7cae4e28de847cbc26c5->enter($__internal_acb677c7157fb6c179645a074e98920b2bb64e58ce2a7cae4e28de847cbc26c5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_31d5fa4aa890071269e7974eea53365b3477653a2a6bb2024348886ac004352d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_31d5fa4aa890071269e7974eea53365b3477653a2a6bb2024348886ac004352d->enter($__internal_31d5fa4aa890071269e7974eea53365b3477653a2a6bb2024348886ac004352d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Movies Crawler";
        
        $__internal_31d5fa4aa890071269e7974eea53365b3477653a2a6bb2024348886ac004352d->leave($__internal_31d5fa4aa890071269e7974eea53365b3477653a2a6bb2024348886ac004352d_prof);

        
        $__internal_acb677c7157fb6c179645a074e98920b2bb64e58ce2a7cae4e28de847cbc26c5->leave($__internal_acb677c7157fb6c179645a074e98920b2bb64e58ce2a7cae4e28de847cbc26c5_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_27b7934e442c1615d3a40c18ef3812c64a7d36bc830c00ea61d53b04893008f0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_27b7934e442c1615d3a40c18ef3812c64a7d36bc830c00ea61d53b04893008f0->enter($__internal_27b7934e442c1615d3a40c18ef3812c64a7d36bc830c00ea61d53b04893008f0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_74801d557e29055ce320a2b25faeb3aa63b17baa7fc66b86cd3b1408c8312e73 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_74801d557e29055ce320a2b25faeb3aa63b17baa7fc66b86cd3b1408c8312e73->enter($__internal_74801d557e29055ce320a2b25faeb3aa63b17baa7fc66b86cd3b1408c8312e73_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_74801d557e29055ce320a2b25faeb3aa63b17baa7fc66b86cd3b1408c8312e73->leave($__internal_74801d557e29055ce320a2b25faeb3aa63b17baa7fc66b86cd3b1408c8312e73_prof);

        
        $__internal_27b7934e442c1615d3a40c18ef3812c64a7d36bc830c00ea61d53b04893008f0->leave($__internal_27b7934e442c1615d3a40c18ef3812c64a7d36bc830c00ea61d53b04893008f0_prof);

    }

    // line 10
    public function block_flashBag($context, array $blocks = array())
    {
        $__internal_4bb3f163d1915d6a33b2fea337c7d27113eb6e06ae3516ffa877b9fd959304ea = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4bb3f163d1915d6a33b2fea337c7d27113eb6e06ae3516ffa877b9fd959304ea->enter($__internal_4bb3f163d1915d6a33b2fea337c7d27113eb6e06ae3516ffa877b9fd959304ea_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "flashBag"));

        $__internal_cf81936d89d9a266ed3895bcd0f10fef6124f7479a68f2f697cb062d15ab3efc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cf81936d89d9a266ed3895bcd0f10fef6124f7479a68f2f697cb062d15ab3efc->enter($__internal_cf81936d89d9a266ed3895bcd0f10fef6124f7479a68f2f697cb062d15ab3efc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "flashBag"));

        // line 11
        echo "    ";
        if (twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 11, $this->getSourceContext()); })()), "session", array()), "flashBag", array()), "has", array(0 => "error"), "method")) {
            // line 12
            echo "        <div align=\"center\" style=\"background-color:red\">
            ";
            // line 13
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 13, $this->getSourceContext()); })()), "session", array()), "flashBag", array()), "get", array(0 => "error"), "method"));
            foreach ($context['_seq'] as $context["_key"] => $context["msg"]) {
                // line 14
                echo "                ";
                echo twig_escape_filter($this->env, $context["msg"], "html", null, true);
                echo "
            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['msg'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 16
            echo "        </div>
    ";
        }
        // line 18
        echo "    ";
        if (twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 18, $this->getSourceContext()); })()), "session", array()), "flashBag", array()), "has", array(0 => "success"), "method")) {
            // line 19
            echo "        <div align=\"center\" style=\"background-color:green\">
            ";
            // line 20
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 20, $this->getSourceContext()); })()), "session", array()), "flashBag", array()), "get", array(0 => "success"), "method"));
            foreach ($context['_seq'] as $context["_key"] => $context["msg"]) {
                // line 21
                echo "                ";
                echo twig_escape_filter($this->env, $context["msg"], "html", null, true);
                echo "
            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['msg'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 23
            echo "        </div>
    ";
        }
        // line 25
        echo "    ";
        if (twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 25, $this->getSourceContext()); })()), "session", array()), "flashBag", array()), "has", array(0 => "notice"), "method")) {
            // line 26
            echo "        <div align=\"center\" style=\"background-color:lightblue\">
            ";
            // line 27
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 27, $this->getSourceContext()); })()), "session", array()), "flashBag", array()), "get", array(0 => "notice"), "method"));
            foreach ($context['_seq'] as $context["_key"] => $context["msg"]) {
                // line 28
                echo "                ";
                echo twig_escape_filter($this->env, $context["msg"], "html", null, true);
                echo "
            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['msg'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 30
            echo "        </div>
    ";
        }
        
        $__internal_cf81936d89d9a266ed3895bcd0f10fef6124f7479a68f2f697cb062d15ab3efc->leave($__internal_cf81936d89d9a266ed3895bcd0f10fef6124f7479a68f2f697cb062d15ab3efc_prof);

        
        $__internal_4bb3f163d1915d6a33b2fea337c7d27113eb6e06ae3516ffa877b9fd959304ea->leave($__internal_4bb3f163d1915d6a33b2fea337c7d27113eb6e06ae3516ffa877b9fd959304ea_prof);

    }

    // line 33
    public function block_body($context, array $blocks = array())
    {
        $__internal_ea272fff1647227984256c836d5aeea87d26d197b0e37fc7204f66f25a987a81 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ea272fff1647227984256c836d5aeea87d26d197b0e37fc7204f66f25a987a81->enter($__internal_ea272fff1647227984256c836d5aeea87d26d197b0e37fc7204f66f25a987a81_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_18c4507cac91e20e4e24ba0fcdaebcb39432fed0722ed5174038f89bad0f3615 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_18c4507cac91e20e4e24ba0fcdaebcb39432fed0722ed5174038f89bad0f3615->enter($__internal_18c4507cac91e20e4e24ba0fcdaebcb39432fed0722ed5174038f89bad0f3615_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_18c4507cac91e20e4e24ba0fcdaebcb39432fed0722ed5174038f89bad0f3615->leave($__internal_18c4507cac91e20e4e24ba0fcdaebcb39432fed0722ed5174038f89bad0f3615_prof);

        
        $__internal_ea272fff1647227984256c836d5aeea87d26d197b0e37fc7204f66f25a987a81->leave($__internal_ea272fff1647227984256c836d5aeea87d26d197b0e37fc7204f66f25a987a81_prof);

    }

    // line 34
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_5e1568d5b2ea1fce8b454c45f379b461aa379ba61ae2fa51f64ff5ded4a7d3fa = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5e1568d5b2ea1fce8b454c45f379b461aa379ba61ae2fa51f64ff5ded4a7d3fa->enter($__internal_5e1568d5b2ea1fce8b454c45f379b461aa379ba61ae2fa51f64ff5ded4a7d3fa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_e71aab692d3303f7e81a55ac16f2dc805deb251ad74bddc3145b84d9a7f40ef6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e71aab692d3303f7e81a55ac16f2dc805deb251ad74bddc3145b84d9a7f40ef6->enter($__internal_e71aab692d3303f7e81a55ac16f2dc805deb251ad74bddc3145b84d9a7f40ef6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_e71aab692d3303f7e81a55ac16f2dc805deb251ad74bddc3145b84d9a7f40ef6->leave($__internal_e71aab692d3303f7e81a55ac16f2dc805deb251ad74bddc3145b84d9a7f40ef6_prof);

        
        $__internal_5e1568d5b2ea1fce8b454c45f379b461aa379ba61ae2fa51f64ff5ded4a7d3fa->leave($__internal_5e1568d5b2ea1fce8b454c45f379b461aa379ba61ae2fa51f64ff5ded4a7d3fa_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  205 => 34,  188 => 33,  176 => 30,  167 => 28,  163 => 27,  160 => 26,  157 => 25,  153 => 23,  144 => 21,  140 => 20,  137 => 19,  134 => 18,  130 => 16,  121 => 14,  117 => 13,  114 => 12,  111 => 11,  102 => 10,  85 => 6,  67 => 5,  55 => 35,  53 => 34,  51 => 33,  49 => 10,  42 => 7,  40 => 6,  36 => 5,  30 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
<head>
    <meta charset=\"UTF-8\" />
    <title>{% block title %}Movies Crawler{% endblock %}</title>
    {% block stylesheets %}{% endblock %}
    <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
</head>
<body>
{% block flashBag %}
    {% if app.session.flashBag.has('error') %}
        <div align=\"center\" style=\"background-color:red\">
            {% for msg in app.session.flashBag.get('error') %}
                {{ msg }}
            {% endfor %}
        </div>
    {% endif %}
    {% if app.session.flashBag.has('success') %}
        <div align=\"center\" style=\"background-color:green\">
            {% for msg in app.session.flashBag.get('success') %}
                {{ msg }}
            {% endfor %}
        </div>
    {% endif %}
    {% if app.session.flashBag.has('notice') %}
        <div align=\"center\" style=\"background-color:lightblue\">
            {% for msg in app.session.flashBag.get('notice') %}
                {{ msg }}
            {% endfor %}
        </div>
    {% endif %}
{% endblock %}
{% block body %}{% endblock %}
{% block javascripts %}{% endblock %}
</body>
</html>
", "base.html.twig", "/home/sorina/Documents/work/movies_crowler/app/Resources/views/base.html.twig");
    }
}
