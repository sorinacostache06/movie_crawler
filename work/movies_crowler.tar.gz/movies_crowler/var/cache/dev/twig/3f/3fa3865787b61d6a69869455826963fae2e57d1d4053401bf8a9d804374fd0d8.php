<?php

/* AvanzuAdminThemeBundle:Widget:default-box.html.twig */
class __TwigTemplate_b93d1169c1bf044e4c2318205867ae9122035b0a9098b477122e3d08e041668c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_98743fc5d6e5b8e71ce54f59d0fc35f0d8fd1c4585aa399989f6174df702d201 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_98743fc5d6e5b8e71ce54f59d0fc35f0d8fd1c4585aa399989f6174df702d201->enter($__internal_98743fc5d6e5b8e71ce54f59d0fc35f0d8fd1c4585aa399989f6174df702d201_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AvanzuAdminThemeBundle:Widget:default-box.html.twig"));

        $__internal_bb86ff8d97ae24c02cc88f19c8b4d0958c3df1bf0cea6930c51a9217abd3a4d6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bb86ff8d97ae24c02cc88f19c8b4d0958c3df1bf0cea6930c51a9217abd3a4d6->enter($__internal_bb86ff8d97ae24c02cc88f19c8b4d0958c3df1bf0cea6930c51a9217abd3a4d6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AvanzuAdminThemeBundle:Widget:default-box.html.twig"));

        
        $__internal_98743fc5d6e5b8e71ce54f59d0fc35f0d8fd1c4585aa399989f6174df702d201->leave($__internal_98743fc5d6e5b8e71ce54f59d0fc35f0d8fd1c4585aa399989f6174df702d201_prof);

        
        $__internal_bb86ff8d97ae24c02cc88f19c8b4d0958c3df1bf0cea6930c51a9217abd3a4d6->leave($__internal_bb86ff8d97ae24c02cc88f19c8b4d0958c3df1bf0cea6930c51a9217abd3a4d6_prof);

    }

    public function getTemplateName()
    {
        return "AvanzuAdminThemeBundle:Widget:default-box.html.twig";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "AvanzuAdminThemeBundle:Widget:default-box.html.twig", "/home/sorina/Documents/work/movies_crowler/vendor/avanzu/admin-theme-bundle/Resources/views/Widget/default-box.html.twig");
    }
}
