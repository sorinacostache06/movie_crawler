<?php

/* @Framework/Form/choice_attributes.html.php */
class __TwigTemplate_23d6b3831c11c8a789facb03b8f803fe834f5a22549fd31c400c275beb02e07b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_514861caa5c8abdd3efa69c4e461660095fbbb9cdc3babbbc4fc953de6cb0a09 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_514861caa5c8abdd3efa69c4e461660095fbbb9cdc3babbbc4fc953de6cb0a09->enter($__internal_514861caa5c8abdd3efa69c4e461660095fbbb9cdc3babbbc4fc953de6cb0a09_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_attributes.html.php"));

        $__internal_2aab53440fe0db68904698840ca37a60367a930eda1744b6a0675e535ea81331 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2aab53440fe0db68904698840ca37a60367a930eda1744b6a0675e535ea81331->enter($__internal_2aab53440fe0db68904698840ca37a60367a930eda1744b6a0675e535ea81331_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_attributes.html.php"));

        // line 1
        echo "<?php if (\$disabled): ?>disabled=\"disabled\" <?php endif ?>
<?php foreach (\$choice_attr as \$k => \$v): ?>
<?php if (\$v === true): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$k)) ?>
<?php elseif (\$v !== false): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$v)) ?>
<?php endif ?>
<?php endforeach ?>
";
        
        $__internal_514861caa5c8abdd3efa69c4e461660095fbbb9cdc3babbbc4fc953de6cb0a09->leave($__internal_514861caa5c8abdd3efa69c4e461660095fbbb9cdc3babbbc4fc953de6cb0a09_prof);

        
        $__internal_2aab53440fe0db68904698840ca37a60367a930eda1744b6a0675e535ea81331->leave($__internal_2aab53440fe0db68904698840ca37a60367a930eda1744b6a0675e535ea81331_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$disabled): ?>disabled=\"disabled\" <?php endif ?>
<?php foreach (\$choice_attr as \$k => \$v): ?>
<?php if (\$v === true): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$k)) ?>
<?php elseif (\$v !== false): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$v)) ?>
<?php endif ?>
<?php endforeach ?>
", "@Framework/Form/choice_attributes.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/choice_attributes.html.php");
    }
}
