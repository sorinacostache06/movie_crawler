<?php

/* @Framework/Form/search_widget.html.php */
class __TwigTemplate_c2a679cd81e03cfc4c99fad3a0460001b075f6f00eea0a838454d7e22f6aeea9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ed3d55356ad2d3efb5ff0cf1bebf9869d2e8cfc7c86f351a78f704863a1403d5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ed3d55356ad2d3efb5ff0cf1bebf9869d2e8cfc7c86f351a78f704863a1403d5->enter($__internal_ed3d55356ad2d3efb5ff0cf1bebf9869d2e8cfc7c86f351a78f704863a1403d5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/search_widget.html.php"));

        $__internal_6c2c0325cae9d7ed31fc6719a7b7910614008c1464dee7e3231a6b24dc3cb0ec = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6c2c0325cae9d7ed31fc6719a7b7910614008c1464dee7e3231a6b24dc3cb0ec->enter($__internal_6c2c0325cae9d7ed31fc6719a7b7910614008c1464dee7e3231a6b24dc3cb0ec_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/search_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'search')) ?>
";
        
        $__internal_ed3d55356ad2d3efb5ff0cf1bebf9869d2e8cfc7c86f351a78f704863a1403d5->leave($__internal_ed3d55356ad2d3efb5ff0cf1bebf9869d2e8cfc7c86f351a78f704863a1403d5_prof);

        
        $__internal_6c2c0325cae9d7ed31fc6719a7b7910614008c1464dee7e3231a6b24dc3cb0ec->leave($__internal_6c2c0325cae9d7ed31fc6719a7b7910614008c1464dee7e3231a6b24dc3cb0ec_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/search_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'search')) ?>
", "@Framework/Form/search_widget.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/search_widget.html.php");
    }
}
