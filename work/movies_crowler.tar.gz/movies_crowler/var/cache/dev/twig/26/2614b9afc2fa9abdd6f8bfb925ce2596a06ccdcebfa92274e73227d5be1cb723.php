<?php

/* TwigBundle:Exception:traces.xml.twig */
class __TwigTemplate_4d3c2cfc47dd22f0d4d3471d46f4b0c4162fd633d544cadafe783f4d71c8ff0b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f266a155fe470b22348fca60c586668b1bc772fd9442b07c70acded72723fc48 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f266a155fe470b22348fca60c586668b1bc772fd9442b07c70acded72723fc48->enter($__internal_f266a155fe470b22348fca60c586668b1bc772fd9442b07c70acded72723fc48_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:traces.xml.twig"));

        $__internal_5c5a5192c8fa3c404656327b1d087a64748a3dfaea01890df5b0d8d48797fe31 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5c5a5192c8fa3c404656327b1d087a64748a3dfaea01890df5b0d8d48797fe31->enter($__internal_5c5a5192c8fa3c404656327b1d087a64748a3dfaea01890df5b0d8d48797fe31_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:traces.xml.twig"));

        // line 1
        echo "        <traces>
";
        // line 2
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["exception"]) || array_key_exists("exception", $context) ? $context["exception"] : (function () { throw new Twig_Error_Runtime('Variable "exception" does not exist.', 2, $this->getSourceContext()); })()), "trace", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["trace"]) {
            // line 3
            echo "            <trace>
";
            // line 4
            $this->loadTemplate("@Twig/Exception/trace.txt.twig", "TwigBundle:Exception:traces.xml.twig", 4)->display(array("trace" => $context["trace"]));
            // line 5
            echo "
            </trace>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['trace'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 8
        echo "        </traces>
";
        
        $__internal_f266a155fe470b22348fca60c586668b1bc772fd9442b07c70acded72723fc48->leave($__internal_f266a155fe470b22348fca60c586668b1bc772fd9442b07c70acded72723fc48_prof);

        
        $__internal_5c5a5192c8fa3c404656327b1d087a64748a3dfaea01890df5b0d8d48797fe31->leave($__internal_5c5a5192c8fa3c404656327b1d087a64748a3dfaea01890df5b0d8d48797fe31_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:traces.xml.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  45 => 8,  37 => 5,  35 => 4,  32 => 3,  28 => 2,  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("        <traces>
{% for trace in exception.trace %}
            <trace>
{% include '@Twig/Exception/trace.txt.twig' with { 'trace': trace } only %}

            </trace>
{% endfor %}
        </traces>
", "TwigBundle:Exception:traces.xml.twig", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/traces.xml.twig");
    }
}
