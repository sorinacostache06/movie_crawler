<?php

/* ::login-layout.html.twig */
class __TwigTemplate_38ad909c7bdead1889104f006b3e93f5dc556a8b520433a7efcc80e20f5243fb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("AvanzuAdminThemeBundle:layout:login-layout.html.twig", "::login-layout.html.twig", 1);
        $this->blocks = array(
            'flashBag' => array($this, 'block_flashBag'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "AvanzuAdminThemeBundle:layout:login-layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_000cae092b26e14361fd122b6964a8a5a2f77e150cbe6695420aa06f47b743b3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_000cae092b26e14361fd122b6964a8a5a2f77e150cbe6695420aa06f47b743b3->enter($__internal_000cae092b26e14361fd122b6964a8a5a2f77e150cbe6695420aa06f47b743b3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::login-layout.html.twig"));

        $__internal_114e3417a7a9f7b940736a18e4a8c74a9d5f2c615ce3c6f0ae59392ebf07aa32 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_114e3417a7a9f7b940736a18e4a8c74a9d5f2c615ce3c6f0ae59392ebf07aa32->enter($__internal_114e3417a7a9f7b940736a18e4a8c74a9d5f2c615ce3c6f0ae59392ebf07aa32_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::login-layout.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_000cae092b26e14361fd122b6964a8a5a2f77e150cbe6695420aa06f47b743b3->leave($__internal_000cae092b26e14361fd122b6964a8a5a2f77e150cbe6695420aa06f47b743b3_prof);

        
        $__internal_114e3417a7a9f7b940736a18e4a8c74a9d5f2c615ce3c6f0ae59392ebf07aa32->leave($__internal_114e3417a7a9f7b940736a18e4a8c74a9d5f2c615ce3c6f0ae59392ebf07aa32_prof);

    }

    // line 3
    public function block_flashBag($context, array $blocks = array())
    {
        $__internal_1c2b7d2c8c5cfb3ca41c68e51c15ad7cc7350124408c71fdc92d1fd8249a6555 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1c2b7d2c8c5cfb3ca41c68e51c15ad7cc7350124408c71fdc92d1fd8249a6555->enter($__internal_1c2b7d2c8c5cfb3ca41c68e51c15ad7cc7350124408c71fdc92d1fd8249a6555_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "flashBag"));

        $__internal_e670d09dd2edd3073d8dc3c376f6238de504a626a6fa6e249d28180773540bd0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e670d09dd2edd3073d8dc3c376f6238de504a626a6fa6e249d28180773540bd0->enter($__internal_e670d09dd2edd3073d8dc3c376f6238de504a626a6fa6e249d28180773540bd0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "flashBag"));

        // line 4
        echo "    ";
        $this->loadTemplate("::flashBag.html.twig", "::login-layout.html.twig", 4)->display($context);
        
        $__internal_e670d09dd2edd3073d8dc3c376f6238de504a626a6fa6e249d28180773540bd0->leave($__internal_e670d09dd2edd3073d8dc3c376f6238de504a626a6fa6e249d28180773540bd0_prof);

        
        $__internal_1c2b7d2c8c5cfb3ca41c68e51c15ad7cc7350124408c71fdc92d1fd8249a6555->leave($__internal_1c2b7d2c8c5cfb3ca41c68e51c15ad7cc7350124408c71fdc92d1fd8249a6555_prof);

    }

    public function getTemplateName()
    {
        return "::login-layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 4,  40 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'AvanzuAdminThemeBundle:layout:login-layout.html.twig' %}

{% block flashBag %}
    {% include '::flashBag.html.twig' %}
{% endblock %}
", "::login-layout.html.twig", "/home/sorina/Documents/work/movies_crowler/app/Resources/views/login-layout.html.twig");
    }
}
