<?php

/* @Framework/Form/form_widget_simple.html.php */
class __TwigTemplate_9f3864f897c3de9afc1f8aec9bb9b6703eb60223fd56eb7dae76098a0f12c960 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7995d2b183f5372845fe584ae453af4fa650de074d387eb46f204293ca7d8265 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7995d2b183f5372845fe584ae453af4fa650de074d387eb46f204293ca7d8265->enter($__internal_7995d2b183f5372845fe584ae453af4fa650de074d387eb46f204293ca7d8265_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_simple.html.php"));

        $__internal_9481e5bc40ace62a5b088416abdce70fc84c3bea7187e83016a4ec5775a9f55d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9481e5bc40ace62a5b088416abdce70fc84c3bea7187e83016a4ec5775a9f55d->enter($__internal_9481e5bc40ace62a5b088416abdce70fc84c3bea7187e83016a4ec5775a9f55d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_simple.html.php"));

        // line 1
        echo "<input type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'text' ?>\" <?php echo \$view['form']->block(\$form, 'widget_attributes') ?><?php if (!empty(\$value) || is_numeric(\$value)): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?> />
";
        
        $__internal_7995d2b183f5372845fe584ae453af4fa650de074d387eb46f204293ca7d8265->leave($__internal_7995d2b183f5372845fe584ae453af4fa650de074d387eb46f204293ca7d8265_prof);

        
        $__internal_9481e5bc40ace62a5b088416abdce70fc84c3bea7187e83016a4ec5775a9f55d->leave($__internal_9481e5bc40ace62a5b088416abdce70fc84c3bea7187e83016a4ec5775a9f55d_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget_simple.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<input type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'text' ?>\" <?php echo \$view['form']->block(\$form, 'widget_attributes') ?><?php if (!empty(\$value) || is_numeric(\$value)): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?> />
", "@Framework/Form/form_widget_simple.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_widget_simple.html.php");
    }
}
