<?php

/* TwigBundle:Exception:error.rdf.twig */
class __TwigTemplate_782164d0d424a216024f85bd9f975f1f8b64ce652214ef37705f27996ebafca6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ba83a2d2b55a184a178e98ed755b40d1fc894d1064e86546061ea260b5936bf0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ba83a2d2b55a184a178e98ed755b40d1fc894d1064e86546061ea260b5936bf0->enter($__internal_ba83a2d2b55a184a178e98ed755b40d1fc894d1064e86546061ea260b5936bf0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        $__internal_e9a6d074638228136405e1ffbeec01b30cc48301ea4be1ca528c0132d01b3f3a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e9a6d074638228136405e1ffbeec01b30cc48301ea4be1ca528c0132d01b3f3a->enter($__internal_e9a6d074638228136405e1ffbeec01b30cc48301ea4be1ca528c0132d01b3f3a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "TwigBundle:Exception:error.rdf.twig", 1)->display($context);
        
        $__internal_ba83a2d2b55a184a178e98ed755b40d1fc894d1064e86546061ea260b5936bf0->leave($__internal_ba83a2d2b55a184a178e98ed755b40d1fc894d1064e86546061ea260b5936bf0_prof);

        
        $__internal_e9a6d074638228136405e1ffbeec01b30cc48301ea4be1ca528c0132d01b3f3a->leave($__internal_e9a6d074638228136405e1ffbeec01b30cc48301ea4be1ca528c0132d01b3f3a_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.rdf.twig";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include '@Twig/Exception/error.xml.twig' %}
", "TwigBundle:Exception:error.rdf.twig", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/error.rdf.twig");
    }
}
