<?php

/* @Framework/Form/submit_widget.html.php */
class __TwigTemplate_90bd864ee72c16d4605a298e6e2244b0b7bf9e47946a5a9e7591059147a01182 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1aa02ff79bcf8cb81d7297a0fe9bff6fb22e9777be67381c362cf0de47c7a24b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1aa02ff79bcf8cb81d7297a0fe9bff6fb22e9777be67381c362cf0de47c7a24b->enter($__internal_1aa02ff79bcf8cb81d7297a0fe9bff6fb22e9777be67381c362cf0de47c7a24b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/submit_widget.html.php"));

        $__internal_ca29bceabb1bea18917aaa218327dae21c6c5fab7c6fc3bdb334d8555667cb07 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ca29bceabb1bea18917aaa218327dae21c6c5fab7c6fc3bdb334d8555667cb07->enter($__internal_ca29bceabb1bea18917aaa218327dae21c6c5fab7c6fc3bdb334d8555667cb07_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/submit_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'submit')) ?>
";
        
        $__internal_1aa02ff79bcf8cb81d7297a0fe9bff6fb22e9777be67381c362cf0de47c7a24b->leave($__internal_1aa02ff79bcf8cb81d7297a0fe9bff6fb22e9777be67381c362cf0de47c7a24b_prof);

        
        $__internal_ca29bceabb1bea18917aaa218327dae21c6c5fab7c6fc3bdb334d8555667cb07->leave($__internal_ca29bceabb1bea18917aaa218327dae21c6c5fab7c6fc3bdb334d8555667cb07_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/submit_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'submit')) ?>
", "@Framework/Form/submit_widget.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/submit_widget.html.php");
    }
}
