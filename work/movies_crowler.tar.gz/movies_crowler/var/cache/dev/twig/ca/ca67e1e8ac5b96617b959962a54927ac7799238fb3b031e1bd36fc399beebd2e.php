<?php

/* AvanzuAdminThemeBundle:layout:macros.html.twig */
class __TwigTemplate_371c175c336ae2aeabfdd70584379656ab7b87e9264c00b91d698451bc7fa19b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'box_collapse' => array($this, 'block_box_collapse'),
            'box_remove' => array($this, 'block_box_remove'),
            'box_header_buttons' => array($this, 'block_box_header_buttons'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c9230535c9b8fc7dbc21f47999a358bfa84e78d1810f4b1464720b413b33a47f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c9230535c9b8fc7dbc21f47999a358bfa84e78d1810f4b1464720b413b33a47f->enter($__internal_c9230535c9b8fc7dbc21f47999a358bfa84e78d1810f4b1464720b413b33a47f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AvanzuAdminThemeBundle:layout:macros.html.twig"));

        $__internal_76b42c62a1456d0d682191fa9ba85ef4a5079f90920883b0e60d5504339d2ae0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_76b42c62a1456d0d682191fa9ba85ef4a5079f90920883b0e60d5504339d2ae0->enter($__internal_76b42c62a1456d0d682191fa9ba85ef4a5079f90920883b0e60d5504339d2ae0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AvanzuAdminThemeBundle:layout:macros.html.twig"));

        // line 1
        $this->displayBlock('box_collapse', $context, $blocks);
        // line 4
        $this->displayBlock('box_remove', $context, $blocks);
        // line 7
        echo "
";
        // line 8
        $this->displayBlock('box_header_buttons', $context, $blocks);
        // line 20
        echo "
";
        // line 28
        echo "

";
        // line 37
        echo "
";
        
        $__internal_c9230535c9b8fc7dbc21f47999a358bfa84e78d1810f4b1464720b413b33a47f->leave($__internal_c9230535c9b8fc7dbc21f47999a358bfa84e78d1810f4b1464720b413b33a47f_prof);

        
        $__internal_76b42c62a1456d0d682191fa9ba85ef4a5079f90920883b0e60d5504339d2ae0->leave($__internal_76b42c62a1456d0d682191fa9ba85ef4a5079f90920883b0e60d5504339d2ae0_prof);

    }

    // line 1
    public function block_box_collapse($context, array $blocks = array())
    {
        $__internal_1e9c139c1bb90df82853799cadde040f474486005464fb06095ec9b5aee2e6a5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1e9c139c1bb90df82853799cadde040f474486005464fb06095ec9b5aee2e6a5->enter($__internal_1e9c139c1bb90df82853799cadde040f474486005464fb06095ec9b5aee2e6a5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "box_collapse"));

        $__internal_570b11a42154cd47b31fa3fad483b00dcb5bc1dbe694b4db36bae457ea91a710 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_570b11a42154cd47b31fa3fad483b00dcb5bc1dbe694b4db36bae457ea91a710->enter($__internal_570b11a42154cd47b31fa3fad483b00dcb5bc1dbe694b4db36bae457ea91a710_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "box_collapse"));

        // line 2
        echo "    <button class=\"btn btn-";
        echo twig_escape_filter($this->env, ((array_key_exists("type", $context)) ? (_twig_default_filter((isset($context["type"]) || array_key_exists("type", $context) ? $context["type"] : (function () { throw new Twig_Error_Runtime('Variable "type" does not exist.', 2, $this->getSourceContext()); })()), "info")) : ("info")), "html", null, true);
        echo " btn-sm\" data-widget=\"collapse\"><i class=\"fa fa-minus\"></i></button>
";
        
        $__internal_570b11a42154cd47b31fa3fad483b00dcb5bc1dbe694b4db36bae457ea91a710->leave($__internal_570b11a42154cd47b31fa3fad483b00dcb5bc1dbe694b4db36bae457ea91a710_prof);

        
        $__internal_1e9c139c1bb90df82853799cadde040f474486005464fb06095ec9b5aee2e6a5->leave($__internal_1e9c139c1bb90df82853799cadde040f474486005464fb06095ec9b5aee2e6a5_prof);

    }

    // line 4
    public function block_box_remove($context, array $blocks = array())
    {
        $__internal_d33083ef560f873125778af8e97149b69fb41700fffa32d2cbd144405cde584e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d33083ef560f873125778af8e97149b69fb41700fffa32d2cbd144405cde584e->enter($__internal_d33083ef560f873125778af8e97149b69fb41700fffa32d2cbd144405cde584e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "box_remove"));

        $__internal_90f46933e68281036274894bf01c115059ba129b3ef01b2216294fb6388a95b7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_90f46933e68281036274894bf01c115059ba129b3ef01b2216294fb6388a95b7->enter($__internal_90f46933e68281036274894bf01c115059ba129b3ef01b2216294fb6388a95b7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "box_remove"));

        // line 5
        echo "    <button class=\"btn btn-";
        echo twig_escape_filter($this->env, ((array_key_exists("type", $context)) ? (_twig_default_filter((isset($context["type"]) || array_key_exists("type", $context) ? $context["type"] : (function () { throw new Twig_Error_Runtime('Variable "type" does not exist.', 5, $this->getSourceContext()); })()), "info")) : ("info")), "html", null, true);
        echo " btn-sm\" data-widget=\"remove\"><i class=\"fa fa-times\"></i></button>
";
        
        $__internal_90f46933e68281036274894bf01c115059ba129b3ef01b2216294fb6388a95b7->leave($__internal_90f46933e68281036274894bf01c115059ba129b3ef01b2216294fb6388a95b7_prof);

        
        $__internal_d33083ef560f873125778af8e97149b69fb41700fffa32d2cbd144405cde584e->leave($__internal_d33083ef560f873125778af8e97149b69fb41700fffa32d2cbd144405cde584e_prof);

    }

    // line 8
    public function block_box_header_buttons($context, array $blocks = array())
    {
        $__internal_e913b31ad5d671686985aecf8db339d991014f8a613653a286ad1d9b51f8b55e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e913b31ad5d671686985aecf8db339d991014f8a613653a286ad1d9b51f8b55e->enter($__internal_e913b31ad5d671686985aecf8db339d991014f8a613653a286ad1d9b51f8b55e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "box_header_buttons"));

        $__internal_4fc1c926e6434b199cbb02bc8d195b9320c82582f9987e64bc85bcd5985f143c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4fc1c926e6434b199cbb02bc8d195b9320c82582f9987e64bc85bcd5985f143c->enter($__internal_4fc1c926e6434b199cbb02bc8d195b9320c82582f9987e64bc85bcd5985f143c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "box_header_buttons"));

        // line 9
        echo "    ";
        if (((isset($context["collapse"]) || array_key_exists("collapse", $context) ? $context["collapse"] : (function () { throw new Twig_Error_Runtime('Variable "collapse" does not exist.', 9, $this->getSourceContext()); })()) || (isset($context["remove"]) || array_key_exists("remove", $context) ? $context["remove"] : (function () { throw new Twig_Error_Runtime('Variable "remove" does not exist.', 9, $this->getSourceContext()); })()))) {
            // line 10
            echo "        <div class=\"box-tools pull-right\">
            ";
            // line 11
            if ((isset($context["collapse"]) || array_key_exists("collapse", $context) ? $context["collapse"] : (function () { throw new Twig_Error_Runtime('Variable "collapse" does not exist.', 11, $this->getSourceContext()); })())) {
                // line 12
                echo "                ";
                $this->displayBlock("box_collapse", $context, $blocks);
                echo "
            ";
            }
            // line 14
            echo "            ";
            if ((isset($context["remove"]) || array_key_exists("remove", $context) ? $context["remove"] : (function () { throw new Twig_Error_Runtime('Variable "remove" does not exist.', 14, $this->getSourceContext()); })())) {
                // line 15
                echo "                ";
                $this->displayBlock("box_remove", $context, $blocks);
                echo "
            ";
            }
            // line 17
            echo "        </div>
    ";
        }
        
        $__internal_4fc1c926e6434b199cbb02bc8d195b9320c82582f9987e64bc85bcd5985f143c->leave($__internal_4fc1c926e6434b199cbb02bc8d195b9320c82582f9987e64bc85bcd5985f143c_prof);

        
        $__internal_e913b31ad5d671686985aecf8db339d991014f8a613653a286ad1d9b51f8b55e->leave($__internal_e913b31ad5d671686985aecf8db339d991014f8a613653a286ad1d9b51f8b55e_prof);

    }

    // line 21
    public function macro_box_header($__title__ = null, $__collapse__ = null, $__remove__ = null, $__type__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "title" => $__title__,
            "collapse" => $__collapse__,
            "remove" => $__remove__,
            "type" => $__type__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            $__internal_787fbc9d9e4fbbfe1737aee80731f23d1811ed5132f25e984982a83af8d5aa8d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
            $__internal_787fbc9d9e4fbbfe1737aee80731f23d1811ed5132f25e984982a83af8d5aa8d->enter($__internal_787fbc9d9e4fbbfe1737aee80731f23d1811ed5132f25e984982a83af8d5aa8d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "macro", "box_header"));

            $__internal_5808375a8c409dd449aef64c388327ad33869e5890d8fefc9d7b3bbb3bf9a437 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
            $__internal_5808375a8c409dd449aef64c388327ad33869e5890d8fefc9d7b3bbb3bf9a437->enter($__internal_5808375a8c409dd449aef64c388327ad33869e5890d8fefc9d7b3bbb3bf9a437_prof = new Twig_Profiler_Profile($this->getTemplateName(), "macro", "box_header"));

            // line 22
            echo "
    <div class=\"box-header\">
        <h3 class=\"box-title\">";
            // line 24
            echo twig_escape_filter($this->env, (isset($context["title"]) || array_key_exists("title", $context) ? $context["title"] : (function () { throw new Twig_Error_Runtime('Variable "title" does not exist.', 24, $this->getSourceContext()); })()), "html", null, true);
            echo "</h3>
        ";
            // line 25
            $this->displayBlock("box_header_buttons", $context, $blocks);
            echo "
    </div>
";
            
            $__internal_5808375a8c409dd449aef64c388327ad33869e5890d8fefc9d7b3bbb3bf9a437->leave($__internal_5808375a8c409dd449aef64c388327ad33869e5890d8fefc9d7b3bbb3bf9a437_prof);

            
            $__internal_787fbc9d9e4fbbfe1737aee80731f23d1811ed5132f25e984982a83af8d5aa8d->leave($__internal_787fbc9d9e4fbbfe1737aee80731f23d1811ed5132f25e984982a83af8d5aa8d_prof);


            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 30
    public function macro_avatar($__image__ = null, $__alt__ = null, $__class__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "image" => $__image__,
            "alt" => $__alt__,
            "class" => $__class__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            $__internal_8f77376548effc087026432ea29d41074d752a5f704e7f19c211fff5446463a2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
            $__internal_8f77376548effc087026432ea29d41074d752a5f704e7f19c211fff5446463a2->enter($__internal_8f77376548effc087026432ea29d41074d752a5f704e7f19c211fff5446463a2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "macro", "avatar"));

            $__internal_2557e79b1064251ddc03b7903a7153ad9c1d987e7c5f7fbf3cad4eb38c0015f1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
            $__internal_2557e79b1064251ddc03b7903a7153ad9c1d987e7c5f7fbf3cad4eb38c0015f1->enter($__internal_2557e79b1064251ddc03b7903a7153ad9c1d987e7c5f7fbf3cad4eb38c0015f1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "macro", "avatar"));

            // line 31
            echo "    ";
            if ((isset($context["image"]) || array_key_exists("image", $context) ? $context["image"] : (function () { throw new Twig_Error_Runtime('Variable "image" does not exist.', 31, $this->getSourceContext()); })())) {
                // line 32
                echo "        <img src=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl((isset($context["image"]) || array_key_exists("image", $context) ? $context["image"] : (function () { throw new Twig_Error_Runtime('Variable "image" does not exist.', 32, $this->getSourceContext()); })())), "html", null, true);
                echo "\" class=\"";
                echo twig_escape_filter($this->env, ((array_key_exists("class", $context)) ? (_twig_default_filter((isset($context["class"]) || array_key_exists("class", $context) ? $context["class"] : (function () { throw new Twig_Error_Runtime('Variable "class" does not exist.', 32, $this->getSourceContext()); })()), "img-circle")) : ("img-circle")), "html", null, true);
                echo "\" alt=\"";
                echo twig_escape_filter($this->env, (isset($context["alt"]) || array_key_exists("alt", $context) ? $context["alt"] : (function () { throw new Twig_Error_Runtime('Variable "alt" does not exist.', 32, $this->getSourceContext()); })()), "html", null, true);
                echo "\" />
    ";
            } else {
                // line 34
                echo "        <img src=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/avanzuadmintheme/img/avatar.png"), "html", null, true);
                echo "\" class=\"";
                echo twig_escape_filter($this->env, ((array_key_exists("class", $context)) ? (_twig_default_filter((isset($context["class"]) || array_key_exists("class", $context) ? $context["class"] : (function () { throw new Twig_Error_Runtime('Variable "class" does not exist.', 34, $this->getSourceContext()); })()), "img-circle")) : ("img-circle")), "html", null, true);
                echo "\" alt=\"";
                echo twig_escape_filter($this->env, (isset($context["alt"]) || array_key_exists("alt", $context) ? $context["alt"] : (function () { throw new Twig_Error_Runtime('Variable "alt" does not exist.', 34, $this->getSourceContext()); })()), "html", null, true);
                echo "\" />
    ";
            }
            
            $__internal_2557e79b1064251ddc03b7903a7153ad9c1d987e7c5f7fbf3cad4eb38c0015f1->leave($__internal_2557e79b1064251ddc03b7903a7153ad9c1d987e7c5f7fbf3cad4eb38c0015f1_prof);

            
            $__internal_8f77376548effc087026432ea29d41074d752a5f704e7f19c211fff5446463a2->leave($__internal_8f77376548effc087026432ea29d41074d752a5f704e7f19c211fff5446463a2_prof);


            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 38
    public function macro_menu_item($__item__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "item" => $__item__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            $__internal_8f4484a135627647d5d65a4c1d4f455239e2eabd3f7b88bf2cdc13463ee850c7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
            $__internal_8f4484a135627647d5d65a4c1d4f455239e2eabd3f7b88bf2cdc13463ee850c7->enter($__internal_8f4484a135627647d5d65a4c1d4f455239e2eabd3f7b88bf2cdc13463ee850c7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "macro", "menu_item"));

            $__internal_b586fa285b03f6f4afc6d19f772698b86074e9a426051596775bdadb7b704f9d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
            $__internal_b586fa285b03f6f4afc6d19f772698b86074e9a426051596775bdadb7b704f9d->enter($__internal_b586fa285b03f6f4afc6d19f772698b86074e9a426051596775bdadb7b704f9d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "macro", "menu_item"));

            // line 39
            echo "    ";
            if ((twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new Twig_Error_Runtime('Variable "item" does not exist.', 39, $this->getSourceContext()); })()), "route", array()) || twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new Twig_Error_Runtime('Variable "item" does not exist.', 39, $this->getSourceContext()); })()), "hasChildren", array()))) {
                // line 40
                echo "        <li id=\"";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new Twig_Error_Runtime('Variable "item" does not exist.', 40, $this->getSourceContext()); })()), "identifier", array()), "html", null, true);
                echo "\" class=\" ";
                echo ((twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new Twig_Error_Runtime('Variable "item" does not exist.', 40, $this->getSourceContext()); })()), "isActive", array())) ? ("active") : (""));
                echo " ";
                echo ((twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new Twig_Error_Runtime('Variable "item" does not exist.', 40, $this->getSourceContext()); })()), "hasChildren", array())) ? ("treeview") : (""));
                echo "\">
            <a href=\"";
                // line 41
                echo twig_escape_filter($this->env, ((twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new Twig_Error_Runtime('Variable "item" does not exist.', 41, $this->getSourceContext()); })()), "hasChildren", array())) ? ("#") : (((twig_in_filter("/", twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new Twig_Error_Runtime('Variable "item" does not exist.', 41, $this->getSourceContext()); })()), "route", array()))) ? (twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new Twig_Error_Runtime('Variable "item" does not exist.', 41, $this->getSourceContext()); })()), "route", array())) : ($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new Twig_Error_Runtime('Variable "item" does not exist.', 41, $this->getSourceContext()); })()), "route", array()), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new Twig_Error_Runtime('Variable "item" does not exist.', 41, $this->getSourceContext()); })()), "routeArgs", array())))))), "html", null, true);
                echo "\">
                ";
                // line 42
                if (twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new Twig_Error_Runtime('Variable "item" does not exist.', 42, $this->getSourceContext()); })()), "icon", array())) {
                    echo " <i class=\"";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new Twig_Error_Runtime('Variable "item" does not exist.', 42, $this->getSourceContext()); })()), "icon", array()), "html", null, true);
                    echo "\"></i> ";
                }
                // line 43
                echo "                <span>";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new Twig_Error_Runtime('Variable "item" does not exist.', 43, $this->getSourceContext()); })()), "label", array()), "html", null, true);
                echo "</span>
                ";
                // line 44
                if (twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new Twig_Error_Runtime('Variable "item" does not exist.', 44, $this->getSourceContext()); })()), "badge", array())) {
                    // line 45
                    echo "                    <small class=\"label pull-right bg-";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new Twig_Error_Runtime('Variable "item" does not exist.', 45, $this->getSourceContext()); })()), "badgeColor", array()), "html", null, true);
                    echo "\">";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new Twig_Error_Runtime('Variable "item" does not exist.', 45, $this->getSourceContext()); })()), "badge", array()), "html", null, true);
                    echo "</small>
                ";
                }
                // line 47
                echo "                ";
                if (twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new Twig_Error_Runtime('Variable "item" does not exist.', 47, $this->getSourceContext()); })()), "hasChildren", array())) {
                    echo "<i class=\"fa fa-angle-left pull-right\"></i>";
                }
                // line 48
                echo "            </a>

            ";
                // line 50
                if (twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new Twig_Error_Runtime('Variable "item" does not exist.', 50, $this->getSourceContext()); })()), "hasChildren", array())) {
                    // line 51
                    echo "                <ul class=\"treeview-menu\">
                    ";
                    // line 52
                    $context['_parent'] = $context;
                    $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new Twig_Error_Runtime('Variable "item" does not exist.', 52, $this->getSourceContext()); })()), "children", array()));
                    foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
                        // line 53
                        echo "                        <li class=\"";
                        echo ((twig_get_attribute($this->env, $this->getSourceContext(), $context["child"], "isActive", array())) ? ("active") : (""));
                        echo "\" id=\"";
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["child"], "identifier", array()), "html", null, true);
                        echo "\">
                            <a href=\"";
                        // line 54
                        echo twig_escape_filter($this->env, ((twig_in_filter("/", twig_get_attribute($this->env, $this->getSourceContext(), $context["child"], "route", array()))) ? (twig_get_attribute($this->env, $this->getSourceContext(), $context["child"], "route", array())) : ($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath(twig_get_attribute($this->env, $this->getSourceContext(), $context["child"], "route", array()), twig_get_attribute($this->env, $this->getSourceContext(), $context["child"], "routeArgs", array())))), "html", null, true);
                        echo "\">
                                <i class=\"";
                        // line 55
                        echo twig_escape_filter($this->env, ((twig_get_attribute($this->env, $this->getSourceContext(), $context["child"], "icon", array(), "any", true, true)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->getSourceContext(), $context["child"], "icon", array()), "fa fa-circle-o")) : ("fa fa-circle-o")), "html", null, true);
                        echo "\"></i>
                                ";
                        // line 56
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["child"], "label", array()), "html", null, true);
                        echo "
                            </a>
                        </li>
                    ";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['_key'], $context['child'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                    // line 60
                    echo "                </ul>
            ";
                }
                // line 62
                echo "        </li>
    ";
            } else {
                // line 64
                echo "        <li class=\"header\">
            ";
                // line 65
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new Twig_Error_Runtime('Variable "item" does not exist.', 65, $this->getSourceContext()); })()), "label", array()), "html", null, true);
                echo "
            ";
                // line 66
                if (twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new Twig_Error_Runtime('Variable "item" does not exist.', 66, $this->getSourceContext()); })()), "badge", array())) {
                    // line 67
                    echo "                <small class=\"label pull-right bg-";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new Twig_Error_Runtime('Variable "item" does not exist.', 67, $this->getSourceContext()); })()), "badgeColor", array()), "html", null, true);
                    echo "\">";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new Twig_Error_Runtime('Variable "item" does not exist.', 67, $this->getSourceContext()); })()), "badge", array()), "html", null, true);
                    echo "</small>
            ";
                }
                // line 69
                echo "        </li>
    ";
            }
            
            $__internal_b586fa285b03f6f4afc6d19f772698b86074e9a426051596775bdadb7b704f9d->leave($__internal_b586fa285b03f6f4afc6d19f772698b86074e9a426051596775bdadb7b704f9d_prof);

            
            $__internal_8f4484a135627647d5d65a4c1d4f455239e2eabd3f7b88bf2cdc13463ee850c7->leave($__internal_8f4484a135627647d5d65a4c1d4f455239e2eabd3f7b88bf2cdc13463ee850c7_prof);


            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    public function getTemplateName()
    {
        return "AvanzuAdminThemeBundle:layout:macros.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  369 => 69,  361 => 67,  359 => 66,  355 => 65,  352 => 64,  348 => 62,  344 => 60,  334 => 56,  330 => 55,  326 => 54,  319 => 53,  315 => 52,  312 => 51,  310 => 50,  306 => 48,  301 => 47,  293 => 45,  291 => 44,  286 => 43,  280 => 42,  276 => 41,  267 => 40,  264 => 39,  246 => 38,  223 => 34,  213 => 32,  210 => 31,  190 => 30,  172 => 25,  168 => 24,  164 => 22,  143 => 21,  131 => 17,  125 => 15,  122 => 14,  116 => 12,  114 => 11,  111 => 10,  108 => 9,  99 => 8,  86 => 5,  77 => 4,  64 => 2,  55 => 1,  44 => 37,  40 => 28,  37 => 20,  35 => 8,  32 => 7,  30 => 4,  28 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block box_collapse %}
    <button class=\"btn btn-{{ type|default('info') }} btn-sm\" data-widget=\"collapse\"><i class=\"fa fa-minus\"></i></button>
{% endblock %}
{% block box_remove %}
    <button class=\"btn btn-{{ type|default('info') }} btn-sm\" data-widget=\"remove\"><i class=\"fa fa-times\"></i></button>
{% endblock %}

{% block box_header_buttons %}
    {% if collapse or remove %}
        <div class=\"box-tools pull-right\">
            {% if collapse %}
                {{ block('box_collapse') }}
            {% endif %}
            {% if remove %}
                {{ block('box_remove') }}
            {% endif %}
        </div>
    {% endif %}
{% endblock %}

{% macro box_header(title, collapse, remove, type) %}

    <div class=\"box-header\">
        <h3 class=\"box-title\">{{ title }}</h3>
        {{ block('box_header_buttons') }}
    </div>
{% endmacro %}


{% macro avatar(image, alt, class) %}
    {% if image %}
        <img src=\"{{ asset(image) }}\" class=\"{{ class|default('img-circle') }}\" alt=\"{{ alt }}\" />
    {% else %}
        <img src=\"{{ asset('bundles/avanzuadmintheme/img/avatar.png') }}\" class=\"{{ class|default('img-circle') }}\" alt=\"{{ alt }}\" />
    {% endif %}
{% endmacro %}

{% macro menu_item(item) %}
    {% if item.route or item.hasChildren %}
        <li id=\"{{ item.identifier }}\" class=\" {{ item.isActive ? 'active' : '' }} {{ item.hasChildren? 'treeview' : '' }}\">
            <a href=\"{{ item.hasChildren ? '#': '/' in item.route ? item.route : path(item.route, item.routeArgs) }}\">
                {% if item.icon %} <i class=\"{{ item.icon }}\"></i> {% endif %}
                <span>{{ item.label }}</span>
                {% if item.badge %}
                    <small class=\"label pull-right bg-{{ item.badgeColor }}\">{{ item.badge }}</small>
                {% endif %}
                {% if item.hasChildren %}<i class=\"fa fa-angle-left pull-right\"></i>{% endif %}
            </a>

            {% if item.hasChildren %}
                <ul class=\"treeview-menu\">
                    {% for child in item.children %}
                        <li class=\"{{ child.isActive ? 'active':'' }}\" id=\"{{ child.identifier }}\">
                            <a href=\"{{ '/' in child.route ? child.route : path(child.route, child.routeArgs) }}\">
                                <i class=\"{{ child.icon|default('fa fa-circle-o') }}\"></i>
                                {{ child.label }}
                            </a>
                        </li>
                    {% endfor %}
                </ul>
            {% endif %}
        </li>
    {% else %}
        <li class=\"header\">
            {{ item.label }}
            {% if item.badge %}
                <small class=\"label pull-right bg-{{ item.badgeColor }}\">{{ item.badge }}</small>
            {% endif %}
        </li>
    {% endif %}
{% endmacro %}
", "AvanzuAdminThemeBundle:layout:macros.html.twig", "/home/sorina/Documents/work/movies_crowler/vendor/avanzu/admin-theme-bundle/Resources/views/layout/macros.html.twig");
    }
}
