<?php

/* @Framework/Form/email_widget.html.php */
class __TwigTemplate_c3f0e0e17f985c6877c55c7a0b7f45761d5fc233e8c7dab31dadf35a8947c7e7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_75400cb93179e4aa27bf3b234d98d37f9556d39140172bcde32c81f6d10b187c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_75400cb93179e4aa27bf3b234d98d37f9556d39140172bcde32c81f6d10b187c->enter($__internal_75400cb93179e4aa27bf3b234d98d37f9556d39140172bcde32c81f6d10b187c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/email_widget.html.php"));

        $__internal_d60d0c67f2afefff488bf18331975f28157e4caf62c052fab957ebb49ea83d25 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d60d0c67f2afefff488bf18331975f28157e4caf62c052fab957ebb49ea83d25->enter($__internal_d60d0c67f2afefff488bf18331975f28157e4caf62c052fab957ebb49ea83d25_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/email_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'email')) ?>
";
        
        $__internal_75400cb93179e4aa27bf3b234d98d37f9556d39140172bcde32c81f6d10b187c->leave($__internal_75400cb93179e4aa27bf3b234d98d37f9556d39140172bcde32c81f6d10b187c_prof);

        
        $__internal_d60d0c67f2afefff488bf18331975f28157e4caf62c052fab957ebb49ea83d25->leave($__internal_d60d0c67f2afefff488bf18331975f28157e4caf62c052fab957ebb49ea83d25_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/email_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'email')) ?>
", "@Framework/Form/email_widget.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/email_widget.html.php");
    }
}
