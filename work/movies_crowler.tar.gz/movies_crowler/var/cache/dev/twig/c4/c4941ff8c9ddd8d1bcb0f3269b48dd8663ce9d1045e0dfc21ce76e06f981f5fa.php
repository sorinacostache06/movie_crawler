<?php

/* @Framework/Form/form_widget.html.php */
class __TwigTemplate_5ddfc765c000494ad6b6617ccad802188987a8fb2fa984b7362972e44c08d500 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_69ed285648c26ef49a5628635ef7d892b8fe9d7fd996c059c84a556d5c307ea6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_69ed285648c26ef49a5628635ef7d892b8fe9d7fd996c059c84a556d5c307ea6->enter($__internal_69ed285648c26ef49a5628635ef7d892b8fe9d7fd996c059c84a556d5c307ea6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget.html.php"));

        $__internal_d8b5ab81df00510b75cbbe5ae231f5f5787c5fd4856b22a8058d6e65aeebb643 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d8b5ab81df00510b75cbbe5ae231f5f5787c5fd4856b22a8058d6e65aeebb643->enter($__internal_d8b5ab81df00510b75cbbe5ae231f5f5787c5fd4856b22a8058d6e65aeebb643_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget.html.php"));

        // line 1
        echo "<?php if (\$compound): ?>
<?php echo \$view['form']->block(\$form, 'form_widget_compound')?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'form_widget_simple')?>
<?php endif ?>
";
        
        $__internal_69ed285648c26ef49a5628635ef7d892b8fe9d7fd996c059c84a556d5c307ea6->leave($__internal_69ed285648c26ef49a5628635ef7d892b8fe9d7fd996c059c84a556d5c307ea6_prof);

        
        $__internal_d8b5ab81df00510b75cbbe5ae231f5f5787c5fd4856b22a8058d6e65aeebb643->leave($__internal_d8b5ab81df00510b75cbbe5ae231f5f5787c5fd4856b22a8058d6e65aeebb643_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$compound): ?>
<?php echo \$view['form']->block(\$form, 'form_widget_compound')?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'form_widget_simple')?>
<?php endif ?>
", "@Framework/Form/form_widget.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_widget.html.php");
    }
}
