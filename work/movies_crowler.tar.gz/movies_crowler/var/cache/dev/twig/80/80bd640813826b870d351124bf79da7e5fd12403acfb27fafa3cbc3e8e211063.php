<?php

/* AvanzuAdminThemeBundle:layout:login-layout.html.twig */
class __TwigTemplate_3fe42bb3358d50b3cc10b2361950411007cca846de803a928d10eb76cc45241c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts_head' => array($this, 'block_javascripts_head'),
            'page_content' => array($this, 'block_page_content'),
            'javascripts' => array($this, 'block_javascripts'),
            'javascripts_inline' => array($this, 'block_javascripts_inline'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_176110dca690f57aae25d145af5c2878dbdea7e6da5a427bc01c08f5d718c25b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_176110dca690f57aae25d145af5c2878dbdea7e6da5a427bc01c08f5d718c25b->enter($__internal_176110dca690f57aae25d145af5c2878dbdea7e6da5a427bc01c08f5d718c25b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AvanzuAdminThemeBundle:layout:login-layout.html.twig"));

        $__internal_b4ad2e6c5cef7af2d7927afaf8afd42f4b5e9299cbd33adc9912a8e200f4ccdd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b4ad2e6c5cef7af2d7927afaf8afd42f4b5e9299cbd33adc9912a8e200f4ccdd->enter($__internal_b4ad2e6c5cef7af2d7927afaf8afd42f4b5e9299cbd33adc9912a8e200f4ccdd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AvanzuAdminThemeBundle:layout:login-layout.html.twig"));

        // line 1
        $context["macro"] = $this->loadTemplate("AvanzuAdminThemeBundle:layout:macros.html.twig", "AvanzuAdminThemeBundle:layout:login-layout.html.twig", 1);
        // line 2
        echo "<!doctype html>
<!--[if lt IE 7 ]><html lang=\"en\" class=\"no-js ie6\"> <![endif]-->
<!--[if IE 7 ]><html lang=\"en\" class=\"no-js ie7\"> <![endif]-->
<!--[if IE 8 ]><html lang=\"en\" class=\"no-js ie8\"> <![endif]-->
<!--[if IE 9 ]><html lang=\"en\" class=\"no-js ie9\"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--><html lang=\"en\" class=\"no-js\"> <!--<![endif]-->
<head>
    <meta charset=\"utf-8\">
    <meta name=\"author\" content=\"\">
    <meta name=\"keywords\" content=\"\">
    <meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">
    <title>";
        // line 13
        $this->displayBlock('title', $context, $blocks);
        echo "</title>

    ";
        // line 16
        echo "    ";
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 19
        echo "

    <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />

    ";
        // line 24
        echo "    ";
        $this->displayBlock('javascripts_head', $context, $blocks);
        // line 31
        echo "
</head>
<body class=\"login-page\">
";
        // line 34
        $this->displayBlock('page_content', $context, $blocks);
        // line 35
        echo "

";
        // line 38
        $this->displayBlock('javascripts', $context, $blocks);
        // line 41
        echo "
";
        // line 43
        $this->displayBlock('javascripts_inline', $context, $blocks);
        // line 45
        echo "</body>
</html>
";
        
        $__internal_176110dca690f57aae25d145af5c2878dbdea7e6da5a427bc01c08f5d718c25b->leave($__internal_176110dca690f57aae25d145af5c2878dbdea7e6da5a427bc01c08f5d718c25b_prof);

        
        $__internal_b4ad2e6c5cef7af2d7927afaf8afd42f4b5e9299cbd33adc9912a8e200f4ccdd->leave($__internal_b4ad2e6c5cef7af2d7927afaf8afd42f4b5e9299cbd33adc9912a8e200f4ccdd_prof);

    }

    // line 13
    public function block_title($context, array $blocks = array())
    {
        $__internal_a7c83f5a5d3c132bb3e72fb96265ca4831bead1a78ebd3f962b07cc3138f5ddc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a7c83f5a5d3c132bb3e72fb96265ca4831bead1a78ebd3f962b07cc3138f5ddc->enter($__internal_a7c83f5a5d3c132bb3e72fb96265ca4831bead1a78ebd3f962b07cc3138f5ddc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_7f3fef95ec62a2baa786701e99636a101c2134f6f22e1664ddef428b37384946 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7f3fef95ec62a2baa786701e99636a101c2134f6f22e1664ddef428b37384946->enter($__internal_7f3fef95ec62a2baa786701e99636a101c2134f6f22e1664ddef428b37384946_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Avanzu Admin!";
        
        $__internal_7f3fef95ec62a2baa786701e99636a101c2134f6f22e1664ddef428b37384946->leave($__internal_7f3fef95ec62a2baa786701e99636a101c2134f6f22e1664ddef428b37384946_prof);

        
        $__internal_a7c83f5a5d3c132bb3e72fb96265ca4831bead1a78ebd3f962b07cc3138f5ddc->leave($__internal_a7c83f5a5d3c132bb3e72fb96265ca4831bead1a78ebd3f962b07cc3138f5ddc_prof);

    }

    // line 16
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_2913e9c35bd841089f291bba8043519dd90d17f88ffa9ff4d580202ad5a1381e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2913e9c35bd841089f291bba8043519dd90d17f88ffa9ff4d580202ad5a1381e->enter($__internal_2913e9c35bd841089f291bba8043519dd90d17f88ffa9ff4d580202ad5a1381e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_fc3b41f55171779039083ac1ffcce794e5440b150370f2bd4c45cb74cc85dd8a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fc3b41f55171779039083ac1ffcce794e5440b150370f2bd4c45cb74cc85dd8a->enter($__internal_fc3b41f55171779039083ac1ffcce794e5440b150370f2bd4c45cb74cc85dd8a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 17
        echo "        <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl((("bundles/avanzuadmintheme/static/" . twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 17, $this->getSourceContext()); })()), "environment", array())) . "/styles/admin-lte-all.css")), "html", null, true);
        echo "\" />
    ";
        
        $__internal_fc3b41f55171779039083ac1ffcce794e5440b150370f2bd4c45cb74cc85dd8a->leave($__internal_fc3b41f55171779039083ac1ffcce794e5440b150370f2bd4c45cb74cc85dd8a_prof);

        
        $__internal_2913e9c35bd841089f291bba8043519dd90d17f88ffa9ff4d580202ad5a1381e->leave($__internal_2913e9c35bd841089f291bba8043519dd90d17f88ffa9ff4d580202ad5a1381e_prof);

    }

    // line 24
    public function block_javascripts_head($context, array $blocks = array())
    {
        $__internal_a64a3a9622b6559a9fe99bb81aaa7c4ba15a369f8a0b3adf1ee0a312bdb26b3d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a64a3a9622b6559a9fe99bb81aaa7c4ba15a369f8a0b3adf1ee0a312bdb26b3d->enter($__internal_a64a3a9622b6559a9fe99bb81aaa7c4ba15a369f8a0b3adf1ee0a312bdb26b3d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts_head"));

        $__internal_7dd8c57b6b18243bf4c9f807628984ae11c1a4cc07c2272f6af48dd9c83e11e9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7dd8c57b6b18243bf4c9f807628984ae11c1a4cc07c2272f6af48dd9c83e11e9->enter($__internal_7dd8c57b6b18243bf4c9f807628984ae11c1a4cc07c2272f6af48dd9c83e11e9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts_head"));

        // line 25
        echo "        <script type=\"text/javascript\" src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl((("bundles/avanzuadmintheme/static/" . twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 25, $this->getSourceContext()); })()), "environment", array())) . "/scripts/modernizr.js")), "html", null, true);
        echo "\"></script>
        <!--[if lt IE 9]>

        <![endif]-->

    ";
        
        $__internal_7dd8c57b6b18243bf4c9f807628984ae11c1a4cc07c2272f6af48dd9c83e11e9->leave($__internal_7dd8c57b6b18243bf4c9f807628984ae11c1a4cc07c2272f6af48dd9c83e11e9_prof);

        
        $__internal_a64a3a9622b6559a9fe99bb81aaa7c4ba15a369f8a0b3adf1ee0a312bdb26b3d->leave($__internal_a64a3a9622b6559a9fe99bb81aaa7c4ba15a369f8a0b3adf1ee0a312bdb26b3d_prof);

    }

    // line 34
    public function block_page_content($context, array $blocks = array())
    {
        $__internal_d5e2ae084f06ab7cce2e1643d34cad5c8073ddcd7049858959021c6806f2f806 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d5e2ae084f06ab7cce2e1643d34cad5c8073ddcd7049858959021c6806f2f806->enter($__internal_d5e2ae084f06ab7cce2e1643d34cad5c8073ddcd7049858959021c6806f2f806_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_content"));

        $__internal_e413223afe70f5d42c0ffd800dde34b4ebd667ff2aa47175d36cbf5cddd99e44 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e413223afe70f5d42c0ffd800dde34b4ebd667ff2aa47175d36cbf5cddd99e44->enter($__internal_e413223afe70f5d42c0ffd800dde34b4ebd667ff2aa47175d36cbf5cddd99e44_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_content"));

        
        $__internal_e413223afe70f5d42c0ffd800dde34b4ebd667ff2aa47175d36cbf5cddd99e44->leave($__internal_e413223afe70f5d42c0ffd800dde34b4ebd667ff2aa47175d36cbf5cddd99e44_prof);

        
        $__internal_d5e2ae084f06ab7cce2e1643d34cad5c8073ddcd7049858959021c6806f2f806->leave($__internal_d5e2ae084f06ab7cce2e1643d34cad5c8073ddcd7049858959021c6806f2f806_prof);

    }

    // line 38
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_fce261c41b5f9a9bb9eeb85e557ee3e80455d2b618cb9fe39719c1b73aad86eb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fce261c41b5f9a9bb9eeb85e557ee3e80455d2b618cb9fe39719c1b73aad86eb->enter($__internal_fce261c41b5f9a9bb9eeb85e557ee3e80455d2b618cb9fe39719c1b73aad86eb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_8420914d449bb2d9cb04e0ffea3798f4519387445032bcd96f54a07e45194f69 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8420914d449bb2d9cb04e0ffea3798f4519387445032bcd96f54a07e45194f69->enter($__internal_8420914d449bb2d9cb04e0ffea3798f4519387445032bcd96f54a07e45194f69_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 39
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl((("bundles/avanzuadmintheme/static/" . twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 39, $this->getSourceContext()); })()), "environment", array())) . "/scripts/admin-lte-all.js")), "html", null, true);
        echo "\"></script>
";
        
        $__internal_8420914d449bb2d9cb04e0ffea3798f4519387445032bcd96f54a07e45194f69->leave($__internal_8420914d449bb2d9cb04e0ffea3798f4519387445032bcd96f54a07e45194f69_prof);

        
        $__internal_fce261c41b5f9a9bb9eeb85e557ee3e80455d2b618cb9fe39719c1b73aad86eb->leave($__internal_fce261c41b5f9a9bb9eeb85e557ee3e80455d2b618cb9fe39719c1b73aad86eb_prof);

    }

    // line 43
    public function block_javascripts_inline($context, array $blocks = array())
    {
        $__internal_6748b48a5e8918d498386eb60300b80faa22fff4c6b3df997a42081fa7300de1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6748b48a5e8918d498386eb60300b80faa22fff4c6b3df997a42081fa7300de1->enter($__internal_6748b48a5e8918d498386eb60300b80faa22fff4c6b3df997a42081fa7300de1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts_inline"));

        $__internal_9c7e26eeec8071324573b5812aa564a2e542a1d5078fd935a8fd005e7a872edb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9c7e26eeec8071324573b5812aa564a2e542a1d5078fd935a8fd005e7a872edb->enter($__internal_9c7e26eeec8071324573b5812aa564a2e542a1d5078fd935a8fd005e7a872edb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts_inline"));

        
        $__internal_9c7e26eeec8071324573b5812aa564a2e542a1d5078fd935a8fd005e7a872edb->leave($__internal_9c7e26eeec8071324573b5812aa564a2e542a1d5078fd935a8fd005e7a872edb_prof);

        
        $__internal_6748b48a5e8918d498386eb60300b80faa22fff4c6b3df997a42081fa7300de1->leave($__internal_6748b48a5e8918d498386eb60300b80faa22fff4c6b3df997a42081fa7300de1_prof);

    }

    public function getTemplateName()
    {
        return "AvanzuAdminThemeBundle:layout:login-layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  201 => 43,  188 => 39,  179 => 38,  162 => 34,  145 => 25,  136 => 24,  123 => 17,  114 => 16,  96 => 13,  84 => 45,  82 => 43,  79 => 41,  77 => 38,  73 => 35,  71 => 34,  66 => 31,  63 => 24,  58 => 21,  54 => 19,  51 => 16,  46 => 13,  33 => 2,  31 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% import \"AvanzuAdminThemeBundle:layout:macros.html.twig\" as macro %}
<!doctype html>
<!--[if lt IE 7 ]><html lang=\"en\" class=\"no-js ie6\"> <![endif]-->
<!--[if IE 7 ]><html lang=\"en\" class=\"no-js ie7\"> <![endif]-->
<!--[if IE 8 ]><html lang=\"en\" class=\"no-js ie8\"> <![endif]-->
<!--[if IE 9 ]><html lang=\"en\" class=\"no-js ie9\"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--><html lang=\"en\" class=\"no-js\"> <!--<![endif]-->
<head>
    <meta charset=\"utf-8\">
    <meta name=\"author\" content=\"\">
    <meta name=\"keywords\" content=\"\">
    <meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">
    <title>{% block title %}Avanzu Admin!{% endblock %}</title>

    {# -------------------------------------------------------------------------------------------------- STYLESHEETS #}
    {% block stylesheets %}
        <link rel=\"stylesheet\" href=\"{{ asset('bundles/avanzuadmintheme/static/'~ app.environment ~'/styles/admin-lte-all.css') }}\" />
    {% endblock %}


    <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />

    {# --------------------------------------------------------------------------------------------- JAVASCRIPTS_HEAD #}
    {%  block javascripts_head %}
        <script type=\"text/javascript\" src=\"{{ asset('bundles/avanzuadmintheme/static/'~ app.environment ~'/scripts/modernizr.js') }}\"></script>
        <!--[if lt IE 9]>

        <![endif]-->

    {% endblock %}

</head>
<body class=\"login-page\">
{% block page_content %}{% endblock %}


{# ------------------------------------------------------------------------------------------------------ JAVASCRIPTS #}
{% block javascripts %}
    <script src=\"{{ asset('bundles/avanzuadmintheme/static/'~ app.environment ~'/scripts/admin-lte-all.js') }}\"></script>
{% endblock %}

{# ----------------------------------------------------------------------------------------------- JAVASCRIPTS_INLINE #}
{% block javascripts_inline %}
{% endblock %}
</body>
</html>
", "AvanzuAdminThemeBundle:layout:login-layout.html.twig", "/home/sorina/Documents/work/movies_crowler/vendor/avanzu/admin-theme-bundle/Resources/views/layout/login-layout.html.twig");
    }
}
