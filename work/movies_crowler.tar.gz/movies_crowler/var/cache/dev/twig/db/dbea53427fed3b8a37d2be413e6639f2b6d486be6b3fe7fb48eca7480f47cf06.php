<?php

/* @Framework/Form/choice_options.html.php */
class __TwigTemplate_cce2f41d4bf9ffd4fc3b53fd8abb7fc91cf18436fe8cc20267e7d6bd1a0e6487 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_619aba7b1beb88703eb301a6d20204abc912a4a60789efe8fd909ba472d3cd05 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_619aba7b1beb88703eb301a6d20204abc912a4a60789efe8fd909ba472d3cd05->enter($__internal_619aba7b1beb88703eb301a6d20204abc912a4a60789efe8fd909ba472d3cd05_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        $__internal_3ccfaebd1708a6eaec5288b6a8902d516ce1acffc9347691b82f86aea3d2df0c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3ccfaebd1708a6eaec5288b6a8902d516ce1acffc9347691b82f86aea3d2df0c->enter($__internal_3ccfaebd1708a6eaec5288b6a8902d516ce1acffc9347691b82f86aea3d2df0c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
";
        
        $__internal_619aba7b1beb88703eb301a6d20204abc912a4a60789efe8fd909ba472d3cd05->leave($__internal_619aba7b1beb88703eb301a6d20204abc912a4a60789efe8fd909ba472d3cd05_prof);

        
        $__internal_3ccfaebd1708a6eaec5288b6a8902d516ce1acffc9347691b82f86aea3d2df0c->leave($__internal_3ccfaebd1708a6eaec5288b6a8902d516ce1acffc9347691b82f86aea3d2df0c_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_options.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
", "@Framework/Form/choice_options.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/choice_options.html.php");
    }
}
