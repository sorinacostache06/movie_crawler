<?php

/* @Framework/Form/form_label.html.php */
class __TwigTemplate_f8143d0db401853410d55ddca5943e93f0389cb6ad2a1fab0da631f1923ad4ea extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d8fc3bc1b99b38ee8931c0f572cdc90e47314f610900cf8afb97645bfee89d5e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d8fc3bc1b99b38ee8931c0f572cdc90e47314f610900cf8afb97645bfee89d5e->enter($__internal_d8fc3bc1b99b38ee8931c0f572cdc90e47314f610900cf8afb97645bfee89d5e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_label.html.php"));

        $__internal_0ec92974c7a06984a66c32617d8debec91fabe052a8954c792ae748fcf4b6beb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0ec92974c7a06984a66c32617d8debec91fabe052a8954c792ae748fcf4b6beb->enter($__internal_0ec92974c7a06984a66c32617d8debec91fabe052a8954c792ae748fcf4b6beb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_label.html.php"));

        // line 1
        echo "<?php if (false !== \$label): ?>
<?php if (\$required) { \$label_attr['class'] = trim((isset(\$label_attr['class']) ? \$label_attr['class'] : '').' required'); } ?>
<?php if (!\$compound) { \$label_attr['for'] = \$id; } ?>
<?php if (!\$label) { \$label = isset(\$label_format)
    ? strtr(\$label_format, array('%name%' => \$name, '%id%' => \$id))
    : \$view['form']->humanize(\$name); } ?>
<label <?php foreach (\$label_attr as \$k => \$v) { printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$v)); } ?>><?php echo \$view->escape(false !== \$translation_domain ? \$view['translator']->trans(\$label, array(), \$translation_domain) : \$label) ?></label>
<?php endif ?>
";
        
        $__internal_d8fc3bc1b99b38ee8931c0f572cdc90e47314f610900cf8afb97645bfee89d5e->leave($__internal_d8fc3bc1b99b38ee8931c0f572cdc90e47314f610900cf8afb97645bfee89d5e_prof);

        
        $__internal_0ec92974c7a06984a66c32617d8debec91fabe052a8954c792ae748fcf4b6beb->leave($__internal_0ec92974c7a06984a66c32617d8debec91fabe052a8954c792ae748fcf4b6beb_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_label.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (false !== \$label): ?>
<?php if (\$required) { \$label_attr['class'] = trim((isset(\$label_attr['class']) ? \$label_attr['class'] : '').' required'); } ?>
<?php if (!\$compound) { \$label_attr['for'] = \$id; } ?>
<?php if (!\$label) { \$label = isset(\$label_format)
    ? strtr(\$label_format, array('%name%' => \$name, '%id%' => \$id))
    : \$view['form']->humanize(\$name); } ?>
<label <?php foreach (\$label_attr as \$k => \$v) { printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$v)); } ?>><?php echo \$view->escape(false !== \$translation_domain ? \$view['translator']->trans(\$label, array(), \$translation_domain) : \$label) ?></label>
<?php endif ?>
", "@Framework/Form/form_label.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_label.html.php");
    }
}
