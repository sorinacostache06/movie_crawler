<?php

/* TwigBundle:Exception:exception.atom.twig */
class __TwigTemplate_be9c9169cd86076fbd1c6c22a3d1c79b35f87fd34acf3274957eaf6ad5980eeb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_41ef28e2c63a0817687d15bb101585821ae5b7a6e848f989e973e4b8f7a16d76 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_41ef28e2c63a0817687d15bb101585821ae5b7a6e848f989e973e4b8f7a16d76->enter($__internal_41ef28e2c63a0817687d15bb101585821ae5b7a6e848f989e973e4b8f7a16d76_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.atom.twig"));

        $__internal_c692616a204ff99bdd9c055811f4e31fddfebd72855952a680ef4a9f14564558 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c692616a204ff99bdd9c055811f4e31fddfebd72855952a680ef4a9f14564558->enter($__internal_c692616a204ff99bdd9c055811f4e31fddfebd72855952a680ef4a9f14564558_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/exception.xml.twig", "TwigBundle:Exception:exception.atom.twig", 1)->display(array_merge($context, array("exception" => (isset($context["exception"]) || array_key_exists("exception", $context) ? $context["exception"] : (function () { throw new Twig_Error_Runtime('Variable "exception" does not exist.', 1, $this->getSourceContext()); })()))));
        
        $__internal_41ef28e2c63a0817687d15bb101585821ae5b7a6e848f989e973e4b8f7a16d76->leave($__internal_41ef28e2c63a0817687d15bb101585821ae5b7a6e848f989e973e4b8f7a16d76_prof);

        
        $__internal_c692616a204ff99bdd9c055811f4e31fddfebd72855952a680ef4a9f14564558->leave($__internal_c692616a204ff99bdd9c055811f4e31fddfebd72855952a680ef4a9f14564558_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include '@Twig/Exception/exception.xml.twig' with { 'exception': exception } %}
", "TwigBundle:Exception:exception.atom.twig", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/exception.atom.twig");
    }
}
