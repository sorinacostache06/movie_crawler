<?php

/* @Framework/Form/button_widget.html.php */
class __TwigTemplate_289a2e98cad7996270ae1a37e7d28af7b4bfe8c9b38de40ffe1aaef558b429b5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b543584e144601bcd73868e0fec9e10dafc1abdcb0135e92a8b7146fa355a10c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b543584e144601bcd73868e0fec9e10dafc1abdcb0135e92a8b7146fa355a10c->enter($__internal_b543584e144601bcd73868e0fec9e10dafc1abdcb0135e92a8b7146fa355a10c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_widget.html.php"));

        $__internal_c98476863d5089892301423273cc00e637a4e0a6c3f8be632e9087557165aeb4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c98476863d5089892301423273cc00e637a4e0a6c3f8be632e9087557165aeb4->enter($__internal_c98476863d5089892301423273cc00e637a4e0a6c3f8be632e9087557165aeb4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_widget.html.php"));

        // line 1
        echo "<?php if (!\$label) { \$label = isset(\$label_format)
    ? strtr(\$label_format, array('%name%' => \$name, '%id%' => \$id))
    : \$view['form']->humanize(\$name); } ?>
<button type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'button' ?>\" <?php echo \$view['form']->block(\$form, 'button_attributes') ?>><?php echo \$view->escape(false !== \$translation_domain ? \$view['translator']->trans(\$label, array(), \$translation_domain) : \$label) ?></button>
";
        
        $__internal_b543584e144601bcd73868e0fec9e10dafc1abdcb0135e92a8b7146fa355a10c->leave($__internal_b543584e144601bcd73868e0fec9e10dafc1abdcb0135e92a8b7146fa355a10c_prof);

        
        $__internal_c98476863d5089892301423273cc00e637a4e0a6c3f8be632e9087557165aeb4->leave($__internal_c98476863d5089892301423273cc00e637a4e0a6c3f8be632e9087557165aeb4_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (!\$label) { \$label = isset(\$label_format)
    ? strtr(\$label_format, array('%name%' => \$name, '%id%' => \$id))
    : \$view['form']->humanize(\$name); } ?>
<button type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'button' ?>\" <?php echo \$view['form']->block(\$form, 'button_attributes') ?>><?php echo \$view->escape(false !== \$translation_domain ? \$view['translator']->trans(\$label, array(), \$translation_domain) : \$label) ?></button>
", "@Framework/Form/button_widget.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/button_widget.html.php");
    }
}
