<?php

/* :default:base-navbar-static.html.twig */
class __TwigTemplate_39309992e438406931b0044bf580bb65b15189ad86aa2137662394aaf6901a5e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fa71624e214ed75485bdcf2e0854463a810d3966d13062aee4ffa8c11fe50704 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fa71624e214ed75485bdcf2e0854463a810d3966d13062aee4ffa8c11fe50704->enter($__internal_fa71624e214ed75485bdcf2e0854463a810d3966d13062aee4ffa8c11fe50704_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":default:base-navbar-static.html.twig"));

        $__internal_762165319b6582d789e9fde0206dae9c7a07e38f501397384ce48e875f50124f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_762165319b6582d789e9fde0206dae9c7a07e38f501397384ce48e875f50124f->enter($__internal_762165319b6582d789e9fde0206dae9c7a07e38f501397384ce48e875f50124f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":default:base-navbar-static.html.twig"));

        
        $__internal_fa71624e214ed75485bdcf2e0854463a810d3966d13062aee4ffa8c11fe50704->leave($__internal_fa71624e214ed75485bdcf2e0854463a810d3966d13062aee4ffa8c11fe50704_prof);

        
        $__internal_762165319b6582d789e9fde0206dae9c7a07e38f501397384ce48e875f50124f->leave($__internal_762165319b6582d789e9fde0206dae9c7a07e38f501397384ce48e875f50124f_prof);

    }

    public function getTemplateName()
    {
        return ":default:base-navbar-static.html.twig";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", ":default:base-navbar-static.html.twig", "/home/sorina/Documents/work/movies_crowler/app/Resources/views/default/base-navbar-static.html.twig");
    }
}
