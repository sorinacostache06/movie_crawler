<?php

/* :Admin:success.html.twig */
class __TwigTemplate_d8b29fa5f8e81d3d5f56200b35944acf62d7657dcc9a55bcf5d9b60a0318bb10 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base-layout.html.twig", ":Admin:success.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base-layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5f14c3cef1bd9cb2ae97b5ff9015b440c34468520b96330bd19ed891973f0761 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5f14c3cef1bd9cb2ae97b5ff9015b440c34468520b96330bd19ed891973f0761->enter($__internal_5f14c3cef1bd9cb2ae97b5ff9015b440c34468520b96330bd19ed891973f0761_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Admin:success.html.twig"));

        $__internal_7d0c65c10dc42f63bc90b4cb5cdb4c5ff244ad5540e1364d39e0718aed5ce178 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7d0c65c10dc42f63bc90b4cb5cdb4c5ff244ad5540e1364d39e0718aed5ce178->enter($__internal_7d0c65c10dc42f63bc90b4cb5cdb4c5ff244ad5540e1364d39e0718aed5ce178_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Admin:success.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5f14c3cef1bd9cb2ae97b5ff9015b440c34468520b96330bd19ed891973f0761->leave($__internal_5f14c3cef1bd9cb2ae97b5ff9015b440c34468520b96330bd19ed891973f0761_prof);

        
        $__internal_7d0c65c10dc42f63bc90b4cb5cdb4c5ff244ad5540e1364d39e0718aed5ce178->leave($__internal_7d0c65c10dc42f63bc90b4cb5cdb4c5ff244ad5540e1364d39e0718aed5ce178_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_41a837c9e349fd543399de5516a0ac299e262f0d94324b1315937464b3f2c7a2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_41a837c9e349fd543399de5516a0ac299e262f0d94324b1315937464b3f2c7a2->enter($__internal_41a837c9e349fd543399de5516a0ac299e262f0d94324b1315937464b3f2c7a2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_cd54080aed5801adccd890f0bf0469dc1b2d68f03fa4243d2104edbe703937df = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cd54080aed5801adccd890f0bf0469dc1b2d68f03fa4243d2104edbe703937df->enter($__internal_cd54080aed5801adccd890f0bf0469dc1b2d68f03fa4243d2104edbe703937df_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 4
        echo "    <div>
        Autentificare cu succes!
    </div>
";
        
        $__internal_cd54080aed5801adccd890f0bf0469dc1b2d68f03fa4243d2104edbe703937df->leave($__internal_cd54080aed5801adccd890f0bf0469dc1b2d68f03fa4243d2104edbe703937df_prof);

        
        $__internal_41a837c9e349fd543399de5516a0ac299e262f0d94324b1315937464b3f2c7a2->leave($__internal_41a837c9e349fd543399de5516a0ac299e262f0d94324b1315937464b3f2c7a2_prof);

    }

    public function getTemplateName()
    {
        return ":Admin:success.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 4,  40 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '::base-layout.html.twig' %}

{% block title%}
    <div>
        Autentificare cu succes!
    </div>
{% endblock %}
", ":Admin:success.html.twig", "/home/sorina/Documents/work/movies_crowler/app/Resources/views/Admin/success.html.twig");
    }
}
