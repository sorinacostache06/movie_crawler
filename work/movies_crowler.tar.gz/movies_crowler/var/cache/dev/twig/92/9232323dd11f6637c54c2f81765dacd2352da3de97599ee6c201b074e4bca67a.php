<?php

/* @Framework/Form/form_errors.html.php */
class __TwigTemplate_fb593f51cdc7034c0e93b9fa61b2a7e5edadb73cedd7bc7f548a3716d22698ef extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2dc6f1afb99e25bcc724406b980ab5766a8f0c3d2a5f06f32c55543b3bb1da84 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2dc6f1afb99e25bcc724406b980ab5766a8f0c3d2a5f06f32c55543b3bb1da84->enter($__internal_2dc6f1afb99e25bcc724406b980ab5766a8f0c3d2a5f06f32c55543b3bb1da84_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_errors.html.php"));

        $__internal_22d1a63d9e1a2a2f4ce57602a657bcf12c1b3db1c97ea4ad3d8506023ddfd550 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_22d1a63d9e1a2a2f4ce57602a657bcf12c1b3db1c97ea4ad3d8506023ddfd550->enter($__internal_22d1a63d9e1a2a2f4ce57602a657bcf12c1b3db1c97ea4ad3d8506023ddfd550_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_errors.html.php"));

        // line 1
        echo "<?php if (count(\$errors) > 0): ?>
    <ul>
        <?php foreach (\$errors as \$error): ?>
            <li><?php echo \$error->getMessage() ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif ?>
";
        
        $__internal_2dc6f1afb99e25bcc724406b980ab5766a8f0c3d2a5f06f32c55543b3bb1da84->leave($__internal_2dc6f1afb99e25bcc724406b980ab5766a8f0c3d2a5f06f32c55543b3bb1da84_prof);

        
        $__internal_22d1a63d9e1a2a2f4ce57602a657bcf12c1b3db1c97ea4ad3d8506023ddfd550->leave($__internal_22d1a63d9e1a2a2f4ce57602a657bcf12c1b3db1c97ea4ad3d8506023ddfd550_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_errors.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (count(\$errors) > 0): ?>
    <ul>
        <?php foreach (\$errors as \$error): ?>
            <li><?php echo \$error->getMessage() ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif ?>
", "@Framework/Form/form_errors.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_errors.html.php");
    }
}
