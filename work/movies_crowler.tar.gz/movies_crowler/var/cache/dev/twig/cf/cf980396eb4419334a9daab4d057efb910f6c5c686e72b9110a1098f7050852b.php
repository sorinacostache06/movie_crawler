<?php

/* TwigBundle:Exception:exception.rdf.twig */
class __TwigTemplate_9c943912f794a155e2c19d4a4a615ca1f85ef8a0b7ae03a950591bcddfe8a943 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7dcadf6a47c704c1e1aa0c86bb1053b74b5e35497366f4b67abd99e3e4e6f940 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7dcadf6a47c704c1e1aa0c86bb1053b74b5e35497366f4b67abd99e3e4e6f940->enter($__internal_7dcadf6a47c704c1e1aa0c86bb1053b74b5e35497366f4b67abd99e3e4e6f940_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.rdf.twig"));

        $__internal_ee19e88af980e143b891ef9dadd185bb8440914da0a97da9aef6dae5c4ed9ae0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ee19e88af980e143b891ef9dadd185bb8440914da0a97da9aef6dae5c4ed9ae0->enter($__internal_ee19e88af980e143b891ef9dadd185bb8440914da0a97da9aef6dae5c4ed9ae0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/exception.xml.twig", "TwigBundle:Exception:exception.rdf.twig", 1)->display(array_merge($context, array("exception" => (isset($context["exception"]) || array_key_exists("exception", $context) ? $context["exception"] : (function () { throw new Twig_Error_Runtime('Variable "exception" does not exist.', 1, $this->getSourceContext()); })()))));
        
        $__internal_7dcadf6a47c704c1e1aa0c86bb1053b74b5e35497366f4b67abd99e3e4e6f940->leave($__internal_7dcadf6a47c704c1e1aa0c86bb1053b74b5e35497366f4b67abd99e3e4e6f940_prof);

        
        $__internal_ee19e88af980e143b891ef9dadd185bb8440914da0a97da9aef6dae5c4ed9ae0->leave($__internal_ee19e88af980e143b891ef9dadd185bb8440914da0a97da9aef6dae5c4ed9ae0_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include '@Twig/Exception/exception.xml.twig' with { 'exception': exception } %}
", "TwigBundle:Exception:exception.rdf.twig", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/exception.rdf.twig");
    }
}
