<?php

/* @Framework/Form/form.html.php */
class __TwigTemplate_47d235d744e113b50544dd496bf4e3a548d2ec569d664cb8b2cd7d77e8c9db74 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_044af006a82b9e1d5eecac4c402381f3d87eb750e24033d017a716467e65e787 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_044af006a82b9e1d5eecac4c402381f3d87eb750e24033d017a716467e65e787->enter($__internal_044af006a82b9e1d5eecac4c402381f3d87eb750e24033d017a716467e65e787_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form.html.php"));

        $__internal_b554afa4086d2c7c0ed5fe9603f52f0fe83f037ffe8e0524c68c131338ada1d0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b554afa4086d2c7c0ed5fe9603f52f0fe83f037ffe8e0524c68c131338ada1d0->enter($__internal_b554afa4086d2c7c0ed5fe9603f52f0fe83f037ffe8e0524c68c131338ada1d0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form.html.php"));

        // line 1
        echo "<?php echo \$view['form']->start(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
<?php echo \$view['form']->end(\$form) ?>
";
        
        $__internal_044af006a82b9e1d5eecac4c402381f3d87eb750e24033d017a716467e65e787->leave($__internal_044af006a82b9e1d5eecac4c402381f3d87eb750e24033d017a716467e65e787_prof);

        
        $__internal_b554afa4086d2c7c0ed5fe9603f52f0fe83f037ffe8e0524c68c131338ada1d0->leave($__internal_b554afa4086d2c7c0ed5fe9603f52f0fe83f037ffe8e0524c68c131338ada1d0_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->start(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
<?php echo \$view['form']->end(\$form) ?>
", "@Framework/Form/form.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form.html.php");
    }
}
