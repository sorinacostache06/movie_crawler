<?php

/* TwigBundle:Exception:error.txt.twig */
class __TwigTemplate_0435f572da3f34c8e81a405c62a7b6ef533a0c7ce874d1e147fd03d9a9539cdf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1d4c99cd19b7ff61003df63a5b9fbbe741eeca5dfd842395d169bd3344b96942 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1d4c99cd19b7ff61003df63a5b9fbbe741eeca5dfd842395d169bd3344b96942->enter($__internal_1d4c99cd19b7ff61003df63a5b9fbbe741eeca5dfd842395d169bd3344b96942_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.txt.twig"));

        $__internal_5cb61f7e4b220cdffb64a9ed02f30584ed264e4943c50b8ae14af1648d09f89a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5cb61f7e4b220cdffb64a9ed02f30584ed264e4943c50b8ae14af1648d09f89a->enter($__internal_5cb61f7e4b220cdffb64a9ed02f30584ed264e4943c50b8ae14af1648d09f89a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.txt.twig"));

        // line 1
        echo "Oops! An Error Occurred
=======================

The server returned a \"";
        // line 4
        echo (isset($context["status_code"]) || array_key_exists("status_code", $context) ? $context["status_code"] : (function () { throw new Twig_Error_Runtime('Variable "status_code" does not exist.', 4, $this->getSourceContext()); })());
        echo " ";
        echo (isset($context["status_text"]) || array_key_exists("status_text", $context) ? $context["status_text"] : (function () { throw new Twig_Error_Runtime('Variable "status_text" does not exist.', 4, $this->getSourceContext()); })());
        echo "\".

Something is broken. Please let us know what you were doing when this error occurred.
We will fix it as soon as possible. Sorry for any inconvenience caused.
";
        
        $__internal_1d4c99cd19b7ff61003df63a5b9fbbe741eeca5dfd842395d169bd3344b96942->leave($__internal_1d4c99cd19b7ff61003df63a5b9fbbe741eeca5dfd842395d169bd3344b96942_prof);

        
        $__internal_5cb61f7e4b220cdffb64a9ed02f30584ed264e4943c50b8ae14af1648d09f89a->leave($__internal_5cb61f7e4b220cdffb64a9ed02f30584ed264e4943c50b8ae14af1648d09f89a_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.txt.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  30 => 4,  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("Oops! An Error Occurred
=======================

The server returned a \"{{ status_code }} {{ status_text }}\".

Something is broken. Please let us know what you were doing when this error occurred.
We will fix it as soon as possible. Sorry for any inconvenience caused.
", "TwigBundle:Exception:error.txt.twig", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/error.txt.twig");
    }
}
