<?php

/* @Framework/Form/money_widget.html.php */
class __TwigTemplate_a077b2d63ba941a1ca3c2d12610dff087831dbf623c791d2bf632b128235eb1e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f49ec26931b0faaec7cc0cd265f6d52e9c292d9535f6223f20cc6ab40e3f5fbe = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f49ec26931b0faaec7cc0cd265f6d52e9c292d9535f6223f20cc6ab40e3f5fbe->enter($__internal_f49ec26931b0faaec7cc0cd265f6d52e9c292d9535f6223f20cc6ab40e3f5fbe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/money_widget.html.php"));

        $__internal_8df8194cbf2984e6abc259fa42c4c4632d6836ac12a8a6368d32b7382209cf11 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8df8194cbf2984e6abc259fa42c4c4632d6836ac12a8a6368d32b7382209cf11->enter($__internal_8df8194cbf2984e6abc259fa42c4c4632d6836ac12a8a6368d32b7382209cf11_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/money_widget.html.php"));

        // line 1
        echo "<?php echo str_replace('";
        echo twig_escape_filter($this->env, (isset($context["widget"]) || array_key_exists("widget", $context) ? $context["widget"] : (function () { throw new Twig_Error_Runtime('Variable "widget" does not exist.', 1, $this->getSourceContext()); })()), "html", null, true);
        echo "', \$view['form']->block(\$form, 'form_widget_simple'), \$money_pattern) ?>
";
        
        $__internal_f49ec26931b0faaec7cc0cd265f6d52e9c292d9535f6223f20cc6ab40e3f5fbe->leave($__internal_f49ec26931b0faaec7cc0cd265f6d52e9c292d9535f6223f20cc6ab40e3f5fbe_prof);

        
        $__internal_8df8194cbf2984e6abc259fa42c4c4632d6836ac12a8a6368d32b7382209cf11->leave($__internal_8df8194cbf2984e6abc259fa42c4c4632d6836ac12a8a6368d32b7382209cf11_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/money_widget.html.php";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo str_replace('{{ widget }}', \$view['form']->block(\$form, 'form_widget_simple'), \$money_pattern) ?>
", "@Framework/Form/money_widget.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/money_widget.html.php");
    }
}
