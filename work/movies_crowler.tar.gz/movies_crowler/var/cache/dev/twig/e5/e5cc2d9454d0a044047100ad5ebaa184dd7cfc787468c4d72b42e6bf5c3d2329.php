<?php

/* @Framework/Form/reset_widget.html.php */
class __TwigTemplate_76c33e3d5f0a712baeae4da2aed5463def6ccfdb31cda04aac61554f117fc72f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c72642c5802dc48b01446bf74f515a6f1d0ea4231f31942ef44d0203e911acc7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c72642c5802dc48b01446bf74f515a6f1d0ea4231f31942ef44d0203e911acc7->enter($__internal_c72642c5802dc48b01446bf74f515a6f1d0ea4231f31942ef44d0203e911acc7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        $__internal_4bae75c8bfdc5782fc4c26f8055b53e7aaf46e3293179ea135ef8060ac5c85b3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4bae75c8bfdc5782fc4c26f8055b53e7aaf46e3293179ea135ef8060ac5c85b3->enter($__internal_4bae75c8bfdc5782fc4c26f8055b53e7aaf46e3293179ea135ef8060ac5c85b3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'reset')) ?>
";
        
        $__internal_c72642c5802dc48b01446bf74f515a6f1d0ea4231f31942ef44d0203e911acc7->leave($__internal_c72642c5802dc48b01446bf74f515a6f1d0ea4231f31942ef44d0203e911acc7_prof);

        
        $__internal_4bae75c8bfdc5782fc4c26f8055b53e7aaf46e3293179ea135ef8060ac5c85b3->leave($__internal_4bae75c8bfdc5782fc4c26f8055b53e7aaf46e3293179ea135ef8060ac5c85b3_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/reset_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'reset')) ?>
", "@Framework/Form/reset_widget.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/reset_widget.html.php");
    }
}
