<?php

/* @Framework/Form/collection_widget.html.php */
class __TwigTemplate_b12bd99971de9b9455642a5867c954f1724f917303379f6f2a4866ff9efc20f4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_917c01539527d30902e8ace2261c386c43494d27e7e38c472bdf107d620744c2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_917c01539527d30902e8ace2261c386c43494d27e7e38c472bdf107d620744c2->enter($__internal_917c01539527d30902e8ace2261c386c43494d27e7e38c472bdf107d620744c2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/collection_widget.html.php"));

        $__internal_2a85b889a875505ff386011107aff0e6ceff4cbcdcb852fa7ea1621451f3d4cd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2a85b889a875505ff386011107aff0e6ceff4cbcdcb852fa7ea1621451f3d4cd->enter($__internal_2a85b889a875505ff386011107aff0e6ceff4cbcdcb852fa7ea1621451f3d4cd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/collection_widget.html.php"));

        // line 1
        echo "<?php if (isset(\$prototype)): ?>
    <?php \$attr['data-prototype'] = \$view->escape(\$view['form']->row(\$prototype)) ?>
<?php endif ?>
<?php echo \$view['form']->widget(\$form, array('attr' => \$attr)) ?>
";
        
        $__internal_917c01539527d30902e8ace2261c386c43494d27e7e38c472bdf107d620744c2->leave($__internal_917c01539527d30902e8ace2261c386c43494d27e7e38c472bdf107d620744c2_prof);

        
        $__internal_2a85b889a875505ff386011107aff0e6ceff4cbcdcb852fa7ea1621451f3d4cd->leave($__internal_2a85b889a875505ff386011107aff0e6ceff4cbcdcb852fa7ea1621451f3d4cd_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/collection_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (isset(\$prototype)): ?>
    <?php \$attr['data-prototype'] = \$view->escape(\$view['form']->row(\$prototype)) ?>
<?php endif ?>
<?php echo \$view['form']->widget(\$form, array('attr' => \$attr)) ?>
", "@Framework/Form/collection_widget.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/collection_widget.html.php");
    }
}
