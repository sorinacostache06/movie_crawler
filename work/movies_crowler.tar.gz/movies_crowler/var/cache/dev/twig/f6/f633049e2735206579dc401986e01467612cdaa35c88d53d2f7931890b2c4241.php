<?php

/* TwigBundle:Exception:exception.css.twig */
class __TwigTemplate_6e25e8c8f49bb567fdceceb803ed1a31368c5042174bcc2260d8cb04cf7d1aaa extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9755f6f54121d8a3ac6f97836e849f8406569604c499e77b7874d2c355fb10c8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9755f6f54121d8a3ac6f97836e849f8406569604c499e77b7874d2c355fb10c8->enter($__internal_9755f6f54121d8a3ac6f97836e849f8406569604c499e77b7874d2c355fb10c8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.css.twig"));

        $__internal_73fdec8554b6ca012adcc1d3b0afd5c43219f9c10f8b79c62e55c5fb9314f14a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_73fdec8554b6ca012adcc1d3b0afd5c43219f9c10f8b79c62e55c5fb9314f14a->enter($__internal_73fdec8554b6ca012adcc1d3b0afd5c43219f9c10f8b79c62e55c5fb9314f14a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        $this->loadTemplate("@Twig/Exception/exception.txt.twig", "TwigBundle:Exception:exception.css.twig", 2)->display(array_merge($context, array("exception" => (isset($context["exception"]) || array_key_exists("exception", $context) ? $context["exception"] : (function () { throw new Twig_Error_Runtime('Variable "exception" does not exist.', 2, $this->getSourceContext()); })()))));
        // line 3
        echo "*/
";
        
        $__internal_9755f6f54121d8a3ac6f97836e849f8406569604c499e77b7874d2c355fb10c8->leave($__internal_9755f6f54121d8a3ac6f97836e849f8406569604c499e77b7874d2c355fb10c8_prof);

        
        $__internal_73fdec8554b6ca012adcc1d3b0afd5c43219f9c10f8b79c62e55c5fb9314f14a->leave($__internal_73fdec8554b6ca012adcc1d3b0afd5c43219f9c10f8b79c62e55c5fb9314f14a_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  30 => 3,  28 => 2,  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{% include '@Twig/Exception/exception.txt.twig' with { 'exception': exception } %}
*/
", "TwigBundle:Exception:exception.css.twig", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/exception.css.twig");
    }
}
