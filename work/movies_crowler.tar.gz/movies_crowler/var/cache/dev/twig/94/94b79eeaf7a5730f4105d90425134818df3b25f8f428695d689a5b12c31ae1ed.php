<?php

/* @WebProfiler/Icon/forward.svg */
class __TwigTemplate_ec527ce2c3085187dd91672f0f1a0faf8f49e605771a2fa40ff700644c2e4d65 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f3351932acf1be631beb5699b706e0cd14e7b16840b8d40714258d84ef2e62dc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f3351932acf1be631beb5699b706e0cd14e7b16840b8d40714258d84ef2e62dc->enter($__internal_f3351932acf1be631beb5699b706e0cd14e7b16840b8d40714258d84ef2e62dc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Icon/forward.svg"));

        $__internal_70faace5779dbf4b79cb83415c4d025a2f8bbdb3eb85aaed5e9d7c94740ee0eb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_70faace5779dbf4b79cb83415c4d025a2f8bbdb3eb85aaed5e9d7c94740ee0eb->enter($__internal_70faace5779dbf4b79cb83415c4d025a2f8bbdb3eb85aaed5e9d7c94740ee0eb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Icon/forward.svg"));

        // line 1
        echo "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\">
    <path style=\"fill:#aaa\" d=\"M23.61,11.07L17.07,4.35A1.2,1.2,0,0,0,15,5.28V9H1.4A1.82,1.82,0,0,0,0,10.82v2.61A1.55,
        1.55,0,0,0,1.4,15H15v3.72a1.2,1.2,0,0,0,2.07.93l6.63-6.72A1.32,1.32,0,0,0,23.61,11.07Z\"/>
</svg>
";
        
        $__internal_f3351932acf1be631beb5699b706e0cd14e7b16840b8d40714258d84ef2e62dc->leave($__internal_f3351932acf1be631beb5699b706e0cd14e7b16840b8d40714258d84ef2e62dc_prof);

        
        $__internal_70faace5779dbf4b79cb83415c4d025a2f8bbdb3eb85aaed5e9d7c94740ee0eb->leave($__internal_70faace5779dbf4b79cb83415c4d025a2f8bbdb3eb85aaed5e9d7c94740ee0eb_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Icon/forward.svg";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\">
    <path style=\"fill:#aaa\" d=\"M23.61,11.07L17.07,4.35A1.2,1.2,0,0,0,15,5.28V9H1.4A1.82,1.82,0,0,0,0,10.82v2.61A1.55,
        1.55,0,0,0,1.4,15H15v3.72a1.2,1.2,0,0,0,2.07.93l6.63-6.72A1.32,1.32,0,0,0,23.61,11.07Z\"/>
</svg>
", "@WebProfiler/Icon/forward.svg", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Icon/forward.svg");
    }
}
