<?php

/* @Framework/Form/form_end.html.php */
class __TwigTemplate_aec9e9c1fd50175d5eb1c0d25625d799aa805e78471d0791d1c5c8d21663d4e8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_73be9beba90fbabf9368f5af39537de65eb2a9514a5f481794e6c58adbf84eef = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_73be9beba90fbabf9368f5af39537de65eb2a9514a5f481794e6c58adbf84eef->enter($__internal_73be9beba90fbabf9368f5af39537de65eb2a9514a5f481794e6c58adbf84eef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_end.html.php"));

        $__internal_ae48fa33a9ce0bcaec59f4de085d17beefb60d9c2864cc6f55be9f7b24e463c1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ae48fa33a9ce0bcaec59f4de085d17beefb60d9c2864cc6f55be9f7b24e463c1->enter($__internal_ae48fa33a9ce0bcaec59f4de085d17beefb60d9c2864cc6f55be9f7b24e463c1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_end.html.php"));

        // line 1
        echo "<?php if (!isset(\$render_rest) || \$render_rest): ?>
<?php echo \$view['form']->rest(\$form) ?>
<?php endif ?>
</form>
";
        
        $__internal_73be9beba90fbabf9368f5af39537de65eb2a9514a5f481794e6c58adbf84eef->leave($__internal_73be9beba90fbabf9368f5af39537de65eb2a9514a5f481794e6c58adbf84eef_prof);

        
        $__internal_ae48fa33a9ce0bcaec59f4de085d17beefb60d9c2864cc6f55be9f7b24e463c1->leave($__internal_ae48fa33a9ce0bcaec59f4de085d17beefb60d9c2864cc6f55be9f7b24e463c1_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_end.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (!isset(\$render_rest) || \$render_rest): ?>
<?php echo \$view['form']->rest(\$form) ?>
<?php endif ?>
</form>
", "@Framework/Form/form_end.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_end.html.php");
    }
}
