<?php

/* :Components:popup.html.twig */
class __TwigTemplate_69d3dc931834e1afb34ed84ad8d0207db031ae8b550b6ec7bff47e005816bab7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_537412abc57d8676827cb0947c09a05eefec9befe65a1295a30e2933851f8177 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_537412abc57d8676827cb0947c09a05eefec9befe65a1295a30e2933851f8177->enter($__internal_537412abc57d8676827cb0947c09a05eefec9befe65a1295a30e2933851f8177_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Components:popup.html.twig"));

        $__internal_8087cb3ab8640ef6a2afc438c31a51d6c3df0e187d3e6da1c88b7ef02818d067 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8087cb3ab8640ef6a2afc438c31a51d6c3df0e187d3e6da1c88b7ef02818d067->enter($__internal_8087cb3ab8640ef6a2afc438c31a51d6c3df0e187d3e6da1c88b7ef02818d067_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Components:popup.html.twig"));

        // line 1
        echo "<a href=\"#myModal_";
        echo twig_escape_filter($this->env, (isset($context["type"]) || array_key_exists("type", $context) ? $context["type"] : (function () { throw new Twig_Error_Runtime('Variable "type" does not exist.', 1, $this->getSourceContext()); })()), "html", null, true);
        echo "_";
        echo twig_escape_filter($this->env, (isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new Twig_Error_Runtime('Variable "id" does not exist.', 1, $this->getSourceContext()); })()), "html", null, true);
        echo "\"
   role=\"button\"
   class=\"btn btn-";
        // line 3
        echo twig_escape_filter($this->env, (isset($context["color"]) || array_key_exists("color", $context) ? $context["color"] : (function () { throw new Twig_Error_Runtime('Variable "color" does not exist.', 3, $this->getSourceContext()); })()), "html", null, true);
        echo " btn-flat\"
   data-toggle=\"modal\"
   title=\"Tooltip Dummy Text\">";
        // line 5
        echo (isset($context["button"]) || array_key_exists("button", $context) ? $context["button"] : (function () { throw new Twig_Error_Runtime('Variable "button" does not exist.', 5, $this->getSourceContext()); })());
        echo "
</a>
<div id=\"myModal_";
        // line 7
        echo twig_escape_filter($this->env, (isset($context["type"]) || array_key_exists("type", $context) ? $context["type"] : (function () { throw new Twig_Error_Runtime('Variable "type" does not exist.', 7, $this->getSourceContext()); })()), "html", null, true);
        echo "_";
        echo twig_escape_filter($this->env, (isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new Twig_Error_Runtime('Variable "id" does not exist.', 7, $this->getSourceContext()); })()), "html", null, true);
        echo "\" class=\"modal fade\" role=\"dialog\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\">×</button>
            </div>
            <div class=\"modal-body\">
                <div class=\"modal-body\">
                    ";
        // line 15
        $context["message"] = ("popup." . (isset($context["type"]) || array_key_exists("type", $context) ? $context["type"] : (function () { throw new Twig_Error_Runtime('Variable "type" does not exist.', 15, $this->getSourceContext()); })()));
        // line 16
        echo "                    <p>";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans((isset($context["message"]) || array_key_exists("message", $context) ? $context["message"] : (function () { throw new Twig_Error_Runtime('Variable "message" does not exist.', 16, $this->getSourceContext()); })())), "html", null, true);
        echo "</p>
                </div>
                <div class=\"modal-footer\">
                    <button type=\"submit\" class=\"btn btn-primary\" formaction=\"";
        // line 19
        echo twig_escape_filter($this->env, (isset($context["action"]) || array_key_exists("action", $context) ? $context["action"] : (function () { throw new Twig_Error_Runtime('Variable "action" does not exist.', 19, $this->getSourceContext()); })()), "html", null, true);
        echo "\">
                        ";
        // line 20
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("popup.accept"), "html", null, true);
        echo "
                    </button>
                    <button type=\"button\" class=\"btn btn-default pull-left\" data-dismiss=\"modal\">
                        ";
        // line 23
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("popup.close"), "html", null, true);
        echo "
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>
";
        // line 30
        $this->displayBlock('javascripts', $context, $blocks);
        
        $__internal_537412abc57d8676827cb0947c09a05eefec9befe65a1295a30e2933851f8177->leave($__internal_537412abc57d8676827cb0947c09a05eefec9befe65a1295a30e2933851f8177_prof);

        
        $__internal_8087cb3ab8640ef6a2afc438c31a51d6c3df0e187d3e6da1c88b7ef02818d067->leave($__internal_8087cb3ab8640ef6a2afc438c31a51d6c3df0e187d3e6da1c88b7ef02818d067_prof);

    }

    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_3be2848d0eeb44140edc525f01f0b72a120b2ec657eadeb6dc24c802dc2d2113 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3be2848d0eeb44140edc525f01f0b72a120b2ec657eadeb6dc24c802dc2d2113->enter($__internal_3be2848d0eeb44140edc525f01f0b72a120b2ec657eadeb6dc24c802dc2d2113_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_da081d95b19e02a10de066bf29a4009912e91073381307dff89261265578547d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_da081d95b19e02a10de066bf29a4009912e91073381307dff89261265578547d->enter($__internal_da081d95b19e02a10de066bf29a4009912e91073381307dff89261265578547d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 31
        echo "    <script>
        \$(document).ready(function(){
            \$(\"body\").tooltip({ selector: '[modal]' });
        });
    </script>
";
        
        $__internal_da081d95b19e02a10de066bf29a4009912e91073381307dff89261265578547d->leave($__internal_da081d95b19e02a10de066bf29a4009912e91073381307dff89261265578547d_prof);

        
        $__internal_3be2848d0eeb44140edc525f01f0b72a120b2ec657eadeb6dc24c802dc2d2113->leave($__internal_3be2848d0eeb44140edc525f01f0b72a120b2ec657eadeb6dc24c802dc2d2113_prof);

    }

    public function getTemplateName()
    {
        return ":Components:popup.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  104 => 31,  86 => 30,  76 => 23,  70 => 20,  66 => 19,  59 => 16,  57 => 15,  44 => 7,  39 => 5,  34 => 3,  26 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<a href=\"#myModal_{{ type }}_{{ id }}\"
   role=\"button\"
   class=\"btn btn-{{ color }} btn-flat\"
   data-toggle=\"modal\"
   title=\"Tooltip Dummy Text\">{{ button|raw }}
</a>
<div id=\"myModal_{{ type }}_{{ id }}\" class=\"modal fade\" role=\"dialog\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\">×</button>
            </div>
            <div class=\"modal-body\">
                <div class=\"modal-body\">
                    {% set message = 'popup.'~type %}
                    <p>{{ message|trans }}</p>
                </div>
                <div class=\"modal-footer\">
                    <button type=\"submit\" class=\"btn btn-primary\" formaction=\"{{ action }}\">
                        {{ 'popup.accept'|trans }}
                    </button>
                    <button type=\"button\" class=\"btn btn-default pull-left\" data-dismiss=\"modal\">
                        {{ 'popup.close'|trans }}
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>
{% block javascripts %}
    <script>
        \$(document).ready(function(){
            \$(\"body\").tooltip({ selector: '[modal]' });
        });
    </script>
{% endblock %}", ":Components:popup.html.twig", "/home/sorina/Documents/work/movies_crowler/app/Resources/views/Components/popup.html.twig");
    }
}
