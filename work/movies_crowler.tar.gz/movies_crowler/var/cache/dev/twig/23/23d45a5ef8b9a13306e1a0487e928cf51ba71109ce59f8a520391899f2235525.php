<?php

/* WebProfilerBundle:Profiler:open.html.twig */
class __TwigTemplate_2cc5a0e35b859d059480edaa50c5084ab8b0defa9f5109e8c35aec8ba0be75b2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/base.html.twig", "WebProfilerBundle:Profiler:open.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c84dfd0a6507780f6dcdd78397dd22eef4a672752f927b5243f96169ae064d2d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c84dfd0a6507780f6dcdd78397dd22eef4a672752f927b5243f96169ae064d2d->enter($__internal_c84dfd0a6507780f6dcdd78397dd22eef4a672752f927b5243f96169ae064d2d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:open.html.twig"));

        $__internal_a3d3183ff47b6218a7d413a1985dc9204f33bb50d2eeb228f32026b11eaef3d2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a3d3183ff47b6218a7d413a1985dc9204f33bb50d2eeb228f32026b11eaef3d2->enter($__internal_a3d3183ff47b6218a7d413a1985dc9204f33bb50d2eeb228f32026b11eaef3d2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:open.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c84dfd0a6507780f6dcdd78397dd22eef4a672752f927b5243f96169ae064d2d->leave($__internal_c84dfd0a6507780f6dcdd78397dd22eef4a672752f927b5243f96169ae064d2d_prof);

        
        $__internal_a3d3183ff47b6218a7d413a1985dc9204f33bb50d2eeb228f32026b11eaef3d2->leave($__internal_a3d3183ff47b6218a7d413a1985dc9204f33bb50d2eeb228f32026b11eaef3d2_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_d825a918af556e5bbec33a920365e60c659c659023e76c95394c1590c7944e3a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d825a918af556e5bbec33a920365e60c659c659023e76c95394c1590c7944e3a->enter($__internal_d825a918af556e5bbec33a920365e60c659c659023e76c95394c1590c7944e3a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_66595083de030b0aeddd15400ecfcdf4e3151a756eed470b356e563b2a559240 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_66595083de030b0aeddd15400ecfcdf4e3151a756eed470b356e563b2a559240->enter($__internal_66595083de030b0aeddd15400ecfcdf4e3151a756eed470b356e563b2a559240_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <style>
        ";
        // line 5
        echo twig_include($this->env, $context, "@WebProfiler/Profiler/open.css.twig");
        echo "
    </style>
";
        
        $__internal_66595083de030b0aeddd15400ecfcdf4e3151a756eed470b356e563b2a559240->leave($__internal_66595083de030b0aeddd15400ecfcdf4e3151a756eed470b356e563b2a559240_prof);

        
        $__internal_d825a918af556e5bbec33a920365e60c659c659023e76c95394c1590c7944e3a->leave($__internal_d825a918af556e5bbec33a920365e60c659c659023e76c95394c1590c7944e3a_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_9854cbbccfafc7ae76b9b0e0b43ee3e708b314e26ac38ee3a0ef6010e620b979 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9854cbbccfafc7ae76b9b0e0b43ee3e708b314e26ac38ee3a0ef6010e620b979->enter($__internal_9854cbbccfafc7ae76b9b0e0b43ee3e708b314e26ac38ee3a0ef6010e620b979_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_d227fed4faf3d4887475649c392f5587ca1cd0795b36784795340be188e85ee0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d227fed4faf3d4887475649c392f5587ca1cd0795b36784795340be188e85ee0->enter($__internal_d227fed4faf3d4887475649c392f5587ca1cd0795b36784795340be188e85ee0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "<div class=\"header\">
    <h1>";
        // line 11
        echo twig_escape_filter($this->env, (isset($context["file"]) || array_key_exists("file", $context) ? $context["file"] : (function () { throw new Twig_Error_Runtime('Variable "file" does not exist.', 11, $this->getSourceContext()); })()), "html", null, true);
        echo " <small>line ";
        echo twig_escape_filter($this->env, (isset($context["line"]) || array_key_exists("line", $context) ? $context["line"] : (function () { throw new Twig_Error_Runtime('Variable "line" does not exist.', 11, $this->getSourceContext()); })()), "html", null, true);
        echo "</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/";
        // line 12
        echo twig_escape_filter($this->env, twig_constant("Symfony\\Component\\HttpKernel\\Kernel::VERSION"), "html", null, true);
        echo "/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    ";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\CodeExtension')->fileExcerpt((isset($context["filename"]) || array_key_exists("filename", $context) ? $context["filename"] : (function () { throw new Twig_Error_Runtime('Variable "filename" does not exist.', 15, $this->getSourceContext()); })()), (isset($context["line"]) || array_key_exists("line", $context) ? $context["line"] : (function () { throw new Twig_Error_Runtime('Variable "line" does not exist.', 15, $this->getSourceContext()); })()),  -1);
        echo "
</div>
";
        
        $__internal_d227fed4faf3d4887475649c392f5587ca1cd0795b36784795340be188e85ee0->leave($__internal_d227fed4faf3d4887475649c392f5587ca1cd0795b36784795340be188e85ee0_prof);

        
        $__internal_9854cbbccfafc7ae76b9b0e0b43ee3e708b314e26ac38ee3a0ef6010e620b979->leave($__internal_9854cbbccfafc7ae76b9b0e0b43ee3e708b314e26ac38ee3a0ef6010e620b979_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:open.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  90 => 15,  84 => 12,  78 => 11,  75 => 10,  66 => 9,  53 => 5,  50 => 4,  41 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/base.html.twig' %}

{% block head %}
    <style>
        {{ include('@WebProfiler/Profiler/open.css.twig') }}
    </style>
{% endblock %}

{% block body %}
<div class=\"header\">
    <h1>{{ file }} <small>line {{ line }}</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/{{ constant('Symfony\\\\Component\\\\HttpKernel\\\\Kernel::VERSION') }}/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    {{ filename|file_excerpt(line, -1) }}
</div>
{% endblock %}
", "WebProfilerBundle:Profiler:open.html.twig", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Profiler/open.html.twig");
    }
}
