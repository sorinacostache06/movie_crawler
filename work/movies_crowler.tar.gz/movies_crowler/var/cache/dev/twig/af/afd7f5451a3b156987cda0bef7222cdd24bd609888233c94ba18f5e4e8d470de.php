<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_5a7b6c0b682e1c4f4f88fee8ac1e92419587dfc203684c49043d3a40cad9e26c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5b22aabc15d1e963520443a0ab7c08a863dd9e5994ad9c0163622c54344ecf7d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5b22aabc15d1e963520443a0ab7c08a863dd9e5994ad9c0163622c54344ecf7d->enter($__internal_5b22aabc15d1e963520443a0ab7c08a863dd9e5994ad9c0163622c54344ecf7d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        $__internal_42517e73b13fbac292bee210862f4a9ebe89525fa44f403246c019d173333239 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_42517e73b13fbac292bee210862f4a9ebe89525fa44f403246c019d173333239->enter($__internal_42517e73b13fbac292bee210862f4a9ebe89525fa44f403246c019d173333239_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_5b22aabc15d1e963520443a0ab7c08a863dd9e5994ad9c0163622c54344ecf7d->leave($__internal_5b22aabc15d1e963520443a0ab7c08a863dd9e5994ad9c0163622c54344ecf7d_prof);

        
        $__internal_42517e73b13fbac292bee210862f4a9ebe89525fa44f403246c019d173333239->leave($__internal_42517e73b13fbac292bee210862f4a9ebe89525fa44f403246c019d173333239_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "@Framework/Form/button_label.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/button_label.html.php");
    }
}
