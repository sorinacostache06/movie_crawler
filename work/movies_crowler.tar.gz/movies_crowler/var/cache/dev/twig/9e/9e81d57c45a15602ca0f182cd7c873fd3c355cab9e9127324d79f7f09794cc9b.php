<?php

/* :Admin:create_account.html.twig */
class __TwigTemplate_2cf990488f35276fe0e4dcc6094c980b31bb56b1f7476f1052f68d274b336ad1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base-layout.html.twig", ":Admin:create_account.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'page_content' => array($this, 'block_page_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base-layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_dcf5ac13b7fb2220eb84999ef307f5fa546f28875e28265d0d75c6f27f218317 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_dcf5ac13b7fb2220eb84999ef307f5fa546f28875e28265d0d75c6f27f218317->enter($__internal_dcf5ac13b7fb2220eb84999ef307f5fa546f28875e28265d0d75c6f27f218317_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Admin:create_account.html.twig"));

        $__internal_b34cc3605def20813ab4a9034edf6be5e5686f7c10609ab32a07774ade8dcf5e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b34cc3605def20813ab4a9034edf6be5e5686f7c10609ab32a07774ade8dcf5e->enter($__internal_b34cc3605def20813ab4a9034edf6be5e5686f7c10609ab32a07774ade8dcf5e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Admin:create_account.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_dcf5ac13b7fb2220eb84999ef307f5fa546f28875e28265d0d75c6f27f218317->leave($__internal_dcf5ac13b7fb2220eb84999ef307f5fa546f28875e28265d0d75c6f27f218317_prof);

        
        $__internal_b34cc3605def20813ab4a9034edf6be5e5686f7c10609ab32a07774ade8dcf5e->leave($__internal_b34cc3605def20813ab4a9034edf6be5e5686f7c10609ab32a07774ade8dcf5e_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_181e19a76adfa52186a7484bf134df64d8154ceb6108e3a333d2cde919a165be = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_181e19a76adfa52186a7484bf134df64d8154ceb6108e3a333d2cde919a165be->enter($__internal_181e19a76adfa52186a7484bf134df64d8154ceb6108e3a333d2cde919a165be_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_5277fc5ac154c6136448f229b74c23392f6c7e1281fcb57aaad16f47b251a308 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5277fc5ac154c6136448f229b74c23392f6c7e1281fcb57aaad16f47b251a308->enter($__internal_5277fc5ac154c6136448f229b74c23392f6c7e1281fcb57aaad16f47b251a308_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 4
        echo "    ";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("create_account.title"), "html", null, true);
        echo "
";
        
        $__internal_5277fc5ac154c6136448f229b74c23392f6c7e1281fcb57aaad16f47b251a308->leave($__internal_5277fc5ac154c6136448f229b74c23392f6c7e1281fcb57aaad16f47b251a308_prof);

        
        $__internal_181e19a76adfa52186a7484bf134df64d8154ceb6108e3a333d2cde919a165be->leave($__internal_181e19a76adfa52186a7484bf134df64d8154ceb6108e3a333d2cde919a165be_prof);

    }

    // line 6
    public function block_page_content($context, array $blocks = array())
    {
        $__internal_dd2d3e2b06828f7318aa2f4151ce8d0f7bb208901768c41f8c76d3a7138130f3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_dd2d3e2b06828f7318aa2f4151ce8d0f7bb208901768c41f8c76d3a7138130f3->enter($__internal_dd2d3e2b06828f7318aa2f4151ce8d0f7bb208901768c41f8c76d3a7138130f3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_content"));

        $__internal_7630d0c6515c8c5d9773f6c9e69426e19a5c7af1bb348fe6679e46dd1a00f872 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7630d0c6515c8c5d9773f6c9e69426e19a5c7af1bb348fe6679e46dd1a00f872->enter($__internal_7630d0c6515c8c5d9773f6c9e69426e19a5c7af1bb348fe6679e46dd1a00f872_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_content"));

        // line 7
        echo "    <body class=\"hold-transition register-page\">
    <div class=\"register-box\">
        <div class=\"register-box-body\">
            <p class=\"login-box-msg\"><b>";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("create_account.title"), "html", null, true);
        echo "</b></p>
            ";
        // line 11
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 11, $this->getSourceContext()); })()), 'form_start');
        echo "
            ";
        // line 12
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 12, $this->getSourceContext()); })()), "email", array()), 'row', array("attr" => array("placeholder" => "account.form.email.placeholder")));
        echo "
            ";
        // line 13
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 13, $this->getSourceContext()); })()), "username", array()), 'row', array("attr" => array("placeholder" => "login.form.firstandlast_name.placeholder")));
        echo "
            ";
        // line 14
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 14, $this->getSourceContext()); })()), "password", array()), 'row', array("attr" => array("placeholder" => "login.form.password.placeholder")));
        echo "
            ";
        // line 15
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 15, $this->getSourceContext()); })()), "password_again", array()), 'row', array("attr" => array("placeholder" => "login.form.password.placeholder")));
        echo "
            <div class=\"row\">
                <div class=\"col-xs-6\">
                    ";
        // line 18
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 18, $this->getSourceContext()); })()), "create", array()), 'row', array("label" => "create.form.name_button_submit", "attr" => array("class" => "btn btn-primary btn-block btn-flat")));
        echo "
                </div>
            </div>
            ";
        // line 21
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 21, $this->getSourceContext()); })()), 'form_end');
        echo "
        </div>
    </div>
    </body>
";
        
        $__internal_7630d0c6515c8c5d9773f6c9e69426e19a5c7af1bb348fe6679e46dd1a00f872->leave($__internal_7630d0c6515c8c5d9773f6c9e69426e19a5c7af1bb348fe6679e46dd1a00f872_prof);

        
        $__internal_dd2d3e2b06828f7318aa2f4151ce8d0f7bb208901768c41f8c76d3a7138130f3->leave($__internal_dd2d3e2b06828f7318aa2f4151ce8d0f7bb208901768c41f8c76d3a7138130f3_prof);

    }

    public function getTemplateName()
    {
        return ":Admin:create_account.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  109 => 21,  103 => 18,  97 => 15,  93 => 14,  89 => 13,  85 => 12,  81 => 11,  77 => 10,  72 => 7,  63 => 6,  50 => 4,  41 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '::base-layout.html.twig' %}

{% block title %}
    {{ 'create_account.title'|trans }}
{% endblock %}
{% block page_content %}
    <body class=\"hold-transition register-page\">
    <div class=\"register-box\">
        <div class=\"register-box-body\">
            <p class=\"login-box-msg\"><b>{{ 'create_account.title'|trans }}</b></p>
            {{ form_start(form) }}
            {{ form_row(form.email, {'attr':{'placeholder':'account.form.email.placeholder'} }) }}
            {{ form_row(form.username, {'attr':{'placeholder':'login.form.firstandlast_name.placeholder'}}) }}
            {{ form_row(form.password, {'attr':{'placeholder':'login.form.password.placeholder'}}) }}
            {{ form_row(form.password_again, {'attr':{'placeholder':'login.form.password.placeholder'}}) }}
            <div class=\"row\">
                <div class=\"col-xs-6\">
                    {{ form_row(form.create, {'label':'create.form.name_button_submit', 'attr': {'class': 'btn btn-primary btn-block btn-flat'}}) }}
                </div>
            </div>
            {{ form_end(form) }}
        </div>
    </div>
    </body>
{% endblock %}
", ":Admin:create_account.html.twig", "/home/sorina/Documents/work/movies_crowler/app/Resources/views/Admin/create_account.html.twig");
    }
}
