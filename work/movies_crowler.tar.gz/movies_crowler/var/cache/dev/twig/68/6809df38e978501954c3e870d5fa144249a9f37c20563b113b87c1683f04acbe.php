<?php

/* @Framework/Form/textarea_widget.html.php */
class __TwigTemplate_8c486e5d84e2b291421db1c113dadd54d62c27f55f7a2141b41db2f5e576cd9f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_88e30f6b4377c667085e0778f9b176fe4ca116866ea5a04594fae93554bb95cb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_88e30f6b4377c667085e0778f9b176fe4ca116866ea5a04594fae93554bb95cb->enter($__internal_88e30f6b4377c667085e0778f9b176fe4ca116866ea5a04594fae93554bb95cb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        $__internal_c1af9f821c19b6e238bc7d4b4143b493e5e08cb94d74316a135360c024224021 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c1af9f821c19b6e238bc7d4b4143b493e5e08cb94d74316a135360c024224021->enter($__internal_c1af9f821c19b6e238bc7d4b4143b493e5e08cb94d74316a135360c024224021_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        // line 1
        echo "<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
";
        
        $__internal_88e30f6b4377c667085e0778f9b176fe4ca116866ea5a04594fae93554bb95cb->leave($__internal_88e30f6b4377c667085e0778f9b176fe4ca116866ea5a04594fae93554bb95cb_prof);

        
        $__internal_c1af9f821c19b6e238bc7d4b4143b493e5e08cb94d74316a135360c024224021->leave($__internal_c1af9f821c19b6e238bc7d4b4143b493e5e08cb94d74316a135360c024224021_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/textarea_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
", "@Framework/Form/textarea_widget.html.php", "/home/sorina/Documents/work/movies_crowler/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/textarea_widget.html.php");
    }
}
